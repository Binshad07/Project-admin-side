import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { LayoutComponent } from "./layouts/layout.component";
import { Error404Component } from "./pages/error/error404/error404.component";
import { AuthGuardService } from "./shared/services/auth-guard.service";
import { ModalModule } from 'ngx-bootstrap/modal';
//import { ToastrModule } from 'ngx-toastr';
const routes: Routes = [
  {
    path: "account",
    loadChildren: () =>
      import("./account/account.module").then((m) => m.AccountModule),
  },
  {
    path: "",
    component: LayoutComponent,
    loadChildren: () =>
      import("./pages/pages.module").then((m) => m.PagesModule),
    canActivate: [AuthGuardService],
  },
  {
    path: "**",
    component: Error404Component,
  },
];

@NgModule({
  imports: [
   // ToastrModule.forRoot(),
    ModalModule.forRoot(),
    RouterModule.forRoot(routes, { scrollPositionRestoration: "top" })],
  exports: [RouterModule],
})
export class AppRoutingModule {}

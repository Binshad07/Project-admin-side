import { AfterViewInit, Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { GeneralDataService } from 'src/app/shared/services/general-data.service';
import { AuthService } from 'src/app/shared/services/auth/auth.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit, AfterViewInit {
  loginForm: FormGroup;
  otpForm: FormGroup
  passwordError = true;
  submitted = false;
  error = "";
  arrModules = []
  mobile: any = false
  email: any = true

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private generalData: GeneralDataService,
    private service : AuthService
  ) {
    
   }

  ngOnInit() {
    if (this.mobile) {
      console.log("mob")
      this.loginForm = this.formBuilder.group({
        mobile: ['', [Validators.required, Validators.pattern('^[0-9]{8,10}$')]],
        strCountryCode: ['', [Validators.required]],
      });
    }
    else if (this.email) {
      console.log("email")
      this.loginForm = this.formBuilder.group({
        email: ["", [Validators.required, Validators.email]],
      });
    }

  }

  ngAfterViewInit() {
    document.body.classList.add("backgroundNew");
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.loginForm.controls;
  }


  /**
  * Mobile Login
   * 
   */
  mobileLogin() {
    this.mobile = true
    this.email = false
    this.loginForm = this.formBuilder.group({
      mobile: ['', [Validators.required, Validators.pattern('^[0-9]{8,10}$')]],
      strCountryCode: ['91', [Validators.required]],
    });
  }

  /**
  * Email Login
   * 
   */
  emailLogin() {
    this.mobile = false
    this.email = true
    this.loginForm = this.formBuilder.group({
      email: ["", [Validators.required, Validators.email]],
    });
  }



  /**
   * On submit form
   */
  onSubmit() {
    console.log("inside")
    this.submitted = true;
    // stop here if form is invalid
    // if (this.loginForm.valid) {
    //   const obj = {
    //     strEmail: this.loginForm.value.email,
    //     strPassword: this.loginForm.value.password,
    //   };

    //   this.generalData.loginService(obj).subscribe((res) => {
    //     console.log('Login Response::::', res);
    //     if (res.success === true) {
    //       console.log('Login Response::::', res);

    //       localStorage.setItem("userId", res.data[0].pkUserId);
    //       localStorage.setItem("token", res.data[1].token);
    //       localStorage.setItem(
    //         "userPermission",
    //         JSON.stringify(res.data[0].arrayPermissionModules.arryModuleDetails)
    //       );
    //       localStorage.setItem("userPermissionsGrouped", JSON.stringify(res.data[2]))
    //       if(res.data[0].fkShopId){
    //         localStorage.setItem("fkShopId", res.data[0].fkShopId); 
    //       }
    //       if(res.data[0].strUserType){
    //         localStorage.setItem("strUserType", res.data[0].strUserType); 
    //       }
    //       if(res.data[0].strViewType){
    //         localStorage.setItem("strViewType", res.data[0].strViewType); 
    //       }
    //       //res.data[0].arrayPermissionModules.arryModuleDetails
    //       this.router.navigate(["/dashboard"]);
    //     } else {
    //       // error
    //       this.passwordError = false;
    //       setTimeout(() => {
    //         this.passwordError = true;
    //       }, 5000);
    //     }
    //   });
    // }
    if (this.loginForm.valid) {
      console.log("inside1")
      if (this.mobile == true) {
        console.log("inside2")
        const obj = {
          "strPhoneNumber": this.loginForm.value.mobile.toString(),
          "strCountryCode": this.loginForm.value.strCountryCode
        }
        this.service.getOtpMobile(obj).subscribe((res)=>{
          console.log(res)
          if(res.success){
            this.router.navigate([`/account/auth/otp-verification`], {
              queryParams: { mobile: this.loginForm.value.mobile,code: this.loginForm.value.strCountryCode }
            })
          }
          else{
            Swal.fire({
              title: "Error",
              text: res.message,
              icon: "error",
              confirmButtonText: "Ok",
            });
          }
        })
      }
      else if (this.email == true) {
        console.log("inside3")
        const obj = {
          "strEmail": this.loginForm.value.email
        }
        this.service.getOtpEmail(obj).subscribe((res)=>{
          console.log(res)
          if(res.success){
            localStorage.setItem("strVerificationId",res.data[0].strVerificationId)
            this.router.navigate([`/account/auth/otp-verification`], {
              queryParams: { email: this.loginForm.value.email,id:res.data[0].strVerificationId }
            })
          }
          else{
            Swal.fire({
              title: "Error",
              text: res.message,
              icon: "error",
              confirmButtonText: "Ok",
            });
          }
        })
      }
    }
  }
  maxLength: number = 0
  onInputChange1(event: any) {
    this.maxLength = 10;

    const value = event.target.value;
    if (value.length > this.maxLength) {
      this.loginForm.patchValue({
        mobile: value.slice(0, this.maxLength)
      });
    }
  }
}
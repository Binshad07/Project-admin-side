import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/shared/services/auth/auth.service';
import { GeneralDataService } from 'src/app/shared/services/general-data.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-otp-verification',
  templateUrl: './otp-verification.component.html',
  styleUrls: ['./otp-verification.component.scss']
})
export class OtpVerificationComponent implements OnInit {
  otpForm: FormGroup
  mobileOTP: any = false
  emailOTP: any = false
  strPhoneNumber: any
  strCountryCode: any
  strEmail: any
  strVerificationId: any
  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private generalData: GeneralDataService,
    private service: AuthService,
    private activatedRoute: ActivatedRoute
  ) {
    this.activatedRoute.queryParams.subscribe(
      (params) => {
        this.strPhoneNumber = params.mobile,
          this.strCountryCode = params.code
           
      });

    this.activatedRoute.queryParams.subscribe((parmas) => {
      this.strEmail = parmas.email,
        this.strVerificationId = parmas.id   
    })
  }

  ngOnInit() {

    this.otpForm = this.formBuilder.group({
      strOtp: ['', Validators.pattern('^[0-9]{5,5}$')]
    })
    
    if(this.strPhoneNumber != ""){
      console.log("email")
      
      this.emailOTP = false
      this.mobileOTP = true
    }
    if(this.strEmail){
      console.log("emailmobile")
      
      this.emailOTP = true
      this.mobileOTP = false
    }
  }
  move(event: any, prev: any, current: any, next: any) {
    let len = current.value.length;
    let maxlen = current.getAttribute('maxlength')
    if (len == maxlen && next != '') {
      next.focus();
    }
    if (event.key == 'Backspace' && prev != '') {
      prev.focus();
    }
  }
  strOTP:any
  onClickVerifyOtp(txt1: any, txt2: any, txt3: any, txt4: any, txt5: any) {
    console.log(txt1.value + txt2.value + txt3.value + txt4.value + txt5.value)
    this.otpForm.value.strOtp = txt1.value + txt2.value + txt3.value + txt4.value + txt5.value;
    console.log("0",this.otpForm.valid)
    //console.log(this.frmOtp.value.otp)
    if (this.otpForm.valid) {
      console.log("1", this.otpForm.value.strOtp,this.mobileOTP,this.emailOTP)
      if (this.mobileOTP) {
        console.log("2")
        let obj = {
          "strPhoneNumber": this.strPhoneNumber,
          "strCountryCode": this.strCountryCode,
          "strOTP": this.otpForm.value.strOtp,
          "strDeviceId": "id",
          "strDeviceType": "ANDROID",
          "strRegistrationToken": ""
        }
        this.service.verifyMobile(obj).subscribe((res) => {
          console.log(res,obj)
          if(res.success){
            localStorage.setItem("userId",res.data.pkUserId)
            this.router.navigate(['/store/create-store'])
          }
          else{
            Swal.fire({
              title: "Error",
              text: res.message,
              icon: "error",
              confirmButtonText: "Ok",
            });
          }
        })
      }
      else if (this.emailOTP) {
        console.log("3")
        let obj = {
          "strVerificationId": this.strVerificationId,
          "strEmail": this.strEmail,
          "strOTP": this.otpForm.value.strOtp,
          "strDeviceId": "id",
          "strDeviceType": "W",
          "strRegistrationToken": ""
        }
        this.service.verifyEmail(obj).subscribe((res) => {
          if(res.success){
            localStorage.setItem("token",res.token)
            localStorage.setItem("userId",res.data.pkUserId)
            this.router.navigate(["/store/create-store"]).then((navigationSuccess) => {
              if (!navigationSuccess) {
                console.error("Navigation to /store/create-store failed.");
              }
            });
          }
          else{
            Swal.fire({
              title: "Error",
              text: res.message,
              icon: "error",
              confirmButtonText: "Ok",
            });
          }
        })
      }

    }
  }

  mobile: any = false
  email: any = true

  /**
  * Mobile Login
   * 
   */
  mobileLogin() {
    this.router.navigate([`/account/auth/signup`])
    localStorage.setItem("mobile", "true")
  }

  /**
  * Email Login
   * 
   */
  emailLogin() {
    this.router.navigate([`/account/auth/signup`])
    localStorage.setItem("email", "true")
  }


}

import { Component, OnInit, AfterViewInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { GeneralDataService } from "../../../shared/services/general-data.service";
import { Router } from "@angular/router";
import Swal from "sweetalert2";

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.scss"],
})
export class LoginComponent implements OnInit, AfterViewInit {
  loginForm: FormGroup;
  passwordError = true;
  submitted = false;
  error = "";
  arrModules = []

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private generalData: GeneralDataService
  ) {}

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email: ["", [Validators.required, Validators.email]],
      password: ["", Validators.required],
    });
  }

  ngAfterViewInit() {
    document.body.classList.add("backgroundNew");
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.loginForm.controls;
  }

  /**
   * On submit form
   */
  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.loginForm.valid) {
      const obj = {
        strEmail: this.loginForm.value.email,
        strPassword: this.loginForm.value.password,
      };

      this.generalData.loginService(obj).subscribe((res) => {
        console.log('LOgin Response::::', res);
        if (res.success === true) {
          console.log('LOgin Response::::', res);

          localStorage.setItem("userId", res.data[0].pkUserId);
          localStorage.setItem("token", res.data[1].token);
          localStorage.setItem(
            "userPermission",
            JSON.stringify(res.data[0].arrayPermissionModules.arryModuleDetails)
          );
          localStorage.setItem("userPermissionsGrouped", JSON.stringify(res.data[2]))
          if(res.data[0].fkShopId){
            localStorage.setItem("fkShopId", res.data[0].fkShopId); 
          }
          if(res.data[0].strUserType){
            localStorage.setItem("strUserType", res.data[0].strUserType); 
          }
          if(res.data[0].strViewType){
            localStorage.setItem("strViewType", res.data[0].strViewType); 
          }
          //res.data[0].arrayPermissionModules.arryModuleDetails
          this.router.navigate(["/dashboard"]);
        } else {
          // error
          this.passwordError = false;
          setTimeout(() => {
            this.passwordError = true;
          }, 5000);
        }
      });
    }
  }
}

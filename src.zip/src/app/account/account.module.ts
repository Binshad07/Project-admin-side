import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AccountRoutingModule } from './account-routing.module';
import { AuthModule } from './auth/auth.module';
import { CreateStoreModule } from './create-store/create-store.module';
import { AddStoreModule } from './add-store/add-store.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    AccountRoutingModule,
    AuthModule,
    CreateStoreModule,
    AddStoreModule
  ]
})
export class AccountModule { }

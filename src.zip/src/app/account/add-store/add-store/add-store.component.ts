import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-store',
  templateUrl: './add-store.component.html',
  styleUrls: ['./add-store.component.scss']
})
export class AddStoreComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

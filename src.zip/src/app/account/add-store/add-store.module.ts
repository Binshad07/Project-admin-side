import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AddStoreRoutingModule } from './add-store-routing.module';
import { AddStoreComponent } from './add-store/add-store.component';

@NgModule({
  declarations: [AddStoreComponent],
  imports: [
    CommonModule,
    AddStoreRoutingModule
  ]
})
export class AddStoreModule { }

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-choose-category',
  templateUrl: './choose-category.component.html',
  styleUrls: ['./choose-category.component.scss']
})
export class ChooseCategoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

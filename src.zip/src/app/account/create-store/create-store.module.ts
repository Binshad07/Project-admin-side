import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CreateStoreRoutingModule } from './create-store-routing.module';
import { ChooseCategoryComponent } from './choose-category/choose-category.component';

@NgModule({
  declarations: [ChooseCategoryComponent],
  imports: [
    CommonModule,
    CreateStoreRoutingModule
  ]
})
export class CreateStoreModule { }

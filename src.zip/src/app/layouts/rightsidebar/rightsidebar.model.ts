// Inbox data
export interface Inbox {
    image: string;
    name: string;
    message: string;
}

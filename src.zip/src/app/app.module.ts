import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { NgModule } from "@angular/core";
import { HttpClientModule } from "@angular/common/http";

import { LayoutsModule } from "./layouts/layouts.module";
import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { ErrorModule } from "./pages/error/error.module";
import { AuthGuardService } from "./shared/services/auth-guard.service";
import { AssetkitModule } from "./pages/assetkit/assetkit.module";
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
// import { SubcategoryComponent } from './assetkit/subcategory/subcategory.component';
//import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AutocompleteLibModule } from 'angular-ng-autocomplete'; // Correct import


@NgModule({
  declarations: [AppComponent,],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    LayoutsModule,
    AppRoutingModule,
    ErrorModule,AssetkitModule,
    AutocompleteLibModule,
  ],
  providers: [AuthGuardService],
  bootstrap: [AppComponent],
})
export class AppModule {}
//platformBrowserDynamic().bootstrapModule(AppModule);

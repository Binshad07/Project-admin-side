export interface CategoryResponse {

  pkCategoryId?: any;
  strName?: any;
}

export interface ShopResponse {
  pkShopId?: any;
  strShopName?: any;
}

export interface ViewtypeResponse {
  pkDeptId?: any;
  strViewType?: any;
}

export interface DummyCategoryResponse {

  pkCategoryId?: any;
  strName?: any;
  fkDefaultDepartmentId?: any;
}
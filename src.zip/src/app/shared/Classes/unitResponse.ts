export interface unitResponse {
  strUnitName?: any
}

export interface dummyunitResponse {
  strUnitName?: any
  fkDepartmentId?: any
}
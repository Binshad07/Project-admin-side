export interface UserOrderDetails {
  strUserName?: any;
  strEmail?: any;
  strPhone?: any;
  strJoinDate?: any;
  arrayCart?: [{
    strProductName?: any;
    intQuantity?: any;
    intMRP?: any;
    intSellingPrice?: any;
    intDiscount?: any;
    arrayThumbnail?: [{
      imageUrl?: any;
      imageName?: any;
    }];
    strSize?: any;
  }];
  arrayAddress?: [{
    strAddress?: any;
    strFullName?: any;
    strAddressType?: any;
    strMobileNumber?: any;
    strEmirate?: any;
    strRoad?: any;
  }];
  arrayOrderDetails?: [{
    strOrderID?: any;
    strDeliveryType?: any;
    intSubTotal?: any;
    intGrandTotal?: any;
    intDeliveryCharge?: any;
    strOrderStatus?: any;
    arrayProductDetails?: [{
      strItemId?: any;
      intQuantity?: any;
      intTotalAmount?: any;
      intDiscountPercentage?: any;
      intTotalOneItem?: any;
      blnCheck?: any;
      blnFrozenFood?: any;
      fkCategoryId?: any;
      fkDepartmentId?: any;
      fkSubCategoryId?: any;
      strArticleNo?: any;
      strBarcode?: any;
      strImagUrl?: [{
        imageUrl?: any;
      }
      ];
      strProductName?: any;
    }]
  }];
  arrayProduct?: [{
    strProductName?: any;
    intMRP?: any;
    intSellingPrice?: any;
  }]
}

export interface UserOrderTracking {

  strOrderID?: any;
  intSubTotal?: any;
  intGrandTotal?: any;
  intDeliveryCharge?: any;
  intTotalItemQuantity?: any;
  intTotalDiscountAmount?: any;
  intTotalRewardPoints?: any;
  strDeliveryDetails?: any;
  strDeliveryType?: any;
  strPaymentMode?: any;
  strPaymentReferenceId?: any;
  strPriorityStatus?: any;
  strOrderStatus?: any;
  strStoreStatus?: any;
  intDiscount?: any;
  strDeliveryAdminStatus?: any;
  strDeliveryStaffStatus?: any;
  strDeliveryStaffId?: any;
  strInvoiceNumber?: any;
  strTripNumber?: any;
  arrayPromocodeDetals:[{
    strDisplayName: any;
  }];
  arrayProductDetails?: [{
    strItemId?: any;
    intQuantity?: any;
    intTotalAmount?: any;
    intDiscountPercentage?: any;
    intTotalOneItem?: any;
    blnCheck?: any;
    blnFrozenFood?: any;
    fkCategoryId?: any;
    fkDepartmentId?: any;
    fkSubCategoryId?: any;
    strArticleNo?: any;
    strBarcode?: any;
    strImagUrl?: [{
      imageUrl?: any
    }];
    strProductName?: any;
  }]
  strUpdateUserId?: any;
  strStatus?: any;
  dateOrderPlace?: any;
  dateUpdate?: any;
  intTimeSlotDeliveryCharge?: any;
  strBillingStatus?: any;
  strPackingStatus?: any;
  strPickingStatus?: any;
  strCreateDateAndTime?: any;
  strUpdateDateAndTime?: any;
  strCreateUser?: [];
  arrayUpdateUser?: [];
  arrayAddress?: [{
    strAddress?: any;
    strFullName?: any;
    strAddressType?: any;
    strMobileNumber?: any;
    strEmirate?: any;
    strRoad?: any;
  }];
  arrayShope?: [{
    strShopName?: any;
    strLocation?: any;
    strAddress?: any;
    strEmirate?: any;
  }]
}

export interface TimeSlotMod {

    strDisplayName?: any;
    strTimeSlotDate?: any;
    pkTimeSlotId?: any;
    strFromTime?: any;
    strToTime?: any;
    intCapacity?: any;
    strDeliveryType?: any;
    intDeliveryCharge?: any;
    intOrdersCount?: any;
    blnView?: any;



}

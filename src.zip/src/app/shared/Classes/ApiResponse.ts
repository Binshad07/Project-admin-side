export class ApiResponse {
  error(arg0: string, error: any) {
    throw new Error("Method not implemented.");
  }
  data: any;
  success: boolean;
  message: string;
  token: string;
  type: string;
  count: any;
  pkIntItemDocNo: string;
}

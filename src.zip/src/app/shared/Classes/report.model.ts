export interface modHubSummary {

  _id?: {
    strTimeSlotId               ?: any;
  }
  intPickingStatusCount         ?: any;
  intBillingStatusCount         ?: any;
  intPackingStatusCount         ?: any;
  intPendingStatusCount         ?: any;
  intReadyStatusCount           ?: any;
  intDeliveredStatusCount       ?: any;
  intCancelledStatusCount       ?: any;
  intReturnedStatusCount        ?: any;
  intTotalOrderCount            ?: any;
  intTotalAmount                ?: any;
  intAverageAmount              ?: any;
  intAverageItems               ?: any;
  intCancelOrderAmount          ?: any;
  intReturnedOrderAmount        ?: any;
  intSlotCapacity               ?: any;
  strShopName                   ?: any;
  strDisplayName                ?: any;
  strDeliveryType               ?: any;
  dateSlot                      ?: any;
}

export interface modOrderSummary {
  _id?: any;
  strOrderID?: any;
  strShopName?: any;
  strSlotName?: any;
  dateCreateDateAndTime?: any;
  intGrandTotal?: any;
  intTotalItemQuantity?: any;
  strOrderStatus?: any;
  strDeliveryType?: any;
  strPaymentMode?: any;
  datePacked?: any;
  dateDelivered?: any;
  dateReturned?: any;
  dateDeliverOrReturnTimeStamp?: any;

}

export interface modCancel {

  strOrderID?: any;
  strShopName?: any;
  strSlotName?: any;
  dateCreateDateAndTime?: any;
  intGrandTotal?: any;
  intTotalItemQuantity?: any;
  strOrderStatus?: any;
  strDeliveryType?: any;
  strPaymentMode?: any;
  dateCancel?: any;
  datePacked?: any;
  dateCancelTimeStamp?: any;
  dateUpdateTimeStamp?: any;

}

export interface modOrderPayment {

  strOrderID?: any;
  intCashAmount?: any;
  intCardAmount?: any;
  intSubTotal?: any;
  intTotalCollectedAmount?: any;
  intDeviationAmount?: any;
  intDeliveryCharge?: any;
  strShopName?: any;
  strPaymentReferenceId?: any;
  intGrandTotal?: any;
  intTotalItemQuantity?: any;
  strOrderStatus?: any;
  strDeliveryType?: any;
  strPaymentMode?: any;
  dateDeliverOrReturnTimeStamp?: any;

}

export interface modPaymentTotal {

  intCashAmount?: any;
  intCardAmount?: any;
  intSubTotal?: any;
  intTotalCollectedAmount?: any;
  intDeviationAmount?: any;
  intDeliveryCharge?: any;
  intGrandTotal?: any;
}

export interface modCartDetails {
  intQuantity?: any;
  datCreateDateAndTime?: any;
  dateUpdateDateAndTime?: any;
  arrayUserDetails: [{
    strUserName?: any;
    strEmail?: any;
    strPhone?: any;
  }];
  intMRP?: any;
  intDiscount?: any;
  strProductName?: any;
  intSellingPrice?: any;
}

export interface modItemSales {

  dateCreateDateAndTime?: any;
  dateOrderAccept?: any;
  datePickAccepted?: any;
  dateBillAcccepted?: any;
  dateBilled?: any;
  dateMoveToPack?: any;
  datePackAccepted?: any;
  datePacked?: any;
  dateDeliveryAccepted?: any;
  dateDeliveryCollect?: any;
  dateDelivered?: any;
  dateReturned?: any;
  dateCancel?: any;
  strOrderID?: any;
  strStoreId?: any;
  intGrandTotal?: any;
  strStoreStatus?: any;
  intSubTotal?: any;
  strPaymentMode?: any;
  strNestoStoreId?: any;
  strPhoneNo?: any;
  strShopName?: any;
  intTotalItemQuantity?: any;
  strProductName?: any;
  intQuantity?: any;
  intTotalAmount?: any;
  intTotalOneItem?: any;
  strBarcode?: any;
  strItemId?: any;
  strSlotName?: any;
  strDeliveryType?: any;
}

export interface modHubOrderTotal {

  intTotalOrdersAmount    ?: any;
  intAvgOrdermount        ?: any;
  intReturnAmount         ?: any;
  intCancelOrderAmount    ?: any;
}

export interface modHubTotal {
  intPickingStatusCount     ?: any;
  intBillingStatusCount     ?: any;
  intPackingStatusCount     ?: any;
  intPendingStatusCount     ?: any;
  intReadyStatusCount       ?: any;
  intDeliveredStatusCount   ?: any;
  intCancelledStatusCount   ?: any;
  intReturnedStatusCount    ?: any;
  intTotalOrderCount        ?: any;
}

export interface modOrderLifecycle {
  dateCreateDateAndTime?: any;
  strOrderID?: any;
  strUserRegNo?: any;
  strVan?: any;
  strTripNumber?: any;
  strShopName?: any;
  strSlotName?: any;
  intGrandTotal?: any;
  intTotalItemQuantity?: any;
  strOrderStatus?: any;
  strDeliveryType?: any;
  strPaymentMode?: any;
  dateBillAcccepted?: any;
  dateBilled?: any;
  dateCancel?: any;
  dateDelivered?: any;
  dateDeliveryAccepted?: any;
  dateDeliveryCollect?: any;
  dateMoveToPack?: any;
  dateOrderAccept?: any;
  datePackAccepted?: any;
  datePacked?: any;
  datePickAccepted?: any;
  dateReturned?: any;

}
export interface modNewReport {

  strCreateUserId?: any;
  strOrderID?: any;
  strShopName?: any;
  strCustomerName?: any;
  strEmail?: any;
  strPhoneNo?: any;
  dateCreateDateAndTime?: any;
  strOrderStatus?: any;
  dateDeliverOrReturnTimeStamp?: any;

}

export interface modDeliveryDetails {
  strOrderID?: any;
  intGrandTotal?: any;
  strOrderStatus?: any;
  strDeliveryStaffId?: any;
  strInvoiceNumber?: any;
  dateUpdateDateAndTime?: any;
  strUserName?: any;
  strEmail?: any;
  strPhone?: any;
}

export interface modTransaction {
  pkTransactionId?: any;
  dateTransDate?: any;
  fltAmount?: any;
  strDeviceType?: any;
  strCreateUserId?: any;
  strOrderNumber?: any;
  strUpdateUserId?: any;
  datCreateDateAndTime?: any;
  dateUpdateDateAndTime?: any;
  strStatus?: any;
  strTransactionStatus?: any;
}

/*
/api/orders/GetNewOrderReport
/api/orders/GetOrderLifeCycle

*/

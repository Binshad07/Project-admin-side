export interface SubCatResponse {

  pkCategoryId?: any
  strName?: any

}

export interface DummySubCatResponse {

  pkCategoryId?: any
  strName?: any
  fkDefaultDepartmentId?: any

}

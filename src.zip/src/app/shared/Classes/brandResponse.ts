export interface BrandResponse {

  pkBrandId?: any;
  strName?: any;
}

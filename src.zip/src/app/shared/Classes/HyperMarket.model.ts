export interface modCategory {
  pkCategoryId?: any;
  strName?: any;
  strDescription?: any;
  strCategoryStatus?: any;
  strImageUrl?: any;
  strStatus?: any;
  strType?: any;
  datCreateDateAndTime?: any;
  dateUpdateDateAndTime?: any;
  strCreateUserId?: any;
  strUpdateUserId?: any;
  intSortNo?: any;
  fkDepartmentId?: any;
  strDepartmentName?: any;
}

export interface modSubCategory {
  pkCategoryId?: any;
  strName?: any;
  strCategoryStatus?: any;
  strImageUrl?: any;
  strParentCategoryId?: any;
  strType?: any;
  datCreateDateAndTime?: any;
  dateUpdateDateAndTime?: any;
  strCreateUserId?: any;
  strUpdateUserId?: any;
  strDescription?: any;
  intSortNo?: any;
  fkDepartmentId?: any;
  blnView?: any;
  strDeptName?: any;
  strCategoryName?: any;
}

export interface modDepartment {
  pkDepartmentId?: any;
  strType?: any;
  strStatus?: any;
  strName?: any;
  strDescription?: any;
  strCategoryStatus?: any;
  strImageUrl?: any;
  intSortNo?: any;
}

import { Injectable } from "@angular/core";
import { environment } from "src/environments/environment";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Router } from "@angular/router";
import { CommonsService } from "./Commons/commons.service";
import { ApiResponse } from "../Classes/ApiResponse";
import { retry, catchError } from "rxjs/operators";

@Injectable({
  providedIn: "root",
})
export class OrderService {
  result: any;
  private apiURL: string = environment.API_ENDPOINT;

  constructor(
    private _http: HttpClient,
    private router: Router,
    private commonService: CommonsService
  ) {}

  httpOptions = {
    headers: new HttpHeaders({
      Authorization: "bearer" + " " + localStorage.getItem("token"),
    }),
  };

  /*
    TODO @Function: THIS Api is IMPORT DATA FROM  TO DB
  */

  getAllHubSummary() {
    return this._http
      .get<ApiResponse>(
        this.apiURL + "/api/orders/getAllHubSummary",
        this.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }

  getSingleOrderDetails(obj) {
    return this._http
    .get<ApiResponse>(
      this.apiURL + "/api/orders/singleOrderListForDashboard",
      {
        params:obj
      }
    )
    .pipe(retry(1), catchError(this.commonService.handleError));
  }
}

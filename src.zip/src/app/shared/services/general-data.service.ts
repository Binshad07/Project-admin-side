import { Injectable } from '@angular/core';
import {environment} from "../../../environments/environment";
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {Router} from "@angular/router";
import {ApiResponse} from "../Classes/ApiResponse";
import {catchError, retry} from "rxjs/operators";
import {throwError} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class GeneralDataService {

  result: any;
  private apiURL: string = environment.API_ENDPOINT;

  constructor(private _http: HttpClient, private router: Router) {

  }

  // Http Options
  httpOptions = {
    headers: new HttpHeaders({
    }),
  };

  loginService(obj) {
    return this._http
      .post<ApiResponse>(
        this.apiURL + "/api/login/AdminLogin",
        (obj),
        this.httpOptions
      )
      .pipe(retry(1), catchError(this.handleError));
  }

  handleError(error) {
    let errorMessage = "";
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    // window.alert(errorMessage);
    return throwError(errorMessage);
  }
}

import { catchError } from 'rxjs/operators';
import { retry } from 'rxjs/operators';
import { ApiResponse } from './../../Classes/ApiResponse';
import { HttpHeaders } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';
import { CommonsService } from './../Commons/commons.service';
import { environment } from 'src/environments/environment';
import { Injectable } from "@angular/core";

@Injectable({
  providedIn: "root",
})
export class PromocodeService {
  private apiURL: string = environment.API_ENDPOINT;

  constructor(
    private commonService: CommonsService,
    private _http: HttpClient
  ) { }

  httpOptions = {
    headers: new HttpHeaders({
      Authorization: "bearer" + " " + localStorage.getItem("token"),
    }),
  };

  getPromoCode(objData) {
    return this._http
      .post<ApiResponse>(
        this.apiURL + "/api/promocode/get_promo_code",
        objData,
        this.commonService.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }
  addPromoCode(objData) {
    return this._http
      .post<ApiResponse>(
        this.apiURL + "/api/promocode/add_promo_code",
        objData,
        this.commonService.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }
  updatePromoCode(objData) {
    return this._http
      .post<ApiResponse>(
        this.apiURL + "/api/promocode/update_promo_code",
        objData,
        this.commonService.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }
  deletePromoCode(objData) {
    return this._http
      .post<ApiResponse>(
        this.apiURL + "/api/promocode/delete_promo_code",
        objData,
        this.commonService.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }

  addPromoCodeGroup(objData) {
    return this._http
      .post<ApiResponse>(
        this.apiURL + "/api/promocode/add_promo_group",
        objData,
        this.commonService.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }
  getPromoCodeGroup(objData) {
    return this._http
      .post<ApiResponse>(
        this.apiURL + "/api/promocode/get_promo_group",
        objData,
        this.commonService.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }
}

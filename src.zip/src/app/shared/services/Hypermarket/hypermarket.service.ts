import { ApiResponse } from "./../../Classes/ApiResponse";
import { catchError } from "rxjs/operators";
import { retry } from "rxjs/operators";
import { HttpClient } from "@angular/common/http";
import { CommonsService } from "./../Commons/commons.service";
import { Injectable } from "@angular/core";

@Injectable({
  providedIn: "root",
})
export class HypermarketService {
  constructor(
    private commonServiceObj: CommonsService,
    private _http: HttpClient,
  ) {}

  getViewType() {
    return this._http
      .get<ApiResponse>(
        this.commonServiceObj.apiURL + "/api/department/GetViewType",
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getVieType(obj) {
    console.log(obj);

    return this._http
      .get<ApiResponse>(
        this.commonServiceObj.apiURL + "/api/department/GetViewType",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getUpdatedeWithdrawalstatus(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/transactions/updateWithdrawRequest",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getDefaultDepartment(obj) {
    console.log(obj);

    return this._http
      .get<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dummyData/getDefaultDepartment",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  // * +++++++++++++++++++++++++ Category +++++++++++++++++++++++++ * //

  getListCategoryService(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURL + "/api/Category/GetAllCategories",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  getSaveCategoryService(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/Category/SaveCategory",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getSavedummyCategoryService(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dummyData/category/addCategory",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  getSaveoffertopbar(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/offerTopBar/create",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getSavedummyBottomBanner(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dummyData/banner/addWebBottomBanner",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getSavedefaultdummysubCategoryService(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dummyData/sub-Category/addSubCategory",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  getDeleteCategoryService(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURL + "/api/Category/DeleteCategory",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  getUpdateCategoryService(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURL + "/api/Category/UpdateCategory",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  // * +++++++++++++++++++++++++ Sub Category +++++++++++++++++++++++++ * //

  getListSubCategoryService(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURL + "/api/sub-Category/GetAllSubCategories",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError)); //
  }
  getSaveSubCategoryService(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/sub-Category/SaveSubCategory",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  getDeleteSubCategoryService(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURL + "/api/sub-Category/DeleteSubCategory",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  getUpdateSubCategoryService(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURL + "/api/sub-Category/UpdateSubCategory",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getUpdatedefaultCategory(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dummyData/updateDefaultCategory",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getUpdateoffertopbar(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/offerTopBar/update",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  getUpdatedefaultsubCategory(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dummyData/updateDefaultSubCategory",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getUpdatedefaultbanners(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dummyData/updateDefaultBanner",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getUpdatedefaultbottombanners(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dummyData/banner/updateWebBottomBanner",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  deleteDefaultCategoryDetails(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dummyData/deleteDefaultCategoryDetails",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  deleteoffertopbar(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/offerTopBar/delete",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  deleteDefaultbannerDetails(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dummyData/deleteDefaultBannerDetails",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  deleteDefaultbottombannerDetails(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dummyData/deleteDefaultBottomBannerDetails",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  deleteDefaultsubCategory(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dummyData/deleteDefaultSubCategoryDetails",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getSavedummyBanner(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dummyData/banner/addHomeTopBanner",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getAllDummyunit(obj) {
    console.log(obj);
    return this._http
      .get<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/v1/dummyData/unit/listUnit",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getAllShopExcel(obj) {
    console.log(obj);
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/store/Get_ExcelAllShop",
        {
          params: {},
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getAllDummybrands(obj) {
    console.log(obj);
    return this._http
      .get<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/v1/dummyData/brand/listBrand",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  getSavedummyUnit(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/v1/dummyData/unit/addUnit",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  getUpdatedefaultUnit(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dummyData/unit/updateDefaultUnit",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  deleteDefaultUnit(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dummyData/unit/deleteDefaultUnit",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  deleteDefaultproduct(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dummyData/deleteDefaultProductDetails",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  // * +++++++++++++++++++++++++ Department +++++++++++++++++++++++++ * //

  //  getListDepartmentService(obj) {
  //   return this._http.get<ApiResponse>(this.commonServiceObj.apiURL+ "/api/department/GetAllDept",obj,
  //   // this.commonServiceObj.httpOptions
  //   )
  //   .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  //  }

  getListDepartmentService(obj) {
    return this._http
      .get<ApiResponse>(
        this.commonServiceObj.apiURL + "/api/department/GetAllDept",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getDefaultDepartmentService(obj) {
    return this._http
      .get<ApiResponse>(
        this.commonServiceObj.apiURL + "/api/company/getDefaultDepartments",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getDefaultCategoryDetails(obj) {
    return this._http
      .get<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dummyData/getDefaultCategoryDetails",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getDefaultBannerDetails(obj) {
    return this._http
      .get<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dummyData/getDefaultBannerDetails?",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getDefaultBottomBannerDetails(obj) {
    return this._http
      .get<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dummyData/getDefaultBottomBannerDetails",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getDomainCount(obj) {
    return this._http
      .get<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dashboardStatus/domainRequestCount",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getPixelCount(obj) {
    return this._http
      .get<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dashboardStatus/pixelRequestCount",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getSettleCount(obj) {
    return this._http
      .get<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dashboardStatus/settlementRequestCount",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getRazorCount(obj) {
    return this._http
      .get<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dashboardStatus/PaymentGatewayRequestCount",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getAgencyCount(obj) {
    return this._http
      .get<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dashboardStatus/AgencyRequestCount",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getTicketCount(obj) {
    return this._http
      .get<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dashboardStatus/ticketRequestCount",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getRenewCount(obj) {
    return this._http
      .get<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dashboardStatus/renewSubscriptionCount",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getWallet(obj) {
    return this._http.
      get<ApiResponse>
      (this.commonServiceObj.apiURLV4 + "/api/v1/dashboardStatus/walletAmountDetails",
        {
          params: obj
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getWebsiteLeads(obj) {
    return this._http.
      get<ApiResponse>
      (this.commonServiceObj.apiURLV4 + "/api/v1/dashboardStatus/websiteLeadCount",
        {
          params: obj
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  getOTPcount(obj) {
    return this._http.
      get<ApiResponse>
      (this.commonServiceObj.apiURLV4 + "/api/v1/dashboardStatus/otpOrderCount",
        {
          params: obj
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  // getDefaultBannerDetails(obj) {
  //   return this._http.
  //     get<ApiResponse>
  //     (this.commonServiceObj.apiURLV4 + "/api/v1/dummyData/getDefaultBannerDetails?",
  //       {
  //         params: obj
  //       }
  //     )
  //     .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  // }

  getDefaultProductDetails(obj) {
    return this._http
      .get<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dummyData/getDefaultProductDetails?",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getDefaultSubCategoryDetails(obj) {
    return this._http
      .get<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dummyData/getDefaultSubCategoryDetails",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getSaveDepartmentService(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/department/SaveDept",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  getDeleteDepartmentService(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURL + "/api/department/DeleteDept",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  getUpdateDepartmentService(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURL + "/api/department/UpdateDept",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  // settlement

  saveSettlementTransactionService(obj) {
    console.log(obj, "buuuuuuuuuuuuu");
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURL +
          "/api/transactions/add_transaction_settlements",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getSettlementTransactionService(obj) {
    {
      return this._http
        .get<ApiResponse>(
          this.commonServiceObj.apiURL + "/api/transactions/getSettlements",
          {
            params: obj,
          }
        )
        .pipe(retry(2), catchError(this.commonServiceObj.handleError));
    }
  }

  getCustomerTicketCount(obj) {
    return this._http.post<ApiResponse>(this.commonServiceObj.apiURLV4 + "/api/v1/company/ticketRequestList", obj,
      this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  getStoreRenewalCount(obj) {
    return this._http.post<ApiResponse>(this.commonServiceObj.apiURLV4 + "/api/v1/company/renewSubscriptionList", obj,
      this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  getOtpOrderCount(obj) {
    return this._http.post<ApiResponse>(this.commonServiceObj.apiURLV4 + "/api/v1/company/getOtpOrders", obj,
      this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  getLeadsCount(obj) {
    return this._http.
      get<ApiResponse>
      (this.commonServiceObj.apiURLV4 + "/api/v1/company/listWebsiteLeads",
        {
          params: obj
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  getSavedummyBrand(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/v1/dummyData/brand/addBrand",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  deleteDefaultBrand(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dummyData/brand/deleteDefaultBrand",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  getUpdatedefaultBrand(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dummyData/brand/updateDefaultBrand",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  // getupdatedefaultproduct(obj) {
  //   return this._http.post<ApiResponse>(this.commonServiceObj.apiURLV4 + "api/v1/dummyData/updateDefaultProduct", obj
  //     , this.commonServiceObj.httpOptions)
  //     .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  // }

  getupdatedefaultproduct(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/dummyData/updateDefaultProduct",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  /* Vocher */

  addVocher(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/v1/salesAdmin/addVoucher",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  updateVocher(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/v1/salesAdmin/addVoucher",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getListVoucher(obj) {
    return this._http
      .get<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/v1/salesAdmin/getVoucher",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  /* End */


  
  addfreezeBMKPay(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/user/freezeBMKPay",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }


  
  addUnfreezeBMKPay(obj) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/user/unfreezeBMKPay",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

}

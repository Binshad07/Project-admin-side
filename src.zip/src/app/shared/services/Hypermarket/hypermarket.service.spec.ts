import { TestBed } from '@angular/core/testing';

import { HypermarketService } from './hypermarket.service';

describe('HypermarketService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: HypermarketService = TestBed.get(HypermarketService);
    expect(service).toBeTruthy();
  });
});

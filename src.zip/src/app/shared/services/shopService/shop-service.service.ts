import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonsService } from '../Commons/commons.service';
import { ApiResponse } from '../../Classes/ApiResponse';
import { retry } from 'rxjs/operators';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ShopServiceService {

  constructor(
    private http: HttpClient,
    private commonServiceObj: CommonsService

  ) { }

getAllShops(obj) {
    return this.http.
      post<ApiResponse>
      (this.commonServiceObj.apiURLV4 + "/api/company/listCompanyAdmin", obj,
        this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));

  }

  getAllShopss(obj) {
    return this.http.
      post<ApiResponse>
      (this.commonServiceObj.apiURL + "/api/company/listCompanyAdmin", obj,
        this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));

  }

  deleteAllShops(obj) {
    return this.http.
      post<ApiResponse>
      (this.commonServiceObj.apiURL + "/api/company/deleteCompany", obj,
        this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));

  }

  
  addShop(obj) {
    return this.http.
      post<ApiResponse>
      (this.commonServiceObj.apiURL + "/api/company/addCompany", obj,
        this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));

  }


  updateShop(obj) {
    return this.http.
      post<ApiResponse>
      (this.commonServiceObj.apiURL + "/api/company/updateCompany", obj,
        this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));

  }

  getCountShopsReport(obj) {
    return this.http.
      post<ApiResponse>
      (this.commonServiceObj.apiURL + "/api/company/getCountShopReports", obj,
        this.commonServiceObj.httpOptions)
      .pipe(retry(1), catchError(this.commonServiceObj.handleError));

  }



  
}

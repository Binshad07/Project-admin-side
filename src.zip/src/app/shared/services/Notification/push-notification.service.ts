import { Injectable } from "@angular/core";
import { CommonsService } from "../Commons/commons.service";
import { HttpClient } from "@angular/common/http";
import { ApiResponse } from "../../Classes/ApiResponse";
import { catchError, retry } from "rxjs/operators";

@Injectable({
  providedIn: "root",
})
export class PushNotificationService {
  constructor(
    private http: HttpClient,
    private commonServiceObj: CommonsService
  ) {}

  getAllNotification(obj) {
    return this.http
      .post<ApiResponse>(
        this.commonServiceObj.apiURL +
          "/api/domain/sendPushNotificationToAllShop",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
}

import { TestBed } from '@angular/core/testing';

import { NeworderServiceService } from './neworder-service.service';

describe('NeworderServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: NeworderServiceService = TestBed.get(NeworderServiceService);
    expect(service).toBeTruthy();
  });
});

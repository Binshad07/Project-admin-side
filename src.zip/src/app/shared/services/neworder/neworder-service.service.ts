import { Injectable } from '@angular/core';
import { CommonsService } from '../Commons/commons.service';
import { HttpClient } from '@angular/common/http';
import { ApiResponse } from '../../Classes/ApiResponse';
import { catchError, retry } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class NeworderServiceService {

  constructor(
    private http: HttpClient,
    private commonServiceObj: CommonsService
  ) { }


  getNewOrderList(obj){
    return this.http.
      get<ApiResponse>
      (this.commonServiceObj.apiURL + "/api/orders/newOrderListForDashboard",
        {
          params: obj
        }
      )
    .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
}

import { Injectable } from "@angular/core";
import { CommonsService } from "../Commons/commons.service";
import { HttpClient } from "@angular/common/http";
import { ApiResponse } from "../../Classes/ApiResponse";
import { catchError, retry } from "rxjs/operators";

@Injectable({
  providedIn: "root",
})
export class CompanyServiceService {
  constructor(
    private http: HttpClient,
    private commonServiceObj: CommonsService
  ) {}

  fngetallCompany(obj) {
    return this.http
      .get<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/v1/getAllCompanyDropDown",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  fnShopListFn(obj) {
    return this.http
      .get<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/v2/getAllShops",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  fngetallShop(obj) {
    return this.http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/company/listCompanyAdmin",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  Listagencymodule(obj) {
    return this.http
      .get<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/Agency/getAgencylinkShopRequests",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  razorpaylist(obj) {
    return this.http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/v1/store/getShopRazorpayCreds",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  fngetallNewCompany(obj) {
    return this.http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/company/getCompanySettings",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  updateurl(obj) {
    return this.http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/v1/store/updateStoreAppUrls",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  //offline Report Add

  addWithdrawRequest(obj) {
    return this.http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/transactions/addWithdrawRequest",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  Getwithdrawreport(obj) {
    return this.http
      .get<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/transactions/getWithdrawRequests?",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  // getAllPixels(obj) {
  //   return this.http.
  //     get<ApiResponse>
  //     (this.commonServiceObj.apiURL + "/api/v1/store/getShopPixels",
  //       {
  //         params: obj
  //       }
  //     )
  //     .pipe(retry(2), catchError(this.commonServiceObj.handleError));

  // }

  getAllPixels(obj) {
    return this.http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/v1/store/getShopPixels",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  AddOfflineReport(obj) {
    return this.http
      .post<ApiResponse>(
        this.commonServiceObj.apiURL +
          "/api/storeSubscription/addOfflineTransactionDetails",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  AddOfflineactiveReport(obj) {
    return this.http
      .post<ApiResponse>(
        this.commonServiceObj.apiURL +
          "/api/storeSubscription/offlineSubscribePlan",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  //offline Report List

  ListStoreSubscription(obj) {
    return this.http
      .get<ApiResponse>(
        this.commonServiceObj.apiURL +
          "/api/storeSubscription/getAllOfflineTransactionDetails",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  // AddsubscriptionReport(obj) {
  //   return this.http
  //     .post<ApiResponse>(
  //       this.commonServiceObj.apiURL + "/api/v1/subscription/saveNewSubscriptionPlan",
  //       obj,
  //       this.commonServiceObj.httpOptions
  //     )
  //     .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  // }

  ListSubscriptionReport(obj) {
    return this.http
      .get<ApiResponse>(
        this.commonServiceObj.apiURL +
          "/api/subscription/getSubscriptionReport",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  Getcustomledger(obj) {
    return this.http
      .get<ApiResponse>(
        this.commonServiceObj.apiURL +
          "/api/transactions/getSettlementTransactions",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  Listleads(obj) {
    return this.http
      .post<ApiResponse>(
        this.commonServiceObj.apiURL + "/api/v1/salesAdmin/admin/listAdmin",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  Salesleads(obj) {
    return this.http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/v1/salesAdmin/lead/listLeads",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  // ListcurrencyList(obj) {
  //   return this.http.
  //     get<ApiResponse>
  //     (this.commonServiceObj.apiURL + "/api/v1/currency/getAllCurrency",
  //       {
  //         params: obj
  //       }
  //     )
  //     .pipe(retry(2), catchError(this.commonServiceObj.handleError));

  // }

  //Plans

  ListPlanDetails(obj) {
    return this.http
      .get<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/storeSubscription/getAllPlans",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  AddsubscriptionReport(obj) {
    return this.http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/subscription/saveNewSubscriptionPlan",
        obj,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  ListcurrencyList(obj) {
    return this.http
      .get<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/v1/currency/getAllCurrency",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  ByPassFilter(obj) {
    return this.http
      .get<ApiResponse>(
        this.commonServiceObj.apiURLV4 +
          "/api/v1/vendor/auth/getBypassingShopDetails",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  fngetallPlans(obj) {
    return this.http
      .get<ApiResponse>(
        this.commonServiceObj.apiURL + "/api/storeSubscription/getAllPlans",
        {
          params: obj,
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
}

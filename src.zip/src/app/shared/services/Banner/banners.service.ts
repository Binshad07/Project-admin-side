  import { Injectable } from '@angular/core';
  import { HttpClient } from '@angular/common/http';
  import { CommonsService } from '../Commons/commons.service';
  import { ApiResponse } from '../../Classes/ApiResponse';
  import { retry } from 'rxjs/operators';
  import { catchError } from 'rxjs/operators';
  @Injectable({
    providedIn: 'root'
  })
  export class BannersService {
    apiURL: string;
    constructor(
      private http: HttpClient,
      private commonServiceObj: CommonsService
    ) { }
  

    getListHomeBanner(obj) {
      return this.http.
        get<ApiResponse>
        (this.commonServiceObj.apiURL + "/api/banner/listHomeTopBannerAdmin",
          {
            params: obj
          }
        )
        .pipe(retry(2), catchError(this.commonServiceObj.handleError));
    }


    getOffertopbar(obj) {
      return this.http.
        get<ApiResponse>
        (this.commonServiceObj.apiURLV4 + "/api/offerTopBar/list",
          {
            params: obj
          }
        )
        .pipe(retry(2), catchError(this.commonServiceObj.handleError));
    }


    addHomeBanner(objData) {
      return this.http
        .post<ApiResponse>(
          this.commonServiceObj.apiURL + "/api/banner/addHomeTopBanner",
          objData,
          this.commonServiceObj.httpOptions
        )
        .pipe(retry(1), catchError(this.commonServiceObj.handleError));
    }
  
    verifytatus(objData) {
      return this.http
        .post<ApiResponse>(
          this.commonServiceObj.apiURLV4 + "/api/v1/Agency/approveShopLinking",
          objData,
          this.commonServiceObj.httpOptions
        )
        .pipe(retry(1), catchError(this.commonServiceObj.handleError));
    }



    verifydomain(objData) {
      return this.http
        .post<ApiResponse>(
          this.commonServiceObj.apiURLSTORE + "/api/domain/verifyDomain",
          objData
         // this.commonServiceObj.httpOptions
        )
        .pipe(retry(1), catchError(this.commonServiceObj.handleError));
    }
    updateHomeBanner(objData) {
      return this.http
        .post<ApiResponse>(
          this.commonServiceObj.apiURL + "/api/banner/updateHomeTopBanner",
          objData,
          this.commonServiceObj.httpOptions
        )
        .pipe(retry(1), catchError(this.commonServiceObj.handleError));
    }
  
    deleteHomeBanner(objData) {
      return this.http
        .post<ApiResponse>(
          this.commonServiceObj.apiURL + "/api/banner/deleteHomeTopBanner",
          objData,
          this.commonServiceObj.httpOptions
        )
        .pipe(retry(1), catchError(this.commonServiceObj.handleError));
    }

    // ***********offer-banners*****************



    updateOfferBanners(objData) {
      objData.forEach((key, value) => console.log(`${key}: ${value}`))
      
      
      return this.http
        .post<ApiResponse>(
          this.commonServiceObj.apiURL + "/api/banner/updateOfferBanner",
          objData,
          this.commonServiceObj.httpOptions
        )
        .pipe(retry(1), catchError(this.commonServiceObj.handleError));
    }
  
//Middle Home BAnner

  

getListHomeMiddleBanner(obj) {
  return this.http.
    get<ApiResponse>
    (this.commonServiceObj.apiURL + "/api/banner/listHomeMiddleBanner",
      {
        params: obj
      }
    )
    .pipe(retry(2), catchError(this.commonServiceObj.handleError));
}

addHomeMiddleBanner(objData) {
  return this.http
    .post<ApiResponse>(
      this.commonServiceObj.apiURL + "/api/banner/addHomeMiddleBanner",
      objData,
      this.commonServiceObj.httpOptions
    )
    .pipe(retry(1), catchError(this.commonServiceObj.handleError));
}

updateHomeMiddleBanner(objData) {
  return this.http
    .post<ApiResponse>(
      this.commonServiceObj.apiURL + "/api/banner/updateHomeMiddleBanner",
      objData,
      this.commonServiceObj.httpOptions
    )
    .pipe(retry(1), catchError(this.commonServiceObj.handleError));
}

deleteHomeMiddleBanner(objData) {
  return this.http
    .post<ApiResponse>(
      this.commonServiceObj.apiURL + "/api/banner/deleteHomeMiddleBanner",
      objData,
      this.commonServiceObj.httpOptions
    )
    .pipe(retry(1), catchError(this.commonServiceObj.handleError));
}


//Domain
ListDomain(obj) {
  return this.http.
    get<ApiResponse>
    (this.commonServiceObj.apiURLV4 + "/api/domain/listDomainDetails",
      {
        params: obj
      }
    )
    .pipe(retry(2), catchError(this.commonServiceObj.handleError));
}
AddDomain(objData) {
  return this.http
    .post<ApiResponse>(
      this.commonServiceObj.apiURL + "/api/domain/addDnDetails",
      objData,
      this.commonServiceObj.httpOptions
    )
    .pipe(retry(1), catchError(this.commonServiceObj.handleError));
}



setSecurityGroupAdded(objData) {
  return this.http
    .post<ApiResponse>(
      this.commonServiceObj.apiURLSTORE + "/api/domain/setSecurityGroupAdded",
      objData,
      this.commonServiceObj.httpOptions
    )
    .pipe(retry(1), catchError(this.commonServiceObj.handleError));
}

setNginxConnection(objData) {
  return this.http
    .post<ApiResponse>(
      this.commonServiceObj.apiURLSTORE + "/api/domain/setNginxConnection",
      objData,
      this.commonServiceObj.httpOptions
    )
    .pipe(retry(1), catchError(this.commonServiceObj.handleError));
}


setSLLConnection(objData) {
  return this.http
    .post<ApiResponse>(
      this.commonServiceObj.apiURLWEBAPP + "/api/v1/domain/setSLLConnection",
      objData,
      this.commonServiceObj.httpOptions
    )
    .pipe(retry(1), catchError(this.commonServiceObj.handleError));
}

setServerFileConnection(objData) {
  return this.http
    .post<ApiResponse>(
      this.commonServiceObj.apiURLWEBAPP + "/api/v1/domain/setServerFileConnection",
      objData,
      this.commonServiceObj.httpOptions
    )
    .pipe(retry(1), catchError(this.commonServiceObj.handleError));
}

setBrandNameChange(objData) {
  return this.http
    .post<ApiResponse>(
      this.commonServiceObj.apiURLWEBAPP + "/api/v1/domain/setBrandNameChange",
      objData,
      this.commonServiceObj.httpOptions
    )
    .pipe(retry(1), catchError(this.commonServiceObj.handleError));
}

deleteDomainList(objData) {
  return this.http
    .post<ApiResponse>(
      this.commonServiceObj.apiURL + "/api/domain/deleteDomain",
      objData,
      this.commonServiceObj.httpOptions
    )
    .pipe(retry(1), catchError(this.commonServiceObj.handleError));
}

  }
  
  
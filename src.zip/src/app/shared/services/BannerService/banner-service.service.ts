import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonsService } from '../Commons/commons.service';
import { ApiResponse } from '../../Classes/ApiResponse';
import { retry } from 'rxjs/operators';
import { catchError } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class BannerServiceService {

  constructor(
    private http: HttpClient,

    private commonServiceObj: CommonsService

  ) { }


  getAllbanners(obj) {
    return this.http.
      get<ApiResponse>
      (this.commonServiceObj.apiURL + "/api/banner/listWebBottomBannerAdmin",
        {
          params: obj
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));

  }

  DeleteBanner(obj) {
    return this.http.
      post<ApiResponse>
      (this.commonServiceObj.apiURL + "/api/banner/deleteWebBottomBanner", obj,
        this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));

  }


  addBottomBanner(obj) {
    return this.http.
      post<ApiResponse>
      (this.commonServiceObj.apiURL + "/api/banner/addWebBottomBanner", obj,
        this.commonServiceObj.httpOptions)
      .pipe(retry(1), catchError(this.commonServiceObj.handleError));
  }


  updateBanner(obj) {
    return this.http.
      post<ApiResponse>
      (this.commonServiceObj.apiURL + "/api/banner/updateBanner", obj,
        this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));

  }


  getListCategoryService(obj) {
    return this.http.
      post<ApiResponse>
      (this.commonServiceObj.apiURL + "/api/Category/GetAllCategories", obj,
        this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));

  }

  getListProductReview(obj) {
    return this.http.
      get<ApiResponse>
      (this.commonServiceObj.apiURL + "/api/review/listReviewAdmin",
        {
          params: obj
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));

  }


  ListDomain(obj) {
    return this.http.
      get<ApiResponse>
      (this.commonServiceObj.apiURL + "/api/domain/listDomainDetails",
        {
          params: obj
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  AddDomain(objData) {
    return this.http
      .post<ApiResponse>(
        this.commonServiceObj.apiURL + "/api/domain/addDnDetails",
        objData,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(1), catchError(this.commonServiceObj.handleError));
  }
}

import { Injectable } from "@angular/core";
import { environment } from "src/environments/environment";
import { CommonsService } from "../Commons/commons.service";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { ApiResponse } from "../../Classes/ApiResponse";
import { retry, catchError } from "rxjs/operators";

@Injectable({
  providedIn: "root",
})
export class ReturnReportService {
  private apiURL: string = environment.API_ENDPOINT;

  constructor(
    private commonService: CommonsService,
    private _http: HttpClient
  ) {}

  httpOptions = {
    headers: new HttpHeaders({
      Authorization: "bearer" + " " + localStorage.getItem("token"),
    }),
  };

  /** @FUNCTION : TO GET RETURN REPORT BY FROM DATE, TO DATE, SHOP NAME, ORDER NUMBER
   * ! Author: Yabish
   * ? Date: 16-jul-2020
   **/
  GetReturnedOrderReport(objData) {
    return this._http
      .post<ApiResponse>(
        this.apiURL + "/api/orders/GetReturnedOrderReport",
        objData,
        this.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }

  /** @FUNCTION : TO GET SHOP LIST
   * ! Author: Yabish
   * ? Date: 16-jul-2020
   **/

  getShopList() {
    const objData = {};
    return this._http
      .post<ApiResponse>(
        this.apiURL + "/api/orders/GetAllShops",
        objData,
        this.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }

  /** @FUNCTION : TO GET DELIVERY REPORT BY FROM DATE, TO DATE, SHOP NAME, ORDER NUMBER
   * ! Author: Yabish
   * ? Date: 17-jul-2020
   **/
  GetDeliveredOrderReport(objData) {
    return this._http
      .post<ApiResponse>(
        this.apiURL + "/api/orders/GetDeliveredOrderReport",
        objData,
        this.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }

  /** @FUNCTION : TO GET DELIVERY SUMMARY BY FROM DATE, TO DATE, SHOP NAME, ORDER NUMBER
   * ! Author: Yabish
   * ? Date: 17-jul-2020
   **/
  GetDeliveredOrderSummary(objData) {
    return this._http
      .post<ApiResponse>(
        this.apiURL + "/api/orders/GetDeliveredOrderSummary",
        objData,
        this.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }

  /** @FUNCTION : TO GET DELIVERY SUMMARY BY FROM DATE, TO DATE, SHOP NAME, ORDER NUMBER
   * ! Author: Yabish
   * ? Date: 17-jul-2020
   **/
  GetWishlistAnalysis(objData) {
    return this._http
      .post<ApiResponse>(
        this.apiURL + "/api/orders/GetWishlistAnalysis",
        objData,
        this.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }
}

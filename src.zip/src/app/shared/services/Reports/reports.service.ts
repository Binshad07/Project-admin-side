import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { CommonsService } from '../Commons/commons.service';
import { HttpClient } from '@angular/common/http';
import { ApiResponse } from '../../Classes/ApiResponse';
import { retry, catchError } from 'rxjs/operators';
//  Created on 16th July 2020
// Edited By : Mithun
@Injectable({
  providedIn: 'root'
})
export class ReportsService {



  constructor(private commonServiceObj: CommonsService,
    private _http: HttpClient,) { }


  // * +++++++++++++++++++++++++ Hub Summary +++++++++++++++++++++++++ * //

  // * @FUNCTION TO GET SHOP LISTING
  getShopListingService() {
    return this._http.post<ApiResponse>(this.commonServiceObj.apiURL + "/api/orders/GetAllShops", '', this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getShopListingSummaryService(obj) {
    return this._http.post<ApiResponse>(this.commonServiceObj.apiURL + "/api/orders/GetAllShops", obj, this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  // * @FUNCTION TO GET HUB SUMMARY
  getHubSummaryService(obj) {
    return this._http.post<ApiResponse>(this.commonServiceObj.apiURL + "/api/orders/getAllHubSummary", obj, this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  // * +++++++++++++++++++++++++ Hub Order Summary +++++++++++++++++++++++++ * //

  getHubOrderSummaryService(obj) {
    return this._http.post<ApiResponse>(this.commonServiceObj.apiURL + "/api/orders/GetAllHubOrderSummary", obj, this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  // getAllSignUp(obj) {
  //   return this._http.get<ApiResponse>(this.commonServiceObj.apiURL + "/api/report/getAllSignUp",
  //     this.commonServiceObj.httpOptions)
  //     .pipe(retry(2), catchError(this.commonServiceObj.handleError));

  // }




  getAllSignUp(obj) {
    return this._http.
      get<ApiResponse>
      (this.commonServiceObj.apiURL + "/api/report/getAllSignUp",
        {
          params: obj
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));

  }


  getAllRequest(obj) {
    return this._http.
      get<ApiResponse>
      (this.commonServiceObj.apiURL + "/api/orders/getReturnRequestsAdmin",
        {
          params: obj
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));

  }



  getRazorpayReport(obj) {

    return this._http.
      post<ApiResponse>
      (this.commonServiceObj.apiURL + "/api/report/getRazorpayReport", obj,
        this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));

  }

  UnitList(obj) {
    return this._http.
      get<ApiResponse>
      (this.commonServiceObj.apiURL + "/api/unit/listAllUnit",
        {
          params: obj
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));

  }

  DefaultUnitList(obj) {
    return this._http.
      get<ApiResponse>
      (this.commonServiceObj.apiURL + "/api/v1/dummyData/unit/listUnit",
        {
          params: obj
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));

  }

  Deleteunitlist(obj) {
    return this._http.
      post<ApiResponse>
      (this.commonServiceObj.apiURL + "/api/unit/deleteUnit", obj,
        this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));

  }
  Addunitlist(objData) {
    return this._http.post<ApiResponse>(this.commonServiceObj.apiURL + "/api/unit/addUnitForShop",
      objData,
      this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  AddDefaultunitlist(objData) {
    return this._http.post<ApiResponse>(this.commonServiceObj.apiURL + "/api/v1/dummyData/unit/addUnit",
      objData,
      this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getunitlist(obj) {
    return this._http.post<ApiResponse>(this.commonServiceObj.apiURL + "/api/unit/updateUnitForShop",
      obj, this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  updateunitlist(objData) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURL + "/api/unit/updateUnitForShop",
        objData,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(1), catchError(this.commonServiceObj.handleError));
  }




  storeSubscription(objData) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/storeSubscription/reNewSubscriptionPlan",
        objData,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(1), catchError(this.commonServiceObj.handleError));
  }


  byPassShop(objData) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/v1/vendor/auth/bypassShopCredential",
        objData,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(1), catchError(this.commonServiceObj.handleError));
  }



  removebypassfilter(objData) {
    return this._http
      .post<ApiResponse>(
        this.commonServiceObj.apiURLV4 + "/api/v1/vendor/auth/removeBypassShopCredential",
        objData,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(1), catchError(this.commonServiceObj.handleError));
  }



  // * +++++++++++++++++++++++++ Order Summary +++++++++++++++++++++++++ * //

  getOrderSummaryService(obj) {
    return this._http.post<ApiResponse>(this.commonServiceObj.apiURL + "/api/orders/GetOrderSummary", obj, this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  // * +++++++++++++++++++++++++ Cancel Order +++++++++++++++++++++++++ * //

  getCancelOrderService(obj) {
    return this._http.post<ApiResponse>(this.commonServiceObj.apiURL + "/api/orders/GetCancelledOrderReport", obj, this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  // * +++++++++++++++++++++++++ Payment Report +++++++++++++++++++++++++ * //

  getOrderPaymentService(obj) {
    return this._http.post<ApiResponse>(this.commonServiceObj.apiURL + "/api/orders/GetPaymentReport", obj, this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  // * +++++++++++++++++++++++++ Cart Report +++++++++++++++++++++++++ * //
  getCartDetailsService(obj) {
    return this._http.post<ApiResponse>(this.commonServiceObj.apiURL + "/api/orders/GetCartAnalysis", obj, this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  // * +++++++++++++++++++++++++ Sales Report +++++++++++++++++++++++++ * //

  getItemSalesService(obj) {
    return this._http.post<ApiResponse>(this.commonServiceObj.apiURLV4 + "/api/item/GetItemSalesReport", obj, this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  // * +++++++++++++++++++++++++ Order LifeCycle Report +++++++++++++++++++++++++ * //

  getOrderLifeCycleService(obj) {
    return this._http.post<ApiResponse>(this.commonServiceObj.apiURL + "/api/orders/GetOrderLifeCycle", obj, this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  // * +++++++++++++++++++++++++ Order LifeCycle Report +++++++++++++++++++++++++ * //

  getNewOrderReportService(obj) {
    return this._http.post<ApiResponse>(this.commonServiceObj.apiURL + "/api/orders/GetNewOrderReport", obj, this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  getNewOrderReportExcelService(obj) {
    return this._http.post<ApiResponse>(this.commonServiceObj.apiURL + "/api/orders/GetNewReportExcel", obj, this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  // * +++++++++++++++++++++++++ Delivery Details Report +++++++++++++++++++++++++ * //

  getDeliveryDetailsExcelService(obj) {
    return this._http.post<ApiResponse>(this.commonServiceObj.apiURL + "/api/product-excel/getAllDeliveryReport", obj, this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }


  getDeliveryDetailsService(obj) {
    return this._http.post<ApiResponse>(this.commonServiceObj.apiURL + "/api/product-excel/GetAllDeliveryData", obj, this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  // * +++++++++++++++++++++++++ User Details Excel +++++++++++++++++++++++++ * //

  getUserDetailsExcelService(obj) {
    return this._http.post<ApiResponse>(this.commonServiceObj.apiURL + "/api/user/GetUserExcel", obj, this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

  // * +++++++++++++++++++++++++ User Details Excel +++++++++++++++++++++++++ * //

  getTransactionDetailsService(obj) {
    return this._http.post<ApiResponse>(this.commonServiceObj.apiURL + "/api/transactions/get_transactions", obj, this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }

}

import { TestBed } from '@angular/core/testing';

import { ReturnReportService } from './return-report.service';

describe('ReturnReportService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ReturnReportService = TestBed.get(ReturnReportService);
    expect(service).toBeTruthy();
  });
});

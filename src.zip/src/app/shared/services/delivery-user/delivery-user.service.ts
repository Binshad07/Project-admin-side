import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonsService } from '../Commons/commons.service';
import { ApiResponse } from '../../Classes/ApiResponse';
import { retry } from 'rxjs/operators';
import { catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class DeliveryUserService {
  apiURL: string;
  constructor(
    private http: HttpClient,
    private commonServiceObj: CommonsService
  ) { }

  getListDeliveryUser(obj) {
    return this.http.
      post<ApiResponse>
      (this.commonServiceObj.apiURL + "/api/DeliveryUser/get_delivery_Users", obj,
        this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));
  }
  addDeliveryUser(objData) {
    return this.http
      .post<ApiResponse>(
        this.commonServiceObj.apiURL + "/api/DeliveryUser/add_User",
        objData,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(1), catchError(this.commonServiceObj.handleError));
  }

  updateDeliveryUser(objData) {
    return this.http
      .post<ApiResponse>(
        this.commonServiceObj.apiURL + "/api/DeliveryUser/update_User",
        objData,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(1), catchError(this.commonServiceObj.handleError));
  }

  deleteDeliveryUser(objData) {
    return this.http
      .post<ApiResponse>(
        this.commonServiceObj.apiURL + "/api/DeliveryUser/delete_User",
        objData,
        this.commonServiceObj.httpOptions
      )
      .pipe(retry(1), catchError(this.commonServiceObj.handleError));
  }


}










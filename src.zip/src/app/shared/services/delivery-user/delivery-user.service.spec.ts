import { TestBed } from '@angular/core/testing';

import { DeliveryUserService } from './delivery-user.service';

describe('DeliveryUserService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DeliveryUserService = TestBed.get(DeliveryUserService);
    expect(service).toBeTruthy();
  });
});

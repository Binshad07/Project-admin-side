import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders,HttpParams } from "@angular/common/http";
import { Router } from "@angular/router";
import { environment } from "../../../environments/environment";
import { throwError } from "rxjs";
import { catchError, retry } from "rxjs/operators";
import { ApiResponse } from "../Classes/ApiResponse";
import { CommonsService } from "./Commons/commons.service";

@Injectable({
  providedIn: "root",
})
export class ProductService {
  result: any;
  private apiURL: string = environment.API_ENDPOINT;

  constructor(
    private _http: HttpClient,
    private router: Router,
    private commonService: CommonsService
  ) {}

  // Http Options

  createProduct(obj) {
    const formdata = new FormData();
    formdata.append("strProductName", obj.strProductName);
    formdata.append("strArabicName", obj.strArabicName);
    formdata.append("strDescription", obj.strDescription);
    formdata.append("strManufacturerDetails", obj.strManufacturerDetails);
    formdata.append("strFeature", obj.strFeature);
    formdata.append("strProductDisclaimer", obj.strProductDisclaimer);
    formdata.append("strBrand", obj.strBrand);
    formdata.append("strProperties", obj.strProperties);
    formdata.append("strSubCategoryId", obj.strSubCategoryId);
    formdata.append("strMoreDetails", obj.strMoreDetails);
    formdata.append("strProductStatus", obj.strProductStatus);
    formdata.append("strUnit", obj.strUnit);
    formdata.append("isInfiniteStock", obj.isInfiniteStock);
    formdata.append("strQuantity", obj.strQuantity);
    formdata.append("intStockQuantity", obj.intStockQuantity);
    formdata.append("strSearchTags", obj.strSearchTags);
    formdata.append("strBarcode", obj.strBarcode);
    formdata.append("strMRP", obj.strMRP);
    formdata.append("strDiscount", obj.strDiscount);
    formdata.append("strMaxQuantity", obj.strMaxQuantity);
    formdata.append("blnCOD", obj.blnCOD);
    formdata.append("blnReturnable", obj.blnReturnable);
    formdata.append("blnFreeDelivery", obj.blnFreeDelivery);
    formdata.append("blnWarranty", obj.blnWarranty);
    formdata.append("ProductThumbnail", obj.ProductThumbnail);
    formdata.append("strLoginUserId", obj.strLoginUserId);
    formdata.append("strSellingPrice", obj.strSellingPrice);
    formdata.append("strMinQuantity", obj.strMinQuantity);
    formdata.append("strArticleNo", obj.strArticleNo);
    formdata.append("blnFrozenFood", obj.blnFrozenFood);
    formdata.append("fkShopId", obj.fkShopId);
    formdata.append("strCategoryId", obj.strCategoryId);
    formdata.append("specialTag", obj.specialTag);
    formdata.append("strVeg", obj.strVeg);

    if (obj.ProductImages) {
      for (let i = 0; i < obj.ProductImages.length; i++) {
        formdata.append(
          "ProductImages",
          obj.ProductImages[i],
          obj.ProductImages[i].name
        );
      }
    }

    formdata.append("blnPriceVariation", obj.blnPriceVariation),
      formdata.append(
        "arrayAddOnPriceDetails",
        JSON.stringify(obj.arrayAddOnPriceDetails)
      );

      
    formdata.append(
      "arrayColourVariations",
      JSON.stringify(obj.arrayColourVariations)
    );
    
      formdata.append(
        "arraySizeVariations",
        JSON.stringify(obj.arraySizeVariations)
      );

    return this._http
      .post<ApiResponse>(
        this.apiURL + "/api/product/SaveProduct",
        formdata,
        this.commonService.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }

  createDummyProduct(obj) {
    const formdata = new FormData();
    formdata.append("strProductName", obj.strProductName);
    formdata.append("strArabicName", obj.strArabicName);
    formdata.append("strDescription", obj.strDescription);
    formdata.append("strManufacturerDetails", obj.strManufacturerDetails);
    formdata.append("strFeature", obj.strFeature);
    formdata.append("strProductDisclaimer", obj.strProductDisclaimer);
    formdata.append("strBrand", obj.strBrand);
    formdata.append("strProperties", obj.strProperties);
    formdata.append("strSubCategoryId", obj.strSubCategoryId);
    formdata.append("strMoreDetails", obj.strMoreDetails);
    formdata.append("strProductStatus", obj.strProductStatus);
    formdata.append("strUnit", obj.strUnit);
    formdata.append("isInfiniteStock", obj.isInfiniteStock);
    formdata.append("strQuantity", obj.strQuantity);
    formdata.append("intStockQuantity", obj.intStockQuantity);
    formdata.append("strSearchTags", obj.strSearchTags);
    formdata.append("strBarcode", obj.strBarcode);
    formdata.append("strMRP", obj.strMRP);
    formdata.append("strDiscount", obj.strDiscount);
    formdata.append("strMaxQuantity", obj.strMaxQuantity);
    formdata.append("blnCOD", obj.blnCOD);
    formdata.append("blnReturnable", obj.blnReturnable);
    formdata.append("blnFreeDelivery", obj.blnFreeDelivery);
    formdata.append("blnWarranty", obj.blnWarranty);
    formdata.append("ProductThumbnail", obj.ProductThumbnail);
    formdata.append("strLoginUserId", obj.strLoginUserId);
    formdata.append("strSellingPrice", obj.strSellingPrice);
    formdata.append("strMinQuantity", obj.strMinQuantity);
    formdata.append("strArticleNo", obj.strArticleNo);
    formdata.append("blnFrozenFood", obj.blnFrozenFood);
    formdata.append("fkShopId", obj.fkShopId);
    formdata.append("strCategoryId", obj.strCategoryId);
    formdata.append("specialTag", obj.specialTag);
    formdata.append("strVeg", obj.strVeg);

    if (obj.ProductImages) {
      for (let i = 0; i < obj.ProductImages.length; i++) {
        formdata.append(
          "ProductImages",
          obj.ProductImages[i],
          obj.ProductImages[i].name
        );
      }
    }

    formdata.append("blnPriceVariation", obj.blnPriceVariation),
      formdata.append(
        "arrayAddOnPriceDetails",
        JSON.stringify(obj.arrayAddOnPriceDetails)
      );

      
    formdata.append(
      "arrayColourVariations",
      JSON.stringify(obj.arrayColourVariations)
    );
    
      formdata.append(
        "arraySizeVariations",
        JSON.stringify(obj.arraySizeVariations)
      );

    return this._http.post<ApiResponse>(this.commonService.apiURLV4 + "/api/v1/dummyData/product/SaveProduct", obj,
      this.commonService.httpOptions)
      .pipe(retry(2), catchError(this.commonService.handleError));
  }

  departmentListingService() {
    return this._http
      .get<ApiResponse>(
        this.apiURL + "/api/department/listDepartment",
        this.commonService.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }

  categoryListingService(obj) {
    console.log(obj);
    return this._http
      .post<ApiResponse>(
        this.apiURL + "/api/Category/listCategories",
        obj,
        this.commonService.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }

  DummycategoryListingService(obj) {
    console.log(obj);
    return this._http
      .post<ApiResponse>(
        this.apiURL + "api/v1/dummyData/getDefaultCategoryDetails",
        obj,
        this.commonService.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }


  subcategoryListingService(obj) {
    return this._http
      .post<ApiResponse>(
        this.apiURL + "/api/subCategory/listSubCategories",
        obj,
        this.commonService.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }

  DummysubcategoryListingService(obj) {
    return this._http
      .post<ApiResponse>(
        this.apiURL + "api/v1/dummyData/getDefaultSubCategoryDetails",
        obj,
        this.commonService.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }


  brandListingService() {
    return this._http
      .get<ApiResponse>(
        this.apiURL + "/api/brand/listBrands",
        this.commonService.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }
  unitListingService() {
    return this._http
      .get<ApiResponse>(
        this.apiURL + "/api/units/listUnits",
        this.commonService.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }


  // listAllUnitService(obj) {
  // //   console.log('Calling listallunitService with parameters:', obj);
    
  //   return this._http
  //     .get<ApiResponse>(
  //       this.apiURL + "/api/unit/listAllUnit",
  //       this.commonService.httpOptions,
  //     )
  //    .pipe(retry(1), catchError(this.commonService.handleError));
  //  }


  httpOptions = {
    headers: new HttpHeaders({
      Authorization: "bearer" + " " + localStorage.getItem("token"),
    }),
  };

  ImportProductPriceList(objData) {
    return this._http
      .post<ApiResponse>(
        this.apiURL + "/api/product/importProductPriceList",
        objData,
        this.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }

  ImportProductList(objData) {
    return this._http
      .post<ApiResponse>(
        this.apiURL + "/api/product/ImportProductExcel",
        objData,
        this.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }

  ImportProdutCategoryandSubcategory(objData) {
    return this._http
      .post<ApiResponse>(
        this.apiURL +
          "/api/categories/ImportProductCategoryandSubcategoryExcel",
        objData,
        this.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }

  ReportCategoryAndSubCategory() {
    return this._http
      .get<ApiResponse>(
        this.apiURL +
          "/api/categories/GetReportProductCategoryandSubcategoryExcel",
        this.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }

  GetSearchProductData(objData) {
    return this._http
      .post<ApiResponse>(
        this.apiURL + "/api/product/GetAllProductDetails",
        objData,
        this.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }

  updateProductdetails(objData) {
    return this._http
      .post<ApiResponse>(
        this.apiURL + "/api/product/UpdateProductDetails",
        objData,
        this.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }

  updateProductColorimage(objData) {
    return this._http
      .post<ApiResponse>(
        this.apiURL + "/api/product/updateProductColorAndImage",
        objData,
        this.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }

  deleteProductdetails(objData) {
    return this._http
      .post<ApiResponse>(
        this.apiURL + "/api/product/DeleteProductDetails",
        objData,
        this.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }

  downloadCsvFromDB(objData) {
    return this._http
      .post<ApiResponse>(
        this.apiURL + "/api/product/GetAllExcelProductDetails",
        objData,
        this.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }

  UpdateProductOutOfStock(objData) {
    return this._http
      .post<ApiResponse>(
        this.apiURL + "/api/product-excel/UpdateProductOutOfStock",
        objData,
        this.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }

  ImportProductImages(objData) {
    return this._http
      .post<ApiResponse>(
        this.apiURL + "/api/product-excel/UploadProductImagesExcel",
        objData,
        this.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }


  // UnitList() {
  //   return this._http
  //     .get<ApiResponse>(
  //       this.apiURL + "/api/unit/listAllUnit",
  //       this.commonService.httpOptions
  //     )
  //     .pipe(retry(1), catchError(this.commonService.handleError));
  // }


  listAllUnitService(obj) {
    return this._http.
      get<ApiResponse>
      (this.commonService.apiURL + "/api/unit/listAllUnit",
        {
          params: obj
        }
      )
      .pipe(retry(2), catchError(this.commonService.handleError));
  }

  listAllDummyUnitService(obj) {
    return this._http.
      get<ApiResponse>
      (this.commonService.apiURL + "api/v1/dummyData/unit/listUnit",
        {
          params: obj
        }
      )
      .pipe(retry(2), catchError(this.commonService.handleError));
  }


}

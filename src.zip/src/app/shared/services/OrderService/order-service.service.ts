import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { CommonsService } from '../Commons/commons.service';
import { ApiResponse } from '../../Classes/ApiResponse';
import { catchError, retry } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class OrderServiceService {

  private apiURL: string = environment.API_ENDPOINT;

  constructor(private commonService: CommonsService,
              private _http: HttpClient,) { }


  //@FUNCTION TO GET ORDER DETAILS BY MOBILE NUMBER SERVICE

  getUserDetailsByMobService(objData) {
    return this._http.post<ApiResponse>(this.apiURL + "/api/orders/UserBaseOrderDetails",
     objData,
    this.commonService.httpOptions)
      .pipe(retry(1), catchError(this.commonService.handleError));
  }

  getUserDetailsByOrderService(objData) {
    console.log('API URL::::::::::::::::', this.apiURL);

    return this._http.post<ApiResponse>(this.apiURL + "/api/orders/OrderHistory",
    objData,
    this.commonService.httpOptions)
      .pipe(retry(1), catchError(this.commonService.handleError));
  }

  // * +++++++++++++++++++++++++++++ TimeSlot Services +++++++++++++++++++++++++++++ * //

  getAddNewTimeSlotService(objData) {
    return this._http.post<ApiResponse>(this.apiURL + "/api/timeSlot/SaveTimeSlotData",
    objData,
    this.commonService.httpOptions)
    .pipe(retry(1), catchError(this.commonService.handleError));
  }

   getTimeSlotDetailsService(objData) {
    return this._http.post<ApiResponse>(this.apiURL + "/api/timeSlot/getCurrentTimeSlotDetails",
    objData,
    this.commonService.httpOptions)
    .pipe(retry(1), catchError(this.commonService.handleError));
  }
  getEditTimeSlotService(objData) {
    return this._http.post<ApiResponse>(this.apiURL + "/api/timeSlot/updateTimeSlot",
    objData,
    this.commonService.httpOptions)
    .pipe(retry(1), catchError(this.commonService.handleError));
  }

    // * +++++++++++++++++++++++++++++ Customer Order Summary +++++++++++++++++++++++++++++ * //

    getUserCartService(objData) {
      return this._http.post<ApiResponse>(this.apiURL + "/api/user/GetCartDetails",
      objData,
      this.commonService.httpOptions)
      .pipe(retry(1), catchError(this.commonService.handleError));
    }
    getUserOrdersService(objData) {
      return this._http.post<ApiResponse>(this.apiURL + "/api/user/GetAllOrderDetails",
      objData,
      this.commonService.httpOptions)
      .pipe(retry(1), catchError(this.commonService.handleError));
    }
    getUserDetailsService(objData) {
      return this._http.post<ApiResponse>(this.apiURL + "/api/user/GetUserDetailsAndAddress",
      objData,
      this.commonService.httpOptions)
      .pipe(retry(1), catchError(this.commonService.handleError));
    }

}

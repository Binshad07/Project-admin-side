import { TestBed } from '@angular/core/testing';

import { BrandserviceService } from './brandservice.service';

describe('BrandserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BrandserviceService = TestBed.get(BrandserviceService);
    expect(service).toBeTruthy();
  });
});

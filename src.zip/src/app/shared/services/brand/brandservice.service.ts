import { Injectable } from '@angular/core';
import { CommonsService } from '../Commons/commons.service';
import { HttpClient } from '@angular/common/http';
import { ApiResponse } from '../../Classes/ApiResponse';
import { catchError, retry } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class BrandserviceService {

  constructor(
    private http: HttpClient,
    private commonServiceObj: CommonsService
  ) { }

  
  getAllbrands(obj) {
    return this.http.
      get<ApiResponse>
      (this.commonServiceObj.apiURL + "/api/v1/brand/listBrands",
        {
          params: obj
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));

  }

    
  getAllDummybrands(obj) {
    return this.http.
      get<ApiResponse>
      (this.commonServiceObj.apiURL + "/api/v1/dummyData/brand/listBrand",
        {
          params: obj
        }
      )
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));

  }

  deleteAllbrands(obj) {
    return this.http.
      post<ApiResponse>
      (this.commonServiceObj.apiURL + "/api/brand/deleteBrand", obj,
        this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));

  }

  
  addbrand(obj) {
    return this.http.
      post<ApiResponse>
      (this.commonServiceObj.apiURL + "/api/brand/addBrand", 
      obj,
        this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));

  }

  addbranddefault(obj) {
    return this.http.
      post<ApiResponse>
      (this.commonServiceObj.apiURL + "api/v1/dummyData/brand/addBrand", 
      obj,
        this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));

  }


  updatebrand(obj) {
    return this.http.
      post<ApiResponse>
      (this.commonServiceObj.apiURL + "/api/brand/updateBrand", obj,
        this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));

  }

  updatebranddefault(obj) {
    return this.http.
      post<ApiResponse>
      (this.commonServiceObj.apiURL + "api/v1/dummyData/brand/updateDefaultBrand", obj,
        this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));

  }
  OtpLimit(obj) {
    return this.http.
      post<ApiResponse>
      (this.commonServiceObj.apiURL + "/api/user/updateOtpCreditLimit", 
      obj,
        this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));

  }

  createBypassUser(obj) {
    return this.http.
      post<ApiResponse>
      (this.commonServiceObj.apiURL + "/api/v1/vendor/auth/createBypassUser"  , 
      obj,
        this.commonServiceObj.httpOptions)
      .pipe(retry(2), catchError(this.commonServiceObj.handleError));

  }
}

import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
import { CommonsService } from '../Commons/commons.service';
import { environment } from "src/environments/environment";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { ApiResponse } from '../../Classes/ApiResponse';
import { retry } from 'rxjs/operators';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiURL: string = environment.STORE_API_ENDPOINT;

  constructor(
    private _http: HttpClient,
    private commonService: CommonsService
  ) { }
  httpOptions = {
    headers: new HttpHeaders({
      Authorization: "bearer" + " " + localStorage.getItem("token"),
    }),
  };


  /**
   * Signin with mobile
   * author Sreelakshmi Iyer
   * */ 

  
  getOtpMobile(obj) {
    return this._http
      .post<ApiResponse>(
        this.apiURL + "/api/user/sendOTPaddVendor",
        obj,
        this.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }

   /**
   * Signin with mobile
   * author Sreelakshmi Iyer
   * */ 

  
   getOtpEmail(obj) {
    return this._http
      .post<ApiResponse>(
        this.apiURL + "/api/user/sendEmailOTPStore",
        obj,
        this.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }

  /**
   * verify otp with mobile
   * author Sreelakshmi Iyer
   * */ 

  
  verifyMobile(obj) {
    return this._http
      .post<ApiResponse>(
        this.apiURL + "/api/user/verifyOTPaddVendor",
        obj,
        this.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }

  /**
   * verify otp with email
   * author Sreelakshmi Iyer
   * */ 

  
  verifyEmail(obj) {
    return this._http
      .post<ApiResponse>(
        this.apiURL + "/api/user/verifyEmailOTPStore",
        obj,
        this.httpOptions
      )
      .pipe(retry(1), catchError(this.commonService.handleError));
  }
}
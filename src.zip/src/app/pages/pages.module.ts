import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { NgbDropdownModule ,NgbModalModule} from "@ng-bootstrap/ng-bootstrap";
import { ModalModule } from 'ngx-bootstrap/modal';
import { PagesRoutingModule } from "./pages-routing.module";
import { ProductModule } from "./product/product.module";
import { ErrorModule } from "./error/error.module";
import { UIModule } from "../shared/ui/ui.module";
import { DashboardModule } from "./dashboard/dashboard.module";
import { AuthGuardService } from "../shared/services/auth-guard.service";
import { CrmModule } from "./crm/crm.module";
import {AutocompleteLibModule} from 'angular-ng-autocomplete';


//import { ToastrModule } from 'ngx-toastr';
@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    NgbDropdownModule,
    NgbModalModule,
    ProductModule,
    DashboardModule,
    CrmModule,
    PagesRoutingModule,
    UIModule,
    ErrorModule,
    AutocompleteLibModule,
    ModalModule.forRoot()
    //ToastrModule.forRoot()
  ],
  providers: [AuthGuardService],
})
export class PagesModule {}

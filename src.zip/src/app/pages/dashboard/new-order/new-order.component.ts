import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ReportsService } from 'src/app/shared/services/Reports/reports.service';
import { NeworderServiceService } from 'src/app/shared/services/neworder/neworder-service.service';
import { PagerService } from 'src/app/shared/services/pager.service';

@Component({
  selector: 'app-new-order',
  templateUrl: './new-order.component.html',
  styleUrls: ['./new-order.component.scss']
})
export class NewOrderComponent implements OnInit {
  
  arrNewOrders:[] = []
  intSkipCount = 0;
  intPageLimit = 10;
  intTotalCount = 0;
  pager: any = {};
  pageLimit: any[];


  constructor(
    private formBuilder : FormBuilder,
    private neworderService : NeworderServiceService,
    private pageServiceObj: PagerService,
    private router:Router

  ) { }

  ngOnInit() {
    
    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist;

    this.getAllNewUserFn()
  }

  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getAllNewUserFn();
  }


  getAllNewUserFn(){
    let skipCount = this.intSkipCount;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }

    const obj = {
      intSkipCount : skipCount,
      intPageLimit : this.intPageLimit
    }
    if(localStorage.getItem('fkShopId')){
      Object.assign(obj,{fkShopId: localStorage.getItem('fkShopId')})
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.neworderService.getNewOrderList(obj).subscribe((res) => {
      if(res && res.success){
        console.log("Response::::::::::",res)
        this.arrNewOrders = res.data
        this.intTotalCount = res.count
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
      }else{
        this.arrNewOrders = [];
        this.pager = {}
        this.intTotalCount = 0

      }
    })

  }


  onClickNavigate(id:any){
    this.router.navigate(['order-tracking'], {queryParams: {id:id}})
  }
}

import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { HypermarketService } from "./../../../shared/services/Hypermarket/hypermarket.service";

@Component({
  selector: "app-dashboard",
  templateUrl: "./dashboard.component.html",
  styleUrls: ["./dashboard.component.scss"],
})
export class DashboardComponent implements OnInit {
  userPermissions;
  arrDomain = [];
  arrPixel = [];
  arrSettle =[];
  arrRazor =[];
  arrAgency=[];
  arrTicket=[];
  arrRenew=[];
  arrDetails=[];
  arrLeads=[];
  arrOTP=[];

  constructor(private router: Router,
    private hypermarketServiceObj: HypermarketService,
  ) {}

  ngOnInit() {
    this.userRole();
    this.getDomainList();
    this.getPixelList();
    this.getSettleList();
    this.getRazorList();
    this.getAgencyList();
    this.getTicketList();
    this.getRenewList();
    this.getWalletList();
    this.getLeads();
    this.getOTPCOUNT();
  }

  userRole() {
    this.userPermissions = JSON.parse(localStorage.getItem("userPermission"));
    console.log(this.userPermissions);
  }

  navigate(path) {
    if (path === "upload") this.router.navigate(["/product/import-product"]);
    if (path === "details") this.router.navigate(["/product/report-product"]);
    if (path === "edit") this.router.navigate(["/product/update-product"]);
    if (path === "hub") this.router.navigate(["/product/hub-summary"]);
    if (path === "hub-order")
      this.router.navigate(["/product/hub-order-summary"]);
    if (path === "order") this.router.navigate(["/product/order-summary"]);
    if (path === "customer-order-summary")
      this.router.navigate(["/product/customer-order-summary"]);
  }
  onClickNavigate(){
    this.router.navigate['/product/List-Domain']
  }

  getDomainList() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
    }

    this.hypermarketServiceObj.getDomainCount(obj).subscribe((res) => {
      if (res && res.success) { this.arrDomain = [{ data: res.data }]; }

       else {
        this.arrDomain = []
   
      }
    })
  }

  getPixelList() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
    }

    this.hypermarketServiceObj.getPixelCount(obj).subscribe((res) => {
      if (res && res.success) { this.arrPixel = [{ data: res.data }]; }

       else {
        this.arrPixel = []
   
      }
    })
  }

  getSettleList() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
    }

    this.hypermarketServiceObj.getSettleCount(obj).subscribe((res) => {
      if (res && res.success) { this.arrSettle = [{ data: res.data }]; }

       else {
        this.arrSettle = []
   
      }
    })
  }

  getRazorList() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
    }

    this.hypermarketServiceObj.getRazorCount(obj).subscribe((res) => {
      if (res && res.success) { this.arrRazor = [{ data: res.data }]; }

       else {
        this.arrRazor = []
   
      }
    })
  }

  getAgencyList() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
    }

    this.hypermarketServiceObj.getAgencyCount(obj).subscribe((res) => {
      if (res && res.success) { this.arrAgency = [{ data: res.data }]; }

       else {
        this.arrAgency = []
   
      }
    })
  }

  getTicketList() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
    }

    this.hypermarketServiceObj.getTicketCount(obj).subscribe((res) => {
      if (res && res.success) { this.arrTicket = [{ data: res.data }]; }

       else {
        this.arrTicket = []
   
      }
    })
  }

  getRenewList() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
    }

    this.hypermarketServiceObj.getRenewCount(obj).subscribe((res) => {
      if (res && res.success) { this.arrRenew = [{ data: res.data }]; }

       else {
        this.arrRenew = []
   
      }
    })
  }
  getWalletList() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
    }

    this.hypermarketServiceObj.getWallet(obj).subscribe((res) => {
      if (res && res.success) { this.arrDetails = [{ data: res.data }]; }

       else {
        this.arrDetails = []
   
      }
    })
  }
  getLeads() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
    }

    this.hypermarketServiceObj.getWebsiteLeads(obj).subscribe((res) => {
      if (res && res.success) { this.arrLeads = [{ data: res.data }]; }

       else {
        this.arrLeads = []
   
      }
    })
  }

  getOTPCOUNT() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
    }

    this.hypermarketServiceObj.getOTPcount(obj).subscribe((res) => {
      if (res && res.success) { this.arrOTP = [{ data: res.data }]; }

       else {
        this.arrOTP = []
   
      }
    })
  }
}

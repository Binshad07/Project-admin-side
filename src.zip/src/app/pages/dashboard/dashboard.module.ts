import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import {
  NgbDatepickerModule,
  NgbDropdownModule,
  NgbProgressbarModule,
  NgbCollapseModule,
  NgbTooltipModule,
} from "@ng-bootstrap/ng-bootstrap";
// import { NgApexchartsModule } from "ng-apexcharts";
import { ChartsModule } from "ng2-charts";
import { UIModule } from "../../shared/ui/ui.module";
import { DashboardRoutingModule } from "./dashboard-routing.module";
import { DashboardComponent } from './dashboard/dashboard.component';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { OrderDashboardComponent } from './order-dashboard/order-dashboard.component';
import { NewOrderComponent } from './new-order/new-order.component';
@NgModule({
  declarations: [DashboardComponent, UserDashboardComponent, OrderDashboardComponent, NewOrderComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    NgbDropdownModule,
    NgbDatepickerModule,
    NgbProgressbarModule,
    NgbTooltipModule,
    ChartsModule,
    NgbCollapseModule,
    UIModule,
    DashboardRoutingModule,
  ],
})
export class DashboardModule {}

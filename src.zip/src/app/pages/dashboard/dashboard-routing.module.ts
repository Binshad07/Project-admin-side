import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { DashboardComponent } from "./dashboard/dashboard.component";
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { OrderDashboardComponent } from './order-dashboard/order-dashboard.component';
const routes: Routes = [
  {
    path: "",
    redirectTo: "/dashboard",
    pathMatch: "full",
  },
  {
    path: "dashboard",
    component: DashboardComponent,
  },
  {
    path: "userdashboard",
    component: UserDashboardComponent,
  },
  {
    path: "orderdashboard",
    component: OrderDashboardComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DashboardRoutingModule {}

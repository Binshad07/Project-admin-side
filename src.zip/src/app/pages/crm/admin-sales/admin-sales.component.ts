import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { PagerService } from "src/app/shared/services/pager.service";
import { UserService } from "src/app/shared/services/user.service";
import { ReportsService } from "src/app/shared/services/Reports/reports.service";
import { DatePipe } from "@angular/common";
import { environment } from "src/environments/environment";
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-sales',
  templateUrl: './admin-sales.component.html',
  styleUrls: ['./admin-sales.component.scss']
})
export class AdminSalesComponent implements OnInit {
  userDetailsArray = [];
  formUserDetails: FormGroup;
  currentDate = new Date();
  pager: any = {};
  intTotalCount = 0;
  intSkipCount = 0;
  intPageLimit = 10;
  arrStores = [];
  datePipe = new DatePipe("en-US");
  pageLimit: any[];
  fromDate;
  toDate;
  private apiURL: string = environment.API_ENDPOINT;
  userType: string;

  constructor(
    private userService: UserService,
    private pageServiceObj: PagerService,
    private reportServiceObj: ReportsService,
    private formBuilder: FormBuilder,
    private router: Router,
    private userServ: UserService
  ) { }

  ngOnInit() {
    this.formUserDetails = this.formBuilder.group({
      txtFromDate: [""],
      txtToDate: [""],
      statusFilter: [""],
      drpPageLimit: "10",
    });
    this.userType=localStorage.getItem("strUserType");
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getShopListingFn();
    this.getUserData();
  }

  _clearForm(form: FormGroup) {
    form.reset({
      txtFromDate: "",
      txtToDate: "",
      statusFilter: "",
      drpPageLimit: "10",
    });
    this.intTotalCount = 0;
    this.intSkipCount = 0;
    this.intPageLimit = 10;
    console.log('Form::::::', this.formUserDetails.value);
    this.refreshPage();
  }
  _getPageLimit() {
    this.intPageLimit = parseInt(this.formUserDetails.value.drpPageLimit);
    this.setPage(1);
  }
  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getUserData();
  }

  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.getUserData();
  }

  getShopListingFn() {
    this.reportServiceObj.getShopListingService().subscribe((res) => {
      this.arrStores = res.data;
    });
  }

  getUserData() {
    let skipCount = this.intSkipCount;

    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }

    if (
      this.formUserDetails.value.txtFromDate &&
      this.formUserDetails.value.txtToDate
    ) {
      this.fromDate = `${this.formUserDetails.value.txtFromDate.year}-${this.formUserDetails.value.txtFromDate.month}-${this.formUserDetails.value.txtFromDate.day}`;
      this.toDate = `${this.formUserDetails.value.txtToDate.year}-${this.formUserDetails.value.txtToDate.month}-${this.formUserDetails.value.txtToDate.day}`;
    }
    if (
      this.formUserDetails.value.txtPhoneNumber === null ||
      this.formUserDetails.value.txtPhoneNumber === undefined
    ) {
      this.formUserDetails.value.txtPhoneNumber = "";
    }
    const obj = {
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
      fromDate: this.fromDate, // fromDate,
      toDate: this.toDate, // toDate,
      statusFilter: this.formUserDetails.value.statusFilter,
    };
    if(localStorage.getItem('fkShopId')){
      Object.assign(obj,{fkShopId: localStorage.getItem('fkShopId')})
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    console.log('User Details Object::::::', obj);

    this.userService.listAdminSales(obj).subscribe((res) => {


      this.userDetailsArray = res.data[1];
      if (res.data[0]) {
        this.intTotalCount = res.data[0].totalCount;
      }
      this.pager = this.pageServiceObj.getPager(
        this.intTotalCount,
        this.pager.currentPage,
        this.intPageLimit
      );
    });
  }


  refreshPage() {
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    this.router.onSameUrlNavigation = 'reload';
    this.router.navigate(['/product/user-details']);
  }
}

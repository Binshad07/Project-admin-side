import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup ,Validators} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { log } from 'console';
import { DatePipe } from "@angular/common";
// import { FranchiseService } from 'src/app/shared/services/franchise/franchise.service';
import { PagerService } from 'src/app/shared/services/pager.service';
import { ShopServiceService } from 'src/app/shared/services/shopService/shop-service.service';
// import { RentalService } from 'src/app/shared/services/rental/rental.service';
import Swal from "sweetalert2";
import { CompanyServiceService } from 'src/app/shared/services/company/company-service.service';
import { HypermarketService } from "./../../../shared/services/Hypermarket/hypermarket.service";
import { environment } from "./../../../../environments/environment.prod";
@Component({
  selector: 'app-list-shop',
  templateUrl: './list-shop.component.html',
  styleUrls: ['./list-shop.component.scss']
})
export class ListShopComponent implements OnInit {
  frmFilterShop: FormGroup
  myform:FormGroup
  arrRentalItem: any[] = []
  pager: any = {};
  intTotalCount = 0;
  intPageLimit = 10;
  pageLimit: any[];
  clicked = false;
  blnLoader = true;
  intSkipCount = 0;
  arrayOfObjFranchiseList: any[] = []
  arrShops: any[] = []
  strShopId: ""
  storeUrl:""
  arrViewType = [];
  arrCompany:any[] = []
  userType: string;
  currentDate = new Date();
  datePipe = new DatePipe("en-US");
  singledata: any;
  submitted = true;
  ShopUpdates:""
  strurl:""
  isIOS: boolean = true;  // Initially disable the iOS input field
  isAndroid: boolean = true;  // Initially disable the Android input field
  strIosUrl:""
  webUrl:"";
  iosUrl:"";
  androidUrl:"";
  blnIOsStatus:"";
  blnAndroidStatus:"";
  strEmail:"";
  pkShopId:"";
  id:any;
  private apiURLV4: string = environment.API_ENDPOINT_1;
  // isWebChecked: boolean = false;
  // blnAndroidStatus:boolean=false
  blnWebStatus:boolean = false;
  isDomainConnected:"";
  // domainUrl:"";
  blnDownloadLoader = false;
  device: any;
  constructor(
    private formbuilder: FormBuilder,
    private pageServiceObj: PagerService,
    private modalService: NgbModal,
    private router: Router,
    private route: ActivatedRoute,
    private shopService: ShopServiceService,
    private hypermarketServiceObj: HypermarketService,
    private companyService: CompanyServiceService
  ) { }

  ngOnInit() {
    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist;

    this.frmFilterShop = this.formbuilder.group({
      strShopName: ["",],
      strEmail: ["",],
      strPlanType: ["",],
      strViewType: ["",],
      cmbShopName: ["",],
      storeUrl:"",
     

    })
    this.myform = this.formbuilder.group({
      strShopName: ["",],
      // strEmail: ["",],
      // strPlanType: ["",],
      // strViewType: ["",],
      cmbShopName: ["",],
      storeUrl:["",],
      blnAndroidStatus: [""],
      blnIOsStatus:[""],
      // domainUrl:["",Validators.required],
      strEmail:"",
      pkShopId:"",
      strIosUrl:["",],
      
      // blnAndroidStatus: [false],
      isDomainConnected:["",],

    })
    this.userType=localStorage.getItem("strUserType");
    this.fnGetAllShopes();
    this.getViewTypeFn();
    // this.getShopSearchData(); 
    this.getAllCompany(); 
  }
  getViewTypeFn() {
    const obj = {};
    if (localStorage.getItem("strUserType") == "SHOP REPORTER") {
      Object.assign(obj, {
        strViewTypeName: localStorage.getItem("strViewType"),
      });
    }
    this.hypermarketServiceObj.getVieType(obj).subscribe((res) => {
      console.log(res, "resssviwetype");
      this.arrViewType = res.data;
      console.log(this.arrViewType, "console");
    });
  }
  get formControls() {
    return this.myform.controls;
  }
  get f() {
    return this.myform.controls;
  }
  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.fnGetAllShopes();
    this.getViewTypeFn();

    // this.getdummyDefaultCategoryDetails();
  }
  _onClear(frmFilterShop: FormGroup) {
    frmFilterShop.reset({
      strViewType: "",
    });
    this.fnGetAllShopes();
  }
  
  getAllCompany(){
    const obj = {
      strLoginUserId:localStorage.getItem("userId"),
    }
    if(localStorage.getItem('fkShopId')){
      // Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallShop(obj).subscribe((res) => {
      if(res && res.success){
        this.arrCompany = res.data
      }
    },(err) => {
      console.log(err)
    })
  }

  openStoreUrl(storeUrl: string | undefined) {
    if (storeUrl) {
      window.open(storeUrl, '_blank');
    }
  }
  fnGetAllShopes() {


    let skipCount = this.intSkipCount;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }


    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
      strSkipCount: skipCount,
      strPageLimit: this.intPageLimit,
      strShopName: this.frmFilterShop.value.strShopName,
      //  pkShopId: this.frmFilterShop.value.strShopName, //this.strShopId, // this.strShopId

      strEmail: this.frmFilterShop.value.strEmail,
      planType: this.frmFilterShop.value.strPlanType,
      strViewType: this.frmFilterShop.value.strViewType,
      // storeUrl:this.frmFilterShop.value.strurl


      
    }
    if(localStorage.getItem('fkShopId')){
      Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }    

    this.shopService.getAllShops(obj).subscribe((res) => {
    if (res.success) {
        this.arrShops = res.data;
         this.intTotalCount = res.count;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
       
      } else {
        // Swal.fire({
        //   title: "error",
        //   text: res.message,
        //   icon: "error",
        //   confirmButtonText: "Ok",
        // });
        this.arrShops = [];
        this.pager = {};
        this.intTotalCount = 0;
        // this.spinner.hide();
      }
    }, (err) => {
      console.log(err)
    })
  }

  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.fnGetAllShopes();
  }

  modalExtendList(modalExtend, item) {
    this.singledata = item
    this.modalService.open(modalExtend, {
      centered: true,
      windowClass: 'modal-product-delete',
    });
  }

  modalExtendstatus(modalExtend1, item,device ) {
    this.singledata = item
    console.log(item);
    this.device = device 
    console.log(device)
    this.modalService.open(modalExtend1, {
      centered: true,
      windowClass: 'modal-product-delete'
    
      
    });
    this.myform.patchValue({ storeUrl: item.storeUrl });
    this.myform.patchValue({ blnAndroidStatus: item.strAndroidUrl });

    this.myform.patchValue({ isDomainConnected: item.domainConnectedUrl });
    this.myform.patchValue({ blnIOsStatus: item.strIosUrl });

    this.myform.patchValue({ pkShopId: item.pkShopId });
    this.myform.patchValue({ strEmail: item.strEmail });
   

    // this.frmCategoryEdit.patchValue({ intSortNo: objType.intSortNo });

  }


  downloadCSV(){
    this.blnDownloadLoader = !this.blnDownloadLoader;
    const obj = {
      strShopName: this.frmFilterShop.value.cmbShopName,
      strEmail: this.frmFilterShop.value.strEmail,
      planType: this.frmFilterShop.value.strPlanType,
      strViewType: this.frmFilterShop.value.strViewType,
      strDataType: "EXCEL",
    };
    if(localStorage.getItem('fkShopId')){
      Object.assign(obj,{fkShopId: localStorage.getItem('fkShopId')})
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.hypermarketServiceObj.getAllShopExcel(obj).subscribe(res => {
      this.blnDownloadLoader = !this.blnDownloadLoader;
      const strPath = this.apiURLV4 + '/' + res.data;
      window.location.href = strPath;
    });
  }

  
 
  
//   updateurl() {
//     this.submitted = true;
//     // if (this.myform.invalid) {
//     //   return;
//     // }
  
//     // Create an object to hold the data to be updated
//     const obj: any = {
   
   
//   strLoginUserId: localStorage.getItem("userId"), // Replace with dynamic user ID if needed
//         pkShopId: this.myform.value.pkShopId,
//       // strEmail: this.myform.value.strEmail,
//       //  storeUrl:this.myform.value.storeUrl,
//       //  strAndroidUrl:this.myform.value.blnAndroidStatus,
//       //  strIosUrl:this.myform.value.strIosUrl,
//       // domainConnectedUrl:this.myform.value.isDomainConnected,
 
// };


// if(this.device=='web' && this.myform.value.storeUrl){
//   obj.blnWebStatus=true
//   obj.storeUrl=this.myform.value.storeUrl
// }
// else if (this.device=='android' && this.myform.value.blnAndroidStatus){
//   obj.blnAndroidStatus=true
//   obj.strAndroidUrl=this.myform.value.blnAndroidStatus
// }
// else if (this.device=='ios' && this.myform.value.strIosUrl){
//   obj.blnIOsStatus=true
//   obj.strIosUrl=this.myform.value.strIosUrl
// }
// else if(this.device=='domain' && this.myform.value.isDomainConnected){
//   obj.isDomainConnected=true
//   obj.domainConnectedUrl=this.myform.value.isDomainConnected
// }
// else{
//   Swal.fire({
//     title: "warning",
//     text: 'URL missing ',
//     icon: "warning",
//     confirmButtonText: "Ok",
//   });
// }
//     console.log(obj, "Updated Object");
  
//     // Call the service to update the URL
//     this.companyService.updateurl(obj).subscribe(
//       (res) => {
//         console.log(res);
//         if (res.success === true) {
//           this.clicked = false;
//           this.blnLoader = true;
//           Swal.fire({
//             title: "Saved!",
//             text: "URL Updated Successfully",
//             icon: "success",
//             confirmButtonText: "Ok",
//           }).then(() => {
//             this.fnGetAllShopes();



            
//             this.modalService.dismissAll();
//           });
//         } else {
//           Swal.fire({
//             title: "Error",
//             text: res.message,
//             icon: "error",
//             confirmButtonText: "Ok",
//           });
//         }
//       },
//       (err) => {
//         console.log(err);
//       }
//     );
//   }
  
updateurl() {
  this.submitted = true;
  
  // Create an object to hold the data to be updated
  const obj: any = {
      strLoginUserId: localStorage.getItem("userId"), // Replace with dynamic user ID if needed
      pkShopId: this.myform.value.pkShopId,
  };

  let isUrlProvided = false;

  if (this.device == 'web' && this.myform.value.storeUrl) {
      obj.blnWebStatus = true;
      obj.storeUrl = this.myform.value.storeUrl;
      isUrlProvided = true;
  } else if (this.device == 'android' && this.myform.value.blnAndroidStatus) {
      obj.blnAndroidStatus = true;
      obj.strAndroidUrl = this.myform.value.blnAndroidStatus;
      isUrlProvided = true;
  } else if (this.device == 'ios' && this.myform.value.strIosUrl) {
      obj.blnIOsStatus = true;
      obj.strIosUrl = this.myform.value.strIosUrl;
      isUrlProvided = true;
  } else if (this.device == 'domain' && this.myform.value.isDomainConnected) {
      obj.isDomainConnected = true;
      obj.domainConnectedUrl = this.myform.value.isDomainConnected;
      isUrlProvided = true;
  }

  if (!isUrlProvided) {
      Swal.fire({
          title: "Warning",
          text: 'Please enter a valid URL.',
          icon: "warning",
          confirmButtonText: "Ok",
      });
      return; // Stop further execution if no URL is provided
  }

  console.log(obj, "Updated Object");
  
  // Call the service to update the URL
  this.companyService.updateurl(obj).subscribe(
      (res) => {
          console.log(res);
          if (res.success === true) {
              this.clicked = false;
              this.blnLoader = true;
              Swal.fire({
                  title: "Saved!",
                  text: "URL Updated Successfully",
                  icon: "success",
                  confirmButtonText: "Ok",
              }).then(() => {
                  this.fnGetAllShopes();
                  this.modalService.dismissAll();
              });
          } else {
              Swal.fire({
                  title: "Error",
                  text: res.message,
                  icon: "error",
                  confirmButtonText: "Ok",
              });
          }
      },
      (err) => {
          console.log(err);
      }
  );
}

 
  
}





  
        
        
        
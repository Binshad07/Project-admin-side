import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { InfiniteScrollModule } from "ngx-infinite-scroll";
//import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import {
  NgbDatepickerModule,
  NgbTimepickerModule,
  NgbDropdownModule,
  NgbProgressbarModule,
  NgbCollapseModule,
  NgbTooltipModule,
} from "@ng-bootstrap/ng-bootstrap";
import { ChartsModule } from "ng2-charts";
import { CrmRoutingModule } from './crm-routing.module';
import { ListShopComponent } from './list-shop/list-shop.component';
import { UIModule } from 'src/app/shared/ui/ui.module';
import { AdminSalesComponent } from './admin-sales/admin-sales.component';

@NgModule({
  declarations: [ListShopComponent, AdminSalesComponent],
  imports: [
    CommonModule,
    CrmRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    NgbDropdownModule,
    NgbDatepickerModule,
    NgbTimepickerModule,
    NgbProgressbarModule,
    NgbTooltipModule,
    ChartsModule,
    NgbCollapseModule,
    UIModule,
    InfiniteScrollModule,
  ]
})
export class CrmModule { }

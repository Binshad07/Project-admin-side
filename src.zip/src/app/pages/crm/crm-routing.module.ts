import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListShopComponent } from './list-shop/list-shop.component';
import { AdminSalesComponent } from './admin-sales/admin-sales.component';

const routes: Routes = [
  {
    path: "crm/leads",
    component: ListShopComponent,
  },
  {
    path: "crm/admin-sales",
    component: AdminSalesComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CrmRoutingModule { }

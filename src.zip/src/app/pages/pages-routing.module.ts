import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { Error404Component } from "./error/error404/error404.component";
import { AuthGuardService } from '../shared/services/auth-guard.service';

const routes: Routes = [
  {
    path: "",
    redirectTo: "/dashboard",
    pathMatch: "full",
  },
  {
    path: "dashboard",
    loadChildren: () =>
      import("./dashboard/dashboard.module").then((m) => m.DashboardModule),
    canActivate: [AuthGuardService],
  },

 
  {
    path: "product",
    loadChildren: () =>
      import("./product/product.module").then((m) => m.ProductModule),
    canActivate: [AuthGuardService],
  },
  {
    path: "assetkit",
    loadChildren: () =>
      import("./assetkit/assetkit.module").then((m) => m.AssetkitModule),
    canActivate: [AuthGuardService],
  },
  {
    path: "**",
    component: Error404Component,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PagesRoutingModule { }

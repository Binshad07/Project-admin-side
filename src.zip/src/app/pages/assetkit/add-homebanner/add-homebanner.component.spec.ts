import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddHomebannerComponent } from './add-homebanner.component';

describe('AddHomebannerComponent', () => {
  let component: AddHomebannerComponent;
  let fixture: ComponentFixture<AddHomebannerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddHomebannerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddHomebannerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

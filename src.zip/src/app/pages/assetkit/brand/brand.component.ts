import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import Swal from "sweetalert2";
import { PagerService } from "./../../../shared/services/pager.service";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { BrandserviceService } from "src/app/shared/services/brand/brandservice.service";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";
import { HypermarketService } from "./../../../shared/services/Hypermarket/hypermarket.service";

export interface modType {
  strName?: any;
}

export interface modShop {
  fkShopId?: any;
}

@Component({
  selector: 'app-brand',
  templateUrl: './brand.component.html',
  styleUrls: ['./brand.component.scss']
})
export class BrandComponent implements OnInit {
  myform: FormGroup;
  submitted: boolean = false;
  intSkipCount = 0;
  pager: any = {};
  intPageLimit = 10;
  pageLimit: any[];
  intTotalCount = 0;
  strTypelId = "";
  arrbrands: modType[] = [];
  arrShops: modShop[] = [];
  frmTypeEdit: FormGroup;
  editSubmitted: boolean = false;
  router: any;
  arrViewType: [];
  arrbrand: [];
  isAdmin = true;
  pkBrandId: any;

  constructor(
    private pageServiceObj: PagerService,
    private formBuilder: FormBuilder,
    private brandService: BrandserviceService,
    // private spinner: NgxSpinnerService,
    // private spinnerObj: NgxSpinnerService,
    private modalService: NgbModal,
    private companyService: CompanyServiceService,
    private hypermarketServiceObj: HypermarketService,
  ) { }

  ngOnInit() {
    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.myform = this.formBuilder.group({
      brandName: ["", Validators.required],
      strViewType: ["", Validators.required],
    });
    this.frmTypeEdit = this.formBuilder.group({
      brandName: ["", Validators.required],
      // strViewType: ["", Validators.required],
    });
    // this.pageLimit = this.pageServiceObj.showPagelist;
    this.ListBrand();
    this.getDefaultDepartment();
    this.getNewDefaultDepartment();
    this.getViewtype;
  }

  _deleteType(responsiveDelete, item) {
    this.pkBrandId = item.pkBrandId;
    this.modalService.open(responsiveDelete);
  }

  _getPageLimit(value$) {
    this.intPageLimit = parseInt(value$);
    this.setPage(1);
  }

  pkDepartmentId: any
  getDefaultDepartment() {
    const obj = {};
    if (localStorage.getItem("strUserType") == "SHOP REPORTER") {
      Object.assign(obj, {
        strViewTypeName: localStorage.getItem("strViewType"),
      });
    }
    this.hypermarketServiceObj.getDefaultDepartment(obj).subscribe((res) => {
      console.log(res, "resssviwetype");
      this.arrViewType = res.data;
      this.pkDepartmentId = res.data[0].pkDepartmentId
      console.log(this.arrViewType, "console", this.pkDepartmentId);
      this.setDefaultViewType(this.arrViewType);
      this.ListBrand();
    });
  }
  setDefaultViewType(viewType) {
    if (!this.isAdmin) {
      const firstOptionValue = viewType[0].strName;
      this.myform.get("strViewType").setValue(firstOptionValue);
    }
  }


  getNewDefaultDepartment() {
    const obj = {};
    if (localStorage.getItem("strUserType") == "SHOP REPORTER") {
      Object.assign(obj, {
        strViewTypeName: localStorage.getItem("strViewType"),
      });
    }
    this.hypermarketServiceObj.getDefaultDepartment(obj).subscribe((res) => {
      console.log(res, "resssviwetype");
      this.arrbrand = res.data;
      this.pkDepartmentId = res.data[0].pkDepartmentId

      this.setnewDefaultViewType(this.arrbrand);
      this.ListBrand();
    });
  }
  setnewDefaultViewType(viewType) {
    if (!this.isAdmin) {
      const firstOptionValue = viewType[0].strName;
      this.myform.get("strViewType").setValue(firstOptionValue);
    }
  }





  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.ListBrand();
  }

  get formControlsEdit() {
    return this.frmTypeEdit.controls;
  }

  strViewType: any
  pkDeptId: any
  getViewtype(strViewType) {
    this.strViewType = strViewType;
    console.log(strViewType, "rtgyuhj")
    let selectedObject: any = this.arrbrand.find((obj: any) => obj.pkDepartmentId === strViewType);
    console.log(this.arrbrand, "ggggg")

    // If object is found, you can access both name and ID
    if (selectedObject) {
      this.strViewType = selectedObject.strViewType;
      this.pkDeptId = strViewType;
    }
    console.log(this.strViewType, "tyfdgh")

    // console.log(selectedObject.strName,"hgfds")
  }


  AddBrand() {
    this.submitted = true;
    if (this.myform.invalid) {
      return;
    }
    const obj = {
      // strLoginUserId: this.myform.value.brandName,
      strName: this.myform.value.brandName,
      strViewType: this.myform.value.strViewType,
      strLoginUserId: "5e93363f66c497c2bb08f357",
      fkDepartmentId: this.pkDeptId
    };
    console.log(obj, "testttttt");
    this.hypermarketServiceObj.getSavedummyBrand(obj).subscribe((res) => {
      console.log(res);
      if (res.success === true) {


        // if (res && res.success) {
        // this.clicked = false;
        // this.spinner.hide();
        Swal.fire({
          title: "Saved!",
          text: "Brand Saved Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then(() => {
          this.myform.reset();
          this.submitted = false;
          this.ngOnInit();
          // this.router.navigate(["/list-brand"]);
          this.router.navigate(['/list-brand'])

        });
      } else {
        // this.spinner.hide();
        Swal.fire({
          title: "Warning",
          text: res.message,
          icon: "warning",
          confirmButtonText: "Ok",
        });
      }
    },
      (err) => {
        console.log(err);
      }
    );
  }

  _onClear() {
    this.submitted = false;
    this.myform.reset();
    this.ngOnInit();
  }



  get f() {
    return this.myform.controls;
  }

  ListBrand() {
    let skipCount = this.intSkipCount;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }

    const obj = {
      // fkDepartmentId:this.pkDepartmentId,
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
    };
    console.log(obj, "gsgsgsgsgs")
    // this.spinner.show()
    this.hypermarketServiceObj.getAllDummybrands(obj).subscribe((res) => {
      console.log(" repsonse::", res);
      if (res.success) {
        this.intTotalCount = res.data[0].intTotalCount;
        this.arrViewType = res.data[1];
        // this.strCategoryId=
        // this.intTotalCount = res.count;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
      } else {
        // this.spinner.hide();
        this.arrViewType = [];
      }
    },
      (err) => {
        // this.spinner.hide();
        // Swal.fire({
        //   title: "Error",
        //   text: "Something went wrong! Please try again",
        //   icon: "error",
        //   confirmButtonText: "Ok",
        // });
        console.log(err);
      }
    );
  }

  deleteType() {
    // this.spinnerObj.show();
    const obj = {
      strLoginUserId: "5e93363f66c497c2bb08f357",
      pkBrandId: this.pkBrandId,
    };

    this.hypermarketServiceObj.deleteDefaultBrand(obj).subscribe((res) => {
      if (res.success === true) {
        Swal.fire({
          title: "Deleted!",
          text: "Brand has been deleted Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then((result) => {
          if (result.value) {
            // this.spinnerObj.hide();
            this.modalService.dismissAll();
            this.ListBrand();
          }
        });
      } else {
        Swal.fire({
          title: "Error",
          text: res.message,
          icon: "error",
          confirmButtonText: "Ok",
        });
        // this.spinnerObj.hide();
      }
      this.ListBrand();
    });
  }

  _getEditType(responsiveData, objType) {
    this.strTypelId = objType.pkBrandId;
    this.modalService.open(responsiveData);
    this.frmTypeEdit.patchValue({ brandName: objType.strName });
    this.frmTypeEdit.patchValue({ strViewType: objType.strViewType });
  }

  getUpdateTypeFn() {
    this.editSubmitted = true;
    if (this.frmTypeEdit.invalid) {
      return;
    }
    // this.spinnerObj.show();
    const obj = {
      strLoginUserId: "5e93363f66c497c2bb08f357",
      strName: this.frmTypeEdit.value.brandName,
      // strViewType: this.frmTypeEdit.value.strViewType,
      // fkDepartmentId: this.pkDepartmentId,
      pkBrandId: this.strTypelId,
      fkDepartmentId:this.pkDepartmentId
      // fkShopId: localStorage.getItem('shopId'),
    };


    this.hypermarketServiceObj
      .getUpdatedefaultBrand(obj)
      .subscribe((res) => {

        if (res.success === true) {
          // this.spinnerObj.hide();
          Swal.fire({
            title: "Updated!",
            text: " Brand has been Updated Sucessfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then((result) => {
            if (result.value) {
              this.modalService.dismissAll();
            }
          });
        } else {
          Swal.fire({
            title: "Warning",
            text: "Brand With Same Name Exist",
            icon: "warning",
            confirmButtonText: "Ok",
          }).then((result) => {
            if (result.value) {
              this.modalService.dismissAll();
            }
          });
          // this.spinnerObj.hide();
        }
        this.ListBrand();
      });
  }
}
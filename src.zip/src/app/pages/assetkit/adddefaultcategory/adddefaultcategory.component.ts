// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-adddefaultcategory',
//   templateUrl: './adddefaultcategory.component.html',
//   styleUrls: ['./adddefaultcategory.component.scss']
// })
// export class AdddefaultcategoryComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }

import { Component, OnInit } from '@angular/core';
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { PagerService } from "src/app/shared/services/pager.service";
import { Router } from "@angular/router";
import Swal from "sweetalert2";
import { FormGroup, FormBuilder } from "@angular/forms";
import { BannersService } from 'src/app/shared/services/Banner/banners.service';
import { HypermarketService } from "./../../../shared/services/Hypermarket/hypermarket.service";
import { Validators } from "@angular/forms";

@Component({
  selector: 'app-adddefaultcategory',
  templateUrl: './adddefaultcategory.component.html',
  styleUrls: ['./adddefaultcategory.component.scss']
})
export class AdddefaultcategoryComponent implements OnInit {


  intTotalCount = 0;
  frmCategory: FormGroup;
  frmCategoryEdit: FormGroup
  // myform: FormGroup;
  intSkipCount = 0;
  pageLimit: any[];
  intPageLimit = 10;
  pager: any = {};
  arrHomeBanner = [];
  strBannerImageId = "";
  showModal: boolean;
  strSelectedImg: string;
  strSelectedImageType: string;
  objSelectedItem: any;
  pkImageId: any;
  isAdmin = true;
  arrcategory = [];
  arrOfCategoryList = [];
  arrViewType: [];
  strName: "";
  id: any;
  strArabicName: ""
  // strCategoryId = "";
  // intSort: "";
  intSortNo:""
  strSortCount:""
  // editSubmitted:  false;
  strImageUrl: ""
  txtDescription: ""
  blnLoader = false;
  // submitted: boolean = false;
  submitted : boolean = false;
  clicked = false;
  strCategoryId: any;
  categoryImg: File[] = [];
  pkCategoryId: any
  //  blnStatus: true


  constructor(

    private pageServiceObj: PagerService,
    private modalService: NgbModal,


    private router: Router,
    private formBuilder: FormBuilder,
    private BannerService: BannersService,
    private hypermarketServiceObj: HypermarketService,


  ) { }

  ngOnInit() {
    // blnStatus: [true]
    strName:

    this.frmCategory = this.formBuilder.group({

      strViewType: ["", Validators.required],
      strImageUrl: ["",Validators.required],
      intSort: ["",],
      strArabicName: ["", Validators.required],
      strName: ["", Validators.required],
      txtImageUrl: ["",],
      txtDescription: "",
      strCategoryName: ["",],
      pkCategoryId: "",
      blnStatus: [true],
      pkDepartmentId: "",
      strSortCount: ""


    });


    this.frmCategoryEdit = this.formBuilder.group({
      strName: "",
      arabicName: "",
      txtDescription: '',
      strImageUrl: "",
      // blnStatus: "",
      strViewType: "",
      intSortNo: "",
      txtImageUrl: "",
      // strSortCount: ""

      // fkShopId: [""],
    });


    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist
    this.getDefaultDepartment();

  }





  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getDefaultDepartment();
    this.getDefaultCategoryDetails();


  }




  // _onSearch() {
  //   this.pager = {};
  //   this.intTotalCount = 0;
  //   this.getDefaultDepartment();
  //   this.getDefaultCategoryDetails();


  // }



  // _onClear(form: FormGroup) {
  //   form.reset({
  //     //   strViewType: "",
  //     // this.submitted = false;

  //     strName: "",
  //     arabicName: "",
  //     txtDescription: '',
  //     strImageUrl: "",
  //     blnStatus: "",
  //     strViewType: "",
  //     intSortNo: "",
  //     txtImageUrl: "",


  //   });
  //   this.getDefaultDepartment();
  // }






  
  _onClear() {
    this.submitted=false;
this.frmCategory.reset();
this.ngOnInit();
    // this.getDefaultDepartment();
    this.getDefaultCategoryDetails();
  }
  pkDepartmentId: any
  getDefaultDepartment() {
    const obj = {};
    if (localStorage.getItem("strUserType") == "SHOP REPORTER") {
      Object.assign(obj, {
        strViewTypeName: localStorage.getItem("strViewType"),
      });
    }
    this.hypermarketServiceObj.getDefaultDepartment(obj).subscribe((res) => {
      console.log(res, "resssviwetype");
      this.arrViewType = res.data;
      this.pkDepartmentId = res.data[0].pkDepartmentId
      console.log(this.arrViewType, "console", this.pkDepartmentId);
      this.setDefaultViewType(this.arrViewType);
      this.getDefaultCategoryDetails();
    });
  }



  setDefaultViewType(viewType) {
    if (!this.isAdmin) {
      const firstOptionValue = viewType[0].strName;
      this.frmCategory.get("drpViewType").setValue(firstOptionValue);
    }
  }

  getDefaultCategoryDetails() {

    let skipCount = this.intSkipCount;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
    const obj = {
      strLoginUserId: localStorage.getItem('userId'),
      // fkDefaultDepartmentId:this.frmCategory.value.strViewType,
      // fkDefaultDepartmentId: this.frmCategory.value.strViewType ? this.frmCategory.value.strViewType : (this.pkDepartmentId ? this.pkDepartmentId : ""),
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,

    };
    console.log(obj, "list banner obj::::::::::::::::::::");

    this.hypermarketServiceObj.getDefaultCategoryDetails(obj).subscribe((res) => {
      // console.log("Banners", res);
      // this.spinner.hide();
      if (res.success) {
        // this.spinner.hide();
        this.intTotalCount = res.data[0].intTotalCount;
        this.arrcategory = res.data[1];
        // this.intTotalCount = res.count;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
      } else {
        this.arrcategory = [];

      }
    });
  }




  errorImage(event) {
    // event.target.src = 'assets/images/Group 4024 (1).png';
  }



  _getEditType(responsiveData, objType) {
    console.log(objType);
    this.modalService.open(responsiveData);
    this.strCategoryId = objType.pkCategoryId;
    this.frmCategoryEdit.patchValue({ strName: objType.strName });
    this.frmCategoryEdit.patchValue({ arabicName: objType.strArabicName });
    this.frmCategoryEdit.patchValue({ txtDescription: objType.strDescription });
    this.frmCategoryEdit.patchValue({ txtImageUrl: objType.strImageUrl });
    this.frmCategoryEdit.patchValue({ txtType: objType.strType });
    this.frmCategoryEdit.patchValue({ intSortNo: objType.intSortNo });
    // this.frmCategoryEdit.patchValue({ intSortNo: objType.intSortNo });



  }


  _getDeleteModal(responsiveDelete, id) {
    this.strCategoryId = id;
    this.modalService.open(responsiveDelete);
  }








  deleteDefaultCategoryDetails() {

    const obj = {
      strLoginUserId: localStorage.getItem("userId"),

      "strCategoryId": this.strCategoryId.pkCategoryId


    };
    console.log(obj, "objjjjjjjj");

    this.hypermarketServiceObj.deleteDefaultCategoryDetails(obj).subscribe((res) => {
      if (res.success === true) {
        Swal.fire({
          title: "Deleted!",
          text: "Category has been deleted Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then((result) => {
          if (result.value) {
            // this.spinnerObj.hide();
            this.ngOnInit();
            this.modalService.dismissAll();
          }
        });
      } else {
        Swal.fire({
          title: "Error",
          text: res.message,
          icon: "error",
          confirmButtonText: "Ok",
        });
        // this.spinnerObj.hide();
      }
      this.getDefaultCategoryDetails();
    });
  }
  hide() {
    this.showModal = false;
  }
  show() {
    this.showModal = true;
  }

  onClickViewImg(item, image, type) {
    this.objSelectedItem = item;
    this.strSelectedImg = image;
    this.strSelectedImageType = type;
    this.show();
  }

  getUpdateTypeFn() {


    this.blnLoader = false;
    this.submitted = false;

    if (this.frmCategoryEdit.invalid) {
      this.blnLoader = true;
      return;
    }
    let fData = new FormData();

    fData.append("strCategoryId", this.strCategoryId)


    fData.append("strArabicName", this.frmCategoryEdit.value.arabicName);

    fData.append("strLoginUserId", localStorage.getItem("userId"));

    fData.append("strDescription", this.frmCategoryEdit.value.txtDescription);
    fData.append("intSortNo", this.frmCategoryEdit.value.intSortNo);
    // fData.append(" intSortNo", this.frmCategoryEdit.value. intSortNo);

    fData.append("strName", this.frmCategoryEdit.value.strName);


    for (let image of this.categoryImg) {
      fData.append("categoryImage", image, image.name);
    }
    fData.forEach((value, key) => {
      console.log(key, value);
    });


    this.hypermarketServiceObj
      .getUpdatedefaultCategory(fData)
      .subscribe((res) => {
        if (res.success === true) {
          this.clicked = false;
          this.blnLoader = true;
          Swal.fire({
            title: "Saved!",
            text: "Category Updated Successfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then(() => {
            // this.refreshPage()
            // this.getListCategoryFn();


            this.modalService.dismissAll()
            this.frmCategory.reset();
            this.router.navigate(["/assetkit/add-defaultcategory"]);
            this.submitted = false;
          });
        } else {
          this.blnLoader = true;

        }
        this.getDefaultCategoryDetails();

      });
  }
  onFileChange(event) {
    console.log("event");
    for (let i of event.target.files) {
      this.categoryImg.push(i);
    }
  }

  get formControls() {
    return this.frmCategory.controls;
  }
  // getf() {
  //   return this.frmCategoryEdit.controls
  // }
  getf() {
    return this.frmCategory.controls
  }
  strViewType: any
  pkDeptId: any
  getViewtype(strViewType) {
    this.strViewType = strViewType;
    console.log(strViewType, "rtgyuhj")
    let selectedObject: any = this.arrViewType.find((obj: any) => obj.pkDepartmentId === strViewType);
    console.log(this.arrViewType, "ggggg")

    // If object is found, you can access both name and ID
    if (selectedObject) {
      this.strViewType = selectedObject.strViewType;
      this.pkDeptId = strViewType;
    }
    console.log(this.strViewType, "tyfdgh")

    // console.log(selectedObject.strName,"hgfds")
  }


  getSaveCategoryFn() {
    this.blnLoader = false;
    this.submitted = true;
    // this.submitted = !this.submitted;
    // if (this.frmCategory.invalid) {
    //   this.blnLoader = true;
    //   return;
    // }
    if (
      !this.categoryImg.length
    ) {
      this.frmCategory.invalid
    }
    if (this.frmCategory.invalid) {
      this.blnLoader = true;
      return;
    }
    let fData = new FormData();
    fData.append("strLoginUserId", localStorage.getItem("userId"));

    fData.append("strName", this.frmCategory.value.strName);
    fData.append("strArabicName", this.frmCategory.value.strArabicName);
    // fData.append("strDescription", this.frmCategory.value.txtDescription)
    // fData.append("strViewStatus", this.frmCategory.value.blnStatus);
    // fData.append("strLoginUserId", localStorage.getItem("userId"));
    fData.append("fkDepartmentId", this.pkDeptId);
    // fData.append("strViewType",  "GROCERY");
    fData.append("strViewType", this.strViewType);
    fData.append("intSort", this.frmCategory.value.intSort);
    // fData.append("strDescription", this.frmCategory.value.txtDescription);
    // fData.append("intSort", this.frmCategory.value.intSortNo);
    for (let image of this.categoryImg) {
      fData.append("categoryImage", image, image.name);
    }
    fData.forEach((value, key) => {
      console.log(key, value);
    });
    // this.clicked = true;

    this.hypermarketServiceObj
      .getSavedummyCategoryService(fData)
      .subscribe((res) => {
        if (res.success === true) {
          this.clicked = false;
          this.blnLoader = true;
          Swal.fire({
            title: "Saved!",
            text: "New Category Added Successfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then(() => {
            // this.refreshPage()
            // this.getListCategoryFn();


            this.frmCategory.reset();
            this.router.navigate(["assetkit/add-defaultcategory"]);
            this.submitted = false;
          });
        } else {
          this.blnLoader = true;
          // Swal.fire({
          //   title: "Error",
          //   text: res.message,
          //   icon: "error",
          //   confirmButtonText: "Ok",
          // })
          // alert(res.message)
        }
        this.getDefaultCategoryDetails();
      });
  }
}


import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdddefaultcategoryComponent } from './adddefaultcategory.component';

describe('AdddefaultcategoryComponent', () => {
  let component: AdddefaultcategoryComponent;
  let fixture: ComponentFixture<AdddefaultcategoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdddefaultcategoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdddefaultcategoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

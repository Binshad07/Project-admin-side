import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import Swal from "sweetalert2";
import { PagerService } from "./../../../shared/services/pager.service";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";
import { unitResponse } from "../../../shared/Classes/unitResponse";
import { ProductService } from "../../../shared/services/product.service";
import { ReportsService } from 'src/app/shared/services/Reports/reports.service';
import { Router } from "@angular/router";
import { HypermarketService } from "./../../../shared/services/Hypermarket/hypermarket.service";
export interface modType {
  strName?: any;
}

export interface modShop {
  fkShopId?: any;
}
@Component({
  selector: 'app-list-unit',
  templateUrl: './list-unit.component.html',
  styleUrls: ['./list-unit.component.scss']
})
export class ListUnitComponent implements OnInit {

  myform: FormGroup;
  submitted: boolean = false;
  intSkipCount = 0;
  pager: any = {};
  intPageLimit = 10;
  pageLimit: any[];
  intTotalCount = 0;
  strTypelId = "";
  arrbrands: modType[] = [];
  arrShops: modShop[] = [];
  frmTypeEdit: FormGroup;
  editSubmitted: boolean = false;
  router: any;
  arrViewType: [];
  arrUnit: [];
  isAdmin = true;
  pkUnitId: any;

  constructor(
    
    private pageServiceObj: PagerService,
    private formBuilder: FormBuilder,
    // private spinner: NgxSpinnerService,
    // private spinnerObj: NgxSpinnerService,
    private modalService: NgbModal,
    private companyService: CompanyServiceService,
    private hypermarketServiceObj: HypermarketService,
  ) { }

  ngOnInit() {
    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.myform = this.formBuilder.group({
      strUnitName: ["", Validators.required],
      strViewType: ["", Validators.required],
    });
    this.frmTypeEdit = this.formBuilder.group({
      strUnitName: ["", Validators.required],
      // strViewType: ["", Validators.required],
    });
    // this.pageLimit = this.pageServiceObj.showPagelist;
    this.ListUnit();
    this.getDefaultDepartment();
    this.getNewDefaultDepartment();
    this.getViewtype;
  }
  _deleteType(responsiveDelete, item) {
    this.pkUnitId = item.pkUnitId;
    this.modalService.open(responsiveDelete);
  }

  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }

  pkDepartmentId: any
  getDefaultDepartment() {
    const obj = {};
    if (localStorage.getItem("strUserType") == "SHOP REPORTER") {
      Object.assign(obj, {
        strViewTypeName: localStorage.getItem("strViewType"),
      });
    }
    this.hypermarketServiceObj.getDefaultDepartment(obj).subscribe((res) => {
      console.log(res, "resssviwetype");
      this.arrViewType = res.data;
      this.pkDepartmentId = res.data[0].pkDepartmentId
      console.log(this.arrViewType, "console", this.pkDepartmentId);
      this.setDefaultViewType(this.arrViewType);
      this.ListUnit();
    });
  }
  setDefaultViewType(viewType) {
    if (!this.isAdmin) {
      const firstOptionValue = viewType[0].strUnitName;
      this.myform.get("strViewType").setValue(firstOptionValue);
    }
  }


  getNewDefaultDepartment() {
    const obj = {};
    if (localStorage.getItem("strUserType") == "SHOP REPORTER") {
      Object.assign(obj, {
        strViewTypeName: localStorage.getItem("strViewType"),
      });
    }
    this.hypermarketServiceObj.getDefaultDepartment(obj).subscribe((res) => {
      console.log(res, "resssviwetype");
      this.arrUnit = res.data;
      this.pkDepartmentId = res.data[0].pkDepartmentId

      this.setnewDefaultViewType(this.arrUnit);
      this.ListUnit();
    });
  }
  setnewDefaultViewType(viewType) {
    if (!this.isAdmin) {
      const firstOptionValue = viewType[0].strUnitName;
      this.myform.get("strViewType").setValue(firstOptionValue);
    }
  }





  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getDefaultDepartment();
    this.ListUnit();
  }

  get formControlsEdit() {
    return this.frmTypeEdit.controls;
  }
  
  


  // get  () {
  //   return this.frmTypeEdit.controls;
  //   // fkShopId: this.myform.value.fkShopId
  // }

  strViewType: any
  pkDeptId: any
  getViewtype(strViewType) {
    this.strViewType = strViewType;
    console.log(strViewType, "rtgyuhj")
    let selectedObject: any = this.arrUnit.find((obj: any) => obj.pkDepartmentId === strViewType);
    console.log(this.arrUnit, "ggggg")

    // If object is found, you can access both name and ID
    if (selectedObject) {
      this.strViewType = selectedObject.strViewType;
      this.pkDeptId = strViewType;
    }
    console.log(this.strViewType, "tyfdgh")

    // console.log(selectedObject.strName,"hgfds")
  }


  AddUnit() {
    this.submitted = true;
    if (this.myform.invalid) {
      return;
    }
    const obj = {
      strUnitName: this.myform.value.strUnitName,
      strViewType: this.myform.value.strViewType,
      strLoginUserId: "5e93363f66c497c2bb08f357",
      fkDepartmentId: this.pkDeptId
    };
    console.log(obj, "testttttt");
    this.hypermarketServiceObj.getSavedummyUnit(obj).subscribe((res) => {
      console.log(res);
      if (res.success === true) {


        // if (res && res.success) {
        // this.clicked = false;
        // this.spinner.hide();
        Swal.fire({
          title: "Saved!",
          text: "Unit Saved Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then(() => {
          this.myform.reset();
          this.submitted = false;
          this.ngOnInit();
          this.router.navigate(['/list-unit'])

        });
      } else {
        // this.spinner.hide();
        Swal.fire({
          title: "Warning",
          text: res.message,
          icon: "warning",
          confirmButtonText: "Ok",
        });
      }
    },
      (err) => {
        console.log(err);
      }
    );
  }

  _onClear() {
    this.submitted = false;
    this.myform.reset();
    this.ngOnInit();
  }



  get f() {
    return this.myform.controls;
  }

  ListUnit() {
    let skipCount = this.intSkipCount;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }

    const obj = {
      // fkDepartmentId:this.pkDepartmentId,
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
    };
    console.log(obj, "gsgsgsgsgs")
    // this.spinner.show()
    this.hypermarketServiceObj.getAllDummyunit(obj).subscribe((res) => {
      console.log(" repsonse::", res);
      if (res.success) {
        this.intTotalCount = res.data[0].intTotalCount;
        this.arrViewType = res.data[1];
        // this.strCategoryId=
        // this.intTotalCount = res.count;
        this.pager = this.pageServiceObj.getPager(    
          this.intTotalCount,
          this.pager.currentPage ,
          this.intPageLimit
        );
      } else {
        // this.spinner.hide();
        this.arrViewType = [];
        // this.pager = {};
        // this.intTotalCount = 0;
      }
    });
      
        // this.spinner.hide();
        // Swal.fire({
        //   title: "Error",
        //   text: "Something went wrong! Please try again",
        //   icon: "error",
        //   confirmButtonText: "Ok",
        // });
        // console.log(err);
      }
   

  deleteType() {
    // this.spinnerObj.show();
    const obj = {
      strLoginUserId: "5e93363f66c497c2bb08f357",
      pkUnitId: this.pkUnitId,
    };

    this.hypermarketServiceObj.deleteDefaultUnit(obj).subscribe((res) => {
      if (res.success === true) {
        Swal.fire({
          title: "Deleted!",
          text: "Unit has been deleted Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then((result) => {
          if (result.value) {
            // this.spinnerObj.hide();
            this.modalService.dismissAll();
            this.ListUnit();
          }
        });
      } else {
        Swal.fire({
          title: "Error",
          text: res.message,
          icon: "error",
          confirmButtonText: "Ok",
        });
        // this.spinnerObj.hide();
      }
      this.ListUnit();
    });
  }

  _getEditType(responsiveData, objType) {
    console.log(responsiveData,"sya")
    this.strTypelId = objType.pkUnitId;
    this.modalService.open(responsiveData);
    this.frmTypeEdit.patchValue({ strUnitName: objType.strUnitName });
    this.frmTypeEdit.patchValue({ strViewType: objType.strViewType });
  }

  getUpdateTypeFn() {
    this.editSubmitted = true;
    if (this.frmTypeEdit.invalid) {
      return;
    }
    // this.spinnerObj.show();
    const obj = {
      strLoginUserId: "5e93363f66c497c2bb08f357",
      strUnitName: this.frmTypeEdit.value.strUnitName,
      // strViewType: this.frmTypeEdit.value.strViewType,
      // fkDepartmentId: this.pkDepartmentId,
      pkUnitId: this.strTypelId,
      fkDepartmentId:this.pkDepartmentId

      // fkShopId: localStorage.getItem('shopId'),
    };


    this.hypermarketServiceObj
      .getUpdatedefaultUnit(obj)
      .subscribe((res) => {

        if (res.success === true) {
          // this.spinnerObj.hide();
          Swal.fire({
            title: "Updated!",
            text: " Unit has been Updated Sucessfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then((result) => {
            if (result.value) {
              this.modalService.dismissAll();
            }
          });
        } else {
          Swal.fire({
            title: "Warning",
            text: "Unit With Same Name Exist",
            icon: "warning",
            confirmButtonText: "Ok",
          }).then((result) => {
            if (result.value) {
              this.modalService.dismissAll();
            }
          });
          // this.spinnerObj.hide();
        }
        this.ListUnit();
      });
  }

}

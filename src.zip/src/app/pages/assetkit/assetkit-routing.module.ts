import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CategoryComponent } from './category/category.component';
import { SubcategoryComponent } from './subcategory/subcategory.component';
import { ProductComponent } from './product/product.component';
import { DefaultbannersComponent } from './defaultbanners/defaultbanners.component';
import { AddProductComponent } from './add-product/add-product.component';
import { BrandComponent } from './brand/brand.component';
import { AdddefaultcategoryComponent } from './adddefaultcategory/adddefaultcategory.component';
import { AdddefaultsubcategoryComponent } from './adddefaultsubcategory/adddefaultsubcategory.component';
import { ListUnitComponent } from './list-unit/list-unit.component';
import { AddUnitComponent } from './add-unit/add-unit.component';
import { ListDefaultBotttomBannerComponent } from './list-default-botttom-banner/list-default-botttom-banner.component';
import { AddDefaultBotttomBannerComponent } from './add-default-botttom-banner/add-default-botttom-banner.component';
import { OffertopbarComponent } from './offertopbar/offertopbar.component';
import { OfferBannersComponent } from '../product/offer-banners/offer-banners.component';
import { AddOffertopbarComponent } from './add-offertopbar/add-offertopbar.component';
import { AddHomebannerComponent } from './add-homebanner/add-homebanner.component';
// import { AnalyticsRequestComponent } from './analytics-request/analytics-request.component';

// import { defaultbannersComponent } from './defaultbanners/defaultbanners.component';
// import { DefaultcategoryComponent } from './defaultcategory/defaultcategory.component';


const routes: Routes = [ 
  {
    path: "category",
    component: CategoryComponent,
  },

  {
    path: "Subcategory",
    component:SubcategoryComponent
  },
 


  {
    path: "product",
    component:ProductComponent
  },

  {
    path:"defaultbanners",
    component:DefaultbannersComponent
  },

  {
    path:"add-product",
    component:AddProductComponent
  },

  {
    path:"brand",
    component:BrandComponent
  },
  {
    path:"add-defaultcategory",
    component:AdddefaultcategoryComponent
  },
  {
    path:"add-defaultsubcategory",
    component:AdddefaultsubcategoryComponent
  },
  {
    path:"add-unit",
    component:AddUnitComponent
  },
  {
    path:"list-unit",
    component:ListUnitComponent
  },
  // {
  //   path:"defaultbanners",
  //   component:defaultbannersComponent
  // }
  
  // {
  //   path: "defaultcategory",
  //   component:DefaultcategoryComponent
  // },
  {
    path:"list-default-bottombanner",
    component:ListDefaultBotttomBannerComponent
  },
  {
    path:"add-default-bottombanner",
    component:AddDefaultBotttomBannerComponent
  },

  {
    path:"offertopbar",
    component:OffertopbarComponent
  },

  {
    path:"add-offertopbar",
    component:AddOffertopbarComponent
  },
  {
    path:"add-homebanner",
    component:AddHomebannerComponent
  },
 
  // {
  //   path:"analytics-request",
  //   component:AnalyticsRequestComponent
  // },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AssetkitRoutingModule { }

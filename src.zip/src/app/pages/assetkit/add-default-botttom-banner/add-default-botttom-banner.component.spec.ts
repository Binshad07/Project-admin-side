import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddDefaultBotttomBannerComponent } from './add-default-botttom-banner.component';

describe('AddDefaultBotttomBannerComponent', () => {
  let component: AddDefaultBotttomBannerComponent;
  let fixture: ComponentFixture<AddDefaultBotttomBannerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddDefaultBotttomBannerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddDefaultBotttomBannerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

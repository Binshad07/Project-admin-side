import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
// import { NgxSpinnerService } from "ngx-spinner";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from "@angular/router";
import { BannersService } from 'src/app/shared/services/Banner/banners.service';
import { HypermarketService } from 'src/app/shared/services/Hypermarket/hypermarket.service';
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";


@Component({
  selector: 'app-add-default-botttom-banner',
  templateUrl: './add-default-botttom-banner.component.html',
  styleUrls: ['./add-default-botttom-banner.component.scss']
})
export class AddDefaultBotttomBannerComponent implements OnInit {
  pager: any = {};
  intTotalCount = 0;
  intPageLimit = 10;
  pageLimit: any[];
  intSkipCount = 0;
  submitted: boolean = false;
  arrRentalItem: any[] = []
  myForm: FormGroup;
  bannerImg: File[] = []
  id = "";
  type = "Add";
  blnUpdate = false;
  strImageUrl: ["",]
  clicked = false;
  arrViewType: any[] = [];
  arrShop: any[] = [];
  arrbanner: [];
  isAdmin = true;


  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private BannerService: BannersService,
    private hypermarketServiceObj: HypermarketService,
    private companyService:CompanyServiceService
  ) { }

  ngOnInit() {
    this.route.queryParams.subscribe((params) => {
      this.id = params["id"];
    });

    this.myForm = this.formBuilder.group({
      deviceType: ["", Validators.required],
      sortNo: ["", Validators.required],
      bannerImg: ["",Validators.required],
      strImageUrl : [""],
      strViewType: ["", Validators.required],

    })
    this.getNewDefaultDepartment();
    // this. getAllShop();
    this.getViewtype;
    
  }
  get f() {
    return this.myForm.controls;
  }

  addBottomBanner() {
    this.submitted = true;
    if (this.myForm.invalid) {
      return
    }
    let fData = new FormData();
    // this.spinner.show()
    fData.append("strLoginUserId",'5e93363f66c497c2bb08f357')
    fData.append("strImageType", this.myForm.value.deviceType)
    fData.append("intSort", this.myForm.value.sortNo)
    fData.append("fkDepartmentId",  this.pkDeptId)
    fData.append("strViewType", this.strViewType);
    // fData.append("strViewType", this.myForm.value.drpViewType)
    // fData.append("strViewType", this.myForm.value.strViewType)
    for (let image of this.bannerImg) {
      fData.append("bottomBannerImg", image, image.name)
    }
    fData.forEach((key, value) => console.log(`${key}: ${value}`))
   this. clicked = true;
   this.hypermarketServiceObj.getSavedummyBottomBanner(fData).subscribe((res) => {
      console.log(res)
      if (res && res.success) {
        this.clicked = false;
        // this.spinner.hide();
        Swal.fire({
          title: "Saved!",
          text: "Bottom Banner Saved Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then(() => {
          this.myForm.reset()
          this.router.navigate(['/assetkit/list-default-bottombanner'])
          this.submitted = false;
        })
      } else {
        // this.spinner.hide();
        Swal.fire({
          title: "Error",
          text: res.message,
          icon: "error",
          confirmButtonText: "Ok",
        });
      }
    }, (err) => {
      console.log(err)
    })


  }
  strViewType: any
  pkDeptId: any
  getViewtype(strViewType) {
    this.strViewType = strViewType;
    console.log(strViewType, "rtgyuhj")
    let selectedObject: any = this.arrbanner.find((obj: any) => obj.pkDepartmentId === strViewType);

    // If object is found, you can access both name and ID
    if (selectedObject) {
      this.strViewType = selectedObject.strViewType;
      this.pkDeptId = strViewType;
    }

    // console.log(selectedObject.strName,"hgfds")
  }

  pkDepartmentId: any
  getNewDefaultDepartment() {
    const obj = {};
    if (localStorage.getItem("strUserType") == "SHOP REPORTER") {
      Object.assign(obj, {
        strViewTypeName: localStorage.getItem("strViewType"),
      });
    }
    this.hypermarketServiceObj.getDefaultDepartment(obj).subscribe((res) => {
      console.log(res, "resssviwetype");
      this.arrbanner = res.data;
      this.pkDepartmentId = res.data[0].pkDepartmentId

      this.setnewDefaultViewType(this.arrbanner);
    });
  }
  setnewDefaultViewType(viewType) {
    if (!this.isAdmin) {
      const firstOptionValue = viewType[0].strName;
      this.myForm.get("strViewType").setValue(firstOptionValue);
    }
  }



  getViewTypeFn() {
    this.hypermarketServiceObj.getViewType().subscribe((res) => {
      this.arrViewType = res.data;
    })
  }

//   getAllShop(){
//     const obj = {
//       loginUserId:localStorage.getItem("userId"),
//     }
//     if(localStorage.getItem('fkShopId')){
//       // Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
//       Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

//       // obj.fkShopId=localStorage.getItem('fkShopId')
//     }
//     this.companyService.fngetallCompany(obj).subscribe((res) => {
        
//         this.arrShop = res.data
// })
//   }


  clearForm() {
    this.submitted = false;
    this.myForm.reset()
  }

  onFileChange(event) {
    for (let i of event.target.files) {
      this.bannerImg.push(i)
    }
  }


  // update() {
  //   this.submitted = true;
  //   if (this.myForm.invalid) {
  //     return
  //   }

  //   // this.spinner.show()
  //   let formData = new FormData();

  //   formData.append("strImageType", this.myForm.value.deviceType)
  //   formData.append("intSort", this.myForm.value.sortNo)
  //   formData.append("loginUserId", localStorage.getItem('userId'))
  //   formData.append("pkImageId", this.id)
  //   // formData.append("strViewType", this.myForm.value.drpViewType)
  //   formData.append("fkShopId", this.myForm.value.cmbShopName);

  //   if (this.bannerImg.length) {
  //     for (const image of this.bannerImg) {
  //       formData.append('imageFile', image, image.name)
  //     }
  //   } else {
  //     formData.append("strImageUrl", this.myForm.value.strImageUrl)
  //   }
  //   formData.forEach((key, value) => console.log(` ${value}:${key}`))


  //   this.BannerService.updateHomeBanner(formData).subscribe((res) => {
      
  //     if (res.success) {
  //       // this.spinner.hide()
  //       Swal.fire({
  //         title: "Saved!",
  //         text: "Home Banner updated successfully",
  //         icon: "success",
  //         confirmButtonText: "Ok",
  //       }).then(() => {
  //         this.myForm.reset()
  //         this.submitted = false;
  //         this.router.navigate(['/homepagebanner'])
  //       })
  //     } else {
  //       // this.spinner.hide();
  //       Swal.fire({
  //         title: "Error",
  //         text: res.message,
  //         icon: "error",
  //         confirmButtonText: "Ok",
  //       }).then(() => {
  //         this.submitted = false;
  //       })
  //     }
  //   }, (err) => {
  //     this.submitted = false;
  //     console.log(err)
  //   })
  // }

  // FunDownloadImage(strImageUrl){
  //   window.open(strImageUrl);
  // }

}

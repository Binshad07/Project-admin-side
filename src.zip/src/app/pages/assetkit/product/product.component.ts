import { Component, OnInit } from '@angular/core';
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { PagerService } from "src/app/shared/services/pager.service";
import { Router } from "@angular/router";
import Swal from "sweetalert2";
import { FormGroup, FormBuilder } from "@angular/forms";
import { BannersService } from 'src/app/shared/services/Banner/banners.service';
import { HypermarketService } from "./../../../shared/services/Hypermarket/hypermarket.service";


@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss']
})
export class ProductComponent implements OnInit {

  intTotalCount = 0;
  frmproduct: FormGroup;
  myform: FormGroup;
  intSkipCount = 0;
  pageLimit: any[];
  intPageLimit = 10;
  pager: any = {};
  arrHomeBanner = [];
  strBannerImageId = "";

  showModal: boolean;
  strSelectedImg: string;
  strSelectedImageType: string;
  objSelectedItem: any;
  pkImageId: any;
  isAdmin = true;
  arrcategory = [];
  arrproduct = [];

  arrOfCategoryList = [];
  arrViewType: [];
  strName: "";
  id: any;
  arabicName: ""
  // strCategoryId = "";
  intSortNo: "";
  editSubmitted: boolean = false;
  strImageUrl: ""
  txtDescription: ""
  blnLoader = false;
  submitted = false;
  clicked = false;
  strCategoryId: any;
  categoryImg: File[] = [];
  pkCategoryId: any
  Sellingprice: "";
  pkProductId: any;
  // cmbCategory: any
  // pkCategoryId:any
  strSubCategoryId: any
  fkDepartmentId: any
  imageUrl: ""
  arrayThumbnail = [
    {
      imageUrl: ""
    }
    // You can add more objects with imageUrl properties here
  ];

  constructor(
    private pageServiceObj: PagerService,
    private modalService: NgbModal,
    private router: Router,
    private formBuilder: FormBuilder,
    private BannerService: BannersService,
    private hypermarketServiceObj: HypermarketService,

  ) { }

  ngOnInit() {

    this.frmproduct = this.formBuilder.group({
      strViewType: "",
      Sellingprice: "",
      arabicName: "",
      txtDescription: "",
      strProductName: "",
      pkCategoryId: "",
      strArabicName: "",
      intSellingPrice: "",
      strDescription: "",
      intMRP: "",
      strCategoryId: "",
      strSubCategoryId: "",
      pkProductId: "",
      fkDepartmentId: "",
      imageUrl: "",
      strBrand: "",
      txtImageUrl: "",
      strImageUrl:""
     
     
    })

    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist
    this.getDefaultDepartment();
    this.getDefaultProductDetails();



  }

  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );

    this.getDefaultProductDetails();
    // this.getDefaultCategoryDetails();


  }
  errorImage(event) {
    // event.target.src = 'assets/images/Group 4024 (1).png';
  }
  onFileChange(event) {
    console.log("event");
    for (let i of event.target.files) {
      this.categoryImg.push(i);
    }
  }

  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    // this.getDefaultDepartment();
    // this.getDefaultCategoryDetails();
    this.getDefaultProductDetails();


  }



  _onClear(form: FormGroup) {
    form.reset({
      strViewType: "",
    });
    this.getDefaultDepartment();
  }

  pkDepartmentId: any
  getDefaultDepartment() {
    const obj = {};
    if (localStorage.getItem("strUserType") == "SHOP REPORTER") {
      Object.assign(obj, {
        strViewTypeName: localStorage.getItem("strViewType"),
      });
    }
    this.hypermarketServiceObj.getDefaultDepartment(obj).subscribe((res) => {
      console.log(res, "resssviwetype");
      this.arrViewType = res.data;
      this.pkDepartmentId = res.data[0].pkDepartmentId
      console.log(this.arrViewType, "console", this.pkDepartmentId);
      this.setDefaultViewType(this.arrViewType);
      this.getDefaultProductDetails();
    });
  }

  setDefaultViewType(viewType) {
    if (!this.isAdmin) {
      const firstOptionValue = viewType[0].strName;
      this.frmproduct.get("drpViewType").setValue(firstOptionValue);
    }
  }





  getDefaultProductDetails() {

    let skipCount = this.intSkipCount;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
    const obj = {
      strLoginUserId: localStorage.getItem('userId'),


      //  fkDefaultDepartmentId: this.frmproduct.value.strViewType ? this.frmproduct.value.strViewType : (this.pkDepartmentId ? this.pkDepartmentId : ""),



      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
      fkDefaultDepartmentId: this.frmproduct.value.strViewType


    };
    console.log(obj, "list product obj::::::::::::::::::::");

    this.hypermarketServiceObj.getDefaultProductDetails(obj).subscribe((res) => {
      // console.log("Banners", res);
      // this.spinner.hide();
      if (res.success) {
        // this.spinner.hide();
        this.intTotalCount = res.data[0].intTotalCount;
        this.arrproduct = res.data[1];
        console.log(this.arrproduct, "fghjk")
        // this.strCategoryId=
        // this.intTotalCount = res.count;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
      } else {
        this.arrproduct = [];
        this.pager = {};
        this.intTotalCount = 0;
      }
    });
  }




  _getEditType(responsiveData, objType) {
    console.log(objType);




    this.modalService.open(responsiveData);
    this.strCategoryId = objType.strCategoryId;
    this.strSubCategoryId = objType.strSubCategoryId
    this.pkProductId = objType.pkProductId;
    this.fkDepartmentId = objType.fkDepartmentId;



    console.log(this.strCategoryId, "dxfcgvhj")




    this.frmproduct.patchValue({ strProductName: objType.strProductName });
    this.frmproduct.patchValue({ strArabicName: objType.strArabicName });
    this.frmproduct.patchValue({ strDescription: objType.strDescription });
    this.frmproduct.patchValue({ txtImageUrl: objType.imageUrl });
    this.frmproduct.patchValue({ intMRP: objType.intMRP });
    this.frmproduct.patchValue({ intSellingPrice: objType.intSellingPrice });
    this.frmproduct.patchValue({ strBrand: objType.strBrand });





  }


  onClickViewImg(item, image, type) {
    this.objSelectedItem = item;
    this.strSelectedImg = image;
    this.strSelectedImageType = type;
    this.show();
  }
  show() {
    this.showModal = true;
  }
  hide() {
    this.showModal = false;
  }
  getUpdateTypeFn() {

    this.blnLoader = false;
    this.submitted = true;

    if (this.frmproduct.invalid) {
      this.blnLoader = true;
      return;
    }
    console.log(this.strCategoryId);

    let fData = new FormData();

    fData.append("strLoginUserId", localStorage.getItem("userId"));
    fData.append("strCategoryId", this.strCategoryId),




      fData.append("strSubCategoryId", this.strSubCategoryId)
    fData.append("pkProductId", this.pkProductId)
    fData.append("fkDepartmentId", this.fkDepartmentId);
    fData.append("strProductName", this.frmproduct.value.strProductName)
    fData.append("intMRP", this.frmproduct.value.intMRP)
    fData.append("strArabicName", this.frmproduct.value.strArabicName)

    fData.append("intSellingPrice", this.frmproduct.value.intSellingPrice)

    fData.append("strDescription", this.frmproduct.value.strDescription)

    for (let image of this.categoryImg) {
      fData.append("ProductImages", image, image.name);
    }
    fData.forEach((value, key) => {
      console.log(key, value);
    });



    this.hypermarketServiceObj.getupdatedefaultproduct(fData).subscribe((res) => {

      if (res.success === true) {
        Swal.fire({
          title: "Updated!",
          text: "product Updated successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then(() =>{
      this.getDefaultProductDetails();
      this.modalService.dismissAll();
      this.categoryImg=[]
      const inputElement = document.getElementById(
        'image'
      ) as HTMLInputElement;
      if (inputElement) {
        inputElement.value = '';
      }
      })
    // this.modalService.dismissAll();
  } else {
    alert(res.message)
  }
    });

  }







  deleteDefaultproduct() {

    const obj = {
      strLoginUserId: localStorage.getItem("userId"),



      "pkProductId": this.pkProductId

    };
    console.log(obj, "objjjjjjjj");

    this.hypermarketServiceObj.deleteDefaultproduct(obj).subscribe((res) => {
      if (res.success === true) {
        Swal.fire({
          title: "Deleted!",
          text: "product has been deleted Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then((result) => {
          if (result.value) {
            // this.spinnerObj.hide();
            this.ngOnInit();
            this.modalService.dismissAll();
          }
        });
      } else {
        Swal.fire({
          title: "Error",
          text: res.message,
          icon: "error",
          confirmButtonText: "Ok",
        });
        // this.spinnerObj.hide();
      }
      this.getDefaultProductDetails();
    });
  }

  _getDeleteModal(responsiveDelete, id) {

    this.pkProductId = id.pkProductId;

    this.modalService.open(responsiveDelete);
  }













}

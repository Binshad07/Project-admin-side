import { Component, OnInit } from '@angular/core';

import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from "@angular/router";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";
import Swal from 'sweetalert2';
import { ReportsService } from 'src/app/shared/services/Reports/reports.service';
import { HypermarketService } from "./../../../shared/services/Hypermarket/hypermarket.service";

@Component({
  selector: 'app-add-unit',
  templateUrl: './add-unit.component.html',
  styleUrls: ['./add-unit.component.scss']
})
export class AddUnitComponent implements OnInit {
  
  myForm: FormGroup;

  pager: any = {};
  intTotalCount = 0;
  intPageLimit = 10;
  pageLimit: any[];
  intSkipCount = 0;
  submitted: boolean = false;
  
  id = "";
  type = "Add";
  blnUpdate = false;
 
  clicked = false;
  isAdmin=true;
  arrViewType: [];
  arrUnit: any;

  strUnitName;
  strLoginUserId: any;
  blnLoader: boolean;


  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private companyService: CompanyServiceService,
    private reportService: ReportsService,
    private hypermarketServiceObj: HypermarketService,

  ) { }

  ngOnInit() {
    this.route.queryParams.subscribe((params) => {
      this.id = params["id"];
    });

    this.myForm = this.formBuilder.group({
      unit: ["", Validators.required],
      strViewType: ["", Validators.required],



    })
    this.getViewtype();
    this.getunitlistFn();


    if (this.id) {
      this.type = "Update";
     
      this.blnUpdate = true;

      this.patchvalue();
    }
  }
  get f() {
    return this.myForm.controls;
  }

  get formControls() {
    return this.myForm.controls;
    // fkShopId: this.myform.value.fkShopId
  }
  pkDepartmentId: any
  getViewtype() {
    const obj = {};
    if (localStorage.getItem("strUserType") == "SHOP REPORTER") {
      Object.assign(obj, {
        strViewTypeName: localStorage.getItem("strViewType"),
      });
    }
    this.hypermarketServiceObj.getDefaultDepartment(obj).subscribe((res) => {
      console.log(res, "resssviwetype");
      this.arrViewType = res.data;
      this.pkDepartmentId = res.data[0].pkDepartmentId
      console.log(this.arrViewType, "console", this.pkDepartmentId);
      this.setDefaultViewType(this.arrViewType);
      this.getunitlistFn();
    });
  }
  setDefaultViewType(viewType) {
    if (!this.isAdmin) {
      const firstOptionValue = viewType[0].strName;
      this.myForm.get("drpViewType").setValue(firstOptionValue);
    }
  }

  addUnitlist() {
    const obj = {
      strLoginUserId: "5e93363f66c497c2bb08f357",
      strUnitName: this.myForm.value.unit,
      // strViewType: this.myForm.value.strViewType,
      fkDepartmentId: this.pkDepartmentId,
      // intPageLimit: this.intPageLimit,
    }
console.log(obj,"nect2234")
    this.clicked = true;
    this.hypermarketServiceObj.getSavedummyUnit(obj).subscribe((res) => {
      console.log(res)
      if (res && res.success) {
        
        Swal.fire({
          title: "Saved!",
          text: "Unit Saved Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then(() => {
          this.myForm.reset()
          this.router.navigate(['/assetkit/list-unit'])
          this.submitted = false;
        })
      } else {
       if(res.message == "Unit name already in use. Please choose another."){
        Swal.fire({
          title: "Warning",
          text: res.message,
          icon: "warning",
          confirmButtonText: "Ok",
        });
       }
       else{
        Swal.fire({
          title: "Warning",
           text: res.message,
          icon: "warning",
          confirmButtonText: "Ok",
        });
       }
        
      }
    }, (err) => {
      console.log(err)
    })


  }







  getAllShop() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
    }
    console.log(obj, "tesghjchbv")
    if (localStorage.getItem('fkShopId')) {
      // Object.assign(obj, { strShopId: localStorage.getItem('fkShopId') })
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

    
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {

      this.arrViewType = res.data
    })
  }

  clearForm() {
    this.myForm.reset();
    this.ngOnInit();
  }

  

  getunitlistFn() {
    const obj = {
      loginUserId: localStorage.getItem('userId'),
    
      pkUnitId: this.id

    }

    this.reportService.getunitlist(obj).subscribe((res) => {
      if (res && res.success) {
        console.log("patch", res.data)
        this.myForm.patchValue({
         
          pkUnitId: res.data[0].unit,
          strViewType: res.data[0].strViewType,
          
        })
      }
    })
  }




  update() {

    const obj = {
      strLoginUserId: localStorage.getItem('userId'),
      strUnitName: this.myForm.value.unit,
      strViewType: this.myForm.value.strViewType,
      strUnitId: this.id,
    }

    console.log(obj)

    this.clicked = true;
    this.reportService.updateunitlist(obj).subscribe((res) => {
      console.log(res)
      if (res && res.success) {
        
        Swal.fire({
          title: "Saved!",
          text: "Unit Updated Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then(() => {
          this.myForm.reset()
          this.router.navigate(['/assetkit/list-unit'])
          this.submitted = false;
        })
      } else {
        
        Swal.fire({
          title: "Error",
          text: res.message,
          icon: "error",
          confirmButtonText: "Ok",
        });
      }
    }, (err) => {
      console.log(err)
    })


  }

  
  




  patchvalue() {

    this.blnLoader = false;

    const obj = {
      strLoginUserId: localStorage.getItem('userId'),
      pkUnitId: this.id,
    }

    this.reportService.UnitList(obj).subscribe((res) => {
      if (res && res.success) {
        this.arrUnit = res.data;
        console.log(this.arrUnit)
        if (this.arrUnit.length) {

          this.myForm.patchValue({ unit: this.arrUnit[0].strUnitName });
          this.myForm.patchValue({ strViewType: this.arrUnit[0].strViewType });

        }
      }
    })
  }
}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdddefaultsubcategoryComponent } from './adddefaultsubcategory.component';

describe('AdddefaultsubcategoryComponent', () => {
  let component: AdddefaultsubcategoryComponent;
  let fixture: ComponentFixture<AdddefaultsubcategoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdddefaultsubcategoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdddefaultsubcategoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

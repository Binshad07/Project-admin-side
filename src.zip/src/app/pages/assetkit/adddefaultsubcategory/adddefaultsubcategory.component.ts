


import { Component, OnInit } from '@angular/core';
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { PagerService } from "src/app/shared/services/pager.service";
import { Router } from "@angular/router";
// import { NgxSpinnerService } from "ngx-spinner";
import Swal from "sweetalert2";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";

import { HypermarketService } from "./../../../shared/services/Hypermarket/hypermarket.service";
import { ProductService } from './../../../shared/services/product.service';



@Component({
  selector: 'app-adddefaultsubcategory',
  templateUrl: './adddefaultsubcategory.component.html',
  styleUrls: ['./adddefaultsubcategory.component.scss']
})
export class AdddefaultsubcategoryComponent implements OnInit {


  intTotalCount = 0;
  frmsubCategory: FormGroup
  frmSubCategoryEdit: FormGroup;

  intSkipCount = 0;

  pageLimit: any[];
  intPageLimit = 10;
  pager: any = {};
  arrHomeBanner = [];
  strBannerImageId = "";
  showModal: boolean;
  strSelectedImg: string;
  strSelectedImageType: string;
  objSelectedItem: any;
  pkImageId: any;
  isAdmin = true;
  arrsubcategory = [];
  arrOfCategoryList = [];
  arrViewType: [];
  myform: FormGroup;
  strSubCategoryId = '';
  subCategoryImg: File[] = [];
  // subCategoryImg: File[] = [];
  // subCategoryImage:
   categoryImg: File[] = [];
   CategoryImg:File[] = [];
  // categoryImage:File[] = [];
  strCategoryId: any;
  strName: any;
  subCategoryImage:File[] = [];
  // pkDepartmentId:"",
  id: any;
  submitted: boolean = false;
  blnLoader = false
  clicked = false
  pkCategoryId: any
  drpCategory: ""
  strViewType: "any"
  arrcategory = [];
   pkDepartmentId:any
  // strCategoryId: any;
  frmCategory:FormGroup
  constructor(

    private pageServiceObj: PagerService,
    private modalService: NgbModal,
    // private spinner: NgxSpinnerService,
    private router: Router,
    private formBuilder: FormBuilder,
    private myProductService: ProductService,

    private hypermarketServiceObj: HypermarketService,


  ) { }

  

  ngOnInit() {


    this.frmsubCategory = this.formBuilder.group({
      strViewType: ["",Validators.required],
      // strViewType: "",
      // strViewType: "",
      pkDepartmentId:"",
      strImageUrl:["",Validators.required],
      strSortCount:["",Validators.required], 
      arabicName: ["",Validators.required],
      strName: ["", Validators.required],
      // txtImageUrl: "",
      txtDescription: "",
      strCategoryName: "",
      drpCategory: ['',Validators.required],
      CategoryImg: "",

      // intSortNo:""
      // pkDepartmentId:""
    });

    this.frmSubCategoryEdit = this.formBuilder.group({
      strName: [''],
      arabicName: [''],
      // txtDescription: [''],
      strImageUrl: [''],
      blnStatus: [''],
      drpViewType: [''],
      txtSortNo: [''],
      // fkShopId: [''],
      drpCategory: [''],
      // intSort:['']
      intSortNo:""
    });

    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist
    this.getDefaultDepartment();
    this.getDefaultSubCategoryDetails();
    console.log(this.strViewType,"yyuui")
    this.getDefaultCategoryDetails(this.strViewType);


  }



  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getDefaultDepartment();
    this.getDefaultSubCategoryDetails();
    // this.getdummyDefaultCategoryDetails();

  }








  



  _clearForm() {
    this.submitted=false;
this.frmsubCategory.reset();
this.ngOnInit();
    this.getDefaultSubCategoryDetails();
  }
  // pkDepartmentId: any

  getDefaultDepartment() {
    const obj = {};
    if (localStorage.getItem("strUserType") == "SHOP REPORTER") {
      Object.assign(obj, {
        strViewTypeName: localStorage.getItem("strViewType"),
      });
    }
    this.hypermarketServiceObj.getDefaultDepartment(obj).subscribe((res) => {
      // console.log(res, "resssviwetype");
      this.arrViewType = res.data;
      this.pkDepartmentId = res.data[0].pkDepartmentId
      this.frmsubCategory.value.pkDepartmentId = this.pkDepartmentId
      console.log(this.arrViewType, "console", this.pkDepartmentId);
      this.setDefaultViewType(this.arrViewType);
      this.getDefaultSubCategoryDetails();
    });
  }

  setDefaultViewType(viewType) {
    if (!this.isAdmin) {
      const firstOptionValue = viewType[0].strName;
      this.frmsubCategory.get("drpViewType").setValue(firstOptionValue);
    }
  }

  // getDefaultSubCategoryDetails() {

  //   let skipCount = this.intSkipCount;
  //   if (this.pager.intSkipCount) {
  //     skipCount = this.pager.intSkipCount;
  //   }
  //   const obj = {
  //     strLoginUserId: localStorage.getItem('userId'),

  //     fkDefaultDepartmentId: this.frmsubCategory.value.strViewType ? this.frmsubCategory.value.strViewType : (this.pkDepartmentId ? this.pkDepartmentId : ""),
  //     intSkipCount: skipCount,
  //     intPageLimit: this.intPageLimit,
  //   };
  //   console.log(obj, "list category obj::::::::::::::::::::");

  //   this.hypermarketServiceObj.getDefaultSubCategoryDetails(obj).subscribe((res) => {

  //     if (res.success) {
  //       // this.spinner.hide();
  //       this.intTotalCount = res.data[0].intTotalCount;
  //       this.arrsubcategory = res.data;
  //       this.intTotalCount = res.count;
  //       this.pager = this.pageServiceObj.getPager(
  //         this.intTotalCount,
  //         this.pager.currentPage,
  //         this.intPageLimit
  //       );
  //     } else {
  //       this.arrsubcategory = [];

  //     }
  //   });
  // }




  getDefaultSubCategoryDetails() {

    let skipCount = this.intSkipCount;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
    const obj = {
      strLoginUserId: localStorage.getItem('userId'),
      //  fkDefaultDepartmentId: this.frmsubCategory.value.pkDepartmentId ? this.frmsubCategory.value.pkDepartmentId : (this.pkDepartmentId ? this.pkDepartmentId : ""),
      // fkDefaultDepartmentId: this.pkDepartmentId,
// strName:this.frmCategory.value.fkDefaultDepartmentId,
      // "strCategoryId": this.strCategoryId.pkCategoryId,
      // strName: this.strName,

      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
      // fkDefaultDepartmentId: this.frmsubCategory.value.strViewType

    };
    console.log(obj, "list category obj::::::::::::::::::::");

    this.hypermarketServiceObj.getDefaultSubCategoryDetails(obj).subscribe((res) => {

      if (res.success) {
        // this.spinner.hide();
        this.intTotalCount = res.data[0].intTotalCount;
        this.arrsubcategory = res.data[1];
        // this.intTotalCount = res.data[0].intTotalCount;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
      } else {
        this.arrsubcategory = [1];

      }
    });
  }









   errorImage(event) {
    // event.target.src = 'assets/images/Group 4024 (1).png';
  }

  hide() {
    this.showModal = false;
  }


//   getUpdateTypeFn() {

//     this.blnLoader = false;
//     this.submitted = false;

//     if (this.frmSubCategoryEdit.invalid) {
//       this.blnLoader = true;
//       return;
//     }
//     let fData = new FormData();


//       // fData.append("strCategoryId", this.frmCategory.value.strCategoryId)

//     //  fData.append("strCategoryId", this.frmsubCategory.value.drpCategory)

//   //   fData.append("strArabicName", this.frmsubCategory.value.arabicName);

//   //   fData.append("strLoginUserId", localStorage.getItem("userId"));

//   //   fData.append("strDescription", this.frmsubCategory.value.txtDescription);
//   //   fData.append("intsortno:", this.frmsubCategory.value.intsortno);

//   //    fData.append("strName", this.frmsubCategory.value.strName);

//   //   //  for (let image of this.categoryImg) {
//   //   //   fData.append("categoryImage", image, image.name);
//   //   // }
//   //   // fData.append("strName:", this.frmsubCategory.value.strName)
//   //   for (let image of this.CategoryImg) {
//   //     fData.append("categoryImage", image, image.name)
//   //   }
//   //   fData.append("CategoryImg", this.frmsubCategory.value.strImageUrl)

//   //   this.hypermarketServiceObj.getUpdatedefaultsubCategory(fData).subscribe((res) => {

//   //     if (res.success === true) {
//   //       Swal.fire({
//   //         title: "Updated!",
//   //         text: "SubCategory Updated successfully",
//   //         icon: "success",
//   //         confirmButtonText: "Ok",
//   //       })
//   //       this.modalService.dismissAll();
//   //     } else {
//   //       alert(res.message)
//   //     }
//   //     this.getDefaultSubCategoryDetails();
//   //   });

//   // }




//   fData.append("strCategoryId", this.strCategoryId)


//   fData.append("strArabicName", this.frmSubCategoryEdit.value.arabicName);

//   fData.append("strLoginUserId", localStorage.getItem("userId"));

//   fData.append("strDescription", this.frmSubCategoryEdit.value.txtDescription);
//   fData.append("intSort", this.frmSubCategoryEdit.value.intSort);

//   fData.append("strName", this.frmSubCategoryEdit.value.strName)
//   // for (let image of this.categoryImage) {
//   //   fData.append("strImageUrl", image, image.name)
//   // }
//   // fData.append("categoryImage", this.frmsubCategory.value.strImageUrl)
  
//   for (let image of this.categoryImg) {
//     fData.append("categoryImage", image, image.name);
//   }
//   fData.forEach((value, key) => {
//     console.log(key, value);
//   });

//   this.hypermarketServiceObj.getUpdatedefaultsubCategory(fData).subscribe((res) => {

//     if (res.success === true) {
//                 this.clicked = false;
//         this.blnLoader = true;
//       Swal.fire({
//         title: "Updated!",
//         text: "SubCategory Updated successfully",
//         icon: "success",
//         confirmButtonText: "Ok",
//       }).then(() => {
//         this.getDefaultSubCategoryDetails();
//         this.modalService.dismissAll();
//         this.categoryImg=[]
//         const inputElement = document.getElementById(
//           'image'
//         ) as HTMLInputElement;
//         if (inputElement) {
//           inputElement.value = '';
//         }

//         })
//       // this.modalService.dismissAll();
//     } else {
//       alert(res.message)
//     }
//     this.getDefaultSubCategoryDetails();
//   });

// }



getUpdateTypeFn() {
  this.blnLoader = false;
  this.submitted = false;
  if (this.frmSubCategoryEdit.invalid) {
    this.blnLoader = true;
    return;
  }
  let fData = new FormData();
    // fData.append("strCategoryId", this.frmCategory.value.strCategoryId)
  //  fData.append("strCategoryId", this.frmsubCategory.value.drpCategory)
//   fData.append("strArabicName", this.frmsubCategory.value.arabicName);
//   fData.append("strLoginUserId", localStorage.getItem("userId"));
//   fData.append("strDescription", this.frmsubCategory.value.txtDescription);
//   fData.append("intsortno:", this.frmsubCategory.value.intsortno);
//    fData.append("strName", this.frmsubCategory.value.strName);
//   //  for (let image of this.categoryImg) {
//   //   fData.append("categoryImage", image, image.name);
//   // }
//   // fData.append("strName:", this.frmsubCategory.value.strName)
//   for (let image of this.CategoryImg) {
//     fData.append("categoryImage", image, image.name)
//   }
//   fData.append("CategoryImg", this.frmsubCategory.value.strImageUrl)
//   this.hypermarketServiceObj.getUpdatedefaultsubCategory(fData).subscribe((res) => {
//     if (res.success === true) {
//       Swal.fire({
//         title: "Updated!",
//         text: "SubCategory Updated successfully",
//         icon: "success",
//         confirmButtonText: "Ok",
//       })
//       this.modalService.dismissAll();
//     } else {
//       alert(res.message)
//     }
//     this.getDefaultSubCategoryDetails();
//   });
// }
fData.append("strCategoryId", this.strCategoryId)
fData.append("strArabicName", this.frmSubCategoryEdit.value.arabicName);
fData.append("strLoginUserId", localStorage.getItem("userId"));
fData.append("strDescription", this.frmSubCategoryEdit.value.txtDescription);
fData.append("intSortNo", this.frmSubCategoryEdit.value.intSortNo);
fData.append("strName", this.frmSubCategoryEdit.value.strName)
// for (let image of this.categoryImage) {
//   fData.append("strImageUrl", image, image.name)
// }
// fData.append("categoryImage", this.frmsubCategory.value.strImageUrl)
for (let image of this.categoryImg) {
  fData.append("categoryImage", image, image.name);
}
fData.forEach((value, key) => {
  console.log(key, value);
});
this.hypermarketServiceObj.getUpdatedefaultsubCategory(fData).subscribe((res) => {
  if (res.success === true) {
              this.clicked = false;
      this.blnLoader = true;
    Swal.fire({
      title: "Updated!",
      text: "SubCategory Updated successfully",
      icon: "success",
      confirmButtonText: "Ok",
    }).then(() => {
      this.getDefaultSubCategoryDetails();
      this.modalService.dismissAll();
      this.categoryImg=[]
      const inputElement = document.getElementById(
        'image'
      ) as HTMLInputElement;
      if (inputElement) {
        inputElement.value = '';
      }
      })
    // this.modalService.dismissAll();
  } else {
    alert(res.message)
  }
  this.getDefaultSubCategoryDetails();
});
}

onClickViewImg(item, image, type) {
  this.objSelectedItem = item;
  this.strSelectedImg = image;
  this.strSelectedImageType = type;
  this.show();
}
show() {
  this.showModal = true;
}
  _getDeleteModal(responsiveDelete, id) {
    this.strCategoryId = id;
    this.modalService.open(responsiveDelete);
  }

  fkDepartmentId:any


  _getEditType(responsiveData, objType) {
    console.log(objType);
    this.modalService.open(responsiveData);
    this.strCategoryId = objType.pkCategoryId;
    this.fkDepartmentId=objType.fkDepartmentId
    // this.frmCategory.patchValue({ strName: objType.strName });
    // this.frmCategory.patchValue({ arabicName: objType.strArabicName });
    // this.frmCategory.patchValue({ txtDescription: objType.strDescription });
    // this.frmCategory.patchValue({ txtImageUrl: objType.strImageUrl });
    // this.frmCategory.patchValue({ txtType: objType.strType });
    // this.frmCategory.patchValue({ txtSortNo: objType.intSortNo });
    this.frmSubCategoryEdit.patchValue({ strName: objType.strName });
    // this.frmsubCategory.patchValue({ strName: objType.strName });
    this.frmSubCategoryEdit.patchValue({ arabicName: objType.strArabicName });
    this.frmSubCategoryEdit.patchValue({ txtDescription: objType.strDescription });
    this.frmSubCategoryEdit.patchValue({ strImageUrl: objType.strImageUrl });
    // this.frmsubCategory.patchValue({ txtImageUrl: objType.categoryImage });
    this.frmSubCategoryEdit.patchValue({ txtType: objType.strType });
    this.frmSubCategoryEdit.patchValue({ intSortNo: objType.intSortNo });
    // this.frmSubCategoryEdit.patchValue({ intSortNo: objType.intSortNo });
    this.frmSubCategoryEdit.patchValue({ drpCategory: objType. strParentCategoryId});

    this.getDefaultCategoryDetails(objType.fkDepartmentId)



  }
  
    // this.frmsubCategory.patchValue({ categoryImage: objType.txtImageUrl });




  
  onFileChange(event) {
    this.categoryImg = []
    console.log("event");
    for (let i of event.target.files) {
      this.categoryImg.push(i);
    }
  }


  deleteDefaultsubCategory() {

    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
      // strCategoryId: this.pkCategoryId,
      "strCategoryId": this.strCategoryId.pkCategoryId


    };
    console.log(obj, "objjjjjjjj");

    this.hypermarketServiceObj.deleteDefaultsubCategory(obj).subscribe((res) => {
      if (res.success === true) {
        Swal.fire({
          title: "Deleted!",
          text: " Subcategory has been deleted Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then((result) => {
          if (result.value) {
            // this.spinnerObj.hide();
            this.ngOnInit();
            this.modalService.dismissAll();
          }
        });
      } else {
        Swal.fire({
          title: "Error",
          text: res.message,
          icon: "error",
          confirmButtonText: "Ok",
        });
        // this.spinnerObj.hide();
      }
      this.getDefaultSubCategoryDetails();
    });
  }
  // errorImage(event) {
  //   event.target.src = 'assets/images/Group 4024 (1).png';
  // }



  getViewtype(strViewType) {
    this.strViewType = strViewType;
    console.log(strViewType,"rtgyuhj")
    let selectedObject:any = this.arrViewType.find((obj :any) => obj.pkDepartmentId === strViewType);
    // strParentCategoryId:this.strCategoryId
      // If object is found, you can access both name and ID
      if (selectedObject) {
        console.log(selectedObject,"seee")
        // this.frmsubCategory.value.strViewType = selectedObject.strViewType;
         this.strViewType = selectedObject.strViewType;
        this.frmsubCategory.value.pkDepartmentId = selectedObject.pkDepartmentId;
         this.frmsubCategory.value.strName=selectedObject.strName
      }
    this.getDefaultCategoryDetails(selectedObject.pkDepartmentId);
  }



  // getViewtype(strViewType) {
  //   this.strViewType = this.pkDepartmentId;
  //   this.getDefaultCategoryDetails(strViewType);
  // }
  // pkDeptId:any
  // getViewtype(strViewType) {
  //   this.strViewType = strViewType;
  //   console.log(strViewType,"rtgyuhj")
  //   let selectedObject:any = this.arrViewType.find((obj :any) => obj.pkDepartmentId === strViewType);
  //   console.log(this.arrViewType,"ggggg")
    
  //     // If object is found, you can access both name and ID
  //     if (selectedObject) {
  //       this.strViewType = selectedObject.strViewType;
  //       this.pkDepartmentId =strViewType;
  //     }
  //     console.log(this.strViewType,"tyfdgh")
  
  //     // console.log(selectedObject.strName,"hgfds")
  // }

 
  // getViewtype(pkDepartmentId){
  //   this.strCategoryId = pkDepartmentId;
  //   this.getDefaultCategoryDetails(pkDepartmentId)
  // }

  
  // _getShoptId($ShopId) {
  //   this.strShopId = $ShopId;
  //   this.getListCategoryFn($ShopId);
  // }
  

  // getListCategoryFn(_id) {
  //   const obj = {
  //     strDepartMentId: _id,

  //   };
  //   console.log(obj);
  //   this.myProductService.categoryListingService(obj).subscribe(res => {
  //     this.arrOfCategoryList = res.data;
  //     console.log(res);
  //   });
  // }

  // getDefaultCategoryDetails(id) {

  //   let skipCount = this.intSkipCount;
  //   if (this.pager.intSkipCount) {
  //     skipCount = this.pager.intSkipCount;
  //   }
  //   const obj = {
  //     strLoginUserId: localStorage.getItem('userId'),
  //     fkDefaultDepartmentId: this.frmsubCategory.value.strViewType ? this.frmsubCategory.value.strViewType : (this.pkDepartmentId ? this.pkDepartmentId : ""),
  //     intSkipCount: skipCount,
  //     intPageLimit: this.intPageLimit,
  //     // fkDefaultDepartmentId:this.frmCategory.value.pkDepartmentId
  //   };
  //   console.log(obj, "list category obj::::::::::::::::::::");

  //   this.hypermarketServiceObj.getDefaultCategoryDetails(obj).subscribe((res) => {
  //     // console.log("Banners", res);
  //     // this.spinner.hide();
  //     if (res.success) {
  //       // this.spinner.hide();
  //       this.intTotalCount = res.data[0].intTotalCount;
  //       this.arrcategory = res.data;
  //       this.intTotalCount = res.count;
  //       this.pager = this.pageServiceObj.getPager(
  //         this.intTotalCount,
  //         this.pager.currentPage,
  //         this.intPageLimit
  //       );
  //     } else {
  //       this.arrcategory = [];
       
  //     }
  //   });
  // }




  getDefaultCategoryDetails(viewType) {

    let skipCount = this.intSkipCount;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
    const obj = {
      strLoginUserId: localStorage.getItem('userId'),
      // fkDefaultDepartmentId: this.frmsubCategory.value.pkDepartmentId ? this.frmsubCategory.value.pkDepartmentId : (this.pkDepartmentId ? this.pkDepartmentId : (viewType ? viewType : "")),
      // strName:this.frmsubCategory.value.strName,
      // intSkipCount: skipCount,
      // intPageLimit: this.intPageLimit,
      fkDefaultDepartmentId: viewType,

    };
    console.log(obj, "list banner obj::::::::::::::::::::");

    this.hypermarketServiceObj.getDefaultCategoryDetails(obj).subscribe((res) => {
      // console.log("Banners", res);
      // this.spinner.hide();
      if (res.success) {
        // this.spinner.hide();
        this.intTotalCount = res.data[0].intTotalCount;
        this.arrcategory = res.data[1]
        this.intTotalCount = res.count;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
      } else {
        this.arrcategory = [];
       
      }
    });
  }


  get formControls() {
    return this.frmsubCategory.controls;
  }









  
  getSavedefaultdummysubCategoryService() {
    this.blnLoader = false;
    this.submitted = true;
    // this.submitted = !this.submitted;
    // if (this.frmsubCategory.invalid) {
    //   this.blnLoader = true;
    //   return;
    // }
    if (this.frmsubCategory.invalid) {
      this.blnLoader = true;
      return;
    }
    let fData = new FormData();


     fData.append("strCategoryId", this. frmsubCategory.value.drpCategory)
    //  "this.strCategoryId": "650d7731ece141ff4c782abf "
    //  fData.append("strCategoryId", this.frmsubCategory.value.drpCategory)
      fData.append("strParentCategoryId", this.frmsubCategory.value.drpCategory);
    // fData.append("strCategoryId", this.frmsubCategory.value.drpCategory)
          // strViewType :this."GROCERY"
          // fData.append("fkDefaultDepartmentId", this.frmsubCategory.value.fkDefaultDepartmentId);

    // fData.append("strCategoryId", this.pkCategoryId)
    //  fData.append("pkCategoryId", this.strCategoryId)
  // fData.append("pkCategoryId", this.frmsubCategory.value.strCtegoryId)
// fData.append("pkCategoryId",this.frmCategory.strCategoryId);

// fData.append("s", this.frmsubCategory.value.strViewType);

    fData.append("strViewType", this.strViewType);
    fData.append("strArabicName", this.frmsubCategory.value.arabicName);
    fData.append("strLoginUserId", localStorage.getItem("userId"));
    fData.append("strDescription", this.frmsubCategory.value.txtDescription);
    // fData.append("strSortCount", this.frmsubCategory.value.strSortCount);
     fData.append("strCategoryName", this.frmsubCategory.value.strName)
    // fData.append("strName", this.frmsubCategory.value.strName)
    // fData.append("fkDepartmentId",  this.pkDeptId);
    for (let image of this.categoryImg) {
      fData.append("subCategoryImage", image, image.name);
    }
    
    // fData.append("categoryImage", this.frmsubCategory.value.strImageUrl)
    fData.forEach((value, key) => {
      console.log(key, value);
    });
    this.hypermarketServiceObj.getSavedefaultdummysubCategoryService(fData).subscribe((res) => {
      console.log(res, "resssviwetype123456");
      if (res.success === true) {
        Swal.fire({
          title: "saved",
          text: "SubCategory added successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then(() =>{
        
        // this.blnLoader = true;
        // alert('Sub category  Saved');
        // this.refreshPage();
        this.frmsubCategory.reset()
        this.router.navigate(["assetkit/add-add-defaultsubcategory"]);
        this.submitted=false;
        });
        // this.getDefaultSubCategoryDetails();
      } else {
        this.blnLoader = true;
        // alert(res.message)
      }
      this.getDefaultSubCategoryDetails();
    });
  }
  //   // fData.append("strName", this.frmsubCategory.value.strName)
  //   // fData.append("strArabicName", this.frmsubCategory.value.arabicName)
  //   // fData.append("strDescription", this.frmsubCategory.value.txtDescription)
  //   // fData.append("strLoginUserId", localStorage.getItem('userId'))

  //   // fData.append("strViewType", this.frmsubCategory.value.drpViewType)
  //   // fData.append("strSortCount", this.frmsubCategory.value.txtSortNo)
  //   // fData.append("strCategoryId", this.frmsubCategory.value.drpCategory)

  //   fData.append("strViewStatus", this.frmsubCategory.value.blnStatus)
  //   for (let image of this.subCategoryImg) {
  //     fData.append("strImageUrl", image, image.name)
  //   }

  //   console.log("view type")

  //   console.log("view type", this.frmsubCategory.value.drpViewType)

  //   this.hypermarketServiceObj.getSavedefaultdummyCategoryService(fData).subscribe((res => {

  //     if (res.success === true) {
  //       Swal.fire({
  //         title: "Saved!",
  //         text: "SubCategory added successfully",
  //         icon: "success",
  //         confirmButtonText: "Ok",
  //       })
  //       this.blnLoader = true;
  //       // alert('Sub category  Saved');
  //       this.refreshPage();
  //       this.getDefaultSubCategoryDetails();
  //     } else {
  //       this.blnLoader = true;
  //       // alert(res.message)
  //     }
  //     this.getDefaultSubCategoryDetails();

  //   }));

  // }
  getf() {
    return this.frmsubCategory.controls
  }

  // refreshPage() {
  //   this.router.routeReuseStrategy.shouldReuseRoute = () => false;
  //   this.router.onSameUrlNavigation = 'reload';
  //   this.router.navigate(['assetkit/add-defaultsubcategory']);
  // }


}
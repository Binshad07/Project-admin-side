import { Component, OnInit } from '@angular/core';
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { PagerService } from "src/app/shared/services/pager.service";
import { Router } from "@angular/router";
import Swal from "sweetalert2";
import { FormGroup, FormBuilder } from "@angular/forms";
import { BannersService } from 'src/app/shared/services/Banner/banners.service';
import { HypermarketService } from "./../../../shared/services/Hypermarket/hypermarket.service";


@Component({
  selector: 'app-defaultbanners',
  templateUrl: './defaultbanners.component.html',
  styleUrls: ['./defaultbanners.component.scss']
})
export class DefaultbannersComponent implements OnInit {


 intTotalCount = 0;
 frmBanners: FormGroup;
  myform: FormGroup;
  intSkipCount = 0;
  pageLimit: any[];
  intPageLimit = 10;
  pager: any = {};
  arrHomeBanner = [];
  // strBannerImageId = "";
  showModal: boolean;
  strSelectedImg: string;
  strSelectedImageType: string;
  objSelectedItem: any;
  pkImageId: any;
  isAdmin = true;
  arrbanners = [];
  arrOfCategoryList = [];
  arrViewType: [];
  strName: "";
  id: any;
  arabicName: ""
  // strCategoryId = "";
  intSortNo: "";
  editSubmitted: boolean = false;
  strImageUrl: ""
  txtDescription: ""
  blnLoader = false;
  submitted = false;
  clicked = false;
  strCategoryId: any;
  categoryImg: File[] = [];
  pkCategoryId:any
  strBannerId:any
  strImageType
  strBannerImageUrl:""
  type = "Add";

  ViewType:""
  // strViewType = '';
 
  value: any;
  constructor(
    private pageServiceObj: PagerService,
    private modalService: NgbModal,
     private router: Router,
    private formBuilder: FormBuilder,
    private BannerService: BannersService,
    private hypermarketServiceObj: HypermarketService,

  ) {




    
   }

  ngOnInit() {




    this.frmBanners = this.formBuilder.group({


      
       strViewType: "",
      strImageUrl: "",
      ViewType:"",
      intSortNo: "",
      arabicName: "",
      strName: "",
      txtImageUrl: "",
      txtDescription: "",
      strCategoryName: "",
      pkCategoryId: "",
      strBannerId:"",
      strImageType:"",
      intSort:"",
      bannerImage:"",
      strBannerImageUrl:"",
      pkImageId:"",
    //  strViewType : 'string'
      //  strViewType: ''
      // strBannerImageUrl:"",
      // strBannerImageId:""
    });


    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist
    this.getDefaultDepartment();

  }

  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getDefaultDepartment();
     this.getDefaultBannerDetails();


  }




  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.getDefaultDepartment();
     this.getDefaultBannerDetails();


  }



  _onClear(form: FormGroup) {
    form.reset({
      strViewType: "",
    });
    this.getDefaultDepartment();
  }

  pkDepartmentId: any
  getDefaultDepartment() {
    const obj = {};
    if (localStorage.getItem("strUserType") == "SHOP REPORTER") {
      Object.assign(obj, {
        strViewTypeName: localStorage.getItem("strViewType"),
      });
    }
    this.hypermarketServiceObj.getDefaultDepartment(obj).subscribe((res) => {
      console.log(res, "resssviwetype");
      this.arrViewType = res.data;
      this.pkDepartmentId = res.data[0].strViewType
      console.log(this.arrViewType, "console", this.pkDepartmentId);
      this.setDefaultViewType(this.arrViewType);
     this.getDefaultBannerDetails();
    });
  }
  setDefaultViewType(viewType) {
    if (!this.isAdmin) {
      const firstOptionValue = viewType[0].strName;
      this.frmBanners.get("drpViewType").setValue(firstOptionValue);
    }
  }







  getDefaultBannerDetails() {

    let skipCount = this.intSkipCount;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
    const obj = {
      strLoginUserId: localStorage.getItem('userId'),
 
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
      // strViewType:
      //  strViewType: this.frmBanners.value.strViewType ? this.frmBanners.value.strViewType : (this.pkDepartmentId ? this.pkDepartmentId : ''),
      strViewType: this.frmBanners.value.strViewType 
      // strViewType: this.frmBanners.value.ViewType 

      
    };
    console.log(obj, "list banner obj::::::::::::::::::::");

    this.hypermarketServiceObj.getDefaultBannerDetails(obj).subscribe((res) => {
      // console.log("Banners", res);
      // this.spinner.hide();
      if (res.success) {
        // this.spinner.hide();
        this.intTotalCount = res.data[0].intTotalCount;
        this.arrbanners = res.data [1];
        // this.intTotalCount = res.count;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
      } else {
        this.arrbanners = [];
       
      }
    });
  }






  errorImage(event) {
    // event.target.src = 'assets/images/Group 4024 (1).png';
  }



  _getEditType(responsiveData, objType) {
    console.log(objType);
    this.modalService.open(responsiveData);
    // this.id = objType.strBannerId;
    this.strBannerId = objType.pkImageId;

    // this.strBannerId=objType.strBannerId
    // "strBannerId="664c8203e88a55e20978533f"
    // this.frmBanners.patchValue({ strImageType: objType.strImageType });
  
    this.frmBanners.patchValue({ strImageType: objType.strImageType });
    this.frmBanners.patchValue({ intSort: objType.intSort });
    this.frmBanners.patchValue({ bannerImage: objType.bannerImage });
    this.frmBanners.patchValue({ strBannerImageUrl: objType.strImageUrl });
    this.frmBanners.patchValue({ strViewType: objType.strViewType });

    // this.frmCategory.patchValue({ txtType: objType.strType });
    // this.frmCategory.patchValue({ intSortNo: objType.intSortNo });

    // console.log(objType.pkImageId,"dxfcgvhj")


  }
  
  

  // _getDeleteModal(responsiveDelete, id) {
  //     // "strBannerId":this.strBannerId.pkImageId
  //     // this.strCategoryId = id;
  //     this.strBannerId = id.strBannerId;

  //   this.modalService.open(responsiveDelete);
  // }

//   _getDeleteModal(responsiveDelete, id) {
//     console.log(id,"details")
//     // this.strBannerId = id.pkImageId;
//     // this.pkImageId = strBannerId;
// // this.strBannerId=pkImageId,id
// this.strBannerId=this.pkImageId
//     this.modalService.open(responsiveDelete);
//   }

_getDeleteModal(responsiveDelete, id) {
  console.log(id,"object")
  this.strBannerId = id.pkImageId;
  this.modalService.open(responsiveDelete);
}

getUpdateTypeFn() {


    this.blnLoader = false;
    this.submitted = true;

    if (this.frmBanners.invalid) {
      this.blnLoader = true;
      return;
    }
    let fData = new FormData();
    // pkImageId: this.strBannerId,

       fData.append("strBannerId", this.strBannerId,
        
      )
      // fData.append("strBannerId", this.id, );

      // fData.append("pkImageId",this.strBannerId)
    // fData.append("id",this.strBannerId)

    // strImageType: this.frmCategory.value.deviceType,

    // fData.append()
    // fData.append("strBannerId", this.frmCategory.value.pkImageId);

    // "strBannerId"="664c8203e88a55e20978533f"


    // fData.append("strArabicName", this.frmCategory.value.arabicName);

    fData.append("strLoginUserId", localStorage.getItem("userId"));

    // fData.append("strDescription", this.frmCategory.value.txtDescription);
    fData.append("intSort", this.frmBanners.value.intSort);
    fData.append("strImageType", this. frmBanners.value.strImageType,);


    // fData.append("strName:", this.frmCategory.value.strName);

    if (this.categoryImg.length) {
    for (let image of this.categoryImg) {
      fData.append("bannerImage", image, image.name);
    }
  }else{
  }
    fData.forEach((value, key) => {
      console.log(key, value);
    });


    this.hypermarketServiceObj
      .getUpdatedefaultbanners(fData)
      .subscribe((res) => {
        if (res.success === true) {
          this.clicked = false;
          this.blnLoader = true;
          Swal.fire({
            title: "Saved!",
            text: "Banner Updated Successfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then(() => {
            this.getDefaultBannerDetails();
            // this.refreshPage()
            // this.getListCategoryFn();


            this.modalService.dismissAll()
          this.categoryImg=[]
          const inputElement = document.getElementById(
            'image'
          ) as HTMLInputElement;
          if (inputElement) {
            inputElement.value = '';
          }
            // this.frmBanners.reset();
            this.router.navigate(["/assetkit/defaultbanners"]);
            this.submitted = false;
          });
        } else {
          this.blnLoader = true;

        }
        this.getDefaultBannerDetails();

      });
  }
  onFileChange(event) {
    console.log("event");
    for (let i of event.target.files) {
      this.categoryImg.push(i);
    }
  }

  onClickViewImg(item, image, type) {
    this.objSelectedItem = item;
    this.strSelectedImg = image;
    this.strSelectedImageType = type;
    this.show();
  }


  show() {
    this.showModal = true;
  }




  // deleteDefaultbannerDetails()  {
   
  //   const obj = {
  //     strLoginUserId: localStorage.getItem("userId"),
  //     // strCategoryId: this.pkCategoryId,
  //     // "strCategoryId":this.strCategoryId.pkCategoryId
  //     // "strBannerId":this.strBannerId.pkImageId
  //     // "strLoginUserId": "5e93363f66c497c2bb08f357",
  //     // "strCategoryId": "650d1bc63009df3d02c17865"
  //     // "strBannerId":"this.id"
  //     strBannerId: this.strBannerId,

  //   };
  //   console.log(obj, "objjjjjjjj");

  //   this.hypermarketServiceObj.deleteDefaultbannerDetails(obj).subscribe((res) => {
  //     if (res.success === true) {
  //       Swal.fire({
  //         title: "Deleted!",
  //         text: "bannershas been deleted Successfully",
  //         icon: "success",
  //         confirmButtonText: "Ok",
  //       }).then((result) => {
  //         if (result.value) {
  //           // this.spinnerObj.hide();
  //           this.ngOnInit();
  //           this.modalService.dismissAll();
  //         }
  //       });
  //     } else {
  //       Swal.fire({
  //         title: "Error",
  //         text: res.message,
  //         icon: "error",
  //         confirmButtonText: "Ok",
  //       });
  //       // this.spinnerObj.hide();
  //     }
  //     this.getDefaultProductDetails();
  //   });
  // }

  hide() {
    this.showModal = false;
  }
  


  deleteDefaultbannerDetails() {


    const obj = {
      strBannerId: this.strBannerId,
      strLoginUserId:localStorage.getItem("userId"),
    }
    console.log(obj)
    this.hypermarketServiceObj.deleteDefaultbannerDetails(obj).subscribe((res) => {      
      if (res.success) {
        this.modalService.dismissAll();
        // this.spinner.hide();
        Swal.fire({
          title: "Home Banner deleted!",
          text: "Home Banner Deleted Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then(() => {
          this.ngOnInit()
          this.getDefaultBannerDetails()
        })
      } else {
        // this.spinner.hide();
        Swal.fire({
          title: "Error",
          text: res.message,
          icon: "error",
          confirmButtonText: "Ok",
        });
      }
      this.getDefaultBannerDetails();
    }, (err) => {
      // this.ngOnInit()
      // console.log(err)
    })
  }












}

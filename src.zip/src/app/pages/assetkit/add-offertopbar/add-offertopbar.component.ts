// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-add-offertopbar',
//   templateUrl: './add-offertopbar.component.html',
//   styleUrls: ['./add-offertopbar.component.scss']
// })
// export class AddOffertopbarComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }


// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-adddefaultcategory',
//   templateUrl: './adddefaultcategory.component.html',
//   styleUrls: ['./adddefaultcategory.component.scss']
// })
// export class AdddefaultcategoryComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }

import { Component, OnInit } from '@angular/core';
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { PagerService } from "src/app/shared/services/pager.service";
import { Router } from "@angular/router";
import Swal from "sweetalert2";
import { FormGroup, FormBuilder } from "@angular/forms";
import { BannersService } from 'src/app/shared/services/Banner/banners.service';
import { HypermarketService } from "./../../../shared/services/Hypermarket/hypermarket.service";
import { Validators } from "@angular/forms";

@Component({
  selector: 'app-add-offertopbar',
  templateUrl: './add-offertopbar.component.html',
  styleUrls:  ['./add-offertopbar.component.scss']
})
export class AddOffertopbarComponent implements OnInit {


  intTotalCount = 0;
  // frmCategory: FormGroup;
  formoffer:FormGroup
  frmOfferEdit: FormGroup
  // myform: FormGroup;
  intSkipCount = 0;
  pageLimit: any[];
  intPageLimit = 10;
  pager: any = {};
  arrHomeBanner = [];
  strBannerImageId = "";
  showModal: boolean;
  strSelectedImg: string;
  strSelectedImageType: string;
  // objSelectedItem: any;
  pkImageId: any;
  isAdmin = true;
  arrOffertopbar = [];
  arrOfCategoryList = [];
  arrViewType: [];
  strName: "";
  id: any;
  strArabicName: ""
  // strCategoryId = "";
  // intSort: "";
  intSortNo:""
  strSortCount:""
  // editSubmitted:  false;
  strImageUrl: ""
  txtDescription: ""
  blnLoader = false;
  // submitted: boolean = false;
  submitted : boolean = false;
  clicked = false;
  strCategoryId: any;
  categoryImg: File[] = [];
  pkCategoryId: any
  pkOffersTopBarId:any
  strOffersTopBarId: any;

  //  blnStatus: true


  constructor(

    private pageServiceObj: PagerService,
    private modalService: NgbModal,


    private router: Router,
    private formBuilder: FormBuilder,
    private BannerService: BannersService,
    private hypermarketServiceObj: HypermarketService,


  ) { }

  ngOnInit() {
    // blnStatus: [true]
    strName:

    this.formoffer = this.formBuilder.group({

      // strViewType: ["", Validators.required],
      strImageUrl: ["",],
      // intSort: ["",],
      arabicName: ["", ],
      strName: ["",],
      // txtImageUrl: ["",Validators.required],
      txtDescription: "",
      strCategoryName: ["",],
      // pkCategoryId: "",
      blnStatus: [true],
      pkDepartmentId: "",
      intSortNo: "",
      strLink:"",
      strArabicName:"",
      strDefaultDepartmentID:""


    });


    this.frmOfferEdit = this.formBuilder.group({
      txtdeviceType: "",
      arabicName:"",
      strImageUrl:"",
      intSortNo:"",
      strName:"",
      txtImageUrl:"",
      strLink:"",
      strOffersTopBarId:"",
      imageFile:""
    });

      // strDefaultDepartmentID:""
      // strSortCount: ""

      // fkShopId: [""],
  


    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist
    this.getOffertopbar();

  }





  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    // this.getDefaultDepartment();
    this.getOffertopbar();


  }



  deleteoffertopbar()  {
   
    const obj = {
     
    strOffersTopBarId:this.strOffersTopBarId.pkOffersTopBarId,
     strLoginUserId: localStorage.getItem("userId"),
    
    // "strCategoryId":this.strCategoryId.pkCategoryId
     
    };
    console.log(obj, "objjjjjjjj");

    this.hypermarketServiceObj.deleteoffertopbar(obj).subscribe((res) => {
      if (res.success === true) {
        Swal.fire({
          title: "Deleted!",
          text: "Offertobbar has been deleted Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then((result) => {
          if (result.value) {
            // this.spinnerObj.hide();
            this.ngOnInit();
            this.modalService.dismissAll();
          }
        });
      } else {
        Swal.fire({
          title: "Error",
          text: res.message,
          icon: "error",
          confirmButtonText: "Ok",
        });
        // this.spinnerObj.hide();
      }
      this.getOffertopbar();
    });
  }


  _getDeleteModal(responsiveDelete, id) {
    this.strOffersTopBarId = id;
    this.modalService.open(responsiveDelete);
  }

  
  getUpdateTypeFn() {


    this.blnLoader = false;
    this.submitted = true;

   
    let fData = new FormData();
    fData.append("strOffersTopBarId", this.pkOffersTopBarId)


    fData.append("strArabicName", this.frmOfferEdit.value.arabicName);

    fData.append("strLoginUserId", localStorage.getItem("userId"));

    // fData.append("strDescription", this.formoffer.value.txtDescription);
    fData.append("intSortNo", this.frmOfferEdit.value.intSortNo);

    fData.append("strName", this.frmOfferEdit.value.strName);

    fData.append("strLink", this.frmOfferEdit.value.strLink);

    for (let image of this.categoryImg) {
      fData.append("imageFile", image, image.name);
    }
    fData.forEach((value, key) => {
      console.log(key, value);
    });
  


    this.hypermarketServiceObj
    .getUpdateoffertopbar(fData)
      .subscribe((res) => {
        if (res.success === true) {
          this.clicked = false;
          this.blnLoader = true;
          Swal.fire({
            title: "Saved!",
            text: "Offertopbar Updated Successfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then(() => {
           


  this.getOffertopbar();
          this.modalService.dismissAll();
          this.categoryImg=[]
          const inputElement = document.getElementById(
            'image'
          ) as HTMLInputElement;
          if (inputElement) {
            inputElement.value = '';
          }
          })
        // this.modalService.dismissAll();
      } else {
        alert(res.message)
      }
      // this.getDefaultSubCategoryDetails();
      })
    }

  // _onClear(form: FormGroup) {
  //   form.reset({
  //     //   strViewType: "",
  //     // this.submitted = false;

  //     strName: "",
  //     arabicName: "",
  //     txtDescription: '',
  //     strImageUrl: "",
  //     blnStatus: "",
  //     strViewType: "",
  //     intSortNo: "",
  //     txtImageUrl: "",


  //   });
  //   this.getDefaultDepartment();
  // }






  
  _onClear() {
    this.submitted=false;
this.formoffer.reset();
this.ngOnInit();
   
    this.getOffertopbar();
  }
  


 

  getOffertopbar() {

    let skipCount = this.intSkipCount;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
     const obj = {
  
       strLoginUserId:  localStorage.getItem('userId'),

       
     
      strSkipCount: skipCount,
       strPageLimit: this.intPageLimit,

    };
    // if(localStorage.getItem('fkShopId')){
    //   Object.assign(obj,{fkShopId: localStorage.getItem('fkShopId')})
    //   // obj.fkShopId=localStorage.getItem('fkShopId')
    // }
    // console.log(obj,"list banner obj::::::::::::::::::::");
    
    this.BannerService.getOffertopbar(obj).subscribe((res) => {
      console.log("Banners", res);
      // this.spinner.hide();
      if (res.success) {
        // this.spinner.hide();
        this.intTotalCount =  res.data[0].intTotalCount;
        this.arrOffertopbar = res.data;
        this.intTotalCount = res.count;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
      } else {
        this.arrOffertopbar =[];
        // Swal.fire({
        //   title: "Error",
        //   text: res.message,
        //   icon: "error",
        //   confirmButtonText: "Ok",
        // });
        // this.spinner.hide();
      }
    });
  }




  errorImage(event) {
    // event.target.src = 'assets/images/Group 4024 (1).png';
  }



  _getEditType(responsiveData, objType) {
    console.log(objType);
    this.modalService.open(responsiveData);
    this.pkOffersTopBarId = objType.pkOffersTopBarId;
    this.frmOfferEdit.patchValue({ strName: objType.strName });
    this.frmOfferEdit.patchValue({ arabicName: objType.strArabicName });
    this.frmOfferEdit.patchValue({ txtDescription: objType.strDescription });
    this.frmOfferEdit.patchValue({ txtImageUrl: objType.strImageUrl });
    this.frmOfferEdit.patchValue({ txtType: objType.strType });
    this.frmOfferEdit.patchValue({ intSortNo: objType.intSortNo });
    this.frmOfferEdit.patchValue({ strLink: objType.strLink });




  }


  // _getDeleteModal(responsiveDelete, id) {
  //   this.strCategoryId = id;
  //   this.modalService.open(responsiveDelete);
  // }








  
  hide() {
    this.showModal = false;
  }


  
  onFileChange(event) {
    console.log("event");
    for (let i of event.target.files) {
      this.categoryImg.push(i);
    }
  }

  get formControls() {
    return this.formoffer.controls;
  }
  // getf() {
  //   return this.frmCategoryEdit.controls
  // }
  getf() {
    return this.frmOfferEdit.controls
  }
 

  pkDeptId:any
  // getSaveoffertopbar() {
  //   this.blnLoader = false;
  //   this.submitted = true;
  //   // this.submitted = !this.submitted;
  //   // if (this.frmCategory.invalid) {
  //   //   this.blnLoader = true;
  //   //   return;
  //   // }
  //   if (
  //     !this.categoryImg.length
  //   ) {
  //     this.formoffer.invalid
  //   }
  //   if (this.formoffer.invalid) {
  //     this.blnLoader = true;
  //     return;
  //   }
  //   let fData = new FormData();
  //   fData.append("strLoginUserId", localStorage.getItem("userId"));

  //   fData.append("strName", this.formoffer.value.strName);
  //   fData.append("strArabicName", this.formoffer.value.arabicName);
  //   fData.append("strLink", this.formoffer.value.strLink);
  //   // strDefaultDepartmentID="6520f46fc03f3a1ea1970e04"
  //    fData.append("strDefaultDepartmentID",this.pkOffersTopBarId); 

  //   fData.append("intSortNo", this.formoffer.value.intSortNo);
    
  //   for (let image of this.categoryImg) {
  //     fData.append("imageFile", image, image.name);
  //   }
  //   fData.forEach((value, key) => {
  //     console.log(key, value);
  //   });
  //   // this.clicked = true;

  //   this.hypermarketServiceObj
  //     .getSaveoffertopbar(fData)
  //     .subscribe((res) => {
  //       if (res.success === true) {
  //         this.clicked = false;
  //         this.blnLoader = true;
  //         Swal.fire({
  //           title: "Saved!",
  //           text: "New offertobbar Added Successfully",
  //           icon: "success",
  //           confirmButtonText: "Ok",
  //         }).then(() => {
  //           // this.refreshPage()
  //           // this.getListCategoryFn();


  //           this.formoffer.reset();
  //           this.router.navigate(["assetkit/add-offertopbar"]);
  //           this.submitted = false;
  //         });
  //       } else {
  //         this.blnLoader = true;
  //         // Swal.fire({
  //         //   title: "Error",
  //         //   text: res.message,
  //         //   icon: "error",
  //         //   confirmButtonText: "Ok",
  //         // })
  //         // alert(res.message)
  //       }
  //       this.getOffertopbar();
  //     });
  // }



  getSaveoffertopbar() {
    this.blnLoader = false;
    this.submitted = true;
    if (!this.categoryImg.length) {
        this.formoffer.invalid;
    }
    if (this.formoffer.invalid) {
        this.blnLoader = true;
        return;
    }
    let fData = new FormData();
    fData.append("strLoginUserId", localStorage.getItem("userId"));
    fData.append("strName", this.formoffer.value.strName);
    fData.append("strArabicName", this.formoffer.value.arabicName);
    fData.append("strLink", this.formoffer.value.strLink);
    // Ensure strDefaultDepartmentID is correctly formatted
    fData.append("strDefaultDepartmentID", "6520f46fc03f3a1ea1970e04".trim());
    fData.append("intSortNo", this.formoffer.value.intSortNo);
    for (let image of this.categoryImg) {
        fData.append("imageFile", image, image.name);
    }
    fData.forEach((value, key) => {
        console.log(key, value);
    });
    this.hypermarketServiceObj.getSaveoffertopbar(fData).subscribe((res) => {
        if (res.success === true) {
            this.clicked = false;
            this.blnLoader = true;
            Swal.fire({
                title: "Saved!",
                text: "New offertopbar Added Successfully",
                icon: "success",
                confirmButtonText: "Ok",
            }).then(() => {
                this.formoffer.reset();
                this.router.navigate(["assetkit/add-offertopbar"]);
                this.submitted = false;
            });
        } else {
            this.blnLoader = true;
            Swal.fire({
                title: "Error",
                text: res.message,
                icon: "error",
                confirmButtonText: "Ok",
            });
        }
        this.getOffertopbar();
    }, (error) => {
        console.error("Error saving offertopbar: ", error);
        Swal.fire({
            title: "Error",
            text: "An error occurred while saving the offertopbar.",
            icon: "error",
            confirmButtonText: "Ok",
        });
        this.blnLoader = true;
    });
}


}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddOffertopbarComponent } from './add-offertopbar.component';

describe('AddOffertopbarComponent', () => {
  let component: AddOffertopbarComponent;
  let fixture: ComponentFixture<AddOffertopbarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddOffertopbarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddOffertopbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";


import { AssetkitRoutingModule } from './assetkit-routing.module';
import { CategoryComponent } from './category/category.component';
import { SubcategoryComponent } from './subcategory/subcategory.component';
import { ProductComponent } from './product/product.component';
import { DefaultbannersComponent } from './defaultbanners/defaultbanners.component';
import { AddProductComponent } from './add-product/add-product.component';
import { BrandComponent } from './brand/brand.component';
import { AdddefaultsubcategoryComponent } from './adddefaultsubcategory/adddefaultsubcategory.component';
import { AdddefaultcategoryComponent } from './adddefaultcategory/adddefaultcategory.component';
import { AddUnitComponent } from './add-unit/add-unit.component';
import { ListUnitComponent } from './list-unit/list-unit.component';
import { AddDefaultBotttomBannerComponent } from './add-default-botttom-banner/add-default-botttom-banner.component';
import { ListDefaultBotttomBannerComponent } from './list-default-botttom-banner/list-default-botttom-banner.component';
import { OffertopbarComponent } from './offertopbar/offertopbar.component';
import { AddOffertopbarComponent } from './add-offertopbar/add-offertopbar.component';
import { AddHomebannerComponent } from './add-homebanner/add-homebanner.component';
// import { AnalyticsRequestComponent } from './analytics-request/analytics-request.component';

@NgModule({
  declarations: [CategoryComponent, SubcategoryComponent, ProductComponent, DefaultbannersComponent, AdddefaultsubcategoryComponent, AdddefaultcategoryComponent,AddProductComponent, BrandComponent, AddUnitComponent, ListUnitComponent, AddDefaultBotttomBannerComponent, ListDefaultBotttomBannerComponent, OffertopbarComponent,  AddHomebannerComponent,AddOffertopbarComponent ],
  imports: [
    CommonModule,
    AssetkitRoutingModule,
    FormsModule,
    ReactiveFormsModule,
  

  ]
  

 
})

export class AssetkitModule {
 

  
 }

import { Component, OnInit } from '@angular/core';
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { PagerService } from "src/app/shared/services/pager.service";
import { Router } from "@angular/router";
import Swal from "sweetalert2";
import { FormGroup, FormBuilder } from "@angular/forms";
import { BannerServiceService } from 'src/app/shared/services/BannerService/banner-service.service';
import { HypermarketService } from "./../../../shared/services/Hypermarket/hypermarket.service";

@Component({
  selector: 'app-list-default-botttom-banner',
  templateUrl: './list-default-botttom-banner.component.html',
  styleUrls: ['./list-default-botttom-banner.component.scss']
})
export class ListDefaultBotttomBannerComponent implements OnInit {

  intTotalCount = 0;
  formBannerImages: FormGroup;
  intSkipCount = 0;
  pageLimit: any[];
  intPageLimit = 10;
  pager: any = {};
  arrBanner = [];
  strBannerImageId = "";
  showModal: boolean;
  strSelectedImg: string;
  strSelectedImageType: string;
  objSelectedItem: any;
  strBannerId: any;
  arrViewType: [];
  isAdmin = true;
  strViewType = '';
  intSort:"";
      bannerImage:"";
  categoryImg: File[] = [];
  blnLoader = false;
  submitted = true;
  clicked = false;
  pkImageId: any;
  strImageUrl:""

  // blnLoader = false;

  constructor(
    private pageServiceObj: PagerService,
    private bannerService: BannerServiceService,
    private modalService: NgbModal,
    private router: Router,
    private formBuilder: FormBuilder,
    private hypermarketServiceObj: HypermarketService,
  ) { }

  ngOnInit() {
    this.formBannerImages = this.formBuilder.group({
      deviceType: "",
      strViewType: "",
      strBannerImageUrl:"",
      strImageType:"",
      intSort:"",
      bannerImage:"",
      pkImageId: "",
      strBannerId:"",
      strImageUrl:""

    });
    // this.shops = [];
    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist;

    this.getDefaultDepartment();
    this.getBannerList();
    // this.getRentalType()
  }
  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getDefaultDepartment();
    this.getBannerList();
  }
  onFileChange(event) {
    console.log("event");
    for (let i of event.target.files) {
      this.categoryImg.push(i);
    }
  }
  _getEditType(responsiveData, objType) {
    console.log(objType);
    this.modalService.open(responsiveData);
   

   
    this.strBannerId = objType.pkImageId;

    
    this.formBannerImages.patchValue({ strImageType: objType.strImageType });
    this.formBannerImages.patchValue({ intSort: objType.intSort });
    this.formBannerImages.patchValue({ bottomBannerImg: objType.bannerImage });
    this.formBannerImages.patchValue({ strBannerImageUrl: objType.strImageUrl });
    this.formBannerImages.patchValue({ strViewType: objType.strViewType });

   


  }

  getUpdateTypeFn() {


    this.blnLoader = false;
    this.submitted = true;

    if (this.formBannerImages.invalid) {
      this.blnLoader = true;
      return;
    }
    let fData = new FormData();
    
    fData.append("strBannerId", this.strBannerId,
        
    )
    fData.append("strLoginUserId", localStorage.getItem("userId"));

   
    fData.append("intSort", this.formBannerImages.value.intSort);
    fData.append("bottomBannerImg", this. formBannerImages.value.strImageType,);


  

    if (this.categoryImg.length) {
    for (let image of this.categoryImg) {
      fData.append("bottomBannerImg", image, image.name);
    }
  }else{
  }
    fData.forEach((value, key) => {
      console.log(key, value);
    });


    this.hypermarketServiceObj
      .getUpdatedefaultbottombanners(fData)
      .subscribe((res) => {
        if (res.success === true) {
          this.clicked = false;
          this.blnLoader = true;
          Swal.fire({
            title: "Saved!",
            text: "Banner Updated Successfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then(() => {
            this.getBannerList();
            // this.refreshPage()
            // this.getListCategoryFn();


            this.modalService.dismissAll()
          this.categoryImg=[]
          const inputElement = document.getElementById(
            'image'
          ) as HTMLInputElement;
          if (inputElement) {
            inputElement.value = '';
          }
            // this.frmBanners.reset();
            this.router.navigate(["/assetkit/list-default-bottombanner"]);
            this.submitted = false;
          });
        } else {
          this.blnLoader = true;

        }
        this.getBannerList();

      });
  }
  // getDefaultDepartment() {
  //   const obj = {};
  //   if (localStorage.getItem("strUserType") == "SHOP REPORTER") {
  //     Object.assign(obj, {
  //       strViewTypeName: localStorage.getItem("strViewType"),
  //     });
  //   }
  //   this.hypermarketServiceObj.getDefaultDepartment(obj).subscribe((res) => {
  //     console.log(res, "resssviwetype");
  //     this.arrViewType = res.data;
  //     this.pkDepartmentId = res.data[0].strViewType
  //     console.log(this.arrViewType, "console", this.pkDepartmentId);
  //     this.setDefaultViewType(this.arrViewType);
  //    this.getDefaultBannerDetails();
  //   });
  // }
  getBannerList() {

    let skipCount = this.intSkipCount;
    // this.blnLoader = false;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
 

    const obj = {
      strLoginUserId: "localStorage.getItem('userId'),",
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
      // fkDepartmentId: this.pkDepartmentId,
      strViewType: this.formBannerImages.value.strViewType 
      // strViewType: "GROCERY"
      // fkDefaultDepartmentId:this.formBannerImages.value.strViewType};

      //  strViewType: this.formBannerImages.value.strViewType ? this.formBannerImages.value.strViewType : (this.pkDepartmentId ? this.pkDepartmentId : ''),

    }
    

    this.hypermarketServiceObj.getDefaultBottomBannerDetails(obj).subscribe((res) => {
      if (res && res.success) {
        //  this.ngOnInit()
        // this.spinner.hide();
        // this.blnLoader = true;
        this.intTotalCount = res.data[0].intTotalCount;
        this.arrBanner = res.data [1];
        // this.intTotalCount = res.count;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
      } else {
        this.arrBanner = []
        // Swal.fire({
        //   title: "Error",
        //   text: res.message,
        //   icon: "error",
        //   confirmButtonText: "Ok",
        // });
        // this.spinner.hide();
      }
    })
  }

  onClickViewImg(item, image, type) {
    this.objSelectedItem = item;
    this.strSelectedImg = image;
    this.strSelectedImageType = type;
    this.show();
  }

  show() {
    this.showModal = true;
  }
  hide() {
    this.showModal = false;
  }

  _onSearch() {

    this.pager = {};
    this.intTotalCount = 0;
    this.getDefaultDepartment();
    this.getBannerList();
    

  }
  // errorImage(event) {
  //   event.target.src = 'assets/images/cart_logo.png';
  // }
  _onClear() {
    this.formBannerImages.reset()
    this.ngOnInit()
  }


  deleteModal(responsiveDelete, item) {
    this.strBannerId = item.pkImageId;
    this.modalService.open(responsiveDelete);
  }

  delete() {
    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
      strBannerId: this.strBannerId,
    }
    console.log(obj)

    // this.spinner.show();

    this.hypermarketServiceObj.deleteDefaultbottombannerDetails(obj).subscribe((res) => {
      if (res.success && res) {
      
        // this.spinner.hide();
        Swal.fire({
          title: "Deleted!",
          text: "Bottom Banner deleted successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then(() => {
          this.modalService.dismissAll();
          this.getBannerList()
        })
      } else {
        // this.spinner.hide();
        this.arrBanner = []

        // Swal.fire({
        //   // title: "Error",
        //   // text: res.message,
        //   // icon: "error",
        //   // confirmButtonText: "Ok",
        // });
      }
      this.getBannerList();
    }, (err) => {
      console.log(err)
    })
  }



  // edit(item) {

  //   console.log(item)
  //   this.router.navigate(["/product/add-banner"], {
  //     queryParams: { id: item.pkImageId },
  //   });
  // }

errorImage(event) {
 
  event.target.src = 'assets/images/Group 4024 (1).png';
}

pkDepartmentId: any
getDefaultDepartment() {
    const obj = {}
    if (localStorage.getItem('strUserType') == 'SHOP REPORTER') {
      Object.assign(obj, {
        strViewTypeName: localStorage.getItem("strViewType"),
      })
    }
    console.log(obj)
    this.hypermarketServiceObj.getDefaultDepartment(obj).subscribe((res) => {
      this.arrViewType = res.data;
      this.setDefaultViewType(this.arrViewType);
    })
  
}

setDefaultViewType(viewType) {
  if (!this.isAdmin) {
    const firstOptionValue = viewType[0].strViewType;
    this.formBannerImages.get("drpViewType").setValue(firstOptionValue);
  }
}

}

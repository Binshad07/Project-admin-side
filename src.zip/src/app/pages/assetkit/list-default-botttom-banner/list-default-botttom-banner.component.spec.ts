import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListDefaultBotttomBannerComponent } from './list-default-botttom-banner.component';

describe('ListDefaultBotttomBannerComponent', () => {
  let component: ListDefaultBotttomBannerComponent;
  let fixture: ComponentFixture<ListDefaultBotttomBannerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListDefaultBotttomBannerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListDefaultBotttomBannerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OffertopbarComponent } from './offertopbar.component';

describe('OffertopbarComponent', () => {
  let component: OffertopbarComponent;
  let fixture: ComponentFixture<OffertopbarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OffertopbarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OffertopbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

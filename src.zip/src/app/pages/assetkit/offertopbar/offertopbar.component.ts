
import { Component, OnInit } from '@angular/core';
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { PagerService } from "src/app/shared/services/pager.service";
import { Router } from "@angular/router";
// import { NgxSpinnerService } from "ngx-spinner";
import Swal from "sweetalert2";
import { FormGroup, FormBuilder } from "@angular/forms";
import { BannersService } from 'src/app/shared/services/Banner/banners.service';
import { HypermarketService } from "./../../../shared/services/Hypermarket/hypermarket.service";


@Component({
  selector: 'app-offertopbar',
  templateUrl: './offertopbar.component.html',
  styleUrls: ['./offertopbar.component.scss']
})
export class OffertopbarComponent implements OnInit {


  intTotalCount = 0;
  formoffer: FormGroup;
  intSkipCount = 0;
  pageLimit: any[];
  intPageLimit = 10;
  pager: any = {};
  arrOffertopbar = [];
  strBannerImageId = "";
  showModal: boolean;
  strSelectedImg: string;
  strSelectedImageType: string;
  objSelectedItem: any;
  pkImageId:any;
  blnLoader = false;
  submitted = false;
  clicked = false;
  categoryImg: File[] = [];
  pkOffersTopBarId:any
  strOffersTopBarId: any;
  // imageFile:""

  constructor(
    private pageServiceObj: PagerService,
    private modalService: NgbModal,
    // private spinner: NgxSpinnerService,
    private router: Router,
    private formBuilder: FormBuilder,
    private BannerService:BannersService,
    private hypermarketServiceObj: HypermarketService,

  ) { }

  ngOnInit() {

    this.formoffer = this.formBuilder.group({
      txtdeviceType: "",
      arabicName:"",
      strImageUrl:"",
      intSortNo:"",
      strName:"",
      txtImageUrl:"",
      strLink:"",
      strOffersTopBarId:"",
      imageFile:""
    });

    

    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getOffertopbar();
  }


  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getOffertopbar();
  }

  


  getOffertopbar() {

    let skipCount = this.intSkipCount;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
     const obj = {
     
       strLoginUserId:  localStorage.getItem('userId'),

       
     
      strSkipCount: skipCount,
       strPageLimit: this.intPageLimit,

    };
    // if(localStorage.getItem('fkShopId')){
    //   Object.assign(obj,{fkShopId: localStorage.getItem('fkShopId')})
    //   // obj.fkShopId=localStorage.getItem('fkShopId')
    // }
    // console.log(obj,"list banner obj::::::::::::::::::::");
    
    this.BannerService.getOffertopbar(obj).subscribe((res) => {
      console.log("Banners", res);
      // this.spinner.hide();
      if (res.success) {
        // this.spinner.hide();
        this.intTotalCount =  res.data[0].intTotalCount;
        this.arrOffertopbar = res.data;
        this.intTotalCount = res.count;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
      } else {
        this.arrOffertopbar =[];
        // Swal.fire({
        //   title: "Error",
        //   text: res.message,
        //   icon: "error",
        //   confirmButtonText: "Ok",
        // });
        // this.spinner.hide();
      }
    });
  }
  _getEditType(responsiveData, objType) {
    console.log(objType);
    this.modalService.open(responsiveData);
    this.pkOffersTopBarId = objType.pkOffersTopBarId;
    this.formoffer.patchValue({ strName: objType.strName });
    // this.formoffer.patchValue({ arabicName: objType.strArabicName });
    this.formoffer.patchValue({ txtDescription: objType.strDescription });
    this.formoffer.patchValue({ txtImageUrl: objType.strImageUrl });
    this.formoffer.patchValue({ txtType: objType.strType });
    this.formoffer.patchValue({ intSortNo: objType.intSortNo });
    this.formoffer.patchValue({ strLink: objType.strLink });




  }





  deleteoffertopbar()  {
   
    const obj = {
     
    strOffersTopBarId:this.strOffersTopBarId.pkOffersTopBarId,
     strLoginUserId: localStorage.getItem("userId"),
    
    // "strCategoryId":this.strCategoryId.pkCategoryId
     
    };
    console.log(obj, "objjjjjjjj");

    this.hypermarketServiceObj.deleteoffertopbar(obj).subscribe((res) => {
      if (res.success === true) {
        Swal.fire({
          title: "Deleted!",
          text: "Offertobbar has been deleted Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then((result) => {
          if (result.value) {
            // this.spinnerObj.hide();
            this.ngOnInit();
            this.modalService.dismissAll();
          }
        });
      } else {
        Swal.fire({
          title: "Error",
          text: res.message,
          icon: "error",
          confirmButtonText: "Ok",
        });
        // this.spinnerObj.hide();
      }
      this.getOffertopbar();
    });
  }


  _getDeleteModal(responsiveDelete, id) {
    this.strOffersTopBarId = id;
    this.modalService.open(responsiveDelete);
  }

  








  


 

  show() {
    this.showModal = true; // Show-Hide Modal Check

  }
  //Bootstrap Modal Close event
  hide() {
    this.showModal = false;
  }

  errorImage(event) {
    // event.target.src = 'assets/images/Group 4024 (1).png';
  }






  getUpdateTypeFn() {


    this.blnLoader = false;
    this.submitted = true;

   
    let fData = new FormData();
    fData.append("strOffersTopBarId", this.pkOffersTopBarId)


    fData.append("strArabicName", this.formoffer.value.arabicName);

    fData.append("strLoginUserId", localStorage.getItem("userId"));

    // fData.append("strDescription", this.formoffer.value.txtDescription);
    fData.append("intSortNo", this.formoffer.value.intSortNo);

    fData.append("strName", this.formoffer.value.strName);

    fData.append("strLink", this.formoffer.value.strLink);

    for (let image of this.categoryImg) {
      fData.append("imageFile", image, image.name);
    }
    fData.forEach((value, key) => {
      console.log(key, value);
    });
  


    this.hypermarketServiceObj
    .getUpdateoffertopbar(fData)
      .subscribe((res) => {
        if (res.success === true) {
          this.clicked = false;
          this.blnLoader = true;
          Swal.fire({
            title: "Saved!",
            text: "Offertopbar Updated Successfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then(() => {
           


  this.getOffertopbar();
          this.modalService.dismissAll();
          this.categoryImg=[]
          const inputElement = document.getElementById(
            'image'
          ) as HTMLInputElement;
          if (inputElement) {
            inputElement.value = '';
          }
          })
        // this.modalService.dismissAll();
      } else {
        alert(res.message)
      }
      // this.getDefaultSubCategoryDetails();
      })
    }

    onFileChange(event) {
      console.log("event");
      for (let i of event.target.files) {
        this.categoryImg.push(i);
      }
    }

}
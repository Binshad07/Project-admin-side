import { Component, OnInit } from '@angular/core';
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { PagerService } from "src/app/shared/services/pager.service";
import { Router } from "@angular/router";
// import { NgxSpinnerService } from "ngx-spinner";
import Swal from "sweetalert2";
import { FormGroup, FormBuilder } from "@angular/forms";

import { HypermarketService } from "./../../../shared/services/Hypermarket/hypermarket.service";



@Component({
  selector: 'app-subcategory',
  templateUrl: './subcategory.component.html',
  styleUrls: ['./subcategory.component.scss']
})
export class SubcategoryComponent implements OnInit {


  intTotalCount = 0;
  frmsubCategory: FormGroup
  frmCategory:FormGroup
  intSkipCount = 0;
  arrcategory=[]
  pageLimit: any[];
  intPageLimit = 10;
  pager: any = {};
  arrHomeBanner = [];
  strBannerImageId = "";
  showModal: boolean;
  strSelectedImg: string;
  strSelectedImageType: string;
  objSelectedItem: any;
  pkImageId: any;
  intSort:""
  isAdmin = true;
  arrsubcategory = [];
  arrOfCategoryList = [];
  arrViewType: [];
  myform: FormGroup;
  strSubCategoryId = '';
  // subCategoryImg: File[] = [];
  //  categoryImg: File[] = [];
  categoryImg: File[] = [];

  //  CategoryImg: File[] = [];
  strCategoryId: any;
  // categoryImage: File[] = [];
  id: any;
  submitted = false
  blnLoader = false
  clicked = false
  constructor(

    private pageServiceObj: PagerService,
    private modalService: NgbModal,
    // private spinner: NgxSpinnerService,
    private router: Router,
    private formBuilder: FormBuilder,

    private hypermarketServiceObj: HypermarketService,


  ) { }

  ngOnInit() {

    console.log("jbczxknm")

    this.frmsubCategory = this.formBuilder.group({
      strViewType: "",
      // strViewType: "",
      strImageUrl: "",
      intSortNo: "",
      arabicName: "",
      strName: "",
      txtImageUrl: "",
      txtDescription: "",
      strCategoryName: "",
      drpCategory:""
      // CategoryImg: ""
    });


    // this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist
    this.getDefaultDepartment();
   
    // this.getDefaultCategoryDetails();
// console.log("jbczxknm")
    // this.getDefaultCategoryDetails()
    
    

  }

  show() {
    this.showModal = true;
  }
  onClickViewImg(item, image, type) {
    this.objSelectedItem = item;
    this.strSelectedImg = image;
    this.strSelectedImageType = type;
    this.show();
  }



  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    // this.getDefaultDepartment();
    this.getDefaultSubCategoryDetails();
    // this.getdummyDefaultCategoryDetails();

  }




  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.getDefaultDepartment();
    this.getDefaultSubCategoryDetails();

    // this.getdummyDefaultCategoryDetails();
  }

  get formControls() {
    return this.frmsubCategory.controls;
  }

  _onClear(form: FormGroup) {
    form.reset({
      strViewType: "",
    });
    this.getDefaultDepartment();
  }

  pkDepartmentId: any

  getDefaultDepartment() {
    const obj = {};
    if (localStorage.getItem("strUserType") == "SHOP REPORTER") {
      Object.assign(obj, {
        strViewTypeName: localStorage.getItem("strViewType"),
      });
    }
    this.hypermarketServiceObj.getDefaultDepartment(obj).subscribe((res) => {
      console.log(res, "resssviwetype");
      this.arrViewType = res.data;
      this.pkDepartmentId = res.data[0].pkDepartmentId
      console.log(this.arrViewType, "console", this.pkDepartmentId);
      this.setDefaultViewType(this.arrViewType);
      this.getDefaultSubCategoryDetails();
    });
  }


  setDefaultViewType(viewType) {
    if (!this.isAdmin) {
      const firstOptionValue = viewType[0].strName;
      this.frmsubCategory.get("drpViewType").setValue(firstOptionValue);
    }
  }

  getDefaultSubCategoryDetails() {

    let skipCount = this.intSkipCount;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
    const obj = {
      strLoginUserId: localStorage.getItem('userId'),

      // fkDefaultDepartmentId: this.frmsubCategory.value.strViewType ? this.frmsubCategory.value.strViewType : (this.pkDepartmentId ? this.pkDepartmentId : ""),
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
       fkDefaultDepartmentId: this.frmsubCategory.value.strViewType
    };
    console.log(obj, "list category obj::::::::::::::::::::");

    this.hypermarketServiceObj.getDefaultSubCategoryDetails(obj).subscribe((res) => {

      if (res.success) {
        // this.spinner.hide();
        this.intTotalCount = res.data[0].intTotalCount;
        this.arrsubcategory = res.data[1]
        // this.intTotalCount = res.count;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
      } else {
        this.arrsubcategory = [];

      }
    });
  }

  errorImage(event) {
    // event.target.src = 'assets/images/Group 4024 (1).png';
  }

  hide() {
    this.showModal = false;
  }

  
  getUpdateTypeFn() {

    this.blnLoader = false;
    this.submitted = true;

    if (this.frmsubCategory.invalid) {
      this.blnLoader = true;
      return;
    }
    let fData = new FormData();


    fData.append("strCategoryId", this.strCategoryId)


    fData.append("strArabicName", this.frmsubCategory.value.arabicName);

    fData.append("strLoginUserId", localStorage.getItem("userId"));

    fData.append("strDescription", this.frmsubCategory.value.txtDescription);
    // fData.append("intSortNo", this.frmCategory.value.intSortNo);
    fData.append("intSortNo", this.frmsubCategory.value.intSortNo);
    // fData.append("intSortNo" ,this.frmsubCategory.value.intSortNo);

    fData.append("strName", this.frmsubCategory.value.strName)
    // fData.append("strCategoryName", this.frmsubCategory.value.drpCategory)


    // for (let image of this.categoryImage) {
    //   fData.append("strImageUrl", image, image.name)
    // }
    // fData.append("categoryImage", this.frmsubCategory.value.strImageUrl)
    if (this.categoryImg.length) {

    for (let image of this.categoryImg) {
      fData.append("categoryImage", image, image.name);
    }
  }else{
    // fData.append("strImageUrl", this.frmsubCategory.value.strImageUrl);

  }
    fData.forEach((value, key) => {
      console.log(key, value);
    });

    this.hypermarketServiceObj.getUpdatedefaultsubCategory(fData).subscribe((res) => {

      if (res.success === true) {
                  this.clicked = false;
          this.blnLoader = true;
        Swal.fire({
          title: "Updated!",
          text: "SubCategory Updated successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then(() => {
          
          this.getDefaultSubCategoryDetails();
          this.modalService.dismissAll();
          this.categoryImg=[]
          const inputElement = document.getElementById(
            'image'
          ) as HTMLInputElement;
          if (inputElement) {
            inputElement.value = '';
          }
          })
        // this.modalService.dismissAll();
      } else {
        alert(res.message)
      }
      // this.getDefaultSubCategoryDetails();
    });

  }


_getDeleteModal(responsiveDelete, id) {
    this.strCategoryId = id;
    this.modalService.open(responsiveDelete);
  }


  fkDepartmentId:any
  _getEditType(responsiveData, objType) {
    console.log(objType);
    this.modalService.open(responsiveData);
    this.strCategoryId = objType.pkCategoryId;
    this.fkDepartmentId=objType.fkDepartmentId
    this.frmsubCategory.patchValue({ strName: objType.strName });
    // this.frmsubCategory.patchValue({ strName: objType.strName });
    this.frmsubCategory.patchValue({ arabicName: objType.strArabicName });
    this.frmsubCategory.patchValue({ txtDescription: objType.strDescription });
    this.frmsubCategory.patchValue({ txtImageUrl: objType.strImageUrl });
    // this.frmsubCategory.patchValue({ txtImageUrl: objType.categoryImage });
    this.frmsubCategory.patchValue({ txtType: objType.strType });
     this.frmsubCategory.patchValue({ intSortNo: objType.intSortNo });
    
    //  this.frmsubCategory.patchValue({ strParentCategoryId: objType.strCategoryName  });
     this.frmsubCategory.patchValue({ drpCategory: objType. strParentCategoryId});
      

// this.frmCategory = objType.strParentCategoryId
     this.getDefaultCategoryDetails(objType.fkDepartmentId)
    // this.getListCategoryFn(objValue.fkShopId)

    console.log("Patched Form Values:", this.arrcategory, this.frmsubCategory.value);

    // fData.append("strCategoryName", this.frmsubCategory.value.drpCategory)
    this.getDefaultCategoryDetails(objType.fkDepartmentId)


  }
  onFileChange(event) {
    console.log("event");
    for (let i of event.target.files) {
      this.categoryImg.push(i);
    }
  }


  deleteDefaultsubCategory() {

    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
      // strCategoryId: this.pkCategoryId,
      "strCategoryId": this.strCategoryId.pkCategoryId


    };
    console.log(obj, "objjjjjjjj");

    this.hypermarketServiceObj.deleteDefaultsubCategory(obj).subscribe((res) => {
      if (res.success === true) {
        Swal.fire({
          title: "Deleted!",
          text: " Subcategory has been deleted Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then((result) => {
          if (result.value) {
            // this.spinnerObj.hide();
            this.ngOnInit();
            this.modalService.dismissAll();
          }
        });
      } else {
        Swal.fire({
          title: "Error",
          text: res.message,
          icon: "error",
          confirmButtonText: "Ok",
        });
        // this.spinnerObj.hide();
      }
      this.getDefaultSubCategoryDetails();
    });
  }
  // errorImage(event) {
  //   event.target.src = 'assets/images/Group 4024 (1).png';
  // }







  getDefaultCategoryDetails(fkDepartmentId) {

    let skipCount = this.intSkipCount;
    // this.blnLoader = true;

    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
    const obj = {
      strLoginUserId: localStorage.getItem('userId'),
      // fkDefaultDepartmentId: this.frmCategory.value.strViewType ? this.frmCategory.value.strViewType : (this.pkDepartmentId ? this.pkDepartmentId : ""),
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
       fkDefaultDepartmentId: fkDepartmentId,
      

    };
      //  fkDefaultDepartmentId:this.frmCategory.value.strViewType};
      
    console.log(obj, fkDepartmentId);

    this.hypermarketServiceObj.getDefaultCategoryDetails(obj).subscribe((res) => {
       console.log("Banners", res);

      // this.spinner.hide();
      if (res.success) {
        // this.spinner.hide();
        this.intTotalCount = res.data[0].intTotalCount;
        this.arrcategory = res.data[1];
        // this.intTotalCount = res.count;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
      
      } else {
        this.arrcategory = [];
       
      }
    });
  }

}
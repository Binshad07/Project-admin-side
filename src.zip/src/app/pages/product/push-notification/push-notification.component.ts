import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { PushNotificationService } from "src/app/shared/services/Notification/push-notification.service";
import { PagerService } from "src/app/shared/services/pager.service";
import Swal from "sweetalert2";

@Component({
  selector: "app-push-notification",
  templateUrl: "./push-notification.component.html",
  styleUrls: ["./push-notification.component.scss"],
})
export class PushNotificationComponent implements OnInit {
  pager: any = {};
  pageLimit: any[];
  myForm: FormGroup;
  notificationImages: string;
  blnImageUrl = false;

  submitted: boolean = false;

  constructor(
    private pageServiceObj: PagerService,
    private modalService: NgbModal,
    private formBuilder: FormBuilder,
    private Notification: PushNotificationService
  ) {}

  ngOnInit() {
    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.myForm = this.formBuilder.group({
      strtitle: ["", Validators.required],
      strBody: ["", Validators.required],
      notificationImages: [""],
    });
  }

  OnSubmit() {
    this.submitted = true;
    if (this.myForm.invalid) {
      return;
    }
    let formData = new FormData();

    formData.append("title", this.myForm.value.strtitle),
      formData.append(
        "notificationImages",
        this.myForm.value.notificationImages
      ),
      formData.append("body", this.myForm.value.strBody),
      formData.append("strLoginUserId", localStorage.getItem("userId"));

    formData.forEach((key, value) => console.log(`${key} : ${value}`));

    this.Notification.getAllNotification(formData).subscribe(
      (res) => {
        if (res && res.success) {
          // this.clicked = false;
          // this.spinner.hide();
          Swal.fire({
            title: "Success!",
            text: "Notification sent!",
            icon: "success",
            confirmButtonText: "Ok",
          }).then(() => {
            this.myForm.reset();
            this.submitted = false;
          });
        } else {
          // this.spinner.hide();
          Swal.fire({
            title: "Error",
            text: res.message,
            icon: "error",
            confirmButtonText: "Ok",
          });
        }
      },
      (err) => {
        console.log(err);
      }
    );
  }

  onCheckImageSizeFn(image: any) {
    const currentImageSize = image.size / 1048576;
    if (currentImageSize > 1) {
      Swal.fire({
        title: "Warning",
        text: "Image size cannot be more than 1 MB",
        icon: "warning",
        confirmButtonText: "Ok",
      });
      return false

    } else {
      return true
    }

  }

  uploadFile(event) {


    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = (event: any) => { // called once readAsDataURL is completed
        console.log(event);
        this.notificationImages = event.target.result;
      }
    }



    const file = event.target.files[0];
    if (this.onCheckImageSizeFn(file)) {

      // console.log(file);

      this.myForm.patchValue({
        // companyImages: file,
        notificationImages: file,
      });
      this.myForm.get("notificationImages");
      this.blnImageUrl = true;
    } else {
      // this.img.nativeElement.value = "";
      this.myForm.patchValue({
        companyImages: file,
        notificationImages: "",
      });
      this.myForm.get("notificationImages");
      this.blnImageUrl = false;
    }

  }



  get f() {
    return this.myForm.controls;
  }

  _clearFormFilter() {
    this.submitted = false;
    this.myForm.reset();
  }
}

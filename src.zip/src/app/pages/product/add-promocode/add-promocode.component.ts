import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import Swal from "sweetalert2";
import { PromocodeService } from "src/app/shared/services/promocode/promocode.service";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";

export interface modShop {
  fkShopId?: any;

}


@Component({
  selector: 'app-add-promocode',
  templateUrl: './add-promocode.component.html',
  styleUrls: ['./add-promocode.component.scss']
})
export class AddPromocodeComponent implements OnInit {

  type = "Add";
  myForm: FormGroup;
  id = "";
  submitted: boolean = false;
  blnUpdate = false;
  arrGroups = [];
  arrShops : modShop[] = [];
  blnLoader = false;
  iconImg: File[] = []
  currentpromoImg :""
  constructor(
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private promoCodeService: PromocodeService,
    private companyService:CompanyServiceService,
    private router: Router
  ) {}

  ngOnInit() {
    this.getAllPromo();
    this.getAllShop();

    this.route.queryParams.subscribe((params) => {
      this.id = params["id"];
    });
    this.myForm = this.formBuilder.group({
      strDisplayName: ["", Validators.required],
      strStartDate: ["", Validators.required],
      strFromTime: ["", Validators.required],
      strEndDate: ["", Validators.required],
      strToTime: ["", Validators.required],
      intMinimumOrderAmount: ["", Validators.required],
      intCapacity: ["", Validators.required],
      intDiscountPercentage: ["", Validators.required],
      intAmountDiscount: ["", Validators.required],
      intUptoAmount: ["", Validators.required],
      strGroupId: ["", Validators.required],
      fkShopId: ["", Validators.required],
      iconImg : ["" ,Validators.required] ,
      strPromoTitle : ["" ,Validators.required] ,
      strPromoDescription : ["" ,Validators.required],
      strImageUrl: ["",]
    });

    if (this.id) {
      this.getOnePromo();
      this.blnUpdate = true;
      this.type = "Update";

            
    this.myForm.patchValue({
     iconImg :"strimage"

    })
    }



  }

  get f() {
    return this.myForm.controls;
  }

  getOnePromo() {
    const obj = {
      strSkipCount: "",
      strPageLimit: "",
      strLoginUserId: localStorage.getItem("userId"),
    };
    this.blnLoader = false;

    this.promoCodeService.getPromoCode(obj).subscribe((res) => {
      // console.log(res);
      if (res.success) {
        this.blnLoader = true;

        res.data.forEach((element) => {
          if (element.pkPromocodeId === this.id) {
            let fromDate = element.strStartDateAndTime.split("T");
            let toDate = element.strEndDateAndTime.split("T");

            let fTime = fromDate[1].split(":");
            let eTime = toDate[1].split(":");
            let strStartDate = fromDate[0];
            let strFromTime = fTime[0] + ":" + fTime[1];

            let strEndDate = toDate[0];
            let strToTime = eTime[0] + ":" + eTime[1];

            this.myForm.patchValue({
              strDisplayName: element.strDisplayName,
              strPromoTitle: element.strPromoTitle,
              strPromoDescription: element.strPromoDescription,
              strStartDate: strStartDate,
              strFromTime: strFromTime,
              strEndDate: strEndDate,
              strToTime: strToTime,
              intMinimumOrderAmount: element.intMinimumOrderAmount,
              intCapacity: element.intCapacity,
              intDiscountPercentage: element.intDiscountPercentage,
              intAmountDiscount: element.intAmountDiscount,
              intUptoAmount: element.intUptoAmount,
              strGroupId: element.fkGroupId,
              fkShopId: element.fkShopId,
            });

            // this.currentpromoImg = element.imageUrl

            this.currentpromoImg = element.strImageUrl;
          }
        });
      }
    });
  }

  getAllShop(){
    const obj = {
      loginUserId:localStorage.getItem("userId"),
    }
    if(localStorage.getItem('fkShopId')){
      // Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
        
        this.arrShops = res.data
})
  }
  
  save() {
    
    this.submitted = true

    if (this.myForm.invalid) {
          return;
        } else {
          const strGroupName = this.arrGroups.find(
            (grp) => grp.pkGroupId === this.myForm.value.strGroupId
          ).strPromocodeGroupName;

    const formData = new FormData()

    
    formData.append("strPromoTitle", this.myForm.value.strPromoTitle)
    formData.append("strPromoDescription", this.myForm.value.strPromoDescription)
    formData.append("strDisplayName", this.myForm.value.strDisplayName)
    formData.append("strStartDate", this.myForm.value.strStartDate)
    formData.append("strFromTime", this.myForm.value.strFromTime)
    formData.append("strEndDate", this.myForm.value.strEndDate)
    formData.append("strToTime", this.myForm.value.strToTime)
    formData.append("intMinimumOrderAmount", this.myForm.value.intMinimumOrderAmount)
    formData.append("intCapacity", this.myForm.value.intCapacity)
    formData.append("intDiscountPercentage", this.myForm.value.intDiscountPercentage)
    formData.append("intAmountDiscount", this.myForm.value.intAmountDiscount)
    formData.append("intUptoAmount", this.myForm.value.intUptoAmount)
    formData.append("fkGroupId", this.myForm.value.strGroupId)
    formData.append("fkShopId", this.myForm.value.fkShopId)
    formData.append("strGroupName", strGroupName)
    formData.append("strLoginUserId", localStorage.getItem("userId"))
    for (let image of this.iconImg) {
      formData.append("imageFile", image, image.name)
    }
   
    formData.forEach((a, b) => console.log(`${a} :: ${b}`))

  

    // this.spinner.show()

    this.promoCodeService.addPromoCode(formData).subscribe((res) => {
      if (res.success) {
        // this.spinner.hide()
        Swal.fire({
          title: "Saved!",
          text: "Promo Code Created Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then(() => {
          this.submitted = false;
          this.myForm.reset()
          this.router.navigate(["/promocode"]);
        })
      } else {
        // this.spinner.hide();
        Swal.fire({
          title: "warning",
          text: res.message,
          icon: "warning",
          confirmButtonText: "Ok",
        }).then(() => {
          this.submitted = false;
        })
      }
    }, (err) => {
      console.log(err)
    })

  }
}

  onReset() {
    this.submitted = false;
    this.myForm.reset();
  }

  // update() {
  //   this.submitted = true;

  //   if (this.myForm.invalid) {
  //     return;
  //   } else {
  //     const strGroupName = this.arrGroups.find(
  //       (grp) => grp.pkGroupId === this.myForm.value.strGroupId
  //     ).strPromocodeGroupName;
  //     const obj = {
  //       strDisplayName: this.myForm.value.strDisplayName,
  //       strStartDate: this.myForm.value.strStartDate,
  //       strFromTime: this.myForm.value.strFromTime,
  //       strEndDate: this.myForm.value.strEndDate,
  //       strToTime: this.myForm.value.strToTime,
  //       intMinimumOrderAmount: this.myForm.value.intMinimumOrderAmount,
  //       strLoginUserId: localStorage.getItem("userId"),
  //       intCapacity: this.myForm.value.intCapacity,
  //       intDiscountPercentage: this.myForm.value.intDiscountPercentage,
  //       intAmountDiscount: this.myForm.value.intAmountDiscount,
  //       intUptoAmount: this.myForm.value.intUptoAmount,
  //       fkGroupId: this.myForm.value.strGroupId,
  //       strGroupName: strGroupName,
  //       strPromocodeId: this.id,
  //     };
  //     this.blnLoader = false;
  //     // console.log(obj);

  //     this.promoCodeService.updatePromoCode(obj).subscribe((res) => {
  //       this.blnLoader = true;
  //       if (res.success) {
  //         Swal.fire({
  //           title: "Updated!",
  //           text: "Promocode Updated",
  //           icon: "success",
  //           confirmButtonText: "Ok",
  //         }).then((result) => {
  //           if (result.value) {
  //             this.submitted = false;
  //             // this.myForm.reset();
  //             this.router.navigate(["/promocode"]);
  //           }
  //         });
  //       } else {
  //         Swal.fire({
  //           title: "Error",
  //           text: res.message,
  //           icon: "error",
  //           confirmButtonText: "Ok",
  //         });
  //       }
  //     });
  //   }
  // }


update() {
    
    this.submitted = true

    if (this.myForm.invalid) {
          return;
        } else {
          const strGroupName = this.arrGroups.find(
            (grp) => grp.pkGroupId === this.myForm.value.strGroupId
          ).strPromocodeGroupName;

    const formData = new FormData()

    
    formData.append("strPromoTitle", this.myForm.value.strPromoTitle)
    formData.append("strPromoDescription", this.myForm.value.strPromoDescription)
    formData.append("strDisplayName", this.myForm.value.strDisplayName)
    formData.append("strStartDate", this.myForm.value.strStartDate)
    formData.append("strFromTime", this.myForm.value.strFromTime)
    formData.append("strEndDate", this.myForm.value.strEndDate)
    formData.append("strToTime", this.myForm.value.strToTime)
    formData.append("intMinimumOrderAmount", this.myForm.value.intMinimumOrderAmount)
    formData.append("intCapacity", this.myForm.value.intCapacity)
    formData.append("intDiscountPercentage", this.myForm.value.intDiscountPercentage)
    formData.append("intAmountDiscount", this.myForm.value.intAmountDiscount)
    formData.append("intUptoAmount", this.myForm.value.intUptoAmount)
    formData.append("fkGroupId", this.myForm.value.strGroupId)
    formData.append("fkShopId", this.myForm.value.fkShopId)
    formData.append("strGroupName", strGroupName)
    formData.append("strLoginUserId", localStorage.getItem("userId"))
    formData.append("strPromocodeId", this.id)
    // for (let image of this.iconImg) {
    //   formData.append("imageFile", image, image.name)
    // }


    if (this.iconImg.length) {
      for (const image of this.iconImg) {
        formData.append('imageFile', image, image.name)
      }
    } else {
      formData.append("imageFile", this.myForm.value.strImageUrl)
    }
   



    formData.forEach((a, b) => console.log(`${a} :: ${b}`))

  

    // this.spinner.show()

    this.promoCodeService.updatePromoCode(formData).subscribe((res) => {
      if (res.success) {
        // this.spinner.hide()
        Swal.fire({
          title: "Updated!",
          text: "Promo Code Updated Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then(() => {
          this.submitted = false;
          this.myForm.reset()
          this.router.navigate(["/promocode"]);
        })
      } else {
        // this.spinner.hide();
        Swal.fire({
          title: "Error",
          text: res.message,
          icon: "error",
          confirmButtonText: "Ok",
        }).then(() => {
          this.submitted = false;
        })
      }
    }, (err) => {
      console.log(err)
    })

  }
}

 getAllPromo() {
    const obj = {
      strSkipCount: "",
      strPageLimit: "",
      strLoginUserId: localStorage.getItem("userId"),
    };
    if(localStorage.getItem('fkShopId')){
      Object.assign(obj,{fkShopId: localStorage.getItem('fkShopId')})
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.blnLoader = false;
    this.promoCodeService.getPromoCodeGroup(obj).subscribe((res) => {
      // console.log(res);

      this.blnLoader = true;
      if (res.success) {
        this.arrGroups = res.data;
      }
    });
  }

  discPrcntType() {
    this.myForm.patchValue({
      intAmountDiscount: 0,
    });
  }
  discAmnt() {
    this.myForm.patchValue({
      intDiscountPercentage: 0,
    });
  }

  
  onchangeIconImg(event) {
    for (let i of event.target.files) {
      this.iconImg.push(i)
    }
  }

}

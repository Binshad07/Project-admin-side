import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddPromogroupComponent } from './add-promogroup.component';

describe('AddPromogroupComponent', () => {
  let component: AddPromogroupComponent;
  let fixture: ComponentFixture<AddPromogroupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddPromogroupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddPromogroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

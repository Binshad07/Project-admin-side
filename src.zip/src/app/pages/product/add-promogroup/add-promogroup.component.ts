import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import Swal from "sweetalert2";
import { PromocodeService } from "src/app/shared/services/promocode/promocode.service";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";

export interface modShop {
  fkShopId?: any;

}

@Component({
  selector: 'app-add-promogroup',
  templateUrl: './add-promogroup.component.html',
  styleUrls: ['./add-promogroup.component.scss']
})
export class AddPromogroupComponent implements OnInit {

  myForm: FormGroup;
  id = "";
  submitted: boolean = false;
  blnLoader = true;
  arrShops : modShop[] = [];
  constructor(
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private promoCodeService: PromocodeService,
    private companyService:CompanyServiceService,
    private router: Router
  ) {}

  ngOnInit() {
    this.myForm = this.formBuilder.group({
      strDisplayName: ["", Validators.required],
      fkShopId: ["", Validators.required],
    });
    this.getAllShop();
  }

  get f() {
    return this.myForm.controls;
  }

  save() {
    this.submitted = true;

    if (this.myForm.invalid) {
      return;
    } else {
      const obj = {
        fkShopId: this.myForm.value.fkShopId,
        strPromocodeGroupName: this.myForm.value.strDisplayName,
        strLoginUserId: localStorage.getItem("userId"),
      };
      console.log(obj);
      this.blnLoader = false;

      this.promoCodeService.addPromoCodeGroup(obj).subscribe((res) => {
        console.log(res);
        this.blnLoader = true;
        if (res.success) {
          Swal.fire({
            title: "Saved!",
            text: "Promocode group Created",
            icon: "success",
            confirmButtonText: "Ok",
          }).then((result) => {
            if (result.value) {
              this.submitted = false;
              // this.myForm.reset();
              this.router.navigate(["/promocode"]);
            }
          });
        } else {
          Swal.fire({
            title: "Warning",
            text: "Group Name Already Exists",
            icon: "warning",
            confirmButtonText: "Ok",
          });
        }
      });
    }
  }

  onReset() {
    this.submitted = false;
    this.myForm.reset();
  }
  getAllShop(){
    const obj = {
      loginUserId:localStorage.getItem("userId"),
    }
    if(localStorage.getItem('fkShopId')){
      // Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
        
        this.arrShops = res.data
})
  }
}

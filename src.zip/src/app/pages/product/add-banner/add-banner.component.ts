import { Component, OnInit } from "@angular/core";
import Swal from "sweetalert2";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { BannerServiceService } from "src/app/shared/services/BannerService/banner-service.service";
// import { BannersService } from 'src/app/shared/services/banners.service';
import { DatePipe } from "@angular/common";
import { PagerService } from "src/app/shared/services/pager.service";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";

@Component({
  selector: "app-add-banner",
  templateUrl: "./add-banner.component.html",
  styleUrls: ["./add-banner.component.scss"],
})
export class AddBannerComponent implements OnInit {


  myForm: FormGroup;
  pager: any = {};
  intTotalCount = 0;
  intPageLimit = 10;
  pageLimit: any[];
  intSkipCount = 0;
  strCategoryId = "";
  blnLoader = false;
  submitted = false;
  Arrbanner = [];
  arrViewType = [];
  arrCategory = [];
  bannerImg: File[] = [];
  arrShops: [];
  id = "";
  type = "Add";
  blnUpdate = false;
  clicked = false;
  // arrOfCategoryList: modCategory[] = [];

  constructor(
    private bannerService: BannerServiceService,
    private pageServiceObj: PagerService,
    private modalService: NgbModal,
    private formBuilder: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private companyService: CompanyServiceService
  ) {}

  ngOnInit() {
    this.route.queryParams.subscribe((params) => {
      this.id = params["id"];
    });
    this.myForm = this.formBuilder.group({
      sortNo: ["", Validators.required],
      deviceType: ["", Validators.required],
      bannerImg: ["", Validators.required],
      fkShopId: ["", Validators.required],
    });

    if (this.id) {
      this.type = "Update";
      this.getallBanners();
      this.blnUpdate = true;

      this.myForm.patchValue({
        bannerImg: "strimage",
      });
    }

    this.getAllShop();
    //  this.getListCategoryFn()
  }

  get f() {
    return this.myForm.controls;
  }

  // ! shop Listing
  getAllShop() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
    };
    if (localStorage.getItem("fkShopId")) {
      // Object.assign(obj, { strShopId: localStorage.getItem("fkShopId") });
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
      this.arrShops = res.data;
    });
  }

  addBottomBanner() {
    this.submitted = !this.submitted;
    if (this.myForm.invalid) {
      this.submitted = true;
      return;
    }
    let fData = new FormData();

    fData.append("loginUserId", localStorage.getItem("userId"));
    fData.append("strImageType", this.myForm.value.deviceType);
    fData.append("intSort", this.myForm.value.sortNo);
    fData.append("fkShopId", this.myForm.value.fkShopId);
    for (let image of this.bannerImg) {
      fData.append("imageFile", image, image.name);
    }

    fData.forEach((key, value) => console.log(`${key}: ${value}`));
    this.clicked = true;

    this.bannerService.addBottomBanner(fData).subscribe(
      (res) => {
        console.log(res);
        if (res && res.success) {
          this.clicked = false;
          // this.spinner.hide();
          Swal.fire({
            title: "Saved!",
            text: "Bottom Banner Saved Successfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then(() => {
            this.myForm.reset();
            this.router.navigate(["/product/list-banner"]);
            this.submitted = false;
          });
        } else {
          // this.spinner.hide();
          Swal.fire({
            title: "Error",
            text: res.message,
            icon: "error",
            confirmButtonText: "Ok",
          });
        }
      },
      (err) => {
        console.log(err);
      }
    );
  }

  onFileChange(event) {
    for (let i of event.target.files) {
      this.bannerImg.push(i);
    }
  }

  getallBanners() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
      pkImageId: this.id,
    };
    console.log(obj);
    this.bannerService.getAllbanners(obj).subscribe((res) => {
      console.log("resonseeeeeeeee", res);
      this.myForm.patchValue({
        deviceType: res.data[0].strImageType,
        fkShopId: res.data[0].fkShopId,
        sortNo: res.data[0]. intSort,
        strImageUrl: res.data[0].strImageUrl,
      });
    });
  }

  update() {
    this.submitted = true;
    if (this.myForm.invalid) {
      return;
    }

    console.log(this.myForm.value.height, this.myForm.value.width);
    let fData = new FormData();
   
    fData.append("deviceType", this.myForm.value.deviceType);
    fData.append("sortNumber", this.myForm.value.sortNo);
    fData.append("fkCategoryId", this.myForm.value.fkCategoryId);
    fData.append("fkShopId", this.myForm.value.fkShopId);
    fData.append("loginUserId", localStorage.getItem("userId"));
    fData.append("pkImageId", this.id);
    if (this.bannerImg.length) {
      for (const image of this.bannerImg) {
        fData.append("imageFile", image, image.name);
      }
    } else {
      fData.append("strImageUrl", this.myForm.value.strImageUrl);
    }

    fData.forEach((key, value) => console.log(` ${value}:${key}`));
    this.bannerService.updateBanner(fData).subscribe(
      (res) => {
        if (res.success) {
          // this.spinner.hide()
          Swal.fire({
            title: "Saved!",
            text: "Bottom Banner Updated Successfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then(() => {
            this.myForm.reset();
            this.submitted = false;
            this.router.navigate(["/product/list-banner"]);
          });
        } else {
          // this.spinner.hide();
          Swal.fire({
            title: "Error",
            text: res.message,
            icon: "error",
            confirmButtonText: "Ok",
          }).then(() => {
            this.submitted = false;
          });
        }
      },
      (err) => {
        this.submitted = false;
        console.log(err);
      }
    );
  }

  clearForm() {
    this.submitted = false;
    this.myForm.reset();
    this.ngOnInit();
  }


}

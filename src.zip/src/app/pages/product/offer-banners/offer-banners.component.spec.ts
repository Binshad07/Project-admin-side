import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OfferBannersComponent } from './offer-banners.component';

describe('OfferBannersComponent', () => {
  let component: OfferBannersComponent;
  let fixture: ComponentFixture<OfferBannersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OfferBannersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OfferBannersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

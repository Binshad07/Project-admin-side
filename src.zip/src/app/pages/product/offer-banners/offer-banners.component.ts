import { Component, OnInit } from "@angular/core";
import { FormGroup, FormArray, FormBuilder, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { BannersService } from "src/app/shared/services/Banner/banners.service";
import Swal from "sweetalert2";
import { HypermarketService } from './../../../shared/services/Hypermarket/hypermarket.service';
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";
// import { NgxSpinnerService } from "ngx-spinner";
@Component({
  selector: 'app-offer-banners',
  templateUrl: './offer-banners.component.html',
  styleUrls: ['./offer-banners.component.scss']
})
export class OfferBannersComponent implements OnInit {

  type = "Add";
  myForm: FormGroup;
  id = "";
  submitted = false;
  blnUpdate = false;
  flDealOfDayImages: File[] = [];
  flLeastProductImages: File[] = [];
  flMostPopularImages: File[] = [];

  arrShopTypes = [];
  arrCard = [];
  strImage: any;
  arrViewType = [];
  arrShop=[];

  constructor(
    private formBuilder: FormBuilder,
    private BannerService: BannersService,
    private hypermarketServiceObj: HypermarketService,
    private companyService:CompanyServiceService,
    // private spinner: NgxSpinnerService,
    private router: Router
  ) { }

  ngOnInit() {
    this.myForm = this.formBuilder.group({
      dealOfDayBanner: [""],
      leastProductBanner: [""],
      mostPopularBanner: [""],
      strDeviceType: [""],
      strViewType: [""],
      cmbShopName:[""],
    });
    this.getViewTypeFn();
    this. getAllShop();
  }

  get f() {
    return this.myForm.controls;
  }

  get formControls() {
    return this.myForm.controls;
  }

  onReset() {
    this.submitted = false;
    this.myForm.reset({
      dealOfDayBanner: [""],
      leastProductBanner: [""],
      mostPopularBanner: [""],
      strDeviceType: [""],
      strViewType: [""],
      cmbShopName:[""],
    });
    this.flDealOfDayImages = [];
    this.flLeastProductImages = [];
    this.flMostPopularImages = [];

  }

  getViewTypeFn() {
    this.hypermarketServiceObj.getViewType().subscribe((res) => {
      this.arrViewType = res.data;
    })
  }

  getAllShop(){
    const obj = {
      loginUserId:localStorage.getItem("userId"),
    }
    if(localStorage.getItem('fkShopId')){
      // Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
        
        this.arrShop = res.data
})
  }


  refreshPageFn() {
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    this.router.onSameUrlNavigation = "reload";
    this.router.navigate(["offer-banners"]);
  }

  onFileChangeDealOfDaytBanner(event) {
    for (let image of event.target.files) {
      this.flDealOfDayImages.push(image);
    }
    this.onCheckImageSizeFn(this.flDealOfDayImages);
  }
  onFileChangeLeastProductImages(event) {
    for (let image of event.target.files) {
      this.flLeastProductImages.push(image);
    }
    this.onCheckImageSizeFn(this.flLeastProductImages);
  }
  onFileChangeMostPopularImages(event) {
    for (let image of event.target.files) {
      this.flMostPopularImages.push(image);
    }
    this.onCheckImageSizeFn(this.flMostPopularImages);
  }


  getOfferImageUploadFn(name: string) {
    const formData = new FormData();

    if (name === "DealOfDayBanner") {
      formData.append("strDeviceType", this.myForm.value.strDeviceType);
      formData.append("strViewType", this.myForm.value.strViewType);
      formData.append("fkShopId", this.myForm.value.cmbShopName);
      formData.append("loginUserId", localStorage.getItem("userId"))
      for (const image of this.flDealOfDayImages) {
        formData.append("fileExclusiveImg", image, image.name);
      }
      this.getUploadImageFn(formData);
    }
    console.log(formData,'aaaaaaaaaaaaaaaaa');
    
    if (name === "LeastProductBanner") {
      formData.append("strDeviceType", this.myForm.value.strDeviceType);
      formData.append("strViewType", this.myForm.value.strViewType);
      formData.append("fkShopId", this.myForm.value.cmbShopName);
      formData.append("loginUserId", localStorage.getItem("userId"))
      for (const image of this.flLeastProductImages) {
        formData.append("fileLatestImg", image, image.name);
      }
      this.getUploadImageFn(formData);
    }
    if (name === "MostPopularBanner") {
      formData.append("strDeviceType", this.myForm.value.strDeviceType);
      formData.append("strViewType", this.myForm.value.strViewType);
      formData.append("fkShopId", this.myForm.value.cmbShopName);
      formData.append("loginUserId", localStorage.getItem("userId"))
      for (const image of this.flMostPopularImages) {
        formData.append("fileMostPopularImg", image, image.name);

      }
      this.getUploadImageFn(formData);

    }
    formData.forEach((key, value) => console.log(`${key}: ${value}`))

  }

  getUploadImageFn(obj) {

    if(this.flDealOfDayImages.length || this.flLeastProductImages.length || this.flMostPopularImages.length){
      this.BannerService.updateOfferBanners(obj).subscribe((res) => {
        console.log('banner service ::::::::::::::::::::::::');
        
        // this.spinner.hide();
        if (res.success) {
          Swal.fire({
            title: "Saved!",
            text: "Image Uploaded Successfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then((result) => {
            if (result.value) {
              this.submitted = false;
              this.onReset();
              this.router.navigate(["/offer-banners"]);
            }
          });
        } else {
          Swal.fire({
            title: "warning",
            text: 'Please select device type',
            icon: "warning",
            confirmButtonText: "Ok",
          });
        }
      });
    }else{
      alert("Please select image!!!")
    }
    
    // this.spinner.show();
   
  }


  onCheckImageSizeFn(imageFiles: any) {
    // for (const image of imageFiles) {
    //   const maxWidth = 1920;
    //   const maxHeight = 600;
    //   const currentImageSize = image.size / 1048576;
    //   if (currentImageSize > 1) {
    //     Swal.fire({
    //       title: "Error",
    //       text: "Image size cannot be more than 1 MB",
    //       icon: "error",
    //       confirmButtonText: "Ok",
    //     });
    //     this.onReset();
    //     return;
    //   }
    //   const URL = window.URL;
    //   const currentImage = new Image();
    //   currentImage.src = URL.createObjectURL(image);
    //   currentImage.onload = (e: any) => {
    //     const height = e.path[0].height;
    //     const width = e.path[0].width;
    //     if (height !== maxHeight && width !== maxWidth) {
    //       Swal.fire({
    //         title: "Error",
    //         text: `Image resolution should be ${maxWidth} * ${maxHeight}  px`,
    //         icon: "error",
    //         confirmButtonText: "Ok",
    //       });
    //       this.onReset();
    //       return;
    //     }
    //   };
    // }
    // return
  }


}

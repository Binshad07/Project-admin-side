import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListShopCountComponent } from './list-shop-count.component';

describe('ListShopCountComponent', () => {
  let component: ListShopCountComponent;
  let fixture: ComponentFixture<ListShopCountComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListShopCountComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListShopCountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from "@angular/core";
import { ShopServiceService } from "src/app/shared/services/shopService/shop-service.service";
import { PagerService } from "src/app/shared/services/pager.service";

@Component({
  selector: "app-list-shop-count",
  templateUrl: "./list-shop-count.component.html",
  styleUrls: ["./list-shop-count.component.scss"],
})
export class ListShopCountComponent implements OnInit {
  arrRentalItem: any[] = [];
  pager: any = {};
  intTotalCount = 0;
  intPageLimit = 10;
  pageLimit: any[];
  intSkipCount = 0;
  blnLoader = false;
  arrayOfObjFranchiseList: any[] = [];
  arrShops: any[] = [];
  strShopId: "";
  userType: string;
  currentDate = new Date();

  constructor(
    private shopService: ShopServiceService,
    private pageServiceObj: PagerService
  ) {}

  ngOnInit() {
    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.fnGetAllShopes();
  }

  fnGetAllShopes() {
    let skipCount = this.intSkipCount;
    this.blnLoader = false;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
    const obj = {
      
      strSkipCount: skipCount,
      strPageLimit: this.intPageLimit,
    };
    this.shopService.getCountShopsReport(obj).subscribe(
      (res) => {
        if (res.success) {
          this.blnLoader = true;
          this.arrShops = res.data;
          this.intTotalCount = res.count;

          this.pager = this.pageServiceObj.getPager(
            this.intTotalCount,
            this.pager.currentPage,
            this.intPageLimit
          );
        } else {
          // Swal.fire({
          //   title: "error",
          //   text: res.message,
          //   icon: "error",
          //   confirmButtonText: "Ok",
          // });
          this.arrShops = [];
          // this.pager = {};
          this.intTotalCount = 0;
          // this.spinner.hide();
        }
      },
      (err) => {
        console.log(err);
      }
    );
  }

  /*
  strDeptName strCategoryName
    TODO @Function: FUNCTION TO SET PAGE LIMIT
    */
  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }
  /*
      TODO @Function: FUNCTION TO SET PAGE NUMBER
      */
  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.fnGetAllShopes();
  }
}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UnitnameComponent } from './unitname.component';

describe('UnitnameComponent', () => {
  let component: UnitnameComponent;
  let fixture: ComponentFixture<UnitnameComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UnitnameComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnitnameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

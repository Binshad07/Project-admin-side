import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import Swal from "sweetalert2";
import { PagerService } from "./../../../shared/services/pager.service";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";
import { unitResponse } from "../../../shared/Classes/unitResponse";
import { ProductService } from "../../../shared/services/product.service";
import { ReportsService } from 'src/app/shared/services/Reports/reports.service';
import { Router } from "@angular/router";





@Component({
  selector: 'app-unitname',
  templateUrl: './unitname.component.html',
  styleUrls: ['./unitname.component.scss']
})
export class UnitnameComponent implements OnInit {

  myform: FormGroup;
  submitted: boolean = false;
  intSkipCount = 0;
  pager: any = {};
  intPageLimit = 10;
  pageLimit: any[];
  intTotalCount = 0;
  // strLoginUserId = "";
  pkUnitId = "";
  arrunit: [];
  arrShops: [];
  unitList: unitResponse[] = [];
  blnLoader = false;
  strUnitId: ""
  fkShopId: any;
  loginUserId = "";


  strShopId: any;



  editSubmitted: boolean = false;
  unit: any;

  constructor(

    private pageServiceObj: PagerService,
    private formBuilder: FormBuilder,
    private myProductService: ProductService,
    private reportService: ReportsService,
    private router: Router,



    private modalService: NgbModal,
    private companyService: CompanyServiceService

  ) { }



  ngOnInit() {



    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.myform = this.formBuilder.group({
      strUnitName: ["", Validators.required],
      fkShopId: ["", Validators.required],
    });
    this.pageLimit = this.pageServiceObj.showPagelist;

    this.getAllShop();
    this.unitListing();
    // this.deleteModal();
  }



  _getPageLimit(value$) {
    this.intPageLimit = parseInt(value$);
    this.setPage(1);
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );

    this.unitListing();

    this.getAllShop();
  }


  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.unitListing();

  }


  getAllShop() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
    }
    console.log(obj, "tesghjchbv")
    if (localStorage.getItem('fkShopId')) {
      // Object.assign(obj, { strShopId: localStorage.getItem('fkShopId') })
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {

      this.arrShops = res.data
    })
  }


  get formControls() {
    return this.myform.controls;
    // fkShopId: this.myform.value.fkShopId
  }


















  


  unitListing() {

    let skipCount = this.intSkipCount;
    this.blnLoader = false;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }

    const obj = {
      strLoginUserId: localStorage.getItem('userId'),
      strShopId: this.myform.value.fkShopId,
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,


    };
    if (localStorage.getItem("fkShopId")) {
      Object.assign(obj, { strShopId: localStorage.getItem("fkShopId") });
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }

    

    this.reportService.UnitList(obj).subscribe((res) => {
      console.log("resoiuh", res)
      if (res && res.success) {
        //  this.ngOnInit()
        // this.spinner.hide();
        this.blnLoader = true;
        this.arrunit = res.data;
        this.intTotalCount = res.count;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,

          this.intPageLimit
        );
      } else {
        this.arrunit = []

      }
    })
  }

  _onClear(form: FormGroup) {
    form.reset({

    });

  }


  deleteBanner(responsiveDelete, item) {
    this.strUnitId = item.pkUnitId;
    this.modalService.open(responsiveDelete);
  }

  edit(item) {
    this.router.navigate(["/add-unit"], {
      queryParams: { id: item.pkUnitId },
    });
  }




  deleteModal(item) {
    console.log("item", item)
    const obj = {
      // strUnitId:this.strUnitId,
      // strLoginUserId:localStorage.getItem("userId"),

      // strShopId:this.strShopId,
      strLoginUserId: localStorage.getItem('userId'),

      strShopId: item.fkShopId,
      strUnitId: item.pkUnitId,




    }
    console.log(obj)
    this.reportService.Deleteunitlist(obj).subscribe((res) => {
      if (res.success) {
        this.modalService.dismissAll();
        // this.spinner.hide();
        Swal.fire({
          title: "Unit  deleted!",
          text: "Unit Deleted Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then(() => {
          this.ngOnInit()
          this.unitListing()
        })
      } else {
        // this.spinner.hide();
        Swal.fire({
          title: "Error",
          text: res.message,
          icon: "error",
          confirmButtonText: "Ok",
        });
      }
      this.unitListing();
    }, (err) => {
      this.ngOnInit()
      console.log(err)
    })
  }






}

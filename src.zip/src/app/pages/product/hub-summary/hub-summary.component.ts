import { environment } from "./../../../../environments/environment.prod";
import { Component, OnInit } from "@angular/core";
import { OrderService } from "src/app/shared/services/order.service";
import { FormGroup, FormBuilder } from "@angular/forms";
import {
  modHubSummary,
  modHubTotal,
} from "src/app/shared/Classes/report.model";
import { PagerService } from "src/app/shared/services/pager.service";
import { ReportsService } from "src/app/shared/services/Reports/reports.service";
import { DatePipe } from "@angular/common";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";

@Component({
  selector: "app-hub-summary",
  templateUrl: "./hub-summary.component.html",
  styleUrls: ["./hub-summary.component.scss"],
})
export class HubSummaryComponent implements OnInit {
  hubSummaryArray = [];
  frmHubSummary: FormGroup;
  currentDate = new Date();
  pager: any = {};
  intTotalCount = 0;
  intSkipCount = 0;
  intPageLimit = 10;
  arrStores = [];
  arrHubSummary: modHubSummary[] = [];
  arrTotal: modHubTotal[] = [];
  datePipe = new DatePipe("en-US");
  pageLimit: any[];
  strShopId = "";
  blnNoData = false;
  fromDate;
  toDate;
  blnLoader = false;
  blnDownloadLoader = false;

  private apiURL: string = environment.API_ENDPOINT;
  constructor(
    private reportServiceObj: ReportsService,
    private pageServiceObj: PagerService,
    private companyService:CompanyServiceService,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit() {
    this.frmHubSummary = this.formBuilder.group({
      txtFromDate: [""],
      txtToDate: [""],
      cmbShopName: [""],
      drpPageLimit: "10",
    });


    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getShopListingFn();
    this.getHubSummaryFn();
  }

  _clearForm(form: FormGroup) {
    form.reset({
      txtFromDate   : "",
      txtToDate     : "",
      cmbShopName   : "",
      drpPageLimit  : "10",
    });
    this.intTotalCount = 0;
    this.intSkipCount = 0;
    this.intPageLimit = 10;
    this.getHubSummaryFn();
  }

  _getPageLimit(value$) {
    this.intPageLimit = parseInt(this.frmHubSummary.value.drpPageLimit);
    this.setPage(1);
  }
  _getShopId(id$) {
    this.strShopId = id$;
    console.log("STORE ID:::::", this.strShopId);
  }
  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getHubSummaryFn();
  }

  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.getHubSummaryFn();
  }

  getShopListingFn() {
    const obj = {
      loginUserId:localStorage.getItem("userId"),
    }
    if(localStorage.getItem('fkShopId')){
      Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
      this.arrStores = res.data;
      this.strShopId = res.data[0].pkShopId;
    });
  }

  getHubSummaryFn() {
    let skipCount = this.intSkipCount;
    this.blnLoader = false;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }

    if (
      this.frmHubSummary.value.txtFromDate === "" &&
      this.frmHubSummary.value.txtToDate === ""
    ) {
      console.log("From Date ::::", this.frmHubSummary.value.txtFromDate);
      this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
      this.toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    }
    if (
      this.frmHubSummary.value.txtFromDate &&
      this.frmHubSummary.value.txtToDate === ""
    ) {
      console.log("To Date ::::", this.frmHubSummary.value.txtToDate);
      this.fromDate = `${this.frmHubSummary.value.txtFromDate.year}-${this.frmHubSummary.value.txtFromDate.month}-${this.frmHubSummary.value.txtFromDate.day}`;
      this.toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    }
    if (
      this.frmHubSummary.value.txtToDate &&
      this.frmHubSummary.value.txtFromDate === ""
    ) {
      console.log("To Date ::::", this.frmHubSummary.value.txtToDate);
      this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
      this.toDate = `${this.frmHubSummary.value.txtToDate.year}-${this.frmHubSummary.value.txtToDate.month}-${this.frmHubSummary.value.txtToDate.day}`;
    }

    if (
      this.frmHubSummary.value.txtFromDate &&
      this.frmHubSummary.value.txtToDate
    ) {
      this.fromDate = `${this.frmHubSummary.value.txtFromDate.year}-${this.frmHubSummary.value.txtFromDate.month}-${this.frmHubSummary.value.txtFromDate.day}`;
      this.toDate = `${this.frmHubSummary.value.txtToDate.year}-${this.frmHubSummary.value.txtToDate.month}-${this.frmHubSummary.value.txtToDate.day}`;
    }

    const objData = {
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
      strStoreId: this.frmHubSummary.value.cmbShopName,
      strFromDate: this.fromDate,
      strToDdate: this.toDate,
    };
    if(localStorage.getItem('fkShopId')){
      Object.assign(objData,{strStoreId: localStorage.getItem('fkShopId')})
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    console.log("OBJECT :::::", objData);
    this.reportServiceObj.getHubSummaryService(objData).subscribe((res) => {
      this.blnLoader = true;
      this.arrHubSummary = res.data[1];
      this.arrTotal = res.data[2];
      if (res.data[0]) {
        this.intTotalCount = res.data[0].inttotalCount;
      }
      console.log("RESPONSE FROM HUB SUMMARY:::::", res);
      this.pager = this.pageServiceObj.getPager(
        this.intTotalCount,
        this.pager.currentPage,
        this.intPageLimit
      );
    });
  }

  getDownloadExcel() {
    this.blnDownloadLoader = !this.blnDownloadLoader;
    const obj = {
      strStoreId: this.frmHubSummary.value.cmbShopName,
      strFromDate: this.fromDate,
      strToDdate: this.toDate,
      strDataType: "EXCEL",
    };

    this.reportServiceObj.getHubSummaryService(obj).subscribe((res) => {
      this.blnDownloadLoader = !this.blnDownloadLoader
      console.log("RESPONSE EXCEL", res);
      const strPath = this.apiURL + "/" + res.data;
      window.location.href = strPath;
    });
  }
}

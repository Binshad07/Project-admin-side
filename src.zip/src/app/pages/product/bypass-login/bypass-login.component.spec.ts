import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BypassLoginComponent } from './bypass-login.component';

describe('BypassLoginComponent', () => {
  let component: BypassLoginComponent;
  let fixture: ComponentFixture<BypassLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BypassLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BypassLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

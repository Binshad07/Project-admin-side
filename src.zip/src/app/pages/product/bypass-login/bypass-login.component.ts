import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import Swal from "sweetalert2";
import { PagerService } from "./../../../shared/services/pager.service";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { BrandserviceService } from "src/app/shared/services/brand/brandservice.service";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";

@Component({
  selector: "app-bypass-login",
  templateUrl: "./bypass-login.component.html",
  styleUrls: ["./bypass-login.component.scss"],
})
export class BypassLoginComponent implements OnInit {
  myform: FormGroup;
  submitted: boolean = false;
  frmTypeEdit: FormGroup;
  arrShops: any;
  
  constructor(
    private pageServiceObj: PagerService,
    private formBuilder: FormBuilder,
    private brandService: BrandserviceService,
    private companyService: CompanyServiceService
  ) {}

  ngOnInit() {
    this.myform = this.formBuilder.group({
      PhoneNumber: ["", Validators.required],
      fkShopId: ["", Validators.required],
    });

    this.getAllShop();
  }

  userCeationFn() {
    this.submitted = true;
    if (this.myform.invalid) {
      return;
    }
    const obj = {
      fkShopId: this.myform.value.fkShopId,
      strPhoneNumber: this.myform.value.PhoneNumber,
      loginUserId:localStorage.getItem("userId")
    };
    console.log(obj, "testttttt");
    this.brandService.createBypassUser(obj).subscribe(
      (res) => {
        console.log(res);
        if (res.success === true) {
          Swal.fire({
            title: "Saved!",
            text: "User Created Saved Successfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then(() => {
            this.myform.reset();
            this.submitted = false;
          });
        } else {
          Swal.fire({
            title: "Warning",
            text: res.message,
            icon: "warning",
            confirmButtonText: "Ok",
          });
        }
      },
      (err) => {
        console.log(err);
      }
    );
  }

  _onClear() {
    this.submitted = false;
    this.myform.reset();
  }

  getAllShop() {
    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
    };
    if (localStorage.getItem("fkShopId")) {
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });
    }
    this.companyService.fnShopListFn(obj).subscribe((res) => {
      this.arrShops = res.data;
    });
  }

  get f() {
    return this.myform.controls;
  }
}

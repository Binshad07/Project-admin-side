import { environment } from './../../../../environments/environment.prod';
import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { PagerService } from "src/app/shared/services/pager.service";
import { ReturnReportService } from "src/app/shared/services/Reports/return-report.service";
import { DatePipe } from '@angular/common';
import { ReportsService } from 'src/app/shared/services/Reports/reports.service';

@Component({
  selector: "app-delivery-summary",
  templateUrl: "./delivery-summary.component.html",
  styleUrls: ["./delivery-summary.component.scss"],
})
export class DeliverySummaryComponent implements OnInit {
  userDetailsArray = [];
  shopListArray = [];
  formUserDetails: FormGroup;
  currentDate = new Date();
  pager: any = {};
  intTotalCount = 0;
  intPageLimit = 10;
  datePipe = new DatePipe('en-US');
  pageLimit: any[];
  strShopId = '';
  arrStores = [];
  intSkipCount = 0;
  fromDate;
  toDate;
  blnLoader = false;
  blnDownloadLoader = false;
  private apiURL: string = environment.API_ENDPOINT;
  // maxCount: number = ;

  constructor(
              private returnReportService: ReturnReportService,
              private pageServiceObj: PagerService,
              private formBuilder: FormBuilder,
              private reportServiceObj: ReportsService,
  ) {}

  ngOnInit() {

    this.formUserDetails = this.formBuilder.group({
      txtFromDate   :  [''],
      txtToDate     :  [''],
      txtTripNo    :  [''],
      cmbShopName   :  '',
      drpPageLimit: "10",
    });
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getShopListingFn();
    this.getUserData();


  }
  _clearForm(form: FormGroup) {
    form.reset({
      txtFromDate   :  '',
      txtToDate     :  '',
      txtTripNo     :  '',
      cmbShopName   :  '',
      drpPageLimit  : "10",
    });
    this.intTotalCount = 0;
    this.intSkipCount = 0;
    this.intPageLimit = 10;
    this.getUserData();
  }

  _getPageLimit(value$) {
    this.intPageLimit = parseInt(this.formUserDetails.value.drpPageLimit);
    this.setPage(1);
  }
  _getShopId(id$) {
    this.strShopId = id$;
  }
  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(this.intTotalCount, page, this.intPageLimit);
    this.getUserData();
  }

  getShopListingFn() {
    this.reportServiceObj.getShopListingService().subscribe((res) => {
      this.arrStores = res.data;
    });
  }
  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.getUserData();
  }
  getUserData() {
    this.blnLoader = false;
    let skipCount = this.intSkipCount;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
    if (this.formUserDetails.value.txtFromDate === '' && this.formUserDetails.value.txtToDate === '') {
      console.log('From Date ::::', this.formUserDetails.value.txtFromDate);
      this.fromDate = this.datePipe.transform(this.currentDate, 'yyyy-M-dd');
      this.toDate = this.datePipe.transform(this.currentDate, 'yyyy-M-dd' );
    }
    if (this.formUserDetails.value.txtFromDate && this.formUserDetails.value.txtToDate === '') {
      console.log('To Date ::::', this.formUserDetails.value.txtToDate);
      this.fromDate = `${this.formUserDetails.value.txtFromDate.year}-${this.formUserDetails.value.txtFromDate.month}-${this.formUserDetails.value.txtFromDate.day}`;
      this.toDate = this.datePipe.transform(this.currentDate, 'yyyy-M-dd' );
    }
    if (this.formUserDetails.value.txtToDate && this.formUserDetails.value.txtFromDate === '') {
      console.log('To Date ::::', this.formUserDetails.value.txtToDate);
      this.fromDate = this.datePipe.transform(this.currentDate, 'yyyy-M-dd');
      this.toDate = `${this.formUserDetails.value.txtToDate.year}-${this.formUserDetails.value.txtToDate.month}-${this.formUserDetails.value.txtToDate.day}`;
    }

    if (this.formUserDetails.value.txtFromDate && this.formUserDetails.value.txtToDate) {
      this.fromDate = `${this.formUserDetails.value.txtFromDate.year}-${this.formUserDetails.value.txtFromDate.month}-${this.formUserDetails.value.txtFromDate.day}`;
      this.toDate = `${this.formUserDetails.value.txtToDate.year}-${this.formUserDetails.value.txtToDate.month}-${this.formUserDetails.value.txtToDate.day}`;
    }
    const obj = {
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
      strStoreId  : this.formUserDetails.value.cmbShopName, // this.strShopId
      strFromDate : this.fromDate, // fromTime
      strToDdate  : this.toDate, // toTime
      strTripNumber  : this.formUserDetails.value.txtTripNo.toUpperCase()
    };

    console.log('OBJECT BEFROE::::::::', obj);

    this.returnReportService.GetDeliveredOrderSummary(obj).subscribe((res) => {
      this.blnLoader = true;
      this.userDetailsArray = res.data[1];
      if (res.data[0]) {
        this.intTotalCount = res.data[0].intTotalCount;
      }
      this.pager = this.pageServiceObj.getPager(this.intTotalCount, this.pager.currentPage, this.intPageLimit);

    });

  }
  getDownloadExcel() {
    this.blnDownloadLoader = !this.blnDownloadLoader;
    const obj = {
      strStoreId  : this.formUserDetails.value.cmbShopName, // this.strShopId
      strFromDate : this.fromDate, // fromTime
      strToDdate  : this.toDate, // toTime
      strTripNumber  : this.formUserDetails.value.txtTripNo,
      strDataType : 'EXCEL'
    };

    this.returnReportService.GetDeliveredOrderSummary(obj).subscribe(res => {
      console.log('RESPONSE EXCEL', res);
      const strPath = this.apiURL + '/' + res.data;
      window.location.href = strPath;
      this.blnDownloadLoader = !this.blnDownloadLoader;

    });

  }


}

import { Component, OnInit } from "@angular/core";
import * as XLSX from "ts-xlsx";
import { ProductService } from "src/app/shared/services/product.service";
import { element } from 'protractor';
import { FormGroup, FormBuilder } from "@angular/forms";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";
@Component({
  selector: "app-import-all-products",
  templateUrl: "./import-all-products.component.html",
  styleUrls: ["./import-all-products.component.scss"],
})
export class ImportAllProductsComponent implements OnInit {
  constructor(
    private srvProduct: ProductService,
    private companyService:CompanyServiceService,) {}
  addform: FormGroup
  blnImportProduct = true;
  arrayProductBuffer: any;
  fileProduct: File;
  arrayAllData = new Array();
  arrayErrorData = new Array();
  arraySuccessData = new Array();
  arrayDuplicateData = new Array();
  categoryList = [];
  arrShops = [];
  subCategoryList = [];
  CategoryId: string = "";
  strShopId: string = "";
  SubCategoryId: string = "";
  catView = false;
  subCatView = false;
  ngOnInit() {
    // this.departmentListing();
    this.getAllShop();
  }


  /*
   TODO @Function: THIS FUNCATION USE GET Department Listing
//   */
//  departmentListing() {
//   this.srvProduct.departmentListingService().subscribe((res) => {
//     // console.log('Department Response :::::',res);

//     if (res.success === true) {
//       this.departmentList = res.data;
//     }
//   });
// }

getAllShop(){
  const obj = {
    loginUserId:localStorage.getItem("userId"),
  }
  if(localStorage.getItem('fkShopId')){
    // Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
    Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

    // obj.fkShopId=localStorage.getItem('fkShopId')
  }
  this.companyService.fngetallCompany(obj).subscribe((res) => {
      
      this.arrShops = res.data
})
}

  /*
   TODO @Function: THIS FUNCATION USE GET Category Listing
  */
  categoryListing() {
    const obj = {
      strShopId: this.strShopId,
    }
    this.srvProduct.categoryListingService(obj).subscribe((res) => {
      // console.log('Category response::::::::', res);

      if (res.success === true) {
        this.categoryList = res.data;
      }
    });
  }
  

  /*
    TODO @Function: THIS FUNCATION USE GET Sub category Listing
  */
  subCategoryListing() {
    const obj = {
      strCategoryId: this.CategoryId,
    };
    this.srvProduct.subcategoryListingService(obj).subscribe((res) => {
      if (res.success === true) {
        this.subCategoryList = res.data;
      }
    });
  }

  _getShoptId(id) {
    this.strShopId = id;
    this.categoryListing();
  }

  catChanged(value) {
    this.CategoryId = value;
    this.subCategoryListing();
  }

  scatChanged(value) {
    this.SubCategoryId = value;
  }

  /*
    TODO @Function: THIS FUNCATION USE GET DATA FROM .xlsx file
    */
  convertFileXLSXFormate(ObjEvent: any) {
    // console.log('Upload Product Event::::::::::::', ObjEvent);

    this.arrayAllData = [];
    try {
      this.fileProduct = ObjEvent.target.files[0];
      let fileReader = new FileReader();
      fileReader.onload = (e) => {
        this.arrayProductBuffer = fileReader.result;
        var arrayOfData = new Uint8Array(this.arrayProductBuffer);
        var arr = new Array();
        for (var i = 0; i != arrayOfData.length; ++i)
          arr[i] = String.fromCharCode(arrayOfData[i]);
        var bstr = arr.join("");
        var workbook = XLSX.read(bstr, { type: "binary" });
        var str_first_sheet_name = workbook.SheetNames[0];
        var worksheet = workbook.Sheets[str_first_sheet_name];
        this.arrayAllData = XLSX.utils.sheet_to_json(worksheet, {
          raw: true,
        });
      };


      this.blnImportProduct = false;
      fileReader.readAsArrayBuffer(this.fileProduct);
      ObjEvent.srcElement.value = null;
    } catch (err) {}
    // console.log('All Data from Excel :::::::::::::', this.arrayAllData);
  }
  /*
    TODO @Function: THIS FUNCATION USE Clear Data
    */

  onClickClearButtonData(event) {
    event.srcElement.value = null;
    this.blnImportProduct = true;
    this.arrayAllData = [];
    this.arrayErrorData = [];
    this.arraySuccessData = [];
    this.arrayDuplicateData = [];
    this.addform.reset();
  }
  /*
    TODO @Function: THIS FUNCATION USE EDIT PRICE LIST TO DATABASE
    */

  UpdateProductData() {
    try {
      this.blnImportProduct = true;
      let intuserId = localStorage.getItem("userId");
      if (this.CategoryId !== "" && this.SubCategoryId !== "") {
        if (this.arrayAllData.length && intuserId) {

          for(let i = 0; i< this.arrayAllData.length; i++) {
            if(!this.arrayAllData[i].MaxProductQuantity
              || !this.arrayAllData[i].MinimumQuantity) {
              this.arrayAllData[i].MinimumQuantity = 1;
              this.arrayAllData[i].MaxProductQuantity = 30
            }
          }
          this.arrayAllData.forEach((element) => {
            if(element)
            element.fkShopId = this.strShopId;
            element.Category = this.CategoryId;
            element.SubCategory = this.SubCategoryId;
          });
          let objData = {
            intuserId: intuserId,
            arrayAllData: this.arrayAllData,
          };
          this.srvProduct.ImportProductList(objData).subscribe((res) => {
            if (res.success === true) {
              this.arrayErrorData = res.data.arrayError;
              this.arraySuccessData = res.data.arraySuccessData;
              this.arrayDuplicateData = res.data.arrayDuplicateData;
              alert(res.message);
            } else {
              alert("update faild :" + res.message);
            }
          });
        } else {
          if (!intuserId) {
            alert("Invalied User");
          } else {
            alert("Data not Found");
          }
          this.blnImportProduct = false;
        }
      } else {
        console.log("error");
        this.blnImportProduct = false;

        if (this.CategoryId === "") {
          this.catView = true;
          setTimeout(() => {
            this.catView = false;
          }, 10000);
        }
        if (this.SubCategoryId === "") {
          this.subCatView = true;
          setTimeout(() => {
            this.subCatView = false;
          }, 10000);
        }
      }
    } catch (err) {}
  }
}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportAllProductsComponent } from './import-all-products.component';

describe('ImportAllProductsComponent', () => {
  let component: ImportAllProductsComponent;
  let fixture: ComponentFixture<ImportAllProductsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImportAllProductsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImportAllProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

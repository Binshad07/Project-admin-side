import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportCategorySubcategoryComponent } from './import-category-subcategory.component';

describe('ImportCategorySubcategoryComponent', () => {
  let component: ImportCategorySubcategoryComponent;
  let fixture: ComponentFixture<ImportCategorySubcategoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImportCategorySubcategoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImportCategorySubcategoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

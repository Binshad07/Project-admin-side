import { Component, OnInit } from '@angular/core';
import * as XLSX from "ts-xlsx";
import { ProductService } from "src/app/shared/services/product.service";
@Component({
  selector: 'app-import-category-subcategory',
  templateUrl: './import-category-subcategory.component.html',
  styleUrls: ['./import-category-subcategory.component.scss']
})
export class ImportCategorySubcategoryComponent implements OnInit {

  constructor(private srvProduct: ProductService) {}


  blnImportCategoryList= true;
  arrayProductBuffer: any;
  fileProduct: File;
  arrayAllData = new Array();
  arrayErrorData= new Array();
  arraySuccessData= new Array();
  arrayDuplicateData = new Array();
  strImportType ="Category";
  ngOnInit() {}

  /*
    TODO @Function: THIS FUNCATION USE GET DATA FROM .xlsx file
    */

  convertFileXLSXFormate(ObjEvent: any) {
    this.arrayAllData = [];
    try {
      this.fileProduct = ObjEvent.target.files[0];
      let fileReader = new FileReader();
      fileReader.onload = (e) => {
        this.arrayProductBuffer = fileReader.result;
        var arrayOfData = new Uint8Array(this.arrayProductBuffer);
        var arr = new Array();

        for (var i = 0; i != arrayOfData.length; ++i)
          arr[i] = String.fromCharCode(arrayOfData[i]);
        var bstr = arr.join("");
        var workbook = XLSX.read(bstr, { type: "binary" });
        var str_first_sheet_name = workbook.SheetNames[0];
        var worksheet = workbook.Sheets[str_first_sheet_name];
        this.arrayAllData = XLSX.utils.sheet_to_json(worksheet, {
          raw: true,
        });
      };
      this.blnImportCategoryList= false;
      fileReader.readAsArrayBuffer(this.fileProduct);
      ObjEvent.srcElement.value = null;
    } catch (err) {}
  }
  /*
    TODO @Function: THIS FUNCATION USE Clear Data
    */

   onClickClearButtonData(event) {
    event.srcElement.value = null;
    this.blnImportCategoryList=true;
    this.arrayAllData = []
    this.arrayErrorData= []
    this.arraySuccessData=[]
    this.arrayDuplicateData =[]
    this.strImportType ="Category";

  }

  onClickReportButtonData(){
    this.srvProduct.ReportCategoryAndSubCategory().subscribe((res) => {
      if (res.success === true) {
        console.log(res)
        alert(res.message);
      } else {
        alert("update faild :"+res.message);
      }
    });
  }
  /*
    TODO @Function: THIS FUNCATION USE EDIT PRICE LIST TO DATABASE
    */

  UpdateCategoryAndSubCategoryData() {
    try {
      this.blnImportCategoryList=true;
      let intuserId =localStorage.getItem('userId')
      if (this.arrayAllData.length && intuserId) {
        let objData ={intuserId:intuserId,arrayAllData:this.arrayAllData,strImportType:this.strImportType}
        this.srvProduct.ImportProdutCategoryandSubcategory(objData).subscribe((res) => {
            if (res.success === true) {
              this.arrayErrorData =res.data.arrayError;
               this.arraySuccessData =res.data.arraySuccessData;
               this.arrayDuplicateData =res.data.arrayDuplicateData;
              alert(res.message);
            } else {
              alert("update faild :"+res.message);
            }
          });
      } else {
          if(!intuserId){
            alert("Invalied User");
          }else{
            alert("Data not Found");
          }

      }
    } catch (err) {
    }
  }

  onClickRadioButton(strType){
    this.strImportType =strType;
 }
}

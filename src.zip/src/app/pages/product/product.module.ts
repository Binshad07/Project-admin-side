import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { AddProductComponent } from "./add-product/add-product.component";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { InfiniteScrollModule } from "ngx-infinite-scroll";
//import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { ImportProductComponent } from "./import-product/import-product.component";

import {
  NgbDatepickerModule,
  NgbTimepickerModule,
  NgbDropdownModule,
  NgbProgressbarModule,
  NgbCollapseModule,
  NgbTooltipModule,
} from "@ng-bootstrap/ng-bootstrap";
import { ChartsModule } from "ng2-charts";

import { UIModule } from "../../shared/ui/ui.module";
import { ProductRoutingModule } from "./product-routing.module";
import { ImportAllProductsComponent } from "./import-all-products/import-all-products.component";
import { ImportCategorySubcategoryComponent } from "./import-category-subcategory/import-category-subcategory.component";
import { ReportProductComponent } from "./report-product/report-product.component";
import { HubOrderSummaryComponent } from "./hub-order-summary/hub-order-summary.component";
import { HubSummaryComponent } from "./hub-summary/hub-summary.component";
import { OrderSummaryComponent } from "./order-summary/order-summary.component";
import { UpdateOutOfStockComponent } from "./update-out-of-stock/update-out-of-stock.component";
import { NewImportProductComponent } from "./new-import-product/new-import-product.component";
import { PayComponent } from "./pay/pay.component";
import { CustomerOrderSummaryComponent } from "./customer-order-summary/customer-order-summary.component";
import { CustomerOrderTrackingComponent } from "./customer-order-tracking/customer-order-tracking.component";
import { TimeSlotManagementComponent } from "./time-slot-management/time-slot-management.component";
import { OrderDetailsComponent } from "./customer-order-summary/order-details/order-details.component";
import { ReturnReportComponent } from "./return-report/return-report.component";
import { OrderSummaryReportComponent } from "./order-summary-report/order-summary-report.component";
import { CancelledReportComponent } from "./cancelled-report/cancelled-report.component";
import { PaymentReportComponent } from "./payment-report/payment-report.component";
import { DeliveryReportComponent } from "./delivery-report/delivery-report.component";
import { OrderLifecycleReportComponent } from "./order-lifecycle-report/order-lifecycle-report.component";
import { DeliverySummaryComponent } from "./delivery-summary/delivery-summary.component";
import { UserDetailsComponent } from './user-details/user-details.component';
import { WishlistAnalysisComponent } from './wishlist-analysis/wishlist-analysis.component';
import { SalesReportComponent } from './sales-report/sales-report.component';
import { CartAnalysisComponent } from './cart-analysis/cart-analysis.component';
import { AddCategoryComponent } from './add-category/add-category.component';
import { CreateAdminUserComponent } from './create-admin-user/create-admin-user.component';
import { NewReportComponent } from './new-report/new-report.component';
import { UploadmultipleimageComponent } from './uploadmultipleimage/uploadmultipleimage.component';
import { DeliveryDetailsComponent } from './delivery-details/delivery-details.component';
import { AddDepartmentComponent } from './add-department/add-department.component';
import { AddSubcategoryComponent } from './add-subcategory/add-subcategory.component';
import { CancelReasonsComponent } from './cancel-reasons/cancel-reasons.component';
import { PermissionsComponent } from './permissions/permissions.component';
import { TransactionReportComponent } from './transaction-report/transaction-report.component';
import { PromocodeComponent } from './promocode/promocode.component';
import { AddPromocodeComponent } from './add-promocode/add-promocode.component';
import { AddPromogroupComponent } from './add-promogroup/add-promogroup.component';
import { AddShopComponent } from './add-shop/add-shop.component';
import { ListShopComponent } from './list-shop/list-shop.component';
import { AddBannerComponent } from './add-banner/add-banner.component';
import { DeliveryUserComponent } from './delivery-user/delivery-user.component';
import { AddDeliveryuserComponent } from './add-deliveryuser/add-deliveryuser.component';
import { HomebannerComponent } from './homebanner/homebanner.component';
import { AddHomebannerComponent } from './add-homebanner/add-homebanner.component';
import { ListBannerComponent } from './list-banner/list-banner.component';
import { AddStoreUserComponent } from './add-store-user/add-store-user.component';
import { StoreUserComponent } from './store-user/store-user.component';
import { OfferBannersComponent } from './offer-banners/offer-banners.component';
import { OrderTrackingComponent } from './order-tracking/order-tracking.component';
import { ProductListComponent } from './product-list/product-list.component';
import { UserComponent } from './user/user.component';
import { AddUserComponent } from './add-user/add-user.component';
import { UserPermissionsComponent } from './user-permissions/user-permissions.component';
import { ListBrandComponent } from './list-brand/list-brand.component';
import { ShopSettingsComponent } from './shop-settings/shop-settings.component';
import { SettlementComponent } from './settlement/settlement.component';
import { InsightsComponent } from './insights/insights.component';
import { SettlementListComponent } from './settlement-list/settlement-list.component';
import { OfflineSubscriptionReportComponent } from "./offline-subscription-report/offline-subscription-report.component";
import { AddOfflineReportComponent } from './add-offline-report/add-offline-report.component';
import { ListSubscriptionReportComponent } from './list-subscription-report/list-subscription-report.component';
import { AddHomemiddleBannerComponent } from './add-homemiddle-banner/add-homemiddle-banner.component';
import { ListHomemiddleBannerComponent } from './list-homemiddle-banner/list-homemiddle-banner.component';
import { ListDomainComponent } from "./list-domain/list-domain.component";
import { AddDomainComponent } from "./add-domain/add-domain.component";
import { StoreloginreportComponent } from './storeloginreport/storeloginreport.component';
import { PushNotificationComponent } from './push-notification/push-notification.component';
import { ListShopCountComponent } from './list-shop-count/list-shop-count.component';
import { AddUnitComponent } from "./add-unit/add-unit.component";
import { UnitnameComponent } from "./unitname/unitname.component";
import { ReturnRequestComponent } from './return-request/return-request.component';
import { RenewShopComponent } from './renew-shop/renew-shop.component';
import { BypassSettingsComponent } from './bypass-settings/bypass-settings.component';
import { OrderTransactionReportComponent } from './order-transaction-report/order-transaction-report.component';
import { OtpLimitComponent } from './otp-limit/otp-limit.component';
import { CreateWithdrawrequestComponent } from './create-withdrawrequest/create-withdrawrequest.component';
import { WithdrawRequestComponent } from "./withdraw-request/withdraw-request.component";
import { CreateSubscriptionReportComponent } from "./create-subscription-report/create-subscription-report.component";
import { CustomledgerComponent } from './customledger/customledger.component';
import { SalesLeadsComponent } from './sales-leads/sales-leads.component';
import { VoucherComponent } from './voucher/voucher.component';
import { VoucherListComponent } from './voucher-list/voucher-list.component';
import { PixelrequestComponent } from './pixelrequest/pixelrequest.component';
import { AnalyticsRequestComponent } from './analytics-request/analytics-request.component';
import { RazorpayRequestComponent } from './razorpay-request/razorpay-request.component';
import { AgencyModuleComponent } from './agency-module/agency-module.component';
import { FreezingModuleComponent } from './freezing-module/freezing-module.component';
import { CustomerTicketRequestComponent } from './customer-ticket-request/customer-ticket-request.component';
import { UpcomingStoreRenewalsComponent } from './upcoming-store-renewals/upcoming-store-renewals.component';
import { WebsiteLeadsListComponent } from './website-leads-list/website-leads-list.component';
import { OtpRequestDetailsComponent } from './otp-request-details/otp-request-details.component';
import {AutocompleteLibModule} from 'angular-ng-autocomplete';
import { BypassLoginComponent } from "./bypass-login/bypass-login.component";
@NgModule({
  declarations: [
    AddProductComponent,
    ImportProductComponent,
    ImportAllProductsComponent,
    ImportCategorySubcategoryComponent,
    ReportProductComponent,
    HubOrderSummaryComponent,
    HubSummaryComponent,
    OrderSummaryComponent,
    UpdateOutOfStockComponent,
    NewImportProductComponent,
    PayComponent,
    CustomerOrderSummaryComponent,
    CustomerOrderTrackingComponent,
    TimeSlotManagementComponent,
    OrderDetailsComponent,
    ReturnReportComponent,
    OrderSummaryReportComponent,
    CancelledReportComponent,
    PaymentReportComponent,
    DeliveryReportComponent,
    DeliverySummaryComponent,
    OrderLifecycleReportComponent,
    UserDetailsComponent,
    WishlistAnalysisComponent,
    SalesReportComponent,
    CartAnalysisComponent,
    AddCategoryComponent,
    CreateAdminUserComponent,
    NewReportComponent,
    UploadmultipleimageComponent,
    DeliveryDetailsComponent,
    AddDepartmentComponent,
    AddSubcategoryComponent,
    CancelReasonsComponent,
    PermissionsComponent,
    TransactionReportComponent,
    PromocodeComponent,
    AddPromocodeComponent,
    AddPromogroupComponent,
    AddShopComponent,
    ListShopComponent,
    AddBannerComponent,
    DeliveryUserComponent,
    AddDeliveryuserComponent,
    HomebannerComponent,
    AddHomebannerComponent,
    ListBannerComponent,
    AddStoreUserComponent,
    StoreUserComponent,
    OfferBannersComponent,
    OrderTrackingComponent,
    ProductListComponent,
    UserComponent,
    AddUserComponent,
    UserPermissionsComponent,
    ListBrandComponent,
    ShopSettingsComponent,
    SettlementComponent,
    InsightsComponent,
    SettlementListComponent,
    OfflineSubscriptionReportComponent,
    AddOfflineReportComponent,
    ListSubscriptionReportComponent,
    AddHomemiddleBannerComponent,
    ListHomemiddleBannerComponent,
    ListDomainComponent,
    AddDomainComponent,
    // storereportComponent,
    StoreloginreportComponent,
    PushNotificationComponent,
    ListShopCountComponent,
    AddUnitComponent,
    UnitnameComponent,
    ReturnRequestComponent,
    RenewShopComponent,
    BypassSettingsComponent,
    OrderTransactionReportComponent,
    OtpLimitComponent,
    CreateWithdrawrequestComponent,
    WithdrawRequestComponent,
    //  Createwithdrawrequest
    CreateSubscriptionReportComponent,
    CustomledgerComponent,
    SalesLeadsComponent,
    PixelrequestComponent,
    AnalyticsRequestComponent,
    RazorpayRequestComponent,
    AgencyModuleComponent,
    VoucherComponent,
    VoucherListComponent,
    FreezingModuleComponent,
    CustomerTicketRequestComponent,
    UpcomingStoreRenewalsComponent,
    WebsiteLeadsListComponent,
    OtpRequestDetailsComponent,
    BypassLoginComponent

  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    NgbDropdownModule,
    NgbDatepickerModule,
    NgbTimepickerModule,
    NgbProgressbarModule,
    NgbTooltipModule,
    ChartsModule,
    NgbCollapseModule,
    UIModule,
    ProductRoutingModule,
    InfiniteScrollModule,
    AutocompleteLibModule

  ],
})
export class ProductModule { }
//platformBrowserDynamic().bootstrapModule(ProductModule);

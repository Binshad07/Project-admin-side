import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RazorpayRequestComponent } from './razorpay-request.component';

describe('RazorpayRequestComponent', () => {
  let component: RazorpayRequestComponent;
  let fixture: ComponentFixture<RazorpayRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RazorpayRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RazorpayRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

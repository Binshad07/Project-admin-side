import { Component, OnInit } from "@angular/core";
import { PagerService } from "src/app/shared/services/pager.service";
import { FormGroup, FormBuilder } from "@angular/forms";
import { ReportsService } from "src/app/shared/services/Reports/reports.service";
import { modItemSales } from "src/app/shared/Classes/report.model";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";
import { DatePipe } from "@angular/common";

@Component({
  selector: "app-razorpay-request",
  templateUrl: "./razorpay-request.component.html",
  styleUrls: ["./razorpay-request.component.scss"],
})
export class RazorpayRequestComponent implements OnInit {
  currentDate = new Date();
  frmItemSales: FormGroup;
  pager: any = {};
  intTotalCount = 0;
  intPageLimit = 10;
  pageLimit: any[];
  strShopId = "";
  arrStores = [];
  intSkipCount = 0;
  datePipe = new DatePipe("en-US");
  arrItemSales: modItemSales[] = [];
  fromDate;
  toDate;
  blnLoader = false;
  blnDownloadLoader = false;
  userType: string;
  submitted = false;
  keyword: string = "strShopName";
  selectedShopName: string;
  searchTimeout: any;

  constructor(
    private pageServiceObj: PagerService,
    private companyService: CompanyServiceService,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit() {
    this.frmItemSales = this.formBuilder.group({
      txtFromDate: [""],
      txtToDate: [""],
      cmbShopName: [""],
      strRazorpayKeySecret: [""],
      status: [""],
      drpPageLimit: "10",
    });

    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getRazorpayReport();
  }

  get formControls() {
    return this.frmItemSales.controls;
  }

  _clearForm(form: FormGroup) {
    (this.selectedShopName = ""), this.frmItemSales.reset();
    form.reset({
      txtToDate: "",
      drpPageLimit: "10",
      status: "",
      razorpay_key_id: "",
    });
    this.getRazorpayReport();
  }

  _getPageLimit(value$) {
    this.intPageLimit = parseInt(this.frmItemSales.value.drpPageLimit);
    this.setPage(1);
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getRazorpayReport();
  }

  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.getRazorpayReport();
  }

  _getShopId(id$) {
    this.strShopId = id$;
  }

  openStoreUrl(storeUrl: string | undefined) {
    if (storeUrl) {
      window.open(storeUrl, "_blank");
    }
  }

  getRazorpayReport() {
    let skipCount = this.intSkipCount;
    this.blnLoader = false;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }

    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
      fromDate: this.fromDate,
      toDate: this.toDate,
      strShopName: this.selectedShopName,
      strRazorpayKeyID: this.frmItemSales.value.strRazorpayKeySecret,
      strSkipCount: skipCount,
      strPageLimit: this.intPageLimit,
      status: this.frmItemSales.value.status,
    };
    this.companyService.razorpaylist(obj).subscribe((res) => {
      console.log(res, "statas");
      if (res && res.success) {
        this.blnLoader = true;
        this.arrItemSales = res.data;
        this.intTotalCount = res.count;
        this.arrItemSales = res.data;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
      } else {
        this.arrItemSales = [];
      }
    });
  }

  onChangeSearch(event: any) {
    clearTimeout(this.searchTimeout);
    this.searchTimeout = setTimeout(() => {
      this.getShopListingFn(event);
    }, 300);
  }

  getShopListingFn(searchString: string) {
    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
      strShopName: searchString || "",
    };
    this.companyService.fnShopListFn(obj).subscribe(
      (res) => {
        if (res && res.data) {
          this.arrStores = res.data
            .filter((shop) => {
              const shopName =
                typeof shop.strShopName === "object" &&
                shop.strShopName !== null
                  ? shop.strShopName.strShopName
                  : shop.strShopName;
              return shopName
                .toLowerCase()
                .includes(searchString.toLowerCase());
            })
            .map((shop) => ({
              pkShopId: shop.pkShopId,
              strShopName:
                typeof shop.strShopName === "object" &&
                shop.strShopName !== null
                  ? shop.strShopName.strShopName
                  : shop.strShopName,
            }));
          if (this.arrStores.length > 0) {
            this.strShopId = this.arrStores[0].pkShopId;
            this.selectedShopName = this.arrStores[0].strShopName;
          }
        } else {
          this.arrStores = [];
        }
      },
      (error) => {
        console.error("Error fetching shop list", error);
        this.arrStores = [];
      }
    );
  }
}

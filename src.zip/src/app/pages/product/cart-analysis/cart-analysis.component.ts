import { Component, OnInit } from "@angular/core";
import { PagerService } from "src/app/shared/services/pager.service";
import { ReportsService } from "src/app/shared/services/Reports/reports.service";
import { FormBuilder, FormGroup } from "@angular/forms";
import { DatePipe } from "@angular/common";
import { modCartDetails } from "src/app/shared/Classes/report.model";
import { skip } from "rxjs/operators";

@Component({
  selector: "app-cart-analysis",
  templateUrl: "./cart-analysis.component.html",
  styleUrls: ["./cart-analysis.component.scss"],
})
export class CartAnalysisComponent implements OnInit {
  frmCart: FormGroup;
  currentDate = new Date();
  pager: any = {};
  intTotalCount = 0;
  intSkipCount = 0;
  intPageLimit = 10;
  arrStores = [];
  datePipe = new DatePipe("en-US");
  pageLimit: any[];
  arrCartDetails: modCartDetails[] = [];
  blnLoader = false;

  constructor(
    private pageServiceObj: PagerService,
    private reportServiceObj: ReportsService,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit() {
    this.frmCart = this.formBuilder.group({
      txtFromDate     : [""],
      txtToDate       : [""],
      txtEmail        : [""],
      txtPhoneNumber  : [""],
      drpPageLimit    : "10",
    });
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getShopListingFn();
    this.getCartDetailsFn();
  }

  _clearForm(form: FormGroup) {
    form.reset({
      txtFromDate: "",
      txtToDate: "",
      txtEmail: "",
      txtPhoneNumber: "",
      drpPageLimit: "10",
    });
    this.intTotalCount = 0;
    this.intSkipCount = 0;
    this.intPageLimit = 10;
    this.getCartDetailsFn();
  }

  _getPageLimit(value$) {
    this.intPageLimit = parseInt(this.frmCart.value.drpPageLimit);
    this.setPage(1);
  }
  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getCartDetailsFn();
  }

  _onSearch() {
    this.pager = {};
    this.getCartDetailsFn();
  }

  getShopListingFn() {
    this.reportServiceObj.getShopListingService().subscribe((res) => {
      this.arrStores = res.data;
    });
  }

  getCartDetailsFn() {
    let skipCount = this.intSkipCount;
    this.blnLoader = false;

    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
    let fromDate;
    let toDate;
    if (
      this.frmCart.value.txtFromDate === "" &&
      this.frmCart.value.txtToDate === ""
    ) {
      console.log("From Date ::::", this.frmCart.value.txtFromDate);
      fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
      toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    }
    if (this.frmCart.value.txtFromDate && this.frmCart.value.txtToDate === "") {
      console.log("To Date ::::", this.frmCart.value.txtToDate);
      fromDate = `${this.frmCart.value.txtFromDate.year}-${this.frmCart.value.txtFromDate.month}-${this.frmCart.value.txtFromDate.day}`;
      toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    }
    if (this.frmCart.value.txtToDate && this.frmCart.value.txtFromDate === "") {
      console.log("To Date ::::", this.frmCart.value.txtToDate);
      fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
      toDate = `${this.frmCart.value.txtToDate.year}-${this.frmCart.value.txtToDate.month}-${this.frmCart.value.txtToDate.day}`;
    }

    if (this.frmCart.value.txtFromDate && this.frmCart.value.txtToDate) {
      fromDate = `${this.frmCart.value.txtFromDate.year}-${this.frmCart.value.txtFromDate.month}-${this.frmCart.value.txtFromDate.day}`;
      toDate = `${this.frmCart.value.txtToDate.year}-${this.frmCart.value.txtToDate.month}-${this.frmCart.value.txtToDate.day}`;
    }
    if (
      this.frmCart.value.txtPhoneNumber === null ||
      this.frmCart.value.txtPhoneNumber === undefined
    ) {
      this.frmCart.value.txtPhoneNumber = "";
    }
    const obj = {
      strSkipCount: skipCount,
      strPageLimit: this.intPageLimit,
      strFromDate: fromDate, //fromDate,
      strToDdate: toDate, //toDate,
      strPhone: this.frmCart.value.txtPhoneNumber + "", //(this.frmCart.value.txtPhoneNumber).toString() 7034674705,
      strEmail: this.frmCart.value.txtEmail,
    };
    console.log("OBJECT :::::::::::", obj);

    this.reportServiceObj.getCartDetailsService(obj).subscribe((res) => {
      this.blnLoader = true;

      console.log("RESPONESSS::::::::::", res);
      this.arrCartDetails = res.data[1];
      if (res.data[0].intTotalCOunt) {
        this.intTotalCount = res.data[0].intTotalCOunt;
      }
      this.pager = this.pageServiceObj.getPager(
        this.intTotalCount,
        this.pager.currentPage,
        this.intPageLimit
      );
    });
  }
}

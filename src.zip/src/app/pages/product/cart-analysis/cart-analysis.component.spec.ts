import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CartAnalysisComponent } from './cart-analysis.component';

describe('CartAnalysisComponent', () => {
  let component: CartAnalysisComponent;
  let fixture: ComponentFixture<CartAnalysisComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CartAnalysisComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CartAnalysisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

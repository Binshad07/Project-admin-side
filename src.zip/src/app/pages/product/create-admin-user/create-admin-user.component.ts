import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-admin-user',
  templateUrl: './create-admin-user.component.html',
  styleUrls: ['./create-admin-user.component.scss']
})
export class CreateAdminUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

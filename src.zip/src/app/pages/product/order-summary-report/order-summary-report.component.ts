import { environment } from "./../../../../environments/environment.prod";
import { Component, OnInit } from "@angular/core";
import { PagerService } from "src/app/shared/services/pager.service";
import { DatePipe } from "@angular/common";
import { ReportsService } from "src/app/shared/services/Reports/reports.service";
import { FormBuilder, FormGroup } from "@angular/forms";
import { modOrderSummary } from "src/app/shared/Classes/report.model";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";

@Component({
  selector: "app-order-summary-report",
  templateUrl: "./order-summary-report.component.html",
  styleUrls: ["./order-summary-report.component.scss"],
})
export class OrderSummaryReportComponent implements OnInit {
  currentDate = new Date();
  frmOrderSummary: FormGroup;
  pager: any = {};
  intTotalCount = 0;
  intPageLimit = 10;
  datePipe = new DatePipe("en-US");
  pageLimit: any[];
  strShopId = "";
  arrStores = [];
  intSkipCount = 0;
  arrOrderSummary: modOrderSummary[] = [];
  fromDate;
  toDate;
  blnLoader = false;
  blnDownloadLoader = false;
  private apiURL: string = environment.API_ENDPOINT;
  userType: string;

  constructor(
    private pageServiceObj: PagerService,
    private formBuilder: FormBuilder,
    private companyService:CompanyServiceService,
    private reportServiceObj: ReportsService
  ) {}

  ngOnInit() {
    this.frmOrderSummary = this.formBuilder.group({
      txtFromDate: [""],
      txtToDate: [""],
      txtOrderId: [""],
      cmbShopName: [""],
      drpPageLimit: "10",
    });
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getShopListingFn();
    this.getOrderSummaryFn();
    this.userType=localStorage.getItem("strUserType");
  }
  _clearForm(form: FormGroup) {
    form.reset({
      txtFromDate: "",
      txtToDate: "",
      txtOrderId: "",
      cmbShopName: "",
      drpPageLimit: "10",
    });
    this.intTotalCount = 0;
    this.intSkipCount = 0;
    this.intPageLimit = 10;
    this.getOrderSummaryFn();
  }
  _getPageLimit(value) {
    this.intPageLimit = parseInt(this.frmOrderSummary.value.drpPageLimit);
    this.setPage(1);
  }
  _getShopId(id$) {
    this.strShopId = id$;
  }
  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getOrderSummaryFn();
  }
  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.getOrderSummaryFn();
  }

  getShopListingFn() {
    const obj = {
      loginUserId:localStorage.getItem("userId"),
    }
    if(localStorage.getItem('fkShopId')){
      // Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
      this.arrStores = res.data;
      this.strShopId = res.data[0].pkShopId;
    });
  }
  getOrderSummaryFn() {
    let skipCount = this.intSkipCount;
    this.blnLoader = false;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
    if (
      this.frmOrderSummary.value.txtFromDate === "" &&
      this.frmOrderSummary.value.txtToDate === ""
    ) {
      console.log("From Date ::::", this.frmOrderSummary.value.txtFromDate);
      this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
      this.toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    }
    if (
      this.frmOrderSummary.value.txtFromDate &&
      this.frmOrderSummary.value.txtToDate === ""
    ) {
      this.fromDate = `${this.frmOrderSummary.value.txtFromDate.year}-${this.frmOrderSummary.value.txtFromDate.month}-${this.frmOrderSummary.value.txtFromDate.day}`;
      this.toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    }
    if (
      this.frmOrderSummary.value.txtToDate &&
      this.frmOrderSummary.value.txtFromDate === ""
    ) {
      this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
      this.toDate = `${this.frmOrderSummary.value.txtToDate.year}-${this.frmOrderSummary.value.txtToDate.month}-${this.frmOrderSummary.value.txtToDate.day}`;
    }

    if (
      this.frmOrderSummary.value.txtFromDate &&
      this.frmOrderSummary.value.txtToDate
    ) {
      this.fromDate = `${this.frmOrderSummary.value.txtFromDate.year}-${this.frmOrderSummary.value.txtFromDate.month}-${this.frmOrderSummary.value.txtFromDate.day}`;
      this.toDate = `${this.frmOrderSummary.value.txtToDate.year}-${this.frmOrderSummary.value.txtToDate.month}-${this.frmOrderSummary.value.txtToDate.day}`;
    }

    const obj = {
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
      strStoreId: this.frmOrderSummary.value.cmbShopName, //this.strShopId, // this.strShopId
      strFromDate: this.fromDate, // fromTime
      strToDdate: this.toDate, // toTime
      strOrderNo: this.frmOrderSummary.value.txtOrderId.toUpperCase(),
    };
    if(localStorage.getItem('fkShopId')){
      Object.assign(obj,{strStoreId: localStorage.getItem('fkShopId')})
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    console.log("Object:::::", obj);

    this.reportServiceObj.getOrderSummaryService(obj).subscribe((res) => {
      this.blnLoader = true;

      this.arrOrderSummary = res.data[1];
      if (res.data[0]) {
        this.intTotalCount = res.data[0].intTotalCount;
      }
      this.pager = this.pageServiceObj.getPager(
        this.intTotalCount,
        this.pager.currentPage,
        this.intPageLimit
      );
    });
  }
  getDownloadExcel() {
    this.blnDownloadLoader = !this.blnDownloadLoader;
    const obj = {
      strStoreId: this.frmOrderSummary.value.cmbShopName, //this.strShopId, // this.strShopId
      strFromDate: this.fromDate, // fromTime
      strToDdate: this.toDate, // toTime
      strOrderNo: this.frmOrderSummary.value.txtOrderId.toUpperCase(),
      strDataType: "EXCEL",
    };

    this.reportServiceObj.getOrderSummaryService(obj).subscribe((res) => {
      console.log("RESPONSE EXCEL", res);
      const strPath = this.apiURL + "/" + res.data;
      window.location.href = strPath;
      this.blnDownloadLoader = !this.blnDownloadLoader;
    });
  }
}

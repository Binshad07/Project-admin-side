import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HubOrderSummaryComponent } from './hub-order-summary.component';

describe('HubOrderSummaryComponent', () => {
  let component: HubOrderSummaryComponent;
  let fixture: ComponentFixture<HubOrderSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HubOrderSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HubOrderSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

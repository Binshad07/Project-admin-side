import { environment } from "./../../../../environments/environment.prod";
import { Component, OnInit } from "@angular/core";
import { PagerService } from "src/app/shared/services/pager.service";
import { FormGroup, FormBuilder } from "@angular/forms";
import { DatePipe } from "@angular/common";
import { ReportsService } from "src/app/shared/services/Reports/reports.service";
import {
  modHubSummary,
  modHubOrderTotal,
} from "src/app/shared/Classes/report.model";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";

@Component({
  selector: "app-hub-order-summary",
  templateUrl: "./hub-order-summary.component.html",
  styleUrls: ["./hub-order-summary.component.scss"],
})
export class HubOrderSummaryComponent implements OnInit {
  currentDate = new Date();
  pager: any = {};
  intTotalCount = 0;
  intPageLimit = 10;
  intSkipCount = 0;
  arrStores = [];
  datePipe = new DatePipe("en-US");
  pageLimit: any[];
  strShopId = "";
  arrTotal: modHubOrderTotal[] = [];
  arrHubOrderSummary: modHubSummary[] = [];
  frmHubOrderSummary: FormGroup;
  fromDate;
  toDate;
  blnLoader = false;
  blnDownloadLoader = false;
  private apiURL: string = environment.API_ENDPOINT;

  constructor(
    private pageServiceObj: PagerService,
    private reportServiceObj: ReportsService,
    private companyService:CompanyServiceService,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit() {
    this.frmHubOrderSummary = this.formBuilder.group({
      txtFromDate   : [""],
      txtToDate     : [""],
      cmbShopName   : [""],
      drpPageLimit  : "10",
    });
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getShopListingFn();
    this.getHubOrderSummaryFn();
  }

  _clearForm(form: FormGroup) {
    form.reset({
      txtFromDate: "",
      txtToDate: "",
      cmbShopName: "",
      drpPageLimit  : "10",
    });
    this.intTotalCount = 0;
    this.intSkipCount = 0;
    this.intPageLimit = 10;
    this.getHubOrderSummaryFn();
  }

  _getPageLimit(value$) {
    this.intPageLimit =  parseInt(this.frmHubOrderSummary.value.drpPageLimit);
    this.setPage(1);
  }
  _getShopId(id$) {
    this.strShopId = id$;
  }
  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getHubOrderSummaryFn();
  }
  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.getHubOrderSummaryFn();
  }
  getShopListingFn() {
    const obj = {
      loginUserId:localStorage.getItem("userId"),
    }
    if(localStorage.getItem('fkShopId')){
      Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
      this.arrStores = res.data;
      this.strShopId = res.data[0].pkShopId;
    });
  }

  getHubOrderSummaryFn() {
    this.blnLoader = false;

    let skipCount = this.intSkipCount;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }

    if (
      this.frmHubOrderSummary.value.txtFromDate === "" &&
      this.frmHubOrderSummary.value.txtToDate === ""
    ) {
      console.log("From Date ::::", this.frmHubOrderSummary.value.txtFromDate);
      this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
      this.toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    }
    if (
      this.frmHubOrderSummary.value.txtFromDate &&
      this.frmHubOrderSummary.value.txtToDate === ""
    ) {
      console.log("To Date ::::", this.frmHubOrderSummary.value.txtToDate);
      this.fromDate = `${this.frmHubOrderSummary.value.txtFromDate.year}-${this.frmHubOrderSummary.value.txtFromDate.month}-${this.frmHubOrderSummary.value.txtFromDate.day}`;
      this.toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    }
    if (
      this.frmHubOrderSummary.value.txtToDate &&
      this.frmHubOrderSummary.value.txtFromDate === ""
    ) {
      console.log("To Date ::::", this.frmHubOrderSummary.value.txtToDate);
      this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
      this.toDate = `${this.frmHubOrderSummary.value.txtToDate.year}-${this.frmHubOrderSummary.value.txtToDate.month}-${this.frmHubOrderSummary.value.txtToDate.day}`;
    }

    if (
      this.frmHubOrderSummary.value.txtFromDate &&
      this.frmHubOrderSummary.value.txtToDate
    ) {
      this.fromDate = `${this.frmHubOrderSummary.value.txtFromDate.year}-${this.frmHubOrderSummary.value.txtFromDate.month}-${this.frmHubOrderSummary.value.txtFromDate.day}`;
      this.toDate = `${this.frmHubOrderSummary.value.txtToDate.year}-${this.frmHubOrderSummary.value.txtToDate.month}-${this.frmHubOrderSummary.value.txtToDate.day}`;
    }
    const obj = {
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
      strStoreId: this.frmHubOrderSummary.value.cmbShopName,
      strFromDate: this.fromDate,
      strToDdate: this.toDate,
    };
    if(localStorage.getItem('fkShopId')){
      Object.assign(obj,{strStoreId: localStorage.getItem('fkShopId')})
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    console.log("Object:::::::", obj);

    this.reportServiceObj.getHubOrderSummaryService(obj).subscribe((res) => {
      this.blnLoader = true;

      console.log("HUB ORDER SUMMARY RESPONSE :::::", res);
      this.arrHubOrderSummary = res.data[1];
      console.log(this.arrHubOrderSummary);
      this.arrTotal = res.data[2];
      if (res.data[0]) {
        this.intTotalCount = res.data[0].intTotalCount;
      }
      this.pager = this.pageServiceObj.getPager(
        this.intTotalCount,
        this.pager.currentPage,
        this.intPageLimit
      );
    });
  }

  getDownloadExcel() {
    this.blnDownloadLoader = !this.blnDownloadLoader;
    const obj = {
      strStoreId: this.frmHubOrderSummary.value.cmbShopName,
      strFromDate: this.fromDate,
      strToDdate: this.toDate,
      strDataType: "EXCEL",
    };

    this.reportServiceObj.getHubOrderSummaryService(obj).subscribe((res) => {
      this.blnDownloadLoader = !this.blnDownloadLoader;
      console.log("RESPONSE EXCEL", res);
      const strPath = this.apiURL + "/" + res.data;
      window.location.href = strPath;
    });
  }
}

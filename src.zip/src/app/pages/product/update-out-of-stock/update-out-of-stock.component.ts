import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators, } from "@angular/forms";
import * as XLSX from "ts-xlsx";
import { ProductService } from "../../../shared/services/product.service";
@Component({
  selector: 'app-update-out-of-stock',
  templateUrl: './update-out-of-stock.component.html',
  styleUrls: ['./update-out-of-stock.component.scss']
})
export class UpdateOutOfStockComponent implements OnInit {
  constructor(private srvProduct: ProductService,private formBuilder: FormBuilder,) {}
  blnImport = false;
  loadingUploadedButton = false;
  arrayBuffer: any;
  file: File;
  arrayAllData = new Array();
  arrayErrorData = new Array();
  arraySuccessData = new Array();
  fileError = false;
  strUpdateType ="OUTOFSTOCK";
  frmProductUpdate: FormGroup;
  ngOnInit() {
    this.frmProductUpdate = this.formBuilder.group({
      cmbUpdateType: ["OUTOFSTOCK"],
      rdbProductVisibility: ["Active"],
      rdbStockStatus: ["true"]

    });
  }
 /*
      TODO @Function: THIS FUNCATION USE GET DATA FROM .xlsx file
      */

     convertFileXLSXFormateBarcode(ObjEvent: any) {
      this.loadingUploadedButton = true;
      this.arrayAllData = [];
      try {
          let extension = ObjEvent.target.files[0].name.split(".").pop();
          if (extension === "xlsx") {
              this.fileError = false;
              this.file = ObjEvent.target.files[0];
              let fileReader = new FileReader();
              fileReader.onload = (e) => {
                  this.arrayBuffer = fileReader.result;
                  var arrayOfData = new Uint8Array(this.arrayBuffer);
                  var arr = new Array();

                  for (var i = 0; i != arrayOfData.length; ++i)
                      arr[i] = String.fromCharCode(arrayOfData[i]);
                  var bstr = arr.join("");
                  var workbook = XLSX.read(bstr, { type: "binary" });
                  var str_first_sheet_name = workbook.SheetNames[0];
                  var worksheet = workbook.Sheets[str_first_sheet_name];
                  this.arrayAllData = XLSX.utils.sheet_to_json(worksheet, {
                      raw: true,
                  });
              };

              fileReader.readAsArrayBuffer(this.file);
              this.blnImport = false;
              ObjEvent.srcElement.value = null;
              this.loadingUploadedButton = false;
          } else {
              // console.log("else called");
              this.fileError = true;
              this.loadingUploadedButton = false;
          }
      } catch (err) {}
  }
  /*
    TODO @Function: THIS FUNCATION USE Clear Data
    */

  onClickClearAllData(event) {
      event.srcElement.value = null;
      this.arrayAllData = [];
      this.blnImport = false;
      this.arrayAllData = [];
      this.arrayErrorData = [];
      this.arraySuccessData = [];
      this.loadingUploadedButton = false;
  }


  /*
    TODO @Function: THIS FUNCATION USE EDIT PRICE LIST TO DATABASE
    */

  UpdateOutOfStockPriceListData() {
      try {
          this.blnImport = true;
          let strLoginUserId = localStorage.getItem('userId')
          let strUpdateType =this.frmProductUpdate.value.cmbUpdateType;
          let strProductStatus =this.frmProductUpdate.value.rdbProductVisibility;
          let blnStockAvailable =this.frmProductUpdate.value.rdbStockStatus;
          if(strLoginUserId && (strUpdateType =="OUTOFSTOCK" || strUpdateType =="PRODUCTHIDE" ) &&
          (strProductStatus =="Active" || strProductStatus =="Deactive" ) && (blnStockAvailable =="true" || blnStockAvailable =="false" )){
            if (this.arrayAllData.length) {
              var objData ={
                arrayUplaodedData   : this.arrayAllData,
                strProductStatus    : strProductStatus,
                blnStockAvailable   : blnStockAvailable,
                strUpdateType       : strUpdateType,
                strLoginUserId      : strLoginUserId
              }
                this.srvProduct
                    .UpdateProductOutOfStock(objData)
                    .subscribe((res) => {
                      this.blnImport = false;
                        if (res.success === true) {

                            this.arrayErrorData = res.data.arrayError;
                            this.arraySuccessData = res.data.arraySuccessData;
                            alert(res.message);
                        } else {
                            alert("update faild");
                        }
                    });
            } else {
              this.blnImport = false;
                alert("Data not Found");
            }
          }
          else{
            this.blnImport = false;
            if(!strLoginUserId)
              alert("Login User Data not found  please re-login");
            else
              alert("Params missing");
          }


      } catch (err) {
        this.blnImport = false;
          alert("Error" + err);
      }
  }
}

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { log } from 'console';
import { DatePipe } from "@angular/common";
// import { FranchiseService } from 'src/app/shared/services/franchise/franchise.service';
import { PagerService } from 'src/app/shared/services/pager.service';
import { ShopServiceService } from 'src/app/shared/services/shopService/shop-service.service';
// import { RentalService } from 'src/app/shared/services/rental/rental.service';
import Swal from "sweetalert2";
import { CompanyServiceService } from 'src/app/shared/services/company/company-service.service';
import { HypermarketService } from "./../../../shared/services/Hypermarket/hypermarket.service";


@Component({
  selector: 'app-list-shop',
  templateUrl: './list-shop.component.html',
  styleUrls: ['./list-shop.component.scss']
})
export class ListShopComponent implements OnInit {

  frmFilterShop: FormGroup
  arrRentalItem: any[] = []
  pager: any = {};
  intTotalCount = 0;
  intPageLimit = 10;
  pageLimit: any[];
  intSkipCount = 0;
  arrayOfObjFranchiseList: any[] = []
  arrShops: any[] = []
  strShopId: ""
  arrViewType = [];
  arrCompany:any[] = []
  userType: string;
  currentDate = new Date();
  datePipe = new DatePipe("en-US");

  constructor(
    private formbuilder: FormBuilder,
    private pageServiceObj: PagerService,
    private modalService: NgbModal,
    private router: Router,
    private route: ActivatedRoute,
    private shopService: ShopServiceService,
    private hypermarketServiceObj: HypermarketService,
    private companyService: CompanyServiceService

  ) { }

  ngOnInit() {
    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist;

    this.frmFilterShop = this.formbuilder.group({
      strShopName: ["",],
      strEmail: ["",],
      strPlanType: ["",],
      strViewType: ["",],
      cmbShopName: ["",],

    })
    this.userType=localStorage.getItem("strUserType");
    this.fnGetAllShopes();
    this.getViewTypeFn();
    // this.getShopSearchData(); 
    this.getAllCompany();  
  }


  getViewTypeFn() {
    const obj = {};
    if (localStorage.getItem("strUserType") == "SHOP REPORTER") {
      Object.assign(obj, {
        strViewTypeName: localStorage.getItem("strViewType"),
      });
    }
    this.hypermarketServiceObj.getVieType(obj).subscribe((res) => {
      console.log(res, "resssviwetype");
      this.arrViewType = res.data;
      console.log(this.arrViewType, "console");
    });
  }


  getAllCompany(){
    const obj = {
      loginUserId:localStorage.getItem("userId"),
    }
    if(localStorage.getItem('fkShopId')){
      // Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
      if(res && res.success){
        this.arrCompany = res.data
      }
    },(err) => {
      console.log(err)
    })
  }


  fnGetAllShopes() {


    let skipCount = this.intSkipCount;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }


    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
      strSkipCount: skipCount,
      strPageLimit: this.intPageLimit,
      strShopName: this.frmFilterShop.value.cmbShopName,
      strEmail: this.frmFilterShop.value.strEmail,
      planType: this.frmFilterShop.value.strPlanType,
      strViewType: this.frmFilterShop.value.strViewType,
      
    }

    if(localStorage.getItem('fkShopId')){
      Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }    

    this.shopService.getAllShops(obj).subscribe((res) => {
    if (res.success) {
        this.arrShops = res.data;
         this.intTotalCount = res.count;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
       
      } else {
        Swal.fire({
          title: "error",
          text: res.message,
          icon: "error",
          confirmButtonText: "Ok",
        });
        this.arrShops = [];
        this.pager = {};
        this.intTotalCount = 0;
        // this.spinner.hide();
      }
    }, (err) => {
      console.log(err)
    })
  }

  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.fnGetAllShopes();
  }


  deleteModal(responsiveDelete, item) {

    console.log("item", item)
    this.strShopId = item.pkShopId;
    this.modalService.open(responsiveDelete);
  }

  delete() {
    const obj = {
      shopId: this.strShopId,
      strLoginUserId: localStorage.getItem("userId")
    }

    console.log("objeeeeeeeee", obj)

    this.shopService.deleteAllShops(obj).subscribe((res) => {
      if (res.success) {
        this.modalService.dismissAll();
        // this.spinner.hide();
        Swal.fire({
          title: "Deleted!",
          text: "Shop deleted successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then(() => {
          this.fnGetAllShopes()
          this.ngOnInit()
        })
      } else {
        // this.spinner.hide();
        Swal.fire({
          title: "error",
          text: res.message,
          icon: "error",
          confirmButtonText: "Ok",
        });
      }
    }, () => {
      this.fnGetAllShopes()
    })
  }

  edit(item: any) {
    this.router.navigate(["/product/add-shop"], {
      queryParams: { id: item.pkShopId }
    })
  }


  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.fnGetAllShopes();

  }

  _clearFormFilter() {
    this.frmFilterShop.reset()
    this.ngOnInit()
  }


  calculateDiff(dateSent){
    if(dateSent){
      let currentDate = new Date();
      dateSent = new Date(dateSent);
      return Math.floor(( Date.UTC(dateSent.getFullYear(), dateSent.getMonth(), dateSent.getDate()) - Date.UTC(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate()) ) /(1000 * 60 * 60 * 24));
  
    }
    return 0
    }
    getAllShop() {
      const obj = {
        loginUserId: localStorage.getItem("userId"),
      };
      if (localStorage.getItem("fkShopId")) {
         Object.assign(obj, { strShopId: localStorage.getItem("fkShopId") });
      // Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

        // obj.fkShopId=localStorage.getItem('fkShopId')
      }
      this.companyService.fngetallCompany(obj).subscribe((res) => {
        this.arrShops = res.data;
      });
    }
  
}

// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-agency-module',
//   templateUrl: './agency-module.component.html',
//   styleUrls: ['./agency-module.component.scss']
// })
// export class AgencyModuleComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }

import { Component, OnInit } from "@angular/core";

import { PagerService } from "src/app/shared/services/pager.service";
import { FormGroup, FormBuilder } from "@angular/forms";
import { ReportsService } from "src/app/shared/services/Reports/reports.service";
import { modItemSales } from "src/app/shared/Classes/report.model";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";
import { DatePipe } from "@angular/common";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import Swal from "sweetalert2";
import { BannersService } from "src/app/shared/services/Banner/banners.service";

@Component({
  selector: "app-agency-module",
  templateUrl: "./agency-module.component.html",
  styleUrls: ["./agency-module.component.scss"],
})
export class AgencyModuleComponent implements OnInit {
  //  myform: FormGroup;

  currentDate = new Date();
  frmItemSales: FormGroup;
  pager: any = {};
  intTotalCount = 0;
  intPageLimit = 10;
  pageLimit: any[];
  // strShopId = "";
  arrStores = [];
  intSkipCount = 0;
  datePipe = new DatePipe("en-US");
  arrItemSales: modItemSales[] = [];
  fromDate;
  toDate;
  blnLoader = false;
  singledata: any;
  device: any;
  strShopId: string;
  blnDownloadLoader = false;
  userType: string;
  arrShops: [];
  withdrawAmount: "";
  status: "";
  submitted = false;
  strShopName: [""];
  fkAgentId: "";
  strAgentId: "";
  // pkShopId:any
  pkShopId: string;
  // strAgentId: any;
  // strShopId: string;
  // strAgentId: string;

  constructor(
    private pageServiceObj: PagerService,
    private reportServiceObj: ReportsService,
    private companyService: CompanyServiceService,
    private modalService: NgbModal,
    private formBuilder: FormBuilder,
    private BannerService: BannersService
  ) {}

  ngOnInit() {
    // this.pkShopId = 'someShopIdValue';
    this.frmItemSales = this.formBuilder.group({
      txtFromDate: [""],
      txtToDate: [""],
      txtOrderId: [""],
      cmbShopName: "",
      drpPageLimit: "10",
      strAgentId: "",
      // fkAgentId: ['someAgentIdValue'], // Replace with actual logic to set this value

      // fkAgentId:[""],
      // strShopName: ["",],
      // strAgentId: "",

      // strShopId : [""],
      // pkShopId:""
      // Set this value correctly

      // fkAgentId: ['id'], // Initialize form control

      // strAgentId:[""]
      // shopId:[""]
      // this.strAgentId = '669f0005b248d193565a0bb1';
      // pkShopId:"",
      // shopId:"",
      // status: "",
      // strShopName: [""]
    });
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getShopListingFn();
    this.getAnalyticsReport();
  }

  get formControls() {
    return this.frmItemSales.controls;
  }

  _clearForm(form: FormGroup) {
    form.reset({
      txtFromDate: "",
      txtToDate: "",
      // txtOrderId: "",
      cmbShopName: "",
      drpPageLimit: "10",
      status: "",
      googleAnalyticsId: "",
    });

    this.getAnalyticsReport();
  }

  // openModal(responsiveData,item){
  //  this.modalService.open(responsiveData)
  //  this.strShopId = item.strShopId;
  // }
  modalExtendList(modalExtend, item) {
    console.log(item, "hfhdfhdhhd");
    // this.singledata = item
    // item.pkShopId
    // item.fkAgentId

    // this.strAgentId=item.fkAgentId
    this.modalService.open(modalExtend, {
      centered: true,
      windowClass: "modal-product-delete",
    });
    this.openModal1(item);
  }

  // modalExtendList(modalExtend, item)
  //  { console.log(item, "hfhdfhdhhd");
  //   const modalRef = this.modalService.open(modalExtend, { centered: true, windowClass: 'modal-product-delete', });
  //    modalRef.componentInstance.pkShopId = item.pkShopId;
  //   modalRef.componentInstance.fkAgentId = item.fkAgentId; }

  openModal1(item) {
    console.log(item, "itemModal1");
    // if (!strShopId || !strAgentId) {
    //   console.error("strShopId or strAgentId is missing");
    //   Swal.fire({
    //     title: "Error",
    //     text: "Shop ID or Agent ID is missing",
    //     icon: "error",
    //     confirmButtonText: "Ok",
    //   });
    //   return; // Exit the function if either is missing
    // }
    // item:any
    const obj = {
      strLoginUserId: localStorage.getItem("userId"),

      strAgentId: item.fkAgentId,
      strShopId: item.pkShopId,
    };
    console.log(obj);

    // this.spinner.show();

    this.BannerService.verifytatus(obj).subscribe(
      (res) => {
        if (res.success && res) {
          this.modalService.dismissAll();
          // this.spinner.hide();
          Swal.fire({
            title: "yes!",
            text: "Verified successfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then(() => {
            this.getAnalyticsReport();
            this.ngOnInit();
          });
        } else {
          // this.spinner.hide();
          this.arrItemSales = [];

          // Swal.fire({
          //   // title: "Error",
          //   // text: res.message,
          //   // icon: "error",
          //   // confirmButtonText: "Ok",
          // });
        }
        this.getAnalyticsReport();
      },
      (err) => {
        console.log(err);
      }
    );
  }
  _getPageLimit(value$) {
    this.intPageLimit = parseInt(this.frmItemSales.value.drpPageLimit);
    this.setPage(1);
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getAnalyticsReport();
  }

  getShopListingFn() {
    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
    };
    if (localStorage.getItem("fkShopId")) {
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });
    }
    this.companyService.fngetallShop(obj).subscribe((res) => {
      this.arrStores = res.data;
      this.strShopId = res.data[0].pkShopId;
    });
  }

  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;

    this.getAnalyticsReport();
  }

  _getShopId(id$) {
    this.strShopId = id$;
  }

  openStoreUrl(storeUrl: string | undefined) {
    if (storeUrl) {
      window.open(storeUrl, "_blank");
    }
  }
  getAnalyticsReport() {
    let skipCount = this.intSkipCount;
    this.blnLoader = false;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }

    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
    if (
      this.frmItemSales.value.txtFromDate === "txtFromDate" &&
      this.frmItemSales.value.txtToDate === "txtToDate"
    ) {
      console.log("From Date ::::", this.frmItemSales.value.txtFromDate);
      this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
      this.toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    }
    if (
      this.frmItemSales.value.txtFromDate &&
      this.frmItemSales.value.txtToDate === "txtToDate"
    ) {
      console.log("To Date ::::", this.frmItemSales.value.txtToDate);
      this.fromDate = `${this.frmItemSales.value.txtFromDate.year}-${this.frmItemSales.value.txtFromDate.month}-${this.frmItemSales.value.txtFromDate.day}`;
      this.toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    }
    if (
      this.frmItemSales.value.txtToDate &&
      this.frmItemSales.value.txtFromDate === "txtFromDate"
    ) {
      console.log("To Date ::::", this.frmItemSales.value.txtToDate);
      this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
      this.toDate = `${this.frmItemSales.value.txtToDate.year}-${this.frmItemSales.value.txtToDate.month}-${this.frmItemSales.value.txtToDate.day}`;
    }

    if (
      this.frmItemSales.value.txtFromDate &&
      this.frmItemSales.value.txtToDate
    ) {
      this.fromDate = `${this.frmItemSales.value.txtFromDate.year}-${this.frmItemSales.value.txtFromDate.month}-${this.frmItemSales.value.txtFromDate.day}`;
      this.toDate = `${this.frmItemSales.value.txtToDate.year}-${this.frmItemSales.value.txtToDate.month}-${this.frmItemSales.value.txtToDate.day}`;
    }

    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
      strSkipCount: skipCount,
      intPageLimit: this.intPageLimit,

      //  status:this.frmItemSales.value.status
    };

    this.companyService.Listagencymodule(obj).subscribe((res) => {
      if (res && res.success) {
        this.blnLoader = true;
        this.arrItemSales = res.data;
        this.intTotalCount = res.count;
        this.arrItemSales = res.data;
        // if (res.data[0]) {
        //   this.intTotalCount = res.data.intTotalCount;
        // }
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
      } else {
        this.arrItemSales = [];
      }
    });
  }
}

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CompanyServiceService } from 'src/app/shared/services/company/company-service.service';
import { PagerService } from 'src/app/shared/services/pager.service';
import { StoreServiceService } from 'src/app/shared/services/store/store-service.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-store-user',
  templateUrl: './store-user.component.html',
  styleUrls: ['./store-user.component.scss'],
  
})
export class StoreUserComponent implements OnInit {
  intSkipCount = 0;
  blnLoader = false;
  intTotalCount = 0;
  intPageLimit = 10;
  pageLimit: any[];
  pager: any = {};
  stores = [];
  blnAdmin = false;
  userType: any;
  strShopId = "";
  strFranchiseId = "";
  frmFilterStore:FormGroup;
  arrCompany:any[] = []
  storeId:""

  constructor(
    private pageServiceObj: PagerService,
    private router: Router,
    private storeService:StoreServiceService,
    private formbuilder:FormBuilder,
    private companyService:CompanyServiceService,
    private modalService: NgbModal,


    
  ) { }

  ngOnInit() {
    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist;

    this.frmFilterStore = this.formbuilder.group({
      cmbShopName:["",],
      email:[""],
      name:[""]
    })
    this.getAllCompany()
    this.getAllStores()
  }

  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getAllStores();
  }

  getAllStores() {
    let skipCount = this.intSkipCount;
    // this.blnLoader = false;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
    const obj = {
      strSkipCount: skipCount,
      strPageLimit: this.intPageLimit,
      strShopName: this.frmFilterStore.value.cmbShopName,
      strEmail:this.frmFilterStore.value.email,
      strUserName:this.frmFilterStore.value.name
    };
    if(localStorage.getItem('fkShopId')){
      Object.assign(obj,{strStoreId: localStorage.getItem('fkShopId')})
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.storeService.getAllStoresUsers(obj).subscribe((res) => {
      if (res.success) {
        // this.spinner.hide();
        this.stores = res.data;
        this.blnLoader = true;
        this.intTotalCount =  res.count;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
      }
    });
  }
  
  getAllCompany(){
    const obj = {
      loginUserId:localStorage.getItem("userId"),
    }
    if(localStorage.getItem('fkShopId')){
      Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
      if(res && res.success){
        this.arrCompany = res.data
      }
    },(err) => {
      console.log(err)
    })
  }

  delete(){
    const obj = {
      strUpdateUserId:localStorage.getItem("userId"),
      pkUserId:this.storeId

    }

    this.storeService.deleteStoreUser(obj).subscribe((res) => {
      if(res && res.success){
        this.modalService.dismissAll();
        Swal.fire({
          title: "Deleted!",
          text:"Store User Deleted Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then(() => {
          this.getAllStores()
          this.ngOnInit()
        })
      }else{
        Swal.fire({
          title: "Error",
          text: res.message,
          icon: "error",
          confirmButtonText: "Ok",
        });
      }
    })
  }

  edit(item) {
    this.router.navigate(["/add-store-user"], {
      queryParams: { id: item.pkUserId },
    });
  }

  _onSearch(){

    this.pager = {};
    this.intTotalCount = 0;
    this.getAllStores()
    
  }


  _clearForm(){
    this.frmFilterStore.reset()
    this.ngOnInit()
  }

  getDelete(responsiveDelete, storeId) {
    this.modalService.open(responsiveDelete);
    this.storeId = storeId;
  }



}

import { environment } from "./../../../../environments/environment.prod";
import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder } from "@angular/forms";
import { DatePipe } from "@angular/common";
import { PagerService } from "src/app/shared/services/pager.service";
import { ReportsService } from "src/app/shared/services/Reports/reports.service";
import { modNewReport } from "src/app/shared/Classes/report.model";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";

@Component({
  selector: "app-new-report",
  templateUrl: "./new-report.component.html",
  styleUrls: ["./new-report.component.scss"],
})
export class NewReportComponent implements OnInit {
  currentDate = new Date();
  frmNewReport: FormGroup;
  pager: any = {};
  intTotalCount = 0;
  intPageLimit = 10;
  datePipe = new DatePipe("en-US");
  pageLimit: any[];
  strShopId = "";
  arrStores = [];
  intSkipCount = 0;
  arrNewReport: modNewReport[] = [];
  fromDate;
  toDate;
  blnLoader = false;
  blnDownloadLoader = false;

  private apiURL: string = environment.API_ENDPOINT;

  constructor(
    private pageServiceObj: PagerService,
    private formBuilder: FormBuilder,
    private companyService:CompanyServiceService,
    private reportServiceObj: ReportsService
  ) {}

  ngOnInit() {
    this.frmNewReport = this.formBuilder.group({
      txtFromDate: [""],
      txtToDate: [""],
      cmbShopName: "",
      drpPageLimit: "10",
    });
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getShopListingFn();
    this.getNewReportFn();
  }

  _clearForm(form: FormGroup) {
    form.reset({
      txtFromDate   : "",
      txtToDate     : "",
      cmbShopName   : "",
      drpPageLimit  : "10",
    });
    this.intTotalCount = 0;
    this.intSkipCount = 0;
    this.intPageLimit = 10;
    this.getNewReportFn();
  }
  _getPageLimit(value$) {
    this.intPageLimit = parseInt(this.frmNewReport.value.drpPageLimit);
    this.setPage(1);
  }
  _getShopId(id$) {
    this.strShopId = id$;
  }
  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getNewReportFn();
  }
  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.getNewReportFn();
  }

  getShopListingFn() {
    const obj = {
      loginUserId:localStorage.getItem("userId"),
    }
    if(localStorage.getItem('fkShopId')){
      // Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
      this.arrStores = res.data;
      this.strShopId = res.data[0].pkShopId;
    });
  }

  getNewReportFn() {
    let skipCount = this.intSkipCount;
    this.blnLoader = false;

    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
    if (
      this.frmNewReport.value.txtFromDate === "" &&
      this.frmNewReport.value.txtToDate === ""
    ) {
      console.log("From Date ::::", this.frmNewReport.value.txtFromDate);
      this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
      this.toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    }
    if (
      this.frmNewReport.value.txtFromDate &&
      this.frmNewReport.value.txtToDate === ""
    ) {
      console.log("To Date ::::", this.frmNewReport.value.txtToDate);
      this.fromDate = `${this.frmNewReport.value.txtFromDate.year}-${this.frmNewReport.value.txtFromDate.month}-${this.frmNewReport.value.txtFromDate.day}`;
      this.toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    }
    if (
      this.frmNewReport.value.txtToDate &&
      this.frmNewReport.value.txtFromDate === ""
    ) {
      console.log("To Date ::::", this.frmNewReport.value.txtToDate);
      this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
      this.toDate = `${this.frmNewReport.value.txtToDate.year}-${this.frmNewReport.value.txtToDate.month}-${this.frmNewReport.value.txtToDate.day}`;
    }

    if (
      this.frmNewReport.value.txtFromDate &&
      this.frmNewReport.value.txtToDate
    ) {
      this.fromDate = `${this.frmNewReport.value.txtFromDate.year}-${this.frmNewReport.value.txtFromDate.month}-${this.frmNewReport.value.txtFromDate.day}`;
      this.toDate = `${this.frmNewReport.value.txtToDate.year}-${this.frmNewReport.value.txtToDate.month}-${this.frmNewReport.value.txtToDate.day}`;
    }
    const obj = {
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
      strStoreId: this.frmNewReport.value.cmbShopName, // this.strShopId
      strFromDate: this.fromDate, // fromTime
      strToDdate: this.toDate, // toTime
    };
    if(localStorage.getItem('fkShopId')){
      Object.assign(obj,{strStoreId: localStorage.getItem('fkShopId')})
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    console.log("OBJECT BEFROE::::::::", obj);

    this.reportServiceObj.getNewOrderReportService(obj).subscribe((res) => {
      this.blnLoader = true;

      this.arrNewReport = res.data[1];
      if (res.data[0]) {
        this.intTotalCount = res.data[0].intTotalCount;
      }
      this.pager = this.pageServiceObj.getPager(
        this.intTotalCount,
        this.pager.currentPage,
        this.intPageLimit
      );
      console.log("NEW REPORT order Response::::::", res);
    });
  }

  getDownloadExcel() {
    this.blnDownloadLoader = !this.blnDownloadLoader;
    const obj = {
      strStoreId: this.frmNewReport.value.cmbShopName, // this.strShopId
      strFromDate: this.fromDate, // fromTime
      strToDdate: this.toDate, // toTime
      strDataType: "EXCEL",
    };
    console.log("New Order Obj:::::", obj);

    this.reportServiceObj.getNewOrderReportExcelService(obj).subscribe((res) => {
        this.blnDownloadLoader = !this.blnDownloadLoader;
        console.log("RESPONSE EXCEL", res);
        const strPath = this.apiURL + "/" + res.data;
        window.location.href = strPath;
      });
  }
}

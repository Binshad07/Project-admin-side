import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RenewShopComponent } from './renew-shop.component';

describe('RenewShopComponent', () => {
  let component: RenewShopComponent;
  let fixture: ComponentFixture<RenewShopComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RenewShopComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RenewShopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import Swal from "sweetalert2";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";
import { unitResponse } from "../../../shared/Classes/unitResponse";
import { ProductService } from "../../../shared/services/product.service";
import { ActivatedRoute } from '@angular/router';
import { OrderService } from 'src/app/shared/services/order.service';
import { ReportsService } from 'src/app/shared/services/Reports/reports.service';

@Component({
  selector: 'app-renew-shop',
  templateUrl: './renew-shop.component.html',
  styleUrls: ['./renew-shop.component.scss']
})
export class RenewShopComponent implements OnInit {

  myform: FormGroup;
  submitted: boolean = false;
  arrShops: [];
  blnLoader = false;
  fkShopId: any;
  arrPlantList: [];
  arrSubscriptionReportList: [];
  arrListReport:[];
  strShopId: any;
  clicked = false;
  planAmount:number;




  constructor(
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private orderService: OrderService,
    private myProductService: ProductService,
    private reportService: ReportsService,
    private modalService: NgbModal,
    private companyService: CompanyServiceService,
   

  ) { }

  ngOnInit() {
    this.route.queryParams.subscribe((parmas) => {
      this.fkShopId = parmas.id ? parmas.id : ''
    })

    this.myform = this.formBuilder.group({
      fkShopId: ["",],
      strPlanId: ["",],
    })

    this.getAllShop();

    this.ListPlantList();

    // this.ListSubscriptionReportList();

  }




  pkShopId:any;


  ListSubscriptionReportList(id:any) {
    const obj = {
      // fkShopId: "65a77c33cef28530c31b00c5",

      fkShopId: id,
      // fkShopId: "this",
      strLoginUserId: localStorage.getItem("userId"),
    };
    // console.log(this.pkShopId,"rfgh")
    if (localStorage.getItem("fkShopId")) {
      Object.assign(obj, { fkShopId: localStorage.getItem("fkShopId") });
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }

    
      console.log(obj, "obj::::::::::::");
    this.companyService.ListSubscriptionReport(obj).subscribe(
      (res) => {
        if (res.success) {
          console.log(res, "response:::::::::::::::::::11");
          this.arrSubscriptionReportList = res.data;
          // this.intTotalCount = res.count;
          // this.pager = this.pageServiceObj.getPager(
          //   this.intTotalCount,
          //   this.pager.currentPage,
          //   this.intPageLimit
          // );
        }
      },
      (err) => {
        Swal.fire({
          title: "Error",
          text: "Something went wrong! Please try again",
          icon: "error",
          confirmButtonText: "Ok",
        });
        console.log(err);
      }
    );
  }



  
  

  getAllShop() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
    }
    console.log(obj, "tesghjchbv")
    if (localStorage.getItem('fkShopId')) {
      Object.assign(obj, { pkShopId: localStorage.getItem('fkShopId') })
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {

      this.arrShops = res.data
    })
  }

  onFileChange(event: any,) {
    const selectedShopId = event.target.value;
    console.log('Selected Shop ID:', selectedShopId);
    // Assuming pkShopId is an attribute of the component, you can use it here.
    this.ListSubscriptionReportList(selectedShopId);
  }
  

  ListPlantList() {
    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
    }
    // console.log(,"fdgcihdsih4444444444444")
    this.companyService.ListPlanDetails(obj).subscribe(
      (res) => {

        
        if (res.success) {
          console.log(res,"fdgcihdsih444444444444455")
          
          this.arrPlantList = res.data;
          // console.log(res,"fdgcihdsih4444444444444")
        }

      },
      (err) => {
        this.arrPlantList = [];
        console.log(err);
      }
    );
  }

  get f() {
    return this.myform.controls;
  }


  //  activatePlan(): void {
  //   this.planService.activatePlan().subscribe(
  //    (success) => {
  //      if (success) {
  //         this.successMessage = 'Plan activated successfully!';
  //      } else {
  //          this.successMessage = 'Failed to activate the plan.';
  //      }
  //     },
  //     (error) => {
  //        console.error('Error activating plan:', error);
  //        this.successMessage = 'An error occurred while activating the plan.';
  //    }
  //    );
  //  }


  activatePlan() {

    const obj = {
      loginUserId: localStorage.getItem('userId'),
      storeId: this.myform.value.fkShopId,
      subscriptionPlanId: this.myform.value.strPlanId,
      isActive:true
      //  strUnitId: this.id,
    }

    console.log(obj)

    this.clicked = true;
    this.reportService.storeSubscription(obj).subscribe((res) => {
      console.log(res)
      if (res && res.success) {
        
        Swal.fire({
          title: "Saved!",
          text: "Payment Actived  Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then(() => {
          this.myform.reset()
          // this.router.navigate(['/productunit'])
          this.submitted = false;
        })
      } else {
        
        Swal.fire({
          title: "Warning",
          text: res.message,
          icon: "warning",
          confirmButtonText: "Ok",
        });
      }
    }, (err) => {
      console.log(err)
    })


  }

  






}



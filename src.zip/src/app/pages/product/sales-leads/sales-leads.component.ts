// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-sales-leads',
//   templateUrl: './sales-leads.component.html',
//   styleUrls: ['./sales-leads.component.scss']
// })
// export class SalesLeadsComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }

import { Component, OnInit } from '@angular/core';
import { PagerService } from "src/app/shared/services/pager.service";
import { FormGroup, FormBuilder } from "@angular/forms";
import { ReportsService } from "src/app/shared/services/Reports/reports.service";
import { modItemSales } from "src/app/shared/Classes/report.model";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";
import { DatePipe } from "@angular/common";

@Component({
  selector: 'app-sales-leads',
  templateUrl: './sales-leads.component.html',
  styleUrls: ['./sales-leads.component.scss']
})
export class SalesLeadsComponent implements OnInit {

  currentDate = new Date();
  frmItemSales: FormGroup;
  pager: any = {};
  intTotalCount = 0;
  intPageLimit = 10;
  pageLimit: any[];
  strShopId = "";
  arrStores = [];
  skip = 0;
  datePipe = new DatePipe("en-US");
  arrItemSales: modItemSales[] = [];
  fromDate;
  toDate;
  blnLoader = false;
  blnDownloadLoader = false;
  userType: string;
  salesman:any;
  arrSales: any;
  salesAdminName:""

  constructor( private pageServiceObj: PagerService,
    private reportServiceObj: ReportsService,
    private companyService:CompanyServiceService,
    private formBuilder: FormBuilder
  ) {}





  

  ngOnInit() {

    this.frmItemSales = this.formBuilder.group({
      txtFromDate: [""],
      txtToDate: [""],
      txtOrderId: [""],
      salesman: [''] ,
      drpPageLimit: "10",
    });
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.Salesleads();
    this.Listleads();
  }



  _clearForm(form: FormGroup) {
    form.reset({
      txtFromDate: "",
      txtToDate: "",
      txtOrderId: "",
      salesman: "",
      drpPageLimit: "10",
    });
    this.intTotalCount = 0;
    this.skip = 0;
    this.intPageLimit = 10;
    this.Salesleads(); 
  }

  _getPageLimit(value$) {
    this.intPageLimit = parseInt(this.frmItemSales.value.drpPageLimit);
    this.setPage(1);
  }



  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.Salesleads();
  }



  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.Salesleads()
    this.Salesleads();
  }

  Salesleads() {
  let skipCount = this.skip;
  this.blnLoader = false;
  if (this.pager.skip) {
    skipCount = this.pager.skip;
  }

  const obj = {
    userId: "65cf5154c191fcbac3cef9b7",
    // userId: localStorage.getItem('loginuserId'),
    // deviceType: this.formBannerImages.value.deviceType,
    skip: skipCount,
    limit: this.intPageLimit,
    createdAt: this.fromDate, //fromDate,
    updatedAt: this.toDate, 
    salesAdminName:this.frmItemSales.value.salesman
  }
  


  this.companyService.Salesleads(obj).subscribe((res) => {
    
    if (res && res.success) {
      
      this.blnLoader = true;
      this.arrItemSales = res.data;
      this.intTotalCount = res.count;
      this.pager = this.pageServiceObj.getPager(
        this.intTotalCount,
        this.pager.currentPage,
        this.intPageLimit
      );
    } else {
      this.arrItemSales = []
     
    }
  })
}



 get formControls() {
   return this.frmItemSales.controls;
}

//  get formControl() {
//    return this.myform.controls;
// }

Listleads() {
  const obj = {
    loginUserId: localStorage.getItem("userId"),
  };
  if (localStorage.getItem("pkUserId")) {
     Object.assign(obj, { strUserName: localStorage.getItem("pkUserId") });
  // Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

    // obj.fkShopId=localStorage.getItem('fkShopId')
  }
  this.companyService.Listleads(obj).subscribe((res) => {
    console.log (res,)
    this.arrSales = res.data;
  
  });
}

}

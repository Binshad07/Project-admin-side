import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { OrderServiceService } from 'src/app/shared/services/OrderService/order-service.service';
import { UserOrderTracking } from 'src/app/shared/Classes/orderDetails.model';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-customer-order-tracking',
  templateUrl: './customer-order-tracking.component.html',
  styleUrls: ['./customer-order-tracking.component.scss']
})
export class CustomerOrderTrackingComponent implements OnInit {

  arrOrderTracking: UserOrderTracking[] = [];
  frmOrderTracking: FormGroup;
  blnLoader = true;
  intLastIndex = 0;

  constructor(private orderServiceObj: OrderServiceService,
              private router: Router,
              private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.frmOrderTracking = this.formBuilder.group({
      txtOrderNo: ['']
    })
    this.getOrderTracking();
  }

  _clearForm(form: FormGroup) {
    form.reset({
      txtOrderNo: ['']
    })
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    this.router.onSameUrlNavigation = 'reload';
    this.router.navigate(['customer-order-tracking']);
  }
  getOrderTracking() {
    this.blnLoader = !this.blnLoader;
    const obj = {
      strOrderID: this.frmOrderTracking.value.txtOrderNo.toUpperCase(), //
      strLoginUserId: localStorage.getItem('userId') //'5ed484f33f06916c995874c1' //
    };
    this.orderServiceObj.getUserDetailsByOrderService(obj).subscribe((res) => {
      console.log('Customer Order tracking:::::::', res);

        this.blnLoader = !this.blnLoader;
        this.arrOrderTracking = res.data;
        if(this.arrOrderTracking.length) {
          this.intLastIndex = this.arrOrderTracking.length - 1;
        } else {
          this.intLastIndex = 0;
        }
        this.intLastIndex = this.arrOrderTracking.length - 1;

    });
  }
}

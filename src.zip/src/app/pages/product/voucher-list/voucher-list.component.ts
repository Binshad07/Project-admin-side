import { Component, OnInit } from "@angular/core";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { PagerService } from "src/app/shared/services/pager.service";
import { Router } from "@angular/router";
import Swal from "sweetalert2";
import { FormGroup, FormBuilder } from "@angular/forms";
import { HypermarketService } from "src/app/shared/services/Hypermarket/hypermarket.service";
import { DatePipe } from "@angular/common";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";

@Component({
  selector: "app-voucher-list",
  templateUrl: "./voucher-list.component.html",
  styleUrls: ["./voucher-list.component.scss"],
})
export class VoucherListComponent implements OnInit {
  intTotalCount = 0;
  intSkipCount = 0;
  pageLimit: any[];
  intPageLimit = 10;
  pager: any = {};
  arrVoucherList = [];
  showModal: boolean;
  voucherfilterFrm: FormGroup;
  currentDate = new Date();
  datePipe = new DatePipe("en-US");
  arrStores = [];
  keyword: string = "strShopName";
  selectedShopName: string;
  searchTimeout: any;
  strShopId = "";
  strShopName:string



  constructor(
    private pageServiceObj: PagerService,
    private router: Router,
    private formBuilder: FormBuilder,
    private hypermarketServiceObj: HypermarketService,
    private companyService: CompanyServiceService
  ) {}

  ngOnInit() {
    this.voucherfilterFrm = this.formBuilder.group({
      txtFromDate: [""],
      txtToDate: [""],
      strPromocode: [""],
      strPromocodeSatus: [""],
      strAmount: [""],


    });
    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getVoucherList();
  }

  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getVoucherList();
  }


  _getShopId(id$) {
    this.strShopId = id$;
  }

  onChangeSearch(event: any) {
    clearTimeout(this.searchTimeout);
    this.searchTimeout = setTimeout(() => {
      this.getShopListingFn(event);
    }, 300);
  }
  
  getShopListingFn(searchString: string) {
    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
      strShopName: searchString || "",
    };
    this.companyService.fnShopListFn(obj).subscribe(
      (res) => {
        if (res && res.data) {
          this.arrStores = res.data
            .filter((shop) => {
              const shopName =
                typeof shop.strShopName === "object" &&
                shop.strShopName !== null
                  ? shop.strShopName.strShopName
                  : shop.strShopName;
              return shopName
                .toLowerCase()
                .includes(searchString.toLowerCase());
            })
            .map((shop) => ({
              pkShopId: shop.pkShopId,
              strShopName:
                typeof shop.strShopName === "object" &&
                shop.strShopName !== null
                  ? shop.strShopName.strShopName
                  : shop.strShopName,
            }));
          if (this.arrStores.length > 0) {
            this.strShopId = this.arrStores[0].pkShopId;
            this.selectedShopName = this.arrStores[0].strShopName;
          }
        } else {
          this.arrStores = [];
        }
      },
      (error) => {
        console.error("Error fetching shop list", error);
        this.arrStores = [];
      }
    );
  }

  getVoucherList() {
    let skipCount = this.intSkipCount;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
 

    let fromDate: string | null = null;
    let toDate: string | null = null;
    
    if (
      this.voucherfilterFrm.value.txtFromDate === "" &&
      this.voucherfilterFrm.value.txtToDate === ""
    ) {
      console.log("Both dates are empty.");
      fromDate = "";  
      toDate = "";
    }
    if (
      this.voucherfilterFrm.value.txtFromDate &&
      this.voucherfilterFrm.value.txtToDate === ""
    ) {
      console.log("From Date set but To Date is empty.");
      fromDate = `${this.voucherfilterFrm.value.txtFromDate.year}-${this.voucherfilterFrm.value.txtFromDate.month}-${this.voucherfilterFrm.value.txtFromDate.day}`;
      toDate = "";
    }
    
    if (
      this.voucherfilterFrm.value.txtToDate &&
      this.voucherfilterFrm.value.txtFromDate === ""
    ) {
      console.log("To Date set but From Date is empty.");
      fromDate = "";  
      toDate = `${this.voucherfilterFrm.value.txtToDate.year}-${this.voucherfilterFrm.value.txtToDate.month}-${this.voucherfilterFrm.value.txtToDate.day}`;
    }
    if (
      this.voucherfilterFrm.value.txtFromDate &&
      this.voucherfilterFrm.value.txtToDate
    ) {
      fromDate = `${this.voucherfilterFrm.value.txtFromDate.year}-${this.voucherfilterFrm.value.txtFromDate.month}-${this.voucherfilterFrm.value.txtFromDate.day}`;
      toDate = `${this.voucherfilterFrm.value.txtToDate.year}-${this.voucherfilterFrm.value.txtToDate.month}-${this.voucherfilterFrm.value.txtToDate.day}`;
    }

    const obj = {
      FromDate: fromDate,
      ToDate: toDate,
      strPromoCode: this.voucherfilterFrm.value.strPromocode,
      strPromocodeStatus: this.voucherfilterFrm.value.strPromocodeSatus,
      intAmount: this.voucherfilterFrm.value.strAmount,
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
      fkShopId: this.strShopId,
    };

    console .log(obj, this.selectedShopName,"obj")
    this.hypermarketServiceObj.getListVoucher(obj).subscribe((res) => {
      console .log(res,"ressss")
      if (res && res.success) {
        this.arrVoucherList = res.data;
        this.intTotalCount = res.count;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
      } else {
        this.arrVoucherList = [];
        Swal.fire({
          title: "Error",
          text: res.message,
          icon: "error",
          confirmButtonText: "Ok",
        });
      }
    });
  }

  show() {
    this.showModal = true;
  }
  hide() {
    this.showModal = false;
  }

  edit(item) {
    console.log(item);
    this.router.navigate(["/product/voucher"], {
      queryParams: { id: item.pkStorePromocodeId },
    });
  }

  errorImage(event) {
    event.target.src = "assets/images/Group 4024 (1).png";
  }
  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.getVoucherList();
  }


  _clearForm() {
   ( this.strShopId = "" ,
    this.keyword = ""// Clear the keyword for the ng-autocomplete component
  )
    this.voucherfilterFrm.reset();
    this.ngOnInit();
  }

  

}

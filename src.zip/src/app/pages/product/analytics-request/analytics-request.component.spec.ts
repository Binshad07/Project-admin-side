import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnalyticsRequestComponent } from './analytics-request.component';

describe('AnalyticsRequestComponent', () => {
  let component: AnalyticsRequestComponent;
  let fixture: ComponentFixture<AnalyticsRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnalyticsRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnalyticsRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

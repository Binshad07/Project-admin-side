import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import Swal from "sweetalert2";
import { PagerService } from "./../../../shared/services/pager.service";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { BrandserviceService } from "src/app/shared/services/brand/brandservice.service";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";

export interface modType {
  strName?: any;
}

export interface modShop {
  fkShopId?: any;
}

@Component({
  selector: "app-list-brand",
  templateUrl: "./list-brand.component.html",
  styleUrls: ["./list-brand.component.scss"],
})
export class ListBrandComponent implements OnInit {
  myform: FormGroup;
  submitted: boolean = false;
  intSkipCount = 0;
  pager: any = {};
  intPageLimit = 10;
  pageLimit: any[];
  intTotalCount = 0;
  strTypelId = "";
  arrbrands: modType[] = [];
  arrShops: modShop[] = [];
  frmTypeEdit: FormGroup;
  editSubmitted: boolean = false;
  router: any;

  constructor(
    private pageServiceObj: PagerService,
    private formBuilder: FormBuilder,
    private brandService: BrandserviceService,
    // private spinner: NgxSpinnerService,
    // private spinnerObj: NgxSpinnerService,
    private modalService: NgbModal,
    private companyService: CompanyServiceService
  ) {}

  ngOnInit() {
    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.myform = this.formBuilder.group({
      brandName: ["", Validators.required],
      fkShopId: ["", Validators.required],
    });
    this.frmTypeEdit = this.formBuilder.group({
      brandName: ["", Validators.required],
      fkShopId: ["", Validators.required],
    });
    // this.pageLimit = this.pageServiceObj.showPagelist;
    this.ListBrand();
    this.getAllShop();
  }

  // _deleteType(responsiveDelete, TypeId$){

  //   this.modalService.open(responsiveDelete);
  //   this.strTypelId = TypeId$;
  // }

  _deleteType(responsiveDelete, item) {
    this.strTypelId = item.pkBrandId;
    this.modalService.open(responsiveDelete);
  }

  _getPageLimit(value$) {
    this.intPageLimit = parseInt(value$);
    this.setPage(1);
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.ListBrand();
    this.getAllShop();
  }

  get formControlsEdit() {
    return this.frmTypeEdit.controls;
  }

  // AddBrand() {

  //   const obj = {
  //     strName: this.myform.value.brandName,
  //     fkShopId: this.myform.value.fkShopId,
  //     loginUserId: localStorage.getItem('userId'),
  //   };

  //   // if(localStorage.getItem('fkShopId')){
  //   //   Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
  //   //   // obj.fkShopId=localStorage.getItem('fkShopId')
  //   // }

  //   console.log(obj,"test::::::::::")

  //   this.submitted = !this.submitted;
  //   if (this.myform.invalid) {
  //     // this.spinnerObj.hide();
  //     return;
  //   }

  //   this.brandService.addbrand(obj).subscribe((res) => {
  //       console.log(res);
  //       if (res && res.success) {
  //         // this.spinner.hide();
  //         Swal.fire({
  //           title: "Saved!",
  //           text: "Brand Saved Successfully",
  //           icon: "success",
  //           confirmButtonText: "Ok",
  //         }).then(() => {
  //           this.myform.reset();
  //           this.router.navigate(["/list-brand"]);
  //           this.submitted = false;
  //         });
  //       } else {
  //         // this.spinner.hide();
  //         Swal.fire({
  //           title: "Error",
  //           text: res.message,
  //           icon: "error",
  //           confirmButtonText: "Ok",
  //         });
  //       }
  //     },
  //     (err) => {
  //       console.log(err);
  //     }
  //   );

  //   }

  AddBrand() {
    this.submitted = true;
    if (this.myform.invalid) {
      return;
    }
    const obj = {
      strName: this.myform.value.brandName,
      fkShopId: this.myform.value.fkShopId,
      loginUserId: localStorage.getItem("userId"),
    };
    console.log(obj, "testttttt");
    this.brandService.addbrand(obj).subscribe(
      (res) => {
        console.log(res);
        if (res.success === true) {


        // if (res && res.success) {
          // this.clicked = false;
          // this.spinner.hide();
          Swal.fire({
            title: "Saved!",
            text: "Brand Saved Successfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then(() => {
            this.myform.reset();
            this.submitted = false;
            // this.router.navigate(["/list-brand"]);
            this.router.navigate(['/list-brand'])

          });
        } else {
          // this.spinner.hide();
          Swal.fire({
            title: "Warning",
            text: res.message,
            icon: "warning",
            confirmButtonText: "Ok",
          });
        }
      },
      (err) => {
        console.log(err);
      }
    );
  }

  _onClear() {
    this.submitted = false;
    this.myform.reset();
    this.ngOnInit();
  }

  //   this.brandService.addbrand(obj).subscribe((res) => {
  //     if (res.success === true) {
  //       // this.spinnerObj.hide();
  //       Swal.fire({
  //         title: "Saved!",
  //         text: "New Brand Saved Successfully",
  //         icon: "success",
  //         confirmButtonText: "Ok",
  //       }).then((result) => {
  //         if (result.value) {

  //           this.ListBrand();
  //           this.getAllShop();
  //         }
  //       });
  //     } else {
  //       Swal.fire({
  //         title: "Warning",
  //         text: "Brand With Same Name Exist",
  //         icon: "warning",
  //         confirmButtonText: "Ok",
  //       });
  //       // this.spinnerObj.hide();
  //     }
  //   });
  //   this.submitted = false;
  //   this.myform.reset();
  // }
  getAllShop() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
    };
    if (localStorage.getItem("fkShopId")) {
      // Object.assign(obj, { strShopId: localStorage.getItem("fkShopId") });
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
      this.arrShops = res.data;
    });
  }

  get f() {
    return this.myform.controls;
  }

  ListBrand() {
    let skipCount = this.intSkipCount;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }

    const obj = {
      skipCount: skipCount,
      pageLimit: this.intPageLimit,
    };

    if (localStorage.getItem("fkShopId")) {
      Object.assign(obj, { fkShopId: localStorage.getItem("fkShopId") });
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    // this.spinner.show()
    this.brandService.getAllbrands(obj).subscribe(
      (res) => {
        console.log(" repsonse::", res);
        if (res.success) {
          this.arrbrands = res.data;
          this.intTotalCount = res.count;
          this.pager = this.pageServiceObj.getPager(
            this.intTotalCount,
            this.pager.currentPage,
            this.intPageLimit
          );
        } else {
          // this.spinner.hide();
          this.arrbrands = [];
        }
      },
      (err) => {
        // this.spinner.hide();
        // Swal.fire({
        //   title: "Error",
        //   text: "Something went wrong! Please try again",
        //   icon: "error",
        //   confirmButtonText: "Ok",
        // });
        console.log(err);
      }
    );
  }

  deleteType(item) {
    // this.spinnerObj.show();
    const obj = {
      loginUserId: localStorage.getItem("userId"),
      strBrandId: this.strTypelId,
    };
    console.log(obj, "objjjjjjjj");

    this.brandService.deleteAllbrands(obj).subscribe((res) => {
      if (res.success === true) {
        Swal.fire({
          title: "Deleted!",
          text: "Brand has been deleted Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then((result) => {
          if (result.value) {
            // this.spinnerObj.hide();
            this.ngOnInit();
            this.modalService.dismissAll();
          }
        });
      } else {
        Swal.fire({
          title: "Error",
          text: res.message,
          icon: "error",
          confirmButtonText: "Ok",
        });
        // this.spinnerObj.hide();
      }
      this.ListBrand();
    });
  }

  _getEditType(responsiveData, objType) {
    this.strTypelId = objType.pkBrandId;
    this.modalService.open(responsiveData);
    this.frmTypeEdit.patchValue({ brandName: objType.strName });
    this.frmTypeEdit.patchValue({ fkShopId: objType.fkShopId });
  }

  getUpdateTypeFn() {
    this.editSubmitted = true;
    if (this.frmTypeEdit.invalid) {
      return;
    }
    // this.spinnerObj.show();
    const obj = {
      loginUserId: localStorage.getItem("userId"),
      strName: this.frmTypeEdit.value.brandName,
      fkShopId: this.frmTypeEdit.value.fkShopId,

      strBrandId: this.strTypelId,

      // fkShopId: localStorage.getItem('shopId'),
    };

    this.brandService.updatebrand(obj).subscribe((res) => {
      if (res.success === true) {
        // this.spinnerObj.hide();
        Swal.fire({
          title: "Updated!",
          text: " Brand has been Updated Sucessfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then((result) => {
          if (result.value) {
            this.modalService.dismissAll();
          }
        });
      } else {
        Swal.fire({
          title: "Warning",
          text: "Brand With Same Name Exist",
          icon: "warning",
          confirmButtonText: "Ok",
        }).then((result) => {
          if (result.value) {
            this.modalService.dismissAll();
          }
        });
        // this.spinnerObj.hide();
      }
      this.ListBrand();
      this.getAllShop();
    });
  }
}

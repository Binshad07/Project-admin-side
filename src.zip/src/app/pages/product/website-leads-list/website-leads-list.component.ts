import { Component, OnInit } from '@angular/core';
import { PagerService } from "src/app/shared/services/pager.service";
import { DatePipe } from "@angular/common";
import { ReportsService } from "src/app/shared/services/Reports/reports.service";
import { FormBuilder, FormGroup } from "@angular/forms";
import { modOrderSummary } from "src/app/shared/Classes/report.model";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";
import { HypermarketService } from './../../../shared/services/Hypermarket/hypermarket.service';
import { environment } from "./../../../../environments/environment.prod";

@Component({
  selector: 'app-website-leads-list',
  templateUrl: './website-leads-list.component.html',
  styleUrls: ['./website-leads-list.component.scss']
})
export class WebsiteLeadsListComponent implements OnInit {
  currentDate = new Date();
  frmLeads: FormGroup;
  pager: any = {};
  intTotalCount = 0;
  strPageLimit = 10;
  datePipe = new DatePipe("en-US");
  pageLimit: any[];
  strShopId = "";
  arrStores = [];
  skipCount = 0;
  arrLeads: [];
  fromDate;
  toDate;
  strSkipCount = 0;
  blnLoader = false;
  blnDownloadLoader = false;
  private apiURL: string = environment.API_ENDPOINT;
  userType: string;

  constructor(
    private pageServiceObj: PagerService,
    private formBuilder: FormBuilder,
    private companyService:CompanyServiceService,
    private reportServiceObj: ReportsService,
    private hypermarketServiceObj: HypermarketService,
  ) { }

  ngOnInit() {
    this.frmLeads = this.formBuilder.group({
      txtFromDate: [""],
      txtToDate: [""],
      strContactNumber: [""],
      strEmail :[],
      cmbShopName: "",
      drpPageLimit: "10",
    });
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getShopListingFn();
    this.getTicket();
    this.userType=localStorage.getItem("strUserType");
  }
  _clearForm(form: FormGroup) {
    form.reset({
      fromDate: "",
      toDate: "",
      cmbShopName: "",
      strContactNumber: "",
      strEmail :"",
      drpPageLimit: "10",
    });
    this.intTotalCount = 0;
    this.strSkipCount = 0;
    this.strPageLimit = 10;
    this.getTicket();
  }
  _getPageLimit(value) {
    this.strPageLimit = parseInt(this.frmLeads.value.drpPageLimit);
    this.setPage(1);
  }
  _getShopId(id$) {
    this.strShopId = id$;
  }
  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.strPageLimit
    );
    this.getTicket();
  }
  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.getTicket();
  }

  getShopListingFn() {
    const obj = {
      loginUserId:localStorage.getItem("userId"),
    }
    if(localStorage.getItem('fkShopId')){
      // Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
      this.arrStores = res.data;
      this.strShopId = res.data[0].pkShopId;
    });
  }
  getTicket() {
    let skipCount = this.strSkipCount;
    this.blnLoader = false;

    if (this.pager.strSkipCount) {
      skipCount = this.pager.strSkipCount;
    }
    if (
      this.frmLeads.value.txtFromDate === "txtFromDate" &&
      this.frmLeads.value.txtToDate === "txtToDate"
    ) {
      console.log("From Date ::::", this.frmLeads.value.txtFromDate);
      this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
      this.toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    }
    if (
      this.frmLeads.value.txtFromDate &&
      this.frmLeads.value.txtToDate === "txtToDate"
    ) {
      console.log("To Date ::::", this.frmLeads.value.txtToDate);
      this.fromDate = `${this.frmLeads.value.txtFromDate.year}-${this.frmLeads.value.txtFromDate.month}-${this.frmLeads.value.txtFromDate.day}`;
      this.toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    }
    if (
      this.frmLeads.value.txtToDate &&
      this.frmLeads.value.txtFromDate === "txtFromDate"
    ) {
      console.log("To Date ::::", this.frmLeads.value.txtToDate);
      this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
      this.toDate = `${this.frmLeads.value.txtToDate.year}-${this.frmLeads.value.txtToDate.month}-${this.frmLeads.value.txtToDate.day}`;
    }

    if (
      this.frmLeads.value.txtFromDate &&
      this.frmLeads.value.txtToDate
    ) {
      this.fromDate = `${this.frmLeads.value.txtFromDate.year}-${this.frmLeads.value.txtFromDate.month}-${this.frmLeads.value.txtFromDate.day}`;
      this.toDate = `${this.frmLeads.value.txtToDate.year}-${this.frmLeads.value.txtToDate.month}-${this.frmLeads.value.txtToDate.day}`;
    }

    const obj = {
      loginUserId:localStorage.getItem("userId"),
      skipCount: skipCount,
      pageLimit: this.strPageLimit,
      strShopName: this.frmLeads.value.cmbShopName, // this.strShopId
      fromDate: this.fromDate, // fromTime
      toDate: this.toDate, // toTime
      strPhone: this.frmLeads.value.strContactNumber,
      strEmail: this.frmLeads.value.strEmail
    };
    console.log("Object:::::", obj);

    this.hypermarketServiceObj.getLeadsCount(obj).subscribe((res) => {
      this.blnLoader = true;
      this.arrLeads = res.data;
      if (res.data) {
        this.intTotalCount = res.count;
      }
      this.pager = this.pageServiceObj.getPager(
        this.intTotalCount,
        this.pager.currentPage,
        this.strPageLimit
      );
    });
  }
}

import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { OrderServiceService } from 'src/app/shared/services/OrderService/order-service.service';
import { UserOrderDetails } from 'src/app/shared/Classes/orderDetails.model';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { PagerService } from 'src/app/shared/services/pager.service';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-customer-order-summary',
  templateUrl: './customer-order-summary.component.html',
  styleUrls: ['./customer-order-summary.component.scss']
})
export class CustomerOrderSummaryComponent implements OnInit {

  intIndex = 0;
  pager: any = {};
  pagerCart: any = {};
  blnLoader = true;
  private intSkipCount = 0;
  private intSkipCountCart = 0;
  private intPagelimit = 10;
  intTotalCountValue = 0;
  intTotalCount = 0;
  frmOrderDetail: FormGroup;
  intIndexForCart = 0;
  arrCartDetails = [];
  arrUserDetails = [];
  arrOrderDetails = [];
  strMobileNo = '';
  blnLoaderCart = false;
  blnLoaderOrder = false;



  constructor(private orderServiceObj: OrderServiceService,
              private modalService: NgbModal,
              private router: Router,
              private formBuilder: FormBuilder,
              private pagerService: PagerService, ) { }

  ngOnInit() {
    this.frmOrderDetail = this.formBuilder.group({
      txtMobileNo: ['']
    });
  }

  _clear(form: FormGroup) {
    form.reset({
      txtMobileNo: ['']
    })
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    this.router.onSameUrlNavigation = 'reload';
    this.router.navigate(['customer-order-summary']);
  }

  setPage(page: number) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    // get pager object from service
    this.pager = this.pagerService.getPager(this.intTotalCountValue, page, this.intPagelimit);
    this.getOrderDetailsFn();
  }
  setPageCart(page: number) {
    if (page < 1 || page > this.pagerCart.totalPages) {
      return;
    }
    // get pager object from service
    this.pagerCart = this.pagerService.getPager(this.intTotalCount, page, this.intPagelimit);
    this.getCartDetailsFn();
  }



  onSearchFn() {
    this.strMobileNo = this.frmOrderDetail.value.txtMobileNo;
    this.getCartDetailsFn();
    this.getOrderDetailsFn();
    this.getUserDetailsFn();


  }

  getUserDetailsFn() {
    this.blnLoader = !this.blnLoader;
    const obj = {
      strLoginUserId: localStorage.getItem('userId'),
      strPhoneNo: this.strMobileNo
    };
    this.orderServiceObj.getUserDetailsService(obj).subscribe((res) => {
      this.blnLoader = !this.blnLoader;
      // console.log('User Details Fn::::::::', res);

      this.arrUserDetails  = res.data;
    })
  }
  getCartDetailsFn() {
    this.blnLoaderCart = !this.blnLoaderCart;

    let skipCount = this.intSkipCountCart;
    if (this.pagerCart.intSkipCount) {
      skipCount = this.pagerCart.intSkipCount;
    }

    const obj = {
      strLoginUserId: localStorage.getItem('userId'),
      strPhoneNo: this.strMobileNo,
      strSkipCount: skipCount,
      strPageLimit: this.intPagelimit
    }
    // console.log('Object Cart:::::::', obj);

    this.orderServiceObj.getUserCartService(obj).subscribe((res) => {
      this.blnLoaderCart = !this.blnLoaderCart;
      // console.log('Cart Details Fn::::::::', res);
      this.arrCartDetails  = res.data[1];
      if(res.data[0]) {
        this.intTotalCount = res.data[0].intTotalCount;
        this.pagerCart = this.pagerService.getPager(this.intTotalCount, this.pagerCart.currentPage, this.intPagelimit);
      }
      // this
    })
  }

  getOrderDetailsFn() {
    this.blnLoaderOrder = !this.blnLoaderOrder;
    let skipCount = this.intSkipCount;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
    const obj = {
      strLoginUserId: localStorage.getItem('userId'),
      strPhoneNo: this.strMobileNo,
      strSkipCount: skipCount,
      strPageLimit: this.intPagelimit
    }
    this.orderServiceObj.getUserOrdersService(obj).subscribe((res) => {

      // console.log('Order Details Fn::::::::', res);
      if(res.success == true) {
        this.blnLoaderOrder = !this.blnLoaderOrder;
        this.arrOrderDetails  = res.data[1];
        if(res.data[0].intTotalCount) {
          this.intTotalCountValue = res.data[0].intTotalCount;
        }
        this.pager = this.pagerService.getPager(this.intTotalCountValue, this.pager.currentPage, this.intPagelimit);
      } else {
        this.blnLoaderOrder = !this.blnLoaderOrder;
        // alert(res.message)
      }
      // this
    })

  }

  largeModal(largeDataModal: string, index) {
    this.modalService.open(largeDataModal, { size: 'lg' });
    this.intIndex = index;
    // console.log('int index is here::::::', this.intIndex);


  }

}

import { Validators } from '@angular/forms';
import { Component, OnInit, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { OrderSummaryComponent } from '../order-summary/order-summary.component';
import { OrderServiceService } from 'src/app/shared/services/OrderService/order-service.service';
import { TimeSlotMod } from 'src/app/shared/Classes/orderDetails.model';
import { ReportsService } from 'src/app/shared/services/Reports/reports.service';
import { PagerService } from 'src/app/shared/services/pager.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";
@Component({
  selector: 'app-time-slot-management',
  templateUrl: './time-slot-management.component.html',
  styleUrls: ['./time-slot-management.component.scss'],
})
export class TimeSlotManagementComponent implements OnInit {
  blnAvailableTimeSLot = false;
  blnNewTimeSlot = true;
  blnSubmitted = false;
  blnSubmittedFilter = false;
  currentDate = new Date();
  frmTimeSlot: FormGroup;
  frmEdiTimeSlot: FormGroup;
  frmFilter: FormGroup;
  arrTimeSLot: TimeSlotMod[] = [];
  arrStores = [];
  strShopId = '';
  modalRef: BsModalRef;
  frmTimeSlotEdit: FormGroup;
  pager: any = {};
  intTotalCount = 0;
  intSkipCount = 0;
  intPageLimit = 10;
  strDate = '';
  strTimeSlotDate = '';
  strTimeSlotId = '';
  datePipe = new DatePipe('en-US');
  datePipeMod = new DatePipe('GMT');
  pageLimit: any[];
  arrOfExpress: TimeSlotMod[] = [];
  arrOfNormal: TimeSlotMod[] = [];

  constructor(
    private reportServiceObj: ReportsService,
    private pageServiceObj: PagerService,
    private modalService: NgbModal,
    private formBuilder: FormBuilder,
    private companyService:CompanyServiceService,
    private orderServiceObj: OrderServiceService
  ) {}

  ngOnInit() {
    this.frmFilter = this.formBuilder.group({
      cmbShopName: ['', Validators.required],
      txtDate: ['', Validators.required],
      cmbDeliveryType: ['NORMAL'],
    });

    this.frmTimeSlot = this.formBuilder.group({
      txtDisplayName: ['', Validators.required],
      txtDate: ['', Validators.required],
      txtFrom: ['', Validators.required],
      txtTo: ['', Validators.required],
      intCapacity: ['20'],
      cmbShopName: ['', Validators.required],
      cmbDeliveryType: ['NORMAL'],
      intDeliveryCharge: ['0'],
      intOrderCount: ['0'],
      blnStatus: true,
    });
    this.frmEdiTimeSlot = this.formBuilder.group({
      txtDisplayName: [''],
      txtDate: [''],
      txtFrom: [''],
      txtTo: [''],
      intCapacity: [''],
      cmbShopName: ['',],
      cmbDeliveryType: '',
      intDeliveryCharge: [''],
      intOrderCount: [''],
      blnStatus: [''],
    });
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getShopListingFn();
    this.frmTimeSlot.patchValue({
      txtDate: '2020-09-23'
    })
  }

  get formControls() {
    return this.frmTimeSlot.controls;
  }
  get filterFormControls() {
    return this.frmFilter.controls;
  }

  _clearFilterForm(form: FormGroup) {
    form.reset({
      cmbShopName: '',
      txtDate: '',
      cmbDeliveryType: ['NORMAL'],
    });
  }
  _clearTimeSlotForm(form: FormGroup) {
    form.reset({
      txtDisplayName: [''],
      txtDate: [''],
      txtFrom: [''],
      txtTo: [''],
      intCapacity: ['20'],
      cmbShopName: [''],
      cmbDeliveryType: 'NORMAL',
      intDeliveryCharge: ['0'],
      intOrderCount: ['0'],
    });
  }
  _toggle(value$) {
    if (value$ === 'available') {
      this.blnAvailableTimeSLot = false;
      this.blnNewTimeSlot = true;
    } else {
      this.blnAvailableTimeSLot = true;
      this.blnNewTimeSlot = false;
    }
  }
  _getShopId(id$) {
    this.strShopId = id$;
  }
  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getTimeSlotFn();
  }

  _getDeliveryTypeFn(id$) {}
  getShopListingFn() {
    const obj = {
      loginUserId:localStorage.getItem("userId"),
    }
    if(localStorage.getItem('fkShopId')){
      Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
        
        this.arrStores = res.data;

})
  }

  getSaveTimeSlotFn(objValue) {
    let strDate = `${this.frmTimeSlot.value.txtDate.year}-${this.frmTimeSlot.value.txtDate.month}-${this.frmTimeSlot.value.txtDate.day}`
    const obj = {
      strDisplayName: this.frmTimeSlot.value.txtDisplayName,
      strFromTime: this.frmTimeSlot.value.txtFrom,
      strToTime: this.frmTimeSlot.value.txtTo,
      strTimeSlotDate: strDate,
      strLoginUserId: localStorage.getItem('userId'), //localStorage.getItem('usertId'),
      strStoreId: this.frmTimeSlot.value.cmbShopName, //this.frmTimeSlot.value.cmbShopName, //localStorage.getItem('storeId'),
      intCapacity: this.frmTimeSlot.value.intCapacity,
      strDeliveryType: this.frmTimeSlot.value.cmbDeliveryType,
      intDeliveryCharge: this.frmTimeSlot.value.intDeliveryCharge,
      intOrdersCount: this.frmTimeSlot.value.intOrderCount,
      blnView: (this.frmTimeSlot.value.blnStatus).toString(),
    };
    // console.log('FORM VALUES OBJ :::::', obj);
    this.blnSubmitted = !this.blnSubmitted;
    this.orderServiceObj.getAddNewTimeSlotService(obj).subscribe((res) => {
      if (res.success === true) {
        alert(res.message);
        this._clearTimeSlotForm(this.frmTimeSlot);
      } else {
      }
    });
  }

  getTimeSlotFn() {
    let skipCount = this.intSkipCount;

    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }


    if (
      this.frmFilter.value.txtDate === '' ||
      this.frmFilter.value.txtDate === null
    ) {
      this.strDate = this.datePipe.transform(this.currentDate, 'yyyy-M-dd');
    } else {
      this.strDate = `${this.frmFilter.value.txtDate.year}-${this.frmFilter.value.txtDate.month}-${this.frmFilter.value.txtDate.day}`;
      // console.log('DATE:::::::::::', this.frmFilter.value.txtDate);
    }

    const obj = {
      intPagelimit: this.intPageLimit,
      intSkipCount: skipCount,
      strStoreId: this.frmFilter.value.cmbShopName, //this.strShopId,
      strDate: this.strDate,
      strDeliveryType: this.frmFilter.value.cmbDeliveryType,
      strLoginUserId: localStorage.getItem('userId'), //localStorage.getItem('userId')
    };
    // console.log('Object:::::::::', obj);
    this.blnSubmittedFilter = !this.blnSubmittedFilter;
    this.orderServiceObj.getTimeSlotDetailsService(obj).subscribe((res) => {
      console.log('Array Time slot ::::::::', res);

      this.arrTimeSLot = res.data;
      this.intTotalCount = 10;
      this.pager = this.pageServiceObj.getPager(
        this.intTotalCount,
        this.pager.currentPage,
        this.intPageLimit
      );
      // console.log('Array Time slot ::::::::', this.arrTimeSLot);
    });
  }

  EditTimeSlot(responsiveData, itemData) {
    console.log('Time Slot to Modify ::::::::', itemData);
    let timeSlotDate =  this.datePipe.transform(itemData.strTimeSlotDate,'yyyy-MM-dd')
    let getFromDate = this.datePipe.transform(itemData.strFromTime,
      'HH:mm',
      'GMT'
    );
    let geToDate = this.datePipe.transform(itemData.strToTime, 'HH:mm', 'GMT');
    this.strTimeSlotDate = itemData.strTimeSlotDate;
    this.strTimeSlotId = itemData.pkTimeSlotId;
    this.modalService.open(responsiveData);
    // this.frmEdiTimeSlot.controls.cmbDeliveryType.disable();
    this.frmEdiTimeSlot.patchValue({ txtDisplayName: itemData.strDisplayName });
    this.frmEdiTimeSlot.patchValue({ txtDate: timeSlotDate });
    this.frmEdiTimeSlot.patchValue({ txtFrom: getFromDate });
    this.frmEdiTimeSlot.patchValue({ txtTo: geToDate });
    this.frmEdiTimeSlot.patchValue({ intCapacity: itemData.intCapacity });
    this.frmEdiTimeSlot.patchValue({ cmbShopName: this.frmFilter.value.cmbShopName });
    this.frmEdiTimeSlot.patchValue({
      cmbDeliveryType: itemData.strDeliveryType,
    });
    this.frmEdiTimeSlot.patchValue({
      intDeliveryCharge: itemData.intDeliveryCharge,
    });
    this.frmEdiTimeSlot.patchValue({ intOrderCount: itemData.intOrdersCount });
    if (itemData.blnView === true || itemData.blnView === 'true') {
      this.frmEdiTimeSlot.patchValue({ blnStatus: true });
    } else {
      this.frmEdiTimeSlot.patchValue({ blnStatus: false });
    }
  }
  deleteTimeSlot() {}

  modifyTimeSlotFn() {
    let date = this.datePipe.transform(this.frmEdiTimeSlot.value.txtDate,'yyyy-M-d')

    const obj = {
      strDisplayName: this.frmEdiTimeSlot.value.txtDisplayName,
      strFromTime: this.frmEdiTimeSlot.value.txtFrom,
      strToTime: this.frmEdiTimeSlot.value.txtTo,
      strTimeSlotDate: date,//this.frmEdiTimeSlot.value.txtDate,
      strLoginUserId: localStorage.getItem('userId'), //localStorage.getItem('usertId'),
      strStoreId: this.frmEdiTimeSlot.value.cmbShopName, //this.frmFilter.value.cmbShopName, //localStorage.getItem('storeId'),
      intCapacity: this.frmEdiTimeSlot.value.intCapacity,
      strDeliveryType: this.frmEdiTimeSlot.value.cmbDeliveryType,
      intDeliveryCharge: this.frmEdiTimeSlot.value.intDeliveryCharge,
      intOrdersCount: this.frmEdiTimeSlot.value.intOrderCount,
      strTimeSlotId: this.strTimeSlotId,
      blnView: (this.frmEdiTimeSlot.value.blnStatus).toString(),
    };
    // console.log('Modify OBJECT::::', obj);
    console.log('Status::::', this.frmEdiTimeSlot.value.blnStatus);
    this.orderServiceObj.getEditTimeSlotService(obj).subscribe((res) => {
      // console.log('RESPONSE :::::::::', res);
      if (res.success === true) {
        this.modalService.dismissAll();
        this.setPage(this.pager.currentPage);
        alert('Time slot modified');
      } else {
        alert(res.message);

      }
    });
  }
}

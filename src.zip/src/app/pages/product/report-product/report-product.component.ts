import { Component, OnInit, TemplateRef } from "@angular/core";
import { BrandResponse } from "../../../shared/Classes/brandResponse";
import {
  FormGroup,
  FormControl,
  FormBuilder,
  Validators,
  FormArray,
} from "@angular/forms";
import { BsModalService, BsModalRef } from "ngx-bootstrap/modal";
import { Router } from "@angular/router";

import { ProductService } from "../../../shared/services/product.service";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";
import { PagerService } from "../../../shared/services/pager.service";
import { from } from "rxjs";
import { TestService } from "src/app/shared/services/Test/test.service";
//import { ToastrService } from 'ngx-toastr';
import { environment } from "../../../../environments/environment";
import { unitResponse } from "src/app/shared/Classes/unitResponse";
import Swal from "sweetalert2";
@Component({
  selector: "app-report-product",
  templateUrl: "./report-product.component.html",
  styleUrls: ["./report-product.component.scss"],
})
export class ReportProductComponent implements OnInit {
  private apiURL: string = environment.API_ENDPOINT;
  title = "hello-world";
  loading = false;
  modalRef: BsModalRef;
  frmProductReport: FormGroup;
  frmProductEdit: FormGroup;
  frmImageUpdate: FormGroup;
  breadCrumbItems: Array<{}>;
  strCategoryId: "";
  strShopId: "";
  pager: any = {};
  showPage: any[];
  intDeleteProductId: any;
  intimageProductId: any;
  objUpdateProductData: any;
  arrayAllProductData: any = [];
  arrayOfObjCategoryList = [];
  arrShops = [];
  arrayOfObjSubCategory = [];
  arrayOfObjBrandList = [];
  brandList: BrandResponse[] = [];
  intPageNumber = 1;
  private intSkipCount = 0;
  private intPagelimit = 25;
  intTotalCountValue = 0;
  GlobelIndex = "";
  blnStock = true;
  blnProductVisibility = true;
  submitted = false;
  testValue: Array<object>;
  blnLoader = false;
  unitList: unitResponse[] = [];
  imageFile: File[] = [];
  specialTagList = ["Must try", "Bestseller"];
  vegList = ["VEG", "NON-VEG", "NA"];
  showStock = true
  userType: string;
  arrcolorandimage: any[] = [];
  arrayColourVariation: any[] = [];
  arraySizeVariations: any[] = [];
  selectedProductId: string | null = null;
  selectedImage: string | null = null;
  arrayColourVariations: any;

  constructor(
    private formBuilder: FormBuilder,
    private myProductService: ProductService,
    private router: Router,
    private pagerService: PagerService,
    private companyService: CompanyServiceService,
    private modalService: BsModalService // private Messagetoastr   : ToastrService
  ) {}

  ngOnInit() {
    // this.selectedProductId = this.arrayAllProductData[0].intProductId; // Set to the first product ID as an example
    this.updateVariations();

    this.frmProductReport = this.formBuilder.group({
      txtProductName: [""],
      arabicName: [""],
      txtArticalNo: [""],
      txtBrand: [""],
      txtBarcode: [""],
      cmbCategory: [""],
      fkShopId: [""],
      cmbSubCategory: [""],
      intStockQuantity: [""],
      cmbSearchCountLimit: 25,
    });

    // this.frmProductEdit = this.formBuilder.group({
    //   txtProductName: ["", Validators.required],
    //   arabicName: ["", Validators.required],
    //   txtProperties: [""],
    //   txtDescription: [""],
    //   strFeature: [""],
    //   strManufacturerDetails: [""],
    //   strProductDisclaimer: [""],
    //   txtArticleNumber: [""],
    //   txtBarcode: [""],
    //   fkShopId: [""],
    //   cmbCategory: [""],
    //   cmbSubCategory: [""],
    //   txtQuantity: [1],
    //   txtMRP: ["", Validators.required],
    //   txtDiscount: [0],
    //   txtSellingPrice: ["", Validators.required],
    //   txtUnit: [""],
    //   rdbStockStatus: ["True", Validators.required],
    //   rdbProductVisibility: ["Active", Validators.required],
    //   txtSize: [""],
    //   txtDeliveryTime: [false],
    //   cbCard: [false],
    //   cbPayOnline: [false],
    //   cbCod: [false],
    //   cbFreeDelivery: [false],
    //   cbRefundable: [false],
    //   cbWarranty: [false],
    //   cbFrozenFood: [false],
    //   intStockQuantity: [""],
    //   isInfiniteStock: [""],
    //   txtMaxProdQty: [""],
    //   txtMinProdQty: [""],
    //   imgFile: [""],
    //   // objPriceVariations: this.formBuilder.array([]),
    //   // objColorVariations: this.formBuilder.array([]),
    //   blnPriceVariation: [false],
    //   strColorVariations: [],
    //   strSeizeVariation: [],
    //   brand: [""],
    //   strVeg: ["NA", Validators.required],
    //   specialTag: [""],
    //   // unit:["",]
    // });

    this.frmProductEdit = this.formBuilder.group({
      txtProductName: ["", Validators.required],
      arabicName: ["", Validators.required],
      txtProperties: [""],
      txtDescription: [""],
      txtArticleNumber: [""],
      strFeature: [""],
      isInfiniteStock: [""],
      strManufacturerDetails: [""],
      strProductDisclaimer: [""],
      txtBarcode: [""],
      cmbDepartment: [""],
      cmbCategory: [""],
      cmbSubCategory: [""],
      txtQuantity: [1],
      txtMRP: ["", Validators.required],
      txtDiscount: [0],
      txtSellingPrice: ["", Validators.required],
      txtUnit: [""],
      rdbStockStatus: ["True", Validators.required],
      rdbProductVisibility: ["Active", Validators.required],
      txtSize: [""],
      intStockQuantity: ["0", [Validators.required, Validators.pattern("[0-9]*")]],
      txtDeliveryTime: [false],
      cbCard: [false],
      cbPayOnline: [false],
      cbCod: [false],
      cbFreeDelivery: [false],
      cbRefundable: [false],
      cbWarranty: [false],
      cbFrozenFood: [false],
      txtMaxProdQty: [""],
      txtMinProdQty: [""],
      imgFile: [""],
      objPriceVariations: this.formBuilder.array([]),
      blnPriceVariation: [false],
      objSeizeVariations: this.formBuilder.array([]),
      objColorVariations: this.formBuilder.array([]),
      fkShopId: [""],
      brand: [""],
      strVeg: ["NA", Validators.required],
      specialTag: [""],
      unit: [""],
    });

    this.showPage = this.pagerService.showPagelist; // Limit Count get com...
    this.AutocompleteBrandListing();
    this.getAllShop();
    this.AutocompleteCategoryListing(this.strShopId);
    this.AutocompleteSubCategoriesListing(this.strCategoryId);
    this.getProductSearchData();

    this.unitListing();
    this.brandListing();

    this.frmProductEdit.controls.txtSellingPrice.valueChanges.subscribe(
      (value) => {
        this.updateDiscountPercentage();
      }
    );



    this.frmProductEdit.controls.isInfiniteStock.valueChanges.subscribe((value) => {
      if (value === 'true') {
        this.showStock = false;
        this.frmProductEdit.controls.intStockQuantity.setValue('0'); // Set to an empty string or any default value
      } else {
        this.showStock = true;
      }
    });


    this.frmProductEdit.controls.txtMRP.valueChanges.subscribe((value) => {
      this.updateDiscountPercentage();
    });
    this.userType = localStorage.getItem("strUserType");

    // this.createForm();

    this.createForm();
    console.log("Initial Form Value:", this.frmImageUpdate.value);
    console.log(
      "Initial Colors Array:",
      this.frmImageUpdate.get("colors").value
    );
    console.log(
      "Initial Images Array:",
      this.frmImageUpdate.get("images").value
    );
  }

  createForm() {
    this.frmImageUpdate = this.formBuilder.group({
      colors: this.formBuilder.array([], [Validators.required]),
      images: this.formBuilder.array([], [Validators.required]),
      // ... other controls
    });
  }

  selectedImageUrls: string[] = [];
  selectedColors: string[] = [];

  clearForm() {
    this.submitted = false;
    this.frmImageUpdate.reset();
  }


colorCodes = [];



  colorselect(event, i, color) {
    console.log(i,color.colourCode,"ttttttttttttttt")

    this.colorCodes.push({
      color:color.color, 
      colorCode:color.colourCode
    });
    console.log(this.colorCodes, "color code json");
    
    const colorsArray = this.frmImageUpdate.get("colors") as FormArray;
    const imagesArray = this.frmImageUpdate.get("images") as FormArray;
    const selectedColor = event.target.value;

    const existingColorIndex = colorsArray.value.findIndex(
      (colorData) =>
        colorData.color === selectedColor ||
        colorData.colourCode === selectedColor
    );

    const existingImageIndex = imagesArray.value.findIndex(
      (image) => image === selectedColor
    );

    if (existingColorIndex !== -1 || existingImageIndex !== -1) {
      console.log("Color already exists:", selectedColor);
    } else {
      colorsArray.push(this.formBuilder.control(selectedColor));
      console.log("Form Value after colorselect:", this.frmImageUpdate.value);
      console.log("Colors Array after colorselect:", colorsArray.value);
    }
  }

  selectedImages: string[] = [];

  selectedImagePreview: string; // Add this property to your component

  Imageselect(event, i: number) {
    const colorsArray = this.frmImageUpdate.get("colors") as FormArray;
    const imagesArray = this.frmImageUpdate.get("images") as FormArray;
    const selectedImage = event.target.value;

    // Replace the last clicked image link in the array
    imagesArray.setControl(i, this.formBuilder.control(selectedImage));
    this.selectedImages[i] = selectedImage;

    console.log("Form Value after Imageselect:", this.frmImageUpdate.value);
    console.log("Images Array after Imageselect:", imagesArray.value);
  }

  updateProductColorAndImage() {
    this.submitted = true;
    if (this.frmImageUpdate.invalid) {
      return;
    }
    const colors = this.frmImageUpdate.get("colors").value;
    const images = this.frmImageUpdate.get("images").value;

      if (colors.length > 0 && images.length > 0) {
        const arrayColourVariations = colors.map((color,index) => ({
          color,
          image: images[index] || null, // Assuming images array has the same length as colors
        }));
      const requestData = {
        arrayColourVariations,
        intProductId: this.intimageProductId.intProductId,
      };


      console.log(arrayColourVariations[0].color)

      for(let i=0; i<arrayColourVariations.length; i++){
        if(arrayColourVariations[i].color == this.colorCodes[i].color){
          arrayColourVariations[i].colourCode = this.colorCodes[i].colorCode
        }
      
      }



      console.log(arrayColourVariations, "final arary")

      this.myProductService
        .updateProductColorimage(requestData)
        .subscribe((res) => {
          if (res.success === true) {
            this.intimageProductId.arrayColourVariations = res.data;
            this.reloadComponent();
            console.log("Update success:", res.data);
          } else {
            console.error("Update failed:", res.error);
          }
          Swal.fire({
            title: "Successfully!",
            text: "Image and Color Updated Successfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then(() => {
            this.frmImageUpdate.reset();
            this.submitted = false;
            this.router.navigate(["/product/report-product"]);
          });
        });
    } else {
      console.log("Both colors and images are required.");
    }
  }

  // updateProductColorAndImage() {
  //   this.submitted = true;

  //   if (this.frmImageUpdate.invalid) {
  //     return;
  //   }

  //   const colors = this.frmImageUpdate.get("colors").value;
  //   const images = this.frmImageUpdate.get("images").value;

  //   if (colors.length > 0 && images.length > 0) {
  //     const arrayColourVariations = colors.map((color, index) => ({
  //       colourCode: color.colourCode,
  //       color: color.color,
  //       image: images[index] || "",
  //     }));

  //     const requestData = {
  //       arrayColourVariations,
  //       intProductId: this.intimageProductId.intProductId,
  //     };

  //       this.myProductService
  //         .updateProductColorimage(requestData)
  //         .subscribe((res) => {
  //           if (res.success === true) {
  //             this.intimageProductId.arrayColourVariations = res.data;
  //             this.reloadComponent();
  //             console.log("Update success:", res.data);
  //           } else {
  //             console.error("Update failed:", res.error);
  //           }

  //           Swal.fire({
  //             title: "Successfully!",
  //             text: "Image and Color Updated Successfully",
  //             icon: "success",
  //             confirmButtonText: "Ok",
  //           }).then(() => {
  //             this.frmImageUpdate.reset();
  //             this.submitted = false;
  //             this.router.navigate(["/product/report-product"]);
  //           });
  //         });
  //     } else {
  //     console.log("Both colors and images are required.");
  //   }
  // }

  reloadComponent() {
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    const currentUrl = this.router.url + "?";
    this.router.navigateByUrl(currentUrl).then(() => {
      this.router.navigated = false;
      this.router.navigate([this.router.url]);
    });
  }

  updateDiscountPercentage() {
    console.log("Discount value working");
    const txtSellingPrice = this.frmProductEdit.controls.txtSellingPrice.value; //SELLING PRICE
    const txtMRP = this.frmProductEdit.controls.txtMRP.value; //MRP
    if (txtSellingPrice && txtMRP) {
      const txtDiscount = ((txtSellingPrice - txtMRP) / txtSellingPrice) * 100;
      this.frmProductEdit.controls.txtDiscount.patchValue(
        txtDiscount.toFixed(0)
      );
    } else {
      this.frmProductEdit.controls.txtDiscount.patchValue(null);
    }
  }

  // color and image End

  get formControls() {
    return this.frmProductEdit.controls;
  }

  get formControlsImage() {
    return this.frmImageUpdate.controls;
  }

  get frmProductEditControls() {
    return this.frmProductEdit.controls;
  }

  getAllShop() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
    };
    if (localStorage.getItem("fkShopId")) {
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
      if (res.success === true) {
        this.arrShops = res.data;
      }
    });
  }

  AutocompleteCategoryListing(_id) {
    const obj = {
      strShopId: _id,
    };
    console.log(obj);
    this.myProductService.categoryListingService(obj).subscribe((res) => {
      if (res.success === true) {
        this.arrayOfObjCategoryList = res.data;
      }
      console.log(res);
    });
  }

  AutocompleteSubCategoriesListing(strCategoryId) {
    const obj = { strCategoryId: strCategoryId };
    this.myProductService.subcategoryListingService(obj).subscribe((res) => {
      if (res.success === true) {
        this.arrayOfObjSubCategory = res.data;
      }
    });
  }

  AutocompleteBrandListing() {
    this.myProductService.brandListingService().subscribe((res) => {
      if (res.success === true) {
        this.arrayOfObjBrandList = res.data;
      }
    });
  }

  onChangeShoptData(objValue) {
    if (objValue.fkShopId) {
      this.AutocompleteCategoryListing(objValue.fkShopId);
    }

    //
  }

  onChangeCategoryData(objValue) {
    if (objValue.cmbCategory) {
      this.AutocompleteSubCategoriesListing(objValue.cmbCategory);
    }

    //
  }

  /*
      TODO @Function: THIS FUNCATION USE Filter data from data base
      */
  onClearhButtonClick() {
    this.frmProductReport.patchValue({ txtProductName: "" });
    this.frmProductReport.patchValue({ arabicName: "" });
    this.frmProductReport.patchValue({ txtArticalNo: "" });
    this.frmProductReport.patchValue({ txtBrand: "" });
    this.frmProductReport.patchValue({ txtBarcode: "" });
    this.frmProductReport.patchValue({ cmbCategory: "" });
    this.frmProductReport.patchValue({ cmbSubCategory: "" });
    this.frmProductReport.patchValue({ fkShopId: "" });
    this.frmProductReport.patchValue({ cmbSearchCountLimit: 25 });
    this.intDeleteProductId = "";
    this.objUpdateProductData = {};
    this.intPageNumber = 1;
    this.intSkipCount = 0;
    this.intPagelimit = 10;
    this.intTotalCountValue = 0;
    this.loading = false;
  }

  get priceVariationsControl() {
    return (this.frmProductEdit.get("objPriceVariations") as FormArray)
      .controls;
  }

  get SeizeVariationsControl() {
    return (this.frmProductEdit.get("objSeizeVariations") as FormArray)
      .controls;
  }

  get colorVariationControl() {
    return (this.frmProductEdit.get("objColorVariations") as FormArray)
      .controls;
  }

  addNewVariation() {
    let control = <FormArray>this.frmProductEdit.controls.objPriceVariations;
    control.push(
      this.formBuilder.group({
        variation: ["", Validators.required],
        priceOption: ["", Validators.required],
      })
    );
  }

  deleteVariation(index) {
    let control = <FormArray>this.frmProductEdit.controls.objPriceVariations;
    control.removeAt(index);
  }

  addSeizeVariation() {
    let control = <FormArray>this.frmProductEdit.controls.objSeizeVariations;
    control.push(
      this.formBuilder.group({
        size: ["", Validators.required],
      })
    );
  }

  addColorVariation() {
    let control = <FormArray>this.frmProductEdit.controls.objColorVariations;
    control.push(
      this.formBuilder.group({
        color: ["", Validators.required],
        strColorCode: ["", Validators.required],
      })
    );

    console.log("Updated Form Value:", this.frmProductEdit.value);
  }

  setPriceDetails(objPriceDetails) {
    console.log(objPriceDetails);
    let control = <FormArray>this.frmProductEdit.controls.objPriceVariations;
    this.removeControl(control);
    objPriceDetails.forEach((x) => {
      console.log("text");
      control.push(
        this.formBuilder.group({
          variation: x.size,
          priceOption: x.price,
        })
      );
    });
  }

  setSeizeDetails(objSeizeVariation) {
    console.log(objSeizeVariation);
    let control = <FormArray>this.frmProductEdit.controls.objSeizeVariations;
    this.removeControl(control);
    objSeizeVariation.forEach((x) => {
      console.log("text");
      control.push(
        this.formBuilder.group({
          size: x.size,
        })
      );
    });
  }

  setColorDetails(objColorVariation) {
    console.log(objColorVariation);
    let control = <FormArray>this.frmProductEdit.controls.objColorVariations;
    this.removeControl(control);
    objColorVariation.forEach((x) => {
      console.log("text");
      control.push(
        this.formBuilder.group({
          strColorCode: x.colourCode,
          color: x.color,
        })
      );
    });
  }

  get seizeVariationControl() {
    return (this.frmProductEdit.get("objSeizeVariations") as FormArray)
      .controls;
  }

  deleteVariations(index) {
    let control = <FormArray>this.frmProductEdit.controls.objColorVariations;
    control.removeAt(index);
  }
  deleteVariationss(index) {
    let control = <FormArray>this.frmProductEdit.controls.objSeizeVariations;
    control.removeAt(index);
  }

  removeControl(control) {
    while (control.length !== 0) {
      control.removeAt(0);
    }
  }

  /*
      TODO @Function: THIS FUNCATION USE Filter data from data base
      */

  getProductSearchData() {
    this.blnLoader = false;
    // this.arrayColourVariation = [];
    // this.arraySizeVariations = [];

    try {
      var skip = this.intSkipCount;
      if (this.pager.intSkipCount) {
        skip = this.pager.intSkipCount;
      }
      const objData = {
        intSkipCount: skip,
        intPagelimit: this.intPagelimit,
        strProductName: this.frmProductReport.value.txtProductName,
        strArabicName: this.frmProductReport.value.arabicName,
        strArticalNo: this.frmProductReport.value.txtArticalNo,
        strBrand: this.frmProductReport.value.txtBrand,
        strBarcode: this.frmProductReport.value.txtBarcode,
        intCategoryId: this.frmProductReport.value.cmbCategory,
        intSubCategoryerId: this.frmProductReport.value.cmbSubCategory,
        fkShopId: this.frmProductReport.value.fkShopId,
      };
      if (localStorage.getItem("fkShopId")) {
        Object.assign(objData, { fkShopId: localStorage.getItem("fkShopId") });
        // obj.fkShopId=localStorage.getItem('fkShopId')
      }

      console.log("OBJECT DATA:::::::::::::::::", objData);

      this.myProductService.GetSearchProductData(objData).subscribe(
        (res) => {
          console.log(res, "rssproduct");
          this.intTotalCountValue = 0;
          if (res.success == true) {
            this.blnLoader = true;
            this.arrayAllProductData = res.data[0];
            console.log(
              "get datada::::::::::::::::::::::::",
              this.arrayAllProductData
            );
            if (res.data[1].totalCount) {
              this.intTotalCountValue = res.data[1].totalCount;
            }
            this.pager = this.pagerService.getPager(
              this.intTotalCountValue,
              this.pager.currentPage,
              this.intPagelimit
            );
          } else {
            this.arrayAllProductData = [];
            // alert("No data found");
          }
        },
        (error) => {
          console.log("error");
        }
      );
    } catch (e) {
      console.log(e);
    }
  }

  updateVariations() {
    this.arrayColourVariation = [];
    this.arraySizeVariations = [];

    const selectedProduct = this.arrayAllProductData.find(
      (product) => product.intProductId === this.selectedProductId
    );

    if (selectedProduct) {
      if (
        selectedProduct.arrayColourVariations &&
        selectedProduct.arrayColourVariations.length > 0
      ) {
        this.arrayColourVariation = [...selectedProduct.arrayColourVariations];
      }

      if (selectedProduct.n && selectedProduct.arraySizeVariations.length > 0) {
        this.arraySizeVariations = [...selectedProduct.arraySizeVariations];
      }
    }
  }

  brandListing() {
    this.myProductService.brandListingService().subscribe((res) => {
      if (res.success === true) {
        this.brandList = res.data;
      }
    });
  }

  downloadCSV() {
    this.loading = true;
    const objData = {
      strProductName: this.frmProductReport.value.txtProductName,
      strArabicName: this.frmProductReport.value.arabicName,
      strArticalNo: this.frmProductReport.value.txtArticalNo,
      strBrand: this.frmProductReport.value.txtBrand,
      strBarcode: this.frmProductReport.value.txtBarcode,
      intCategoryId: this.frmProductReport.value.cmbCategory,
      intSubCategoryerId: this.frmProductReport.value.cmbSubCategory,
    };

    this.myProductService.downloadCsvFromDB(objData).subscribe(
      (res) => {
        if (res.success == true) {
          this.loading = false;
          let strPath = this.apiURL + "/" + res.data;
          window.location.href = strPath;

          //
          //console.log(strPath)
          //let url = window.URL.createObjectURL(strPath);
          // console.log(url)
          //window.open(res.data);
        }
      },
      (error) => {
        this.loading = false;
        console.log("error");
      }
    );
  }

  setPageLimit() {
    this.intPagelimit = parseInt(
      this.frmProductReport.value.cmbSearchCountLimit
    );
    this.setPage(1);
  }

  setPage(page: number) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    // get pager object from service
    this.pager = this.pagerService.getPager(
      this.intTotalCountValue,
      page,
      this.intPagelimit
    );
    this.getProductSearchData();
  }

  DeleteProductData() {
    try {
      let intuserId = localStorage.getItem("userId");
      const objData = {
        intProductId: this.intDeleteProductId,
        strUserId: intuserId,
      };
      this.myProductService.deleteProductdetails(objData).subscribe(
        (res) => {
          if (res.success == true) {
            this.setPage(this.pager.currentPage);
            // this.Messagetoastr.success(res.message, '', {
            //   closeButton: true,
            //   timeOut: 3000

            // });
            alert(res.message);
          } else {
            alert(res.message);
            // this.Messagetoastr.warning(res.message, '', {
            //   closeButton: true,
            //   timeOut: 3000
            // });
          }
        },
        (error) => {
          console.log(error);
          // this.Messagetoastr.error(error, '', {
          //   closeButton: true,
          //   timeOut: 3000
          // });
        }
      );
    } catch (e) {
      console.log(e);
    }
  }

  /*
   * Edit on: 7th August 2020
   * Features: Card on delivery and Pay online added
   */

  showProductDetails(modalDetete: TemplateRef<any>, objProductData: any) {
    console.log("product details::::::::", objProductData);

    let blnFrozenFood = true;
    let blnCod = true;
    let blnReturnable = true;
    let blnFreeDelivery = true;
    let blnWarranty = true;
    let blnPriceVariation = true;
    this.modalRef = this.modalService.show(modalDetete);
    this.objUpdateProductData = objProductData;
    this.frmProductEdit.patchValue({
      txtProductName: objProductData.strProductName,
    });
    this.frmProductEdit.patchValue({
      arabicName: objProductData.strArabicName,
    });
    this.frmProductEdit.patchValue({ txtQuantity: objProductData.intQuantity });
    this.frmProductEdit.patchValue({
      intStockQuantity: objProductData.intStockQuantity,
    });
    this.frmProductEdit.patchValue({
      isInfiniteStock: objProductData.isInfiniteStock,
    });
    this.frmProductEdit.patchValue({
      txtMaxProdQty: objProductData.intMaxQuantity,
    });
    this.frmProductEdit.patchValue({
      txtMinProdQty: objProductData.intMinQuantity,
    });
    this.frmProductEdit.patchValue({ txtMRP: objProductData.intSellingPrice });
    this.frmProductEdit.patchValue({ txtDiscount: objProductData.intDiscount });
    this.frmProductEdit.patchValue({
      txtProperties: objProductData.strProperties,
    });
    this.frmProductEdit.patchValue({
      txtDescription: objProductData.strDescription,
    });
    this.frmProductEdit.patchValue({
      strManufacturerDetails: objProductData.strManufacturerDetails,
    });
    this.frmProductEdit.patchValue({
      strProductDisclaimer: objProductData.strProductDisclaimer,
    });
    this.frmProductEdit.patchValue({ strFeature: objProductData.strFeature });
    this.frmProductEdit.patchValue({ brand: objProductData.strBrand });
    this.frmProductEdit.patchValue({
      txtSellingPrice: objProductData.intMRP,
    });

    this.frmProductEdit.patchValue({ txtUnit: objProductData.strUnit });
    // this.frmProductEdit.get("txtUnit").patchValue(objProductData.strUnit)

    this.frmProductEdit.patchValue({
      rdbStockStatus: objProductData.blnStockAvailable,
    });
    this.frmProductEdit.patchValue({ txtBarcode: objProductData.strBarcode });
    this.frmProductEdit.patchValue({
      txtArticleNumber: objProductData.strArticleNo,
    });
    this.frmProductEdit.patchValue({
      fkShopId: objProductData.fkShopId,
    });
    this.AutocompleteCategoryListing(objProductData.fkShopId);
    this.frmProductEdit.patchValue({
      cmbCategory: objProductData.strMainCategoryId,
    });
    this.AutocompleteSubCategoriesListing(objProductData.strMainCategoryId);
    this.frmProductEdit.patchValue({
      cmbSubCategory: objProductData.strSubCategoryId,
    });
    this.frmProductEdit.patchValue({
      rdbProductVisibility: objProductData.strProductStatus,
    });
    this.frmProductEdit.patchValue({
      cbCard: objProductData.blnCardOnDelivery,
    });
    this.frmProductEdit.patchValue({
      cbPayOnline: objProductData.blnPayOnline,
    });

    if (
      objProductData.blnStockAvailable === "true" ||
      objProductData.blnStockAvailable === true
    ) {
      this.blnStock = true;
    } else {
      this.blnStock = false;
    }
    // if (objProductData.strProductStatus === 'Active') {
    //   this.blnProductVisibility = true;
    // } else {cmbDepartment cmbCategory
    //   this.blnProductVisibility = false;
    // }
    if (
      objProductData.blnFrozenFood === "true" ||
      objProductData.blnFrozenFood === true
    ) {
      this.frmProductEdit.patchValue({ cbFrozenFood: blnFrozenFood });
    } else {
      this.frmProductEdit.patchValue({ cbFrozenFood: !blnFrozenFood });
    }
    if (objProductData.blnCOD === "true" || objProductData.blnCOD === true) {
      this.frmProductEdit.patchValue({ cbCod: blnCod });
    } else {
      this.frmProductEdit.patchValue({ cbCod: !blnCod });
    }
    if (
      objProductData.blnFreeDelivery === "true" ||
      objProductData.blnFreeDelivery === true
    ) {
      this.frmProductEdit.patchValue({ cbFreeDelivery: blnFreeDelivery });
    } else {
      this.frmProductEdit.patchValue({ cbFreeDelivery: !blnFreeDelivery });
    }
    if (
      objProductData.blnReturnable === "true" ||
      objProductData.blnReturnable === true
    ) {
      this.frmProductEdit.patchValue({ cbRefundable: blnReturnable });
    } else {
      this.frmProductEdit.patchValue({ cbRefundable: !blnReturnable });
    }
    if (
      objProductData.blnWarranty === "true" ||
      objProductData.blnWarranty === true
    ) {
      this.frmProductEdit.patchValue({ cbWarranty: blnWarranty });
    } else {
      this.frmProductEdit.patchValue({ cbWarranty: !blnWarranty });
    }

    if (
      objProductData.blnPriceVariation === "true" ||
      objProductData.blnPriceVariation === true
    ) {
      this.frmProductEdit.patchValue({ blnPriceVariation: blnPriceVariation });
    } else {
      this.frmProductEdit.patchValue({ blnPriceVariation: !blnPriceVariation });
    }

    if (objProductData.blnPriceVariation) {
      if (
        objProductData.blnPriceVariation === "true" ||
        objProductData.blnPriceVariation === true
      ) {
        console.log(objProductData.blnPriceVariation);
        this.frmProductEdit.patchValue({
          blnPriceVariation: blnPriceVariation,
        });
      } else {
        this.frmProductEdit.patchValue({
          blnPriceVariation: !blnPriceVariation,
        });
      }
    } else {
      this.frmProductEdit.patchValue({ blnPriceVariation: !blnPriceVariation });
    }

    if (objProductData.strVeg) {
      console.log(objProductData.strVeg);
      this.frmProductEdit.patchValue({ strVeg: objProductData.strVeg });
    }

    if (objProductData.specialTag) {
      console.log(objProductData.specialTag);
      this.frmProductEdit.patchValue({ specialTag: objProductData.specialTag });
    }

    let updatePriceDetails: any[] = [];
    if (
      objProductData.arrayAddOnPriceDetails &&
      objProductData.arrayAddOnPriceDetails.length
    ) {
      objProductData.arrayAddOnPriceDetails.forEach((element) => {
        let objPriceDetails = {
          size: element.size,
          price: element.price,
        };
        updatePriceDetails.push(objPriceDetails);
      });
      this.setPriceDetails(updatePriceDetails);
    }

    let updateSeizeDetails: any[] = [];
    if (
      objProductData.arraySizeVariations &&
      objProductData.arraySizeVariations.length
    ) {
      objProductData.arraySizeVariations.forEach((element) => {
        let objSeizeVariation = {
          size: element.size,
        };
        updateSeizeDetails.push(objSeizeVariation);
      });
      this.setSeizeDetails(updateSeizeDetails);
    }

    let updateColorDetails: any[] = [];
    if (
      objProductData.arrayColourVariations &&
      objProductData.arrayColourVariations.length
    ) {
      objProductData.arrayColourVariations.forEach((element) => {
        let objColorVariation = {
          color: element.color,
          colourCode: element.colourCode,
        };
        updateColorDetails.push(objColorVariation);
      });
      this.setColorDetails(updateColorDetails);
    }
  }

  // Edited on : 22nd July 2020
  // Issue: #25
  _onSearch() {
    this.pager = {};
    this.getProductSearchData();
  }

  confirmMessage(modalEdit: TemplateRef<any>, intProductId: any) {
    this.modalRef = this.modalService.show(modalEdit);
    this.intDeleteProductId = intProductId;
  }

  txtImageurl: any;
  txtColor: any;

  ImageColor(modalImage: TemplateRef<any>, intProductId: any) {
    this.modalRef = this.modalService.show(modalImage);
    this.intimageProductId = intProductId;
    console.log(intProductId, "res::::::::::::::txt");

    this.frmImageUpdate.patchValue({
      color: intProductId.txtColor,
    });
    this.frmImageUpdate.patchValue({
      // txtImage: intProductId.imageUrl
    });

    this.txtImageurl = intProductId.imageUrl;
    this.txtColor = intProductId.color;
  }

  stock(res) {
    if (res === "stock") {
      this.blnStock = true;
    } else {
      this.blnStock = false;
    }
  }
  productVisibility(res) {
    if (res === "show") {
      this.blnProductVisibility = true;
    } else {
      this.blnProductVisibility = false;
    }
  }

  /*
   * Function to update product features
   */
  /*
   * Edit on: 7th August 2020
   * Features: Card on delivery and Pay online added
   */
  EditProductDetails(objProduct) {
    console.log("objproductnew", objProduct);
    console.log("blnstatus", this.blnStock);

    try {
      let intuserId = localStorage.getItem("userId");
      // const objData = {
      //   intProductId: this.objUpdateProductData.intProductId,
      //   strUserId: intuserId,
      //   strProductName: objProduct.txtProductName,
      //   strArabicName: objProduct.arabicName,
      //   intSellingPrice: parseFloat(objProduct.txtSellingPrice),
      //   intMRP: parseFloat(objProduct.txtMRP),
      //   intDiscount: parseFloat(objProduct.txtDiscount),
      //   intQuantity: objProduct.txtQuantity,
      //   strUnit: objProduct.txtUnit,
      //   blnStockAvailable: this.blnStock,
      //   blnCOD: objProduct.cbCod,
      //   blnFreeDelivery: objProduct.cbFreeDelivery,
      //   blnFrozenFood: objProduct.cbFrozenFood,
      //   blnReturnable: objProduct.cbRefundable,
      //   blnWarranty: objProduct.cbWarranty,
      //   strProductStatus: objProduct.rdbProductVisibility,
      //   strArticleNo: objProduct.txtArticleNumber,
      //   strBarcode: objProduct.txtBarcode,
      //   strDeptId: objProduct.cmbDepartment,
      //   strCategoryId: objProduct.cmbCategory,
      //   strSubCategoryId: objProduct.cmbSubCategory,
      //   strProperties: objProduct.txtProperties,
      //   strDescription: objProduct.txtDescription,
      //   blnCardOnDelivery: objProduct.cbCard,
      //   blnPayOnline: objProduct.cbPayOnline,
      //   intMaxQuantity: objProduct.txtMaxProdQty,
      //   intMinQuantity: objProduct.txtMinProdQty,
      //   ProductImages: this.imageFile, // this.imageFile.slice(1, this.imageFile.length-1)
      //   ProductThumbnail: this.imageFile,
      // };
      //     let arrPriceVariations = [];
      //     let arrColorVariations = [];
      //     let arrSeizeVariations = [];

      //     objProduct.objPriceVariations.forEach((element) => {
      //       let objVariation = {
      //         size: element.variation,
      //         price: element.priceOption,
      //       };
      //       arrPriceVariations.push(objVariation);
      //       console.log(arrPriceVariations, "res::::::::::::::::::::", objProduct);
      //     });

      //     objProduct.objColorVariations.forEach((element) => {
      //       let objColorVariation = {
      //         color: element.color,
      //         colourCode: element.strColorCode,
      //         image: "",
      //       };
      //       arrColorVariations.push(objColorVariation);
      //       console.log("objColorVariation", arrColorVariations);
      //     });

      //     objProduct.objSeizeVariations.forEach((element) => {
      //       let objSeizeVariations = {
      //         size: element.size,
      //       };
      //       arrSeizeVariations.push(objSeizeVariations);
      //     });

      //     if (
      //       objProduct.blnPriceVariation === "true" ||
      //       objProduct.blnPriceVariation === true
      //     ) {
      //       if (!arrPriceVariations.length) {
      //         alert("Price variations required!");

      //         return;
      //       }
      //     } else {
      //       let control = <FormArray>(
      //         this.frmProductEdit.controls.objPriceVariations
      //       );
      //       while (control.length !== 0) {
      //         control.removeAt(0);
      //       }
      //       //this.addProductForm.controls.objPriceVariations=this.formBuilder.array([])
      //       arrPriceVariations = [];
      //     }

      //     let fdata = new FormData();

      //     fdata.append("intProductId", this.objUpdateProductData.intProductId);
      //     fdata.append("strLoginUserId", intuserId);
      //     fdata.append("strProductName", objProduct.txtProductName);
      //     fdata.append("strArabicName", objProduct.arabicName);
      //     fdata.append("intSellingPrice", objProduct.txtMRP),
      //       fdata.append("intMRP", objProduct.txtSellingPrice);
      //     fdata.append("intDiscount", objProduct.txtDiscount);
      //     fdata.append("intQuantity", objProduct.txtQuantity);
      //     fdata.append("strUnit", objProduct.txtUnit);
      //     fdata.append("blnStockAvailable", this.blnStock.toString());
      //     fdata.append("blnCOD", objProduct.cbCod);
      //     fdata.append("blnFreeDelivery", objProduct.cbFreeDelivery);
      //     fdata.append("blnFrozenFood", objProduct.cbFrozenFood);
      //     fdata.append("blnReturnable", objProduct.cbRefundable);
      //     fdata.append("blnWarranty", objProduct.cbWarranty);
      //     fdata.append("strProductStatus", objProduct.rdbProductVisibility);
      //     fdata.append("strArticleNo", objProduct.txtArticleNumber);
      //     fdata.append("strBarcode", objProduct.txtBarcode);
      //     fdata.append("fkShopId", objProduct.fkShopId);
      //     fdata.append("strCategoryId", objProduct.cmbCategory);
      //     fdata.append("strSubCategoryId", objProduct.cmbSubCategory);
      //     fdata.append("strProperties", objProduct.txtProperties);
      //     fdata.append("strDescription", objProduct.txtDescription);
      //     fdata.append("strManufacturerDetails", objProduct.strManufacturerDetails);
      //     fdata.append("strProductDisclaimer", objProduct.strProductDisclaimer);
      //     fdata.append("strFeature", objProduct.strFeature);
      //     fdata.append("blnCardOnDelivery", objProduct.cbCard);
      //     fdata.append("blnPayOnline", objProduct.cbPayOnline);
      //     fdata.append("intStockQuantity", objProduct.intStockQuantity);
      //     fdata.append("isInfiniteStock", objProduct.isInfiniteStock);
      //     fdata.append("intMaxQuantity", objProduct.txtMaxProdQty);
      //     fdata.append("intMinQuantity", objProduct.txtMinProdQty);

      //     fdata.append("blnPriceVariation", objProduct.blnPriceVariation);

      //     fdata.append("strSeizeVariation", objProduct.strSeizeVariation);

      //     fdata.append("strColorVariations", objProduct.strColorVariations);
      //     fdata.append("strBrand", objProduct.brand);
      //     fdata.append(
      //       "arrayAddOnPriceDetails",
      //       JSON.stringify(arrPriceVariations)
      //     );
      //     fdata.append("strVeg", objProduct.strVeg);
      //     fdata.append("specialTag", objProduct.specialTag);

      //     for (let item of this.imageFile) {
      //       fdata.append("ProductImages", item, item.name);
      //       console.log("itietieiteiteitie", item);
      //     }

      //     for (let item of this.imageFile) {
      //       fdata.append("ProductThumbnail", item, item.name);
      //       console.log("itietieiteiteitie", item);
      //     }

      //     console.log("bln stock", this.blnStock);

      //     fdata.forEach((key, value) => console.log(` ${value}:${key}`));

      //     this.myProductService.updateProductdetails(fdata).subscribe(
      //       (res) => {
      //         if (res.success == true) {
      //           this.setPage(this.pager.currentPage);
      //           alert(res.message);
      //           this.imageFile = [];
      //         } else {
      //           // this.imageFile = []
      //           Swal.fire("Warning!", res.message, "warning");
      //         }
      //       },
      //       (error) => {
      //         console.log("error");
      //       }
      //     );
      //   } catch (e) {
      //     console.log(e);
      //   }
      // }

      let arrPriceVariations = [];

      objProduct.objPriceVariations.forEach((element) => {
        let objVariation = {
          size: element.variation,
          price: element.priceOption,
        };
        arrPriceVariations.push(objVariation);
      });
      if (
        objProduct.blnPriceVariation === "true" ||
        objProduct.blnPriceVariation === true
      ) {
        // if (!arrPriceVariations.length) {
        //   alert("Price variations required!");
        //   return;
        // }
      } else {
        let control = <FormArray>(
          this.frmProductEdit.controls.objPriceVariations
        );
        while (control.length !== 0) {
          control.removeAt(0);
        }
        //this.addProductForm.controls.objPriceVariations=this.formBuilder.array([])
      }
      arrPriceVariations = [];

      //Price variation

      let arrSeizeVariations = [];

      objProduct.objSeizeVariations.forEach((element) => {
        let objVariation = {
          size: element.size,
        };
        arrSeizeVariations.push(objVariation);
      });

      let control = <FormArray>this.frmProductEdit.controls.objSeizeVariations;
      while (control.length !== 0) {
        control.removeAt(0);
        // arrSeizeVariations = [];
      }

      let arrayColourVariation = [];

      objProduct.objColorVariations.forEach((element) => {
        let objVariation = {
          color: element.color,
          colourCode: element.strColorCode,
        };
        arrayColourVariation.push(objVariation);
      });

      // let controls = <FormArray>this.frmProductEdit.controls.objColorVariations;
      // while (controls.length !== 0) {
      //   control.removeAt(0);
      // }

      // arrSeizeVariations = []
      //end

      let fdata = new FormData();

      fdata.append("intProductId", this.objUpdateProductData.intProductId);
      fdata.append("strUserId", intuserId);
      fdata.append("strProductName", objProduct.txtProductName);
      fdata.append("strArabicName", objProduct.arabicName);
      fdata.append("strManufacturerDetails", objProduct.strManufacturerDetails);
      fdata.append("strProductDisclaimer", objProduct.strProductDisclaimer);
      fdata.append("intSellingPrice", objProduct.txtMRP),
        fdata.append("strFeature", objProduct.strFeature);
      fdata.append("intMRP", objProduct.txtSellingPrice);
      fdata.append("intDiscount", objProduct.txtDiscount);
      fdata.append("intQuantity", objProduct.txtQuantity);
      fdata.append("strUnit", objProduct.txtUnit);
      fdata.append("blnStockAvailable", this.blnStock.toString());
      fdata.append("blnCOD", objProduct.cbCod);
      fdata.append("blnFreeDelivery", objProduct.cbFreeDelivery);
      fdata.append("blnFrozenFood", objProduct.cbFrozenFood);
      fdata.append("blnReturnable", objProduct.cbRefundable);
      fdata.append("blnWarranty", objProduct.cbWarranty);
      fdata.append("strProductStatus", objProduct.rdbProductVisibility);
      fdata.append("strArticleNo", objProduct.txtArticleNumber);
      fdata.append("strBarcode", objProduct.txtBarcode);
      fdata.append("strDeptId", objProduct.cmbDepartment);
      fdata.append("strCategoryId", objProduct.cmbCategory);
      fdata.append("strSubCategoryId", objProduct.cmbSubCategory);
      fdata.append("strProperties", objProduct.txtProperties);
      fdata.append("strDescription", objProduct.txtDescription);
      fdata.append("blnCardOnDelivery", objProduct.cbCard);
      fdata.append("blnPayOnline", objProduct.cbPayOnline);
      fdata.append("intMaxQuantity", objProduct.txtMaxProdQty);
      fdata.append("intMinQuantity", objProduct.txtMinProdQty);
      fdata.append("blnPriceVariation", objProduct.blnPriceVariation);
      fdata.append("strBrand", objProduct.brand);
      fdata.append(
        "arrayAddOnPriceDetails",
        JSON.stringify(arrPriceVariations)
      );
      fdata.append("arraySizeVariations", JSON.stringify(arrSeizeVariations));
      fdata.append(
        "arrayColourVariations",
        JSON.stringify(arrayColourVariation)
      );

      fdata.append("strVeg", objProduct.strVeg);
      fdata.append("specialTag", objProduct.specialTag);
      fdata.append("intStockQuantity", objProduct.intStockQuantity);
      fdata.append("isInfiniteStock", objProduct.isInfiniteStock);

      for (let item of this.imageFile) {
        fdata.append("ProductImages", item, item.name);
        console.log("itietieiteiteitie", item);
      }

      for (let item of this.imageFile) {
        fdata.append("ProductThumbnail", item, item.name);
        console.log("itietieiteiteitie", item);
      }

      console.log("bln stock", this.blnStock);

      fdata.forEach((key, value) => console.log(` ${value}:${key}`));

      this.myProductService.updateProductdetails(fdata).subscribe(
        (res) => {
          if (res.success == true) {
            this.setPage(this.pager.currentPage);
            alert(res.message);
            this.imageFile = [];
          } else {
            // this.imageFile = []
            Swal.fire("Warning!", res.message, "warning");
          }
        },
        (error) => {
          console.log("error");
        }
      );
    } catch (e) {
      console.log(e);
    }
  }

  unitListing() {
    this.myProductService.unitListingService().subscribe((res) => {
      if (res.success === true) {
        this.blnLoader = true;
        this.unitList = res.data;
        console.log("Unit List", res.data);
      }
    });
  }

  onFileChange(event) {
    for (let i = 0; i < event.target.files.length; i++) {
      this.imageFile.push(event.target.files[i]);
    }
  }
}

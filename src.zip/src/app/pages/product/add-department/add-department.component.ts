import { Router } from "@angular/router";
import { Validators } from "@angular/forms";
import { FormBuilder } from "@angular/forms";
import { modDepartment } from "./../../../shared/Classes/HyperMarket.model";
import { HypermarketService } from "./../../../shared/services/Hypermarket/hypermarket.service";
import { GeneralDataService } from "./../../../shared/services/general-data.service";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { ProductService } from "./../../../shared/services/product.service";
import { FormGroup } from "@angular/forms";
import { Component, OnInit } from "@angular/core";
import { DatePipe } from "@angular/common";
import { PagerService } from "src/app/shared/services/pager.service";
import Swal from "sweetalert2";

@Component({
  selector: "app-add-department",
  templateUrl: "./add-department.component.html",
  styleUrls: ["./add-department.component.scss"],
})
export class AddDepartmentComponent implements OnInit {
  frmDepartment: FormGroup;
  frmEditDepartment: FormGroup;
  submitted = false;
  submittedEdit = false;
  imageFile: File[] = [];
  datePipe = new DatePipe("en-US");
  strDepartmentId = "";
  arrOfDepartment: modDepartment[] = [];
  blnLoader = false;
  deptImg: File[] = [];
  intTotalCount = 0;
  formBannerImages: FormGroup;
  intSkipCount = 0;
  pageLimit: any[];
  intPageLimit = 10;
  pager: any = {};

  constructor(
    private pageServiceObj: PagerService,
    private myProductService: ProductService,
    private modalService: NgbModal,
    private generalServiceObj: GeneralDataService,
    private hypermarketServiceObj: HypermarketService,
    private formBuilder: FormBuilder,
    private router: Router
  ) {}

  ngOnInit() {
    this.frmDepartment = this.formBuilder.group({
      txtName: ["", Validators.required],
      arabicName: ["", Validators.required],
      txtDescription: ["", Validators.required],
      txtViewType: [""],
      txtImageUrl: ["", Validators.required],
      blnStatus: true,
      txtSortNo: ["", Validators.required],
    });

    this.frmEditDepartment = this.formBuilder.group({
      txtName: ["", Validators.required],
      txtDescription: ["", Validators.required],
      txtViewType: ["", Validators.required],
      txtImageUrl: ["", Validators.required],
      blnStatus: [""],
      txtSortNo: ["", Validators.required],
      arabicName: ["", Validators.required],
      imgFile: [""],
    });
    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getListDepartmentFn();
  }

  get formControls() {
    return this.frmDepartment.controls;
  }

  get f() {
    return this.frmEditDepartment.controls;
  }

  _clearForm(form: FormGroup) {
    // form.clearValidators()
    form.patchValue({ txtName: "" });
    form.patchValue({ arabicName: "" });
    form.patchValue({ txtDescription: "" });
    form.patchValue({ txtImageUrl: "" });
    form.patchValue({ txtSortNo: "" });
    //  form.patchValue({blnStatus: 'true'});
  }

  refreshPage() {
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    this.router.onSameUrlNavigation = "reload";
    this.router.navigate(["add-department"]);
  }

  /*
    TODO @Function: FUNCTION TO SET PAGE LIMIT
    */
  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getListDepartmentFn();
  }

  _EditModal(responsiveData, objData) {
    this.modalService.open(responsiveData);
    this.strDepartmentId = objData.pkDepartmentId;
    this.frmEditDepartment.patchValue({ txtName: objData.strName });
    this.frmEditDepartment.patchValue({ arabicName: objData.strArabicName });
    this.frmEditDepartment.patchValue({
      txtDescription: objData.strDescription,
    });
    this.frmEditDepartment.patchValue({ txtSortNo: objData.intSortNo });
    this.frmEditDepartment.patchValue({ txtImageUrl: objData.strImageUrl });
    this.frmEditDepartment.patchValue({ txtViewType: objData.strType });
    if (objData.strCategoryStatus === "N") {
      this.frmEditDepartment.patchValue({ blnStatus: true });
    } else {
      this.frmEditDepartment.patchValue({ blnStatus: false });
    }
  }
  _DeleteModal(responsiveDelete, $departmentId) {
    this.strDepartmentId = $departmentId;
    this.modalService.open(responsiveDelete);
  }

  getListDepartmentFn() {
    let skipCount = this.intSkipCount;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
    const obj = {
      // strCategoryId: '',
      strLoginUserId: localStorage.getItem("userId"),
      intPageLimit: this.intPageLimit,
      intSkipCount: skipCount,
    };
    this.hypermarketServiceObj
      .getListDepartmentService(obj)
      .subscribe((res) => {
        this.intTotalCount = res.data[0].intTotalCount;
        this.blnLoader = true;
        this.arrOfDepartment = res.data;
        this.intTotalCount = res.count;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
        {
          // this.arrBanner = []
          //  Swal.fire({
          //    title: "Error",
          //   text: res.message,
          //   icon: "error",
          //   confirmButtonText: "Ok",
          //  });
          //  this.spinner.hide();
        }
      });
  }

  // getListDepartmentFn() {

  //   let skipCount = this.intSkipCount;
  //   if (this.pager.intSkipCount) {
  //     skipCount = this.pager.intSkipCount;
  //   }
  //   this.blnLoader = false;
  //   const obj = {
  //     strLoginUserId: localStorage.getItem("userId"),
  //     intSkipCount : skipCount,
  //     intPageLimit : this.intPageLimit,
  //   }
  //   console.log("pagination",obj)
  //   this.hypermarketServiceObj.getListDepartmentService(obj).subscribe((res) => {
  //     if (res && res.success) {
  //       //  this.ngOnInit()
  //       this.blnLoader = true;
  //       this.arrOfDepartment = res.data;
  //       this.intTotalCount = res.count;
  //       console.log(  this.intTotalCount,"countytt")
  //       this.pager = this.pageServiceObj.getPager(
  //         this.intTotalCount,
  //         this.pager.currentPage,
  //         this.intPageLimit
  //       );
  //     } else {
  //       this.arrOfDepartment = []

  //     }
  //   })
  // }

  //

  // Add Department
  getSaveDepartmentFn() {
    this.blnLoader = false;
    this.submitted = true;
    if (this.frmDepartment.invalid) {
      this.blnLoader = true;
      return;
    }

    let fData = new FormData();
    fData.append("strDeptName", this.frmDepartment.value.txtName);
    fData.append("strArabicName", this.frmDepartment.value.arabicName);
    fData.append("strDescription", this.frmDepartment.value.txtDescription);
    fData.append("strViewStatus", this.frmDepartment.value.blnStatus);
    fData.append("strLoginUserId", localStorage.getItem("userId"));
    fData.append("strSortCount", this.frmDepartment.value.txtSortNo);
    for (let image of this.deptImg) {
      fData.append("strImageUrl", image, image.name);
    }

    fData.forEach((key, value) => console.log(`${key}  : ${value}`));

    this.hypermarketServiceObj
      .getSaveDepartmentService(fData)
      .subscribe((res) => {
        console.log("res DCD", res);
        if (res.success === true) {
          this.blnLoader = true;
          Swal.fire({
            title: "Saved!",
            text: "Department added successfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then(() => {
            // this.refreshPage();
            this.frmDepartment.reset();
            // this.getListDepartmentFn();
            this.submitted = false;
          });
        } else {
          Swal.fire({
            title: "Error",
            text: res.message,
            icon: "error",
            confirmButtonText: "Ok",
          });
          // alert(res.message)
        }
        this.getListDepartmentFn();
      });
  }

  getDeleteDepartmentFn() {
    const obj = {
      strDeptId: this.strDepartmentId,
      strLoginUserId: localStorage.getItem("userId"),
    };
    this.hypermarketServiceObj
      .getDeleteDepartmentService(obj)
      .subscribe((res) => {
        if (res.success === true) {
          this.modalService.dismissAll();
          Swal.fire({
            title: "Deleted!",
            text: "Department Deleted Succesfully",
            icon: "success",
            confirmButtonText: "Ok",
          });
        } else {
          Swal.fire({
            title: "Error",
            text: res.message,
            icon: "error",
            confirmButtonText: "Ok",
          });
        }
        this.getListDepartmentFn();
      });
  }

  //  update dep
  getUpdateDepartmentFn() {
    this.blnLoader = false;
    this.submittedEdit = !this.submittedEdit;
    if (this.frmEditDepartment.invalid) {
      this.blnLoader = true;
      return;
    }

    //  const obj = {
    //   strDeptName: this.frmEditDepartment.value.txtName,
    //   strArabicName :this.frmEditDepartment.value.arabicName ,
    //   strDescription: this.frmEditDepartment.value.txtDescription,
    //   strLoginUserId: localStorage.getItem('userId'),
    //   strSortCount: this.frmEditDepartment.value.txtSortNo,
    //   strDeptId: this.strDepartmentId,
    //   strImageUrl: this.frmEditDepartment.value.txtImageUrl,
    //   strViewStatus: this.frmEditDepartment.value.blnStatus,
    //  }
    let fData = new FormData();
    fData.append("strDeptName", this.frmEditDepartment.value.txtName);
    fData.append("strArabicName", this.frmEditDepartment.value.arabicName);
    fData.append("strDescription", this.frmEditDepartment.value.txtDescription);
    fData.append("strViewStatus", this.frmEditDepartment.value.blnStatus);
    fData.append("strLoginUserId", localStorage.getItem("userId"));
    fData.append("strDeptId", this.strDepartmentId);
    fData.append("strSortCount", this.frmEditDepartment.value.txtSortNo);
    for (let image of this.deptImg) {
      fData.append("strImageUrl", image, image.name);
    }
    fData.forEach((key, value) => console.log(`${key}  : ${value}`));
    this.hypermarketServiceObj
      .getUpdateDepartmentService(fData)
      .subscribe((res) => {
        if (res.success === true) {
          Swal.fire({
            title: "Updated!",
            text: "Department Updated Succesfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then(() => {
            this.modalService.dismissAll();
            this.getListDepartmentFn();
          });
        } else {
          Swal.fire({
            title: "Error",
            text: res.message,
            icon: "error",
            confirmButtonText: "Ok",
          });
          this.getListDepartmentFn();
        }
      });
  }

  onFileChange(event) {
    console.log("event");
    for (let i of event.target.files) {
      this.deptImg.push(i);
    }
  }
}

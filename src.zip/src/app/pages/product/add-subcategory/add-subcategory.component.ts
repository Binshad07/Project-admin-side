import { Router } from '@angular/router';
import { Validators } from '@angular/forms';
import { modSubCategory } from './../../../shared/Classes/HyperMarket.model';
import { HypermarketService } from './../../../shared/services/Hypermarket/hypermarket.service';
import { FormBuilder } from '@angular/forms';
import { GeneralDataService } from './../../../shared/services/general-data.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ProductService } from './../../../shared/services/product.service';
import { FormGroup } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { PagerService } from 'src/app/shared/services/pager.service';
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-subcategory',
  templateUrl: './add-subcategory.component.html',
  styleUrls: ['./add-subcategory.component.scss']
})
export class AddSubcategoryComponent implements OnInit {
  frmSubCategory: FormGroup;
  frmSubCategoryEdit: FormGroup;
  pager: any = {};
  intTotalCount = 0;
  intPageLimit = 10;
  datePipe = new DatePipe('en-US');
  pageLimit: any[];
  strSkipCount = 0;
  arrShops = [];
  strShopId: String;
  submitted = false;
  arrOfCategoryList = [];
  arrViewType = [];
  strSubCategoryId = '';
  blnLoader = false;
  arrOfSubCategoryList: modSubCategory[] = [];
  subCategoryImg: File[] = [];
  intSkipCount: 0;
  isAdmin = true;

  constructor(
    private pageServiceObj: PagerService,
    private myProductService: ProductService,
    private modalService: NgbModal,
    private hypermarketServiceObj: HypermarketService,
    private formBuilder: FormBuilder,
    private router: Router,
    private companyService: CompanyServiceService,
  ) { }

  ngOnInit() {
    this.frmSubCategory = this.formBuilder.group({
      txtName: ['', Validators.required],
      arabicName: ['', Validators.required],
      txtDescription: ['', Validators.required],
      txtImageUrl: ['', Validators.required],
      blnStatus: true,
      drpViewType: ['', Validators.required],
      txtSortNo: ['', Validators.required],
      fkShopId: ['', Validators.required],
      drpCategory: ['', Validators.required],

    });
    this.frmSubCategoryEdit = this.formBuilder.group({
      txtName: [''],
      arabicName: [''],
      txtDescription: [''],
      txtImageUrl: [''],
      blnStatus: [''],
      drpViewType: [''],
      txtSortNo: [''],
      fkShopId: [''],
      drpCategory: [''],
    });
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getAllShop();
    this.getViewTypeFn();
    this.getListSubCategoryFn();
    if (localStorage.getItem('strUserType') == 'SHOP REPORTER') {
      this.isAdmin = false
    }
    
  }

  get formControls() {
    return this.frmSubCategory.controls;
  }

  // _clearForm(form: FormGroup) {
  //   form.reset({
  //     txtName: '',
  //     arabicName:'',
  //     txtDescription: '',
  //     flImage: '',
  //     blnStatus: true,
  //     drpViewType: '',
  //     txtSortNo: '',
  //     drpDepartment: '',
  //     drpCategory: '',

  //   });
  // }
  // _clearForm(form: FormGroup) {
  //   form.patchValue({
  //     txtName: '',
  //     arabicName: '',
  //     txtDescription: '',
  //     txtImageUrl: '',
  //     drpViewType: '',
  //     txtSortNo: '',
  //     drpDepartment: '',
  //   });
  //   Object.keys(form.controls).forEach(key => {
  //     const control = form.get(key) as FormGroup;
  //     control.clearValidators();
  //     control.updateValueAndValidity();
  //   });
  // }



  _clearForm(form: FormGroup) {

    // form.clearValidators()
    form.patchValue({
      txtName: '',
      arabicName: '',
      txtDescription: '',
      txtImageUrl: '',
      drpViewType: '',
      txtSortNo: '',
      fkShopId: '',
    });
    //  form.patchValue({blnStatus: 'true'});

  }


  refreshPage() {
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    this.router.onSameUrlNavigation = 'reload';
    this.router.navigate(['add-subcategory']);
  }


  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }

  _getEditModal(responsiveData, objValue) {
    this.modalService.open(responsiveData);
    this.strSubCategoryId = objValue.pkCategoryId;
    this.frmSubCategoryEdit.patchValue({ txtName: objValue.strName });
    this.frmSubCategoryEdit.patchValue({ arabicName: objValue.strArabicName });
    this.frmSubCategoryEdit.patchValue({ txtDescription: objValue.strDescription });
    this.frmSubCategoryEdit.patchValue({ txtImageUrl: objValue.strImageUrl });
    this.frmSubCategoryEdit.patchValue({ txtType: objValue.strType });
    this.frmSubCategoryEdit.patchValue({ txtSortNo: objValue.intSortNo });
    this.frmSubCategoryEdit.patchValue({ fkShopId: objValue.fkShopId });
    this.frmSubCategoryEdit.patchValue({ drpViewType: objValue.strViewType });
    this.getListCategoryFn(objValue.fkShopId)
    this.frmSubCategoryEdit.patchValue({ drpCategory: objValue.strParentCategoryId });
    if (objValue.strCategoryStatus === 'N') {
      this.frmSubCategoryEdit.patchValue({ blnStatus: true });
    } else {
      this.frmSubCategoryEdit.patchValue({ blnStatus: false });
    }
  }

  _getDeleteModal(responsiveDelete, id) {
    this.strSubCategoryId = id;
    this.modalService.open(responsiveDelete);
  }


  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(this.intTotalCount, page, this.intPageLimit);
    this.getListSubCategoryFn();
  }
  _getShoptId($ShopId) {
    this.strShopId = $ShopId;
    this.getListCategoryFn($ShopId);
  }

  getListCategoryFn(_id) {
    const obj = {
      strShopId: _id,

    };
    console.log(obj);
    this.myProductService.categoryListingService(obj).subscribe(res => {
      this.arrOfCategoryList = res.data;
      console.log(res);
    });
  }

  getAllShop() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
    }
    if (localStorage.getItem('fkShopId')) {
      // Object.assign(obj, { strShopId: localStorage.getItem('fkShopId') })
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {

      this.arrShops = res.data;
      console.log(this.arrShops)
    })
  }
  // getListSubCategoryFn() {

  //   let skipCount = this.intSkipCount;
  //   this.blnLoader = true;

  //   if (this.pager.intSkipCount) {
  //     skipCount = this.pager.intSkipCount;
  //   }

  //   const obj = {
  //     strSubCategoryId: '',
  //     intPageLimit: this.intPageLimit,
  //     intSkipCount: skipCount,
  //   };
  //   this.hypermarketServiceObj.getListSubCategoryService(obj).subscribe((res) => {
  //     this.blnLoader = true;
  //     this.arrOfSubCategoryList = res.data[1];
  //     console.log(res)
  //     // this._clearForm(this.frmSubCategory)
  //     this.intTotalCount = res.data[0].intTotalCount;
  //     this.arrOfSubCategoryList = res.data[1];

  //     // this.intTotalCount = res.data.length;
  //     this.pager = this.pageServiceObj.getPager(
  //       this.intTotalCount,
  //       this.pager.currentPage,
  //       this.intPageLimit
  //     );



  //   })
  // }
  // getSaveSubCategoryFn() {
  //   this.blnLoader = false;
  //   this.submitted = !this.submitted;
  //   if (this.frmSubCategory.invalid) {
  //     this.blnLoader = true;
  //     return;
  //   }

  // let skipCount = this.strSkipCount;
  //  this.blnLoader = false;

  getListSubCategoryFn() {
    let skipCount = this.intSkipCount;
    this.blnLoader = true;

    if (this.pager.strSkipCount) {
      skipCount = this.pager.strSkipCount;
    }
    const obj = {
      // strCategoryId: '',
      strSubCategoryId: '',

      intPageLimit: this.intPageLimit,
      strSkipCount: skipCount,
    };
    if (localStorage.getItem('fkShopId')) {
      Object.assign(obj, { strShopId: localStorage.getItem('fkShopId') })
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }

    this.hypermarketServiceObj.getListSubCategoryService(obj).subscribe(res => {
      this.intTotalCount = res.data[0].intTotalCount;
      this.blnLoader = true;
      this.arrOfSubCategoryList = res.data[1];
      console.log(this.arrOfSubCategoryList)
      this.pager = this.pageServiceObj.getPager(this.intTotalCount, this.pager.currentPage, this.intPageLimit);
    });
  }

  getSaveSubCategoryFn() {
    this.blnLoader = false;
    this.submitted = true;
    // this.submitted = !this.submitted;
    if (this.frmSubCategory.invalid) {
      this.blnLoader = true;
      return;
    }

    let fData = new FormData();

    fData.append("strCategoryName", this.frmSubCategory.value.txtName)
    fData.append("strArabicName", this.frmSubCategory.value.arabicName)
    fData.append("strDescription", this.frmSubCategory.value.txtDescription)
    fData.append("strLoginUserId", localStorage.getItem('userId'))
    fData.append("fkShopId", this.frmSubCategory.value.fkShopId)
    fData.append("strViewType", this.frmSubCategory.value.drpViewType)
    fData.append("strSortCount", this.frmSubCategory.value.txtSortNo)
    fData.append("strCategoryId", this.frmSubCategory.value.drpCategory)
    fData.append("strViewStatus", this.frmSubCategory.value.blnStatus)
    for (let image of this.subCategoryImg) {
      fData.append("strImageUrl", image, image.name)
    }

    console.log("view type")

    console.log("view type", this.frmSubCategory.value.drpViewType)

    this.hypermarketServiceObj.getSaveSubCategoryService(fData).subscribe((res => {

      if (res.success === true) {
        Swal.fire({
          title: "Saved!",
          text: "SubCategory added successfully",
          icon: "success",
          confirmButtonText: "Ok",
        })
        this.blnLoader = true;
        // alert('Sub category  Saved');
        this.refreshPage();
        this.getListSubCategoryFn();
      } else {
        this.blnLoader = true;
        // alert(res.message)
      }
      this.getListSubCategoryFn();

    }));

  }

  getDeleteSubCategoryFn() {
    const obj = {
      strLoginUserId: localStorage.getItem('userId'),
      strCategoryId: this.strSubCategoryId
    };
    this.hypermarketServiceObj.getDeleteSubCategoryService(obj).subscribe((res) => {
      if (res.success === true) {
        Swal.fire({
          title: "Deleted!",
          text: "SubCategory Deleted successfully",
          icon: "success",
          confirmButtonText: "Ok",
        })
        this.modalService.dismissAll();
        this.router.routeReuseStrategy.shouldReuseRoute = () => false;
        this.router.onSameUrlNavigation = 'reload';
        this.router.navigate(['add-subcategory']);
        this.ngOnInit()
      } else {
        alert(res.message);
      }
      this.getListSubCategoryFn();
    });


  }

  getUpdateSubCategoryFn() {

    let fData = new FormData();

    fData.append("strCategoryName", this.frmSubCategoryEdit.value.txtName)
    fData.append("strArabicName", this.frmSubCategoryEdit.value.arabicName)
    fData.append("strDescription", this.frmSubCategoryEdit.value.txtDescription)
    fData.append("strLoginUserId", localStorage.getItem('userId'))
    fData.append("fkShopId", this.frmSubCategoryEdit.value.fkShopId)
    fData.append("strViewType", this.frmSubCategoryEdit.value.drpViewType)
    fData.append("strSortCount", this.frmSubCategoryEdit.value.txtSortNo)
    fData.append("strCategoryId", this.strSubCategoryId)
    fData.append("strViewStatus", this.frmSubCategoryEdit.value.blnStatus)
    for (let image of this.subCategoryImg) {
      fData.append("strImageUrl", image, image.name)
    }
    fData.append("strParentCategoryId", this.frmSubCategoryEdit.value.drpCategory)

    this.hypermarketServiceObj.getUpdateSubCategoryService(fData).subscribe((res) => {

      if (res.success === true) {
        Swal.fire({
          title: "Updated!",
          text: "SubCategory Updated successfully",
          icon: "success",
          confirmButtonText: "Ok",
        })
        this.modalService.dismissAll();
      } else {
        alert(res.message)
      }
      this.getListSubCategoryFn();
    });

  }

  getViewTypeFn() {
    const obj = {}
    if (localStorage.getItem('strUserType') == 'SHOP REPORTER') {
      Object.assign(obj, {
        strViewTypeName: localStorage.getItem("strViewType"),
      })
    }
    console.log(obj)
    this.hypermarketServiceObj.getVieType(obj).subscribe((res) => {
      this.arrViewType = res.data;
      this.setDefaultViewType(this.arrViewType);
    })
  }

  onFileChange(event) {
    console.log("event")
    for (let i of event.target.files) {
      this.subCategoryImg.push(i);
    }
  }

  setDefaultViewType(viewType) {
    if (!this.isAdmin) {
      const firstOptionValue = viewType[0].strName;
      this.frmSubCategory.get('drpViewType').setValue(firstOptionValue);
    }
  }

}

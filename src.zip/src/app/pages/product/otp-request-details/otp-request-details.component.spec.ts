import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtpRequestDetailsComponent } from './otp-request-details.component';

describe('OtpRequestDetailsComponent', () => {
  let component: OtpRequestDetailsComponent;
  let fixture: ComponentFixture<OtpRequestDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtpRequestDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtpRequestDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from "@angular/core";
import {
  FormGroup,
  FormControl,
  FormBuilder,
  Validators,
  FormArray,
} from "@angular/forms";
import { ProductService } from "../../../shared/services/product.service";
import Swal from "sweetalert2";
import { Router } from "@angular/router";
import { SubCatResponse } from "../../../shared/Classes/subCatResponse";
import { unitResponse } from "../../../shared/Classes/unitResponse";
import { BrandResponse } from "../../../shared/Classes/brandResponse";
import {
  CategoryResponse,
  ShopResponse,
} from "src/app/shared/Classes/categoryResponse";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";
import { BrandserviceService } from "src/app/shared/services/brand/brandservice.service";
import { controllers } from "chart.js";
import { log } from "console";
@Component({
  selector: "app-add-product",
  templateUrl: "./add-product.component.html",
  styleUrls: ["./add-product.component.scss"],
})
export class AddProductComponent implements OnInit {
  addProductForm: FormGroup;
  submitted = false;
  productStatus: String = "Active";
  subCategoryId: any;
  brandId: any;
  CategoryId: any;
  strShopId: any;
  imageFile: File[] = [];
  subCategory: SubCatResponse[] = [];
  unitList: unitResponse[] = [];
  brandList: BrandResponse[] = [];
  categoryList: CategoryResponse[] = [];
  arrShops: ShopResponse[] = [];
  boolFreeDelivery = false;
  boolCOD = false;
  boolRefund = false;
  boolWarranty = false;
  boolFrozenFood = false;
  breadCrumbItems: Array<{}>;
  private formdata = new FormData();
  blnLoader = false;
  specialTagList = ["Must try", "Bestseller"];
  vegList = ["VEG", "NON-VEG", "NA"];
  showStock  = true

  constructor(
    private formBuilder: FormBuilder,
    private myProductService: ProductService,
    private companyService: CompanyServiceService,
    private brandService: BrandserviceService,
    private router: Router
  ) { }

  ngOnInit() {
    this.breadCrumbItems = [
      { label: "Product", path: "/" },
      { label: "Add Product", path: "/", active: true },
    ];
    this.addProductForm = this.formBuilder.group({
      name: ["", Validators.required],
      Arabicname: ["", Validators.required],
      unit: ["", Validators.required],
      isInfiniteStock: ["", Validators.required],
      strBrand: ["", Validators.required],
      quantity: ["1", Validators.required],
      // intStockQuantity: ["", Validators.required],
      intStockQuantity: ["0", [Validators.required, Validators.pattern("[0-9]*")]],

      price: ["", [Validators.required, Validators.pattern("[0-9]*")]],
      currentPrice: ["", [Validators.required, Validators.pattern("[0-9]*")]],
      discount: [""],
      barcode: ["", Validators.required],
      maxproductQuantity: ["20", Validators.required],
      category: ["", Validators.required],
      fkShopId: ["", Validators.required],
      file: ["", Validators.required],
      fileSource: [""],
      subcategory: ["", Validators.required],
      status: ["Active", Validators.required],
      properties: ["", Validators.required],
      searchTag: [""],
      description: ["", Validators.required],
      strManufacturerDetails: [""],
      strFeature: [""],
      strProductDisclaimer: [""],
      specialFeature: [""],
      minQty: ["1", Validators.required],
      articleNumber: [""],
      tax: ["5"],
      warranty: [false],
      freeDelivery: [false],
      cod: [false],
      refund: [false],
      frozenFood: [false],
      cardOnDelivery: [false],
      payOnline: [false],
      objPriceVariations: this.formBuilder.array([]),
      objSeizeVariations: this.formBuilder.array([]),
      objColorVariations: this.formBuilder.array([]),

      blnPriceVariation: [false],
      strColorVariations: [],
      strSeizeVariation: [],

      strVeg: ["", Validators.required],
      strShopId: String,
      specialTag: [""],
    });
    // this.unitListing();


    this.addProductForm.controls.price.valueChanges.subscribe((value) => {
      this.updateDiscountPercentage();
    });

    // this.addProductForm.controls.isInfiniteStock.valueChanges.subscribe((value) => {
    //   if(value === 'true'){
    //     this.showStock = false;
    //     this.addProductForm.value.isInfiniteStock = 0;

    //   }
    //   else{this.showStock = true}
    // });

    this.addProductForm.controls.isInfiniteStock.valueChanges.subscribe((value) => {
      if (value === 'true') {
        this.showStock = false;
        // this.addProductForm.controls.intStockQuantity.setValue('0'); // Set the form control to an empty string
                this.addProductForm.value.intStockQuantity = 0;

      } else {
        this.showStock = true;
      }
    });
    this.addProductForm.controls.currentPrice.valueChanges.subscribe(
      (value) => {
        this.updateDiscountPercentage();
      }
    );

    this.brandListing();
    this.getAllShop();
  }

  //   priceValidator(control) {
  //   const price = control.value;
  //   const currentPrice = this.addProductForm.get('currentPrice').value;

  //   if (price > currentPrice) {
  //     return { greaterThanCurrentPrice: true };
  //   }
  //  return null;
  // }

  updateDiscountPercentage() {
    console.log("Discount value working");
    const price = this.addProductForm.controls.price.value;
    const currentPrice = this.addProductForm.controls.currentPrice.value;

    if (price && currentPrice) {
      const discount = ((price - currentPrice) / price) * 100;

      this.addProductForm.controls.discount.patchValue(discount.toFixed(0));
    } else {
      this.addProductForm.controls.discount.patchValue(null);
    }
  }

  get formControls() {
    return this.addProductForm.controls;
  }

  get priceVariationsControl() {
    return (this.addProductForm.get("objPriceVariations") as FormArray)
      .controls;
  }

  get seizeVariationControl() {
    return (this.addProductForm.get("objSeizeVariations") as FormArray)
      .controls;
  }
  get colorVariationControl() {
    return (this.addProductForm.get("objColorVariations") as FormArray)
      .controls;
  }

  _clearForm(form: FormGroup) {
    form.reset({
      name: "",
      Arabicname: "",
      unit: "",
      isInfiniteStock: "",
      strBrand: "",
      quantity: "1",
      intStockQuantity: "",
      price: "",
      currentPrice: "",
      barcode: "",
      discount: "",
      maxproductQuantity: "20",
      category: "",
      fkShopId: "",
      file: "",
      fileSource: "",
      subcategory: "",
      status: "Active",
      properties: "",
      searchTag: "",
      description: "",
      strManufacturerDetails: "",
      strProductDisclaimer: "",
      strFeature: "",
      specialFeature: "",
      minQty: "1",
      articleNumber: "",
      tax: "5",
      warranty: false,
      freeDelivery: false,
      cod: false,
      refund: false,
      frozenFood: false,
      cardOnDelivery: false,
      payOnline: false,
      blnPriceVariation: false,
      strVeg: "NA",
      specialTag: "",
    });
  }
  onFileChange(event) {
    for (let i = 0; i < event.target.files.length; i++) {
      this.imageFile.push(event.target.files[i]);
    }
  }
  refreshPage() {
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    this.router.onSameUrlNavigation = "reload";
    this.router.navigate(["add-product"]);
  }

  addNewVariation() {
    let control = <FormArray>this.addProductForm.controls.objPriceVariations;
    control.push(
      this.formBuilder.group({
        variation: ["", Validators.required],
        priceOption: ["", Validators.required],
      })
    );
  }
  addColorVariation() {
    let control = <FormArray>this.addProductForm.controls.objColorVariations;
    control.push(
      this.formBuilder.group({
        color: [""],
        strColorCode: [""],
      })
    );

    console.log("Updated Form Value:", this.addProductForm.value);
  }
  addSeizeVariation() {
    let control = <FormArray>this.addProductForm.controls.objSeizeVariations;
    control.push(
      this.formBuilder.group({
        size: ["", Validators.required],
      })
    );
  }

  deleteVariation(index) {
    let control = <FormArray>this.addProductForm.controls.objPriceVariations;
    control.removeAt(index);
  }
  deleteVariations(index) {
    let control = <FormArray>this.addProductForm.controls.objColorVariations;
    control.removeAt(index);
  }
  deleteVariationss(index) {
    let control = <FormArray>this.addProductForm.controls.objSeizeVariations;
    control.removeAt(index);
  }
  getSubCategoryId(id) {
    this.subCategoryId = id;
  }
  getBrandId(id) {
    this.brandId = id;
  }
  getUnitId(id) {
    this.getUnitId = id;
  }
  // ! TO MODIFY WITH DEPARTMENT
  // getDepartmentId(id) {
  //   this.departmentId = id;
  //   console.log('Department Id', this.departmentId);

  //   this.categoryListing();
  // }

  _getShopId(id) {
    console.log("shopid", id)
    this.strShopId = id;
    // this.getUnitId=id;
    this.categoryListing();
    this.brandListing();
    this.listallunit()
  }

  getCategoryId(id) {
    this.CategoryId = id;
    this.subCategoriesListing();
  }

  // ! shop Listing
  getAllShop() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
    };
    if (localStorage.getItem("fkShopId")) {
      // Object.assign(obj, { strShopId: localStorage.getItem("fkShopId") });
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
     if(res && res.success){
      if(res.data.length){
        this.arrShops = res.data;
        // this.listallunit()
      }
     }else{
      this.arrShops = []
     }
    });
  }

  categoryListing() {
    const obj = {
      strShopId: this.strShopId,
    };
    this.myProductService.categoryListingService(obj).subscribe((res) => {
      console.log("Category listing response::::::", res);
      if (res.success === true) {
        this.categoryList = res.data;
        console.log("Category listing response::::::");
      } else {
        this.categoryList = res.data;
      }
    });
  }
  subCategoriesListing() {
    const obj = {
      strCategoryId: this.CategoryId,
    };
    this.myProductService.subcategoryListingService(obj).subscribe((res) => {
      if (res.success === true) {
        this.subCategory = res.data;
      } else {
        this.subCategory = [];
      }
    });
  }
  // unitListing() {
  //   this.myProductService.unitListingService().subscribe((res) => {
  //     if (res.success === true) {
  //       this.blnLoader = true;
  //       this.unitList = res.data;
  //       console.log("Unit List", res.data);
  //     }
  //   });
  // }

  listallunit() {
    console.log(this.strShopId + "shop id")
    const obj = {
      strShopId: this.strShopId,
      strLoginUserId: localStorage.getItem("userId"),

    };
    console.log("odbj", obj)
    this.myProductService.listAllUnitService(obj).subscribe((res) => {
      console.log("resffhgvcgvbhnjhgfdsfghjgfdfghjk", res)
      if (res.success === true) {
        this.blnLoader = true;
        this.unitList = res.data;
        console.log("Unit List", res.data);
      }
    });
  }
  brandListing() {
    const obj = {
      fkShopId: this.strShopId,
    };
    this.brandService.getAllbrands(obj).subscribe((res) => {
      if (res.success === true) {
        this.brandList = res.data;
      }
    });
  }

  onSubmit() {
    this.blnLoader = false;
    let arrPriceVariations = [];
    let arrColorVariations = [];
    let arrSeizeVariations = [];

    this.addProductForm.value.objPriceVariations.forEach((element) => {
      let objVariation = {
        size: element.variation,
        price: element.priceOption,
      };

      arrPriceVariations.push(objVariation);
      console.log(
        arrPriceVariations,
        "res::::::::::::::::::::",
        this.addProductForm
      );
    });

    this.addProductForm.value.objColorVariations.forEach((element) => {
      let objColorVariation = {
        colourCode: element.strColorCode,
        color: element.color,
        image: "",
      };
      arrColorVariations.push(objColorVariation);
    });

    console.log("objColorVariation", arrColorVariations);
    this.addProductForm.value.objSeizeVariations.forEach((element) => {
      let objSeizeVariations = {
        size: element.size,
      };
      arrSeizeVariations.push(objSeizeVariations);
    });

    if (
      this.addProductForm.value.blnPriceVariation === "true" ||
      this.addProductForm.value.blnPriceVariation === true
    ) {
      if (!arrPriceVariations.length) {
        Swal.fire({
          title: "Warning",
          text: "Price variations required!",
          icon: "warning",
          confirmButtonText: "Ok",
        });
        this.blnLoader = true;
        return;
      }
    } else {
      let control = <FormArray>this.addProductForm.controls.objPriceVariations;
      while (control.length !== 0) {
        control.removeAt(0);
      }
      //this.addProductForm.controls.objPriceVariations=this.formBuilder.array([])
    }

    const sellingPrice =
      this.addProductForm.value.price -
      this.addProductForm.value.price *
      (this.addProductForm.value.discount / 100);

    const obj = {
      strProductName: this.addProductForm.value.name,
      strArabicName: this.addProductForm.value.Arabicname,
      strDescription: this.addProductForm.value.description,
      strManufacturerDetails: this.addProductForm.value.strManufacturerDetails,
      strFeature: this.addProductForm.value.strFeature,
      strProductDisclaimer: this.addProductForm.value.strProductDisclaimer,
      strBrand: this.addProductForm.value.strBrand,
      strProperties: this.addProductForm.value.properties,
      strSubCategoryId: this.subCategoryId,
      // strMoreDetails: this.addProductForm.value.description,
      strProductStatus: this.addProductForm.value.status,
      strUnit: this.addProductForm.value.unit,
      isInfiniteStock: this.addProductForm.value.isInfiniteStock,
      strQuantity: this.addProductForm.value.quantity,
      intStockQuantity: this.addProductForm.value.intStockQuantity,
      strSearchTags: this.addProductForm.value.searchTag,
      strBarcode: this.addProductForm.value.barcode,

      strMRP: this.addProductForm.value.price,
      strSellingPrice: this.addProductForm.value.currentPrice,
      strDiscount: this.addProductForm.value.discount,

      strMaxQuantity: this.addProductForm.value.maxproductQuantity,
      blnCOD: this.addProductForm.value.cod,
      blnReturnable: this.addProductForm.value.refund,
      blnFreeDelivery: this.addProductForm.value.freeDelivery,
      blnWarranty: this.addProductForm.value.warranty,
      ProductImages: this.imageFile, // this.imageFile.slice(1, this.imageFile.length-1)
      ProductThumbnail: this.imageFile[0],
      strLoginUserId: localStorage.getItem("userId"),
      strMinQuantity: this.addProductForm.value.minQty,
      strArticleNo: this.addProductForm.value.articleNumber,
      blnFrozenFood: this.addProductForm.value.frozenFood,
      blnCardOnDelivery: this.addProductForm.value.cardOnDelivery,
      blnPayOnline: this.addProductForm.value.payOnline,
      fkShopId: this.addProductForm.value.fkShopId,
      strCategoryId: this.addProductForm.value.category,
      blnPriceVariation: this.addProductForm.value.blnPriceVariation,
      strSeizeVariation: this.addProductForm.value.strSeizeVariation,
      strColorVariations: this.addProductForm.value.strColorVariations,
      arrayAddOnPriceDetails: arrPriceVariations,
      arraySizeVariations: arrSeizeVariations,
      arrayColourVariations: arrColorVariations,
      strVeg: this.addProductForm.value.strVeg,
      specialTag: this.addProductForm.value.specialTag,
    };
    console.log(obj, "add product ::::::::::::::::::::", arrColorVariations);
    this.submitted = true;
    if (this.addProductForm.valid) {
      //console.log("news")
      this.blnLoader = true;
      console.log("Add product::::::::", obj);

      this.myProductService.createProduct(obj).subscribe((res) => {
        console.log("RESPONSE ::::::", res);

        if (res.success === true) {
          this.blnLoader = true;
          arrPriceVariations = [];
          arrColorVariations = [];
          arrSeizeVariations = [];
          Swal.fire("Created!", "New product has been added.", "success");
          this.refreshPage();
        } else {
          this.blnLoader = true;
          arrPriceVariations = [];
          arrColorVariations = [];
          arrSeizeVariations = [];
          Swal.fire("Warning!", res.message, "warning");
        }
      });
    } else {
      this.blnLoader = true;
      this.submitted = true;

      //  if(!obj.strMRP || !obj.strSellingPrice){
      //   Swal.fire(
      //     'Warning!',
      //     'MRP or selling price missing',
      //     'warning'
      //   );
      //  }
      //  else if (obj.strDiscount<0){
      //   Swal.fire(
      //     'Warning!',
      //     'Selling price is higher than MRP',
      //     'warning'
      //   );
      //   }
      //  else if (!this.imageFile || !this.imageFile.length){
      //   Swal.fire(
      //     'Warning!',
      //     'Image data missing',
      //     'warning'
      //   );
      //  }else{
      //   Swal.fire(
      //     'Warning!',
      //     'Please fill the form properly or remove unwanted input fields!',
      //     'warning'
      //   );
      //  }

      return;

      // Swal.fire(
      //   'Error!',
      //   'Please check the form',
      //   'error'
      // );
    }
  }
}

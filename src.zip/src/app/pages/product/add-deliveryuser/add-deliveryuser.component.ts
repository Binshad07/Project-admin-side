
import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";
import { DeliveryUserService } from "src/app/shared/services/delivery-user/delivery-user.service";
// import { NgxSpinnerService } from "ngx-spinner";
import Swal from "sweetalert2";

@Component({
  selector: 'app-add-deliveryuser',
  templateUrl: './add-deliveryuser.component.html',
  styleUrls: ['./add-deliveryuser.component.scss']
})
export class AddDeliveryuserComponent implements OnInit {
  type = "Add";
  myForm: FormGroup;
  id = "";
  submitted = false;
  deliveryType: any;
  blnUpdate = false;
  userTypes = [];
  selectedCity = "";
  userType: any;
  blnAdmin = false;
  arrShop= [];

  constructor(
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private router: Router,
    private DeliveryUsers:DeliveryUserService,
    private companyService:CompanyServiceService,
    // private spinner: NgxSpinnerService,
  ) {}

  ngOnInit() {
    this.userType = localStorage.getItem('userRole')
   
    this.route.queryParams.subscribe((params) => {
      this.id = params["id"];
    });
    this.myForm = this.formBuilder.group({
      strUserName: ["", Validators.required],
      strEmail: ["", [Validators.required,Validators.email]],
      strPassword: ["", Validators.required],
      strVehicleNumber: ["", Validators.required],
      strVehicleType: ["", Validators.required],
      strStorageCapacity: ["", Validators.required],
      strPhone: ["", [Validators.required,Validators.pattern('^[0-9]{8,13}$')]],
      strCity: ["", Validators.required],
      cmbShopName:["", Validators.required], 
    });

      this. getAllShop();
    if (this.id) {
      this.getOneUser();
      this.blnUpdate = true;
      this.type = "Update";
      
      this.myForm.patchValue({
        strPassword:"password",
      })
    }
  }

  get f() {
    return this.myForm.controls;
  }

  getOneUser() {
    const obj = {
      pkStaffId: this.id,
      strUpdateUserId: localStorage.getItem("userId"),
    };
    // this.spinner.show();
    this.DeliveryUsers.getListDeliveryUser(obj).subscribe((res) => {
      console.log("User By Id :::::", res);

      if (res.success) {
        // this.spinner.hide();
        const datas = res.data.data;
        this.myForm.get("strPassword").disable();
        this.myForm.patchValue({
          strUserName: datas[0].strStaffName,
          strEmail: datas[0].strEmail,
          strVehicleNumber: datas[0].strVehicleNumber,
          strVehicleType: datas[0].strVehicleType,
          strStorageCapacity: datas[0].intStorageCapacity,
          strPhone: datas[0].strPhoneNumber,
          strCity: datas[0].strLocation,
          cmbShopName :datas[0].fkStoreId
        });
      }
      console.log(res,"Add Delivery User:::::::::::::::::::::");

    });
  }


  SaveUser() {
    this.submitted = true;
    if (this.myForm.invalid) {
      console.log('Invalid Form::::::');
      return;
    }
    const obj = {
      strName: this.myForm.value.strUserName,
      strEmail: this.myForm.value.strEmail,
      strPassword: this.myForm.value.strPassword,
      strPhoneNo: this.myForm.value.strPhone.toString(),
      strStorageCapacity: this.myForm.value.strStorageCapacity,
      strVehicleNumber: this.myForm.value.strVehicleNumber,
      strVehicleType: this.myForm.value.strVehicleType,
      strCity: this.myForm.value.strCity,
      strShopId:this.myForm.value.cmbShopName,
      strUpdateUserId: localStorage.getItem("userId"),
    };
    console.log(obj,"Add Delivery User:::::::::::::::::::::");
    
    this.DeliveryUsers.addDeliveryUser(obj).subscribe((res) => {
      if (res.success) {
        // this.spinner.hide();
        this.submitted = false;
        Swal.fire({
          title: "Saved!",
          text: "New delivery user has been created!",
          icon: "success",
          confirmButtonText: "Ok",
        }).then((result) => {
          if (result.value) {
            this.submitted = false;
            // this.myForm.reset();
            this.router.navigate(["/delivery-user"]);
          }
        });
       
      } else {
        // this.spinner.hide();
        Swal.fire({
          title: "Error",
          text: res.message,
          icon: "error",
          confirmButtonText: "Ok",
        });
      }
    },(err) => {
      console.log(err)
    });
  }

  onReset() {
    this.submitted = false;
    this.myForm.reset();
  }


  
  
  getAllShop(){
    const obj = {
      loginUserId:localStorage.getItem("userId"),
    }
    if(localStorage.getItem('fkShopId')){
      // Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
      if(res && res.success){
        console.log(res,"deliveryeeeeeeeeeee::::::::::::");
        
        this.arrShop = res.data
      }
    },(err) => {
      console.log(err)
    })
  }



  update() {
    this.submitted = true;

    if (this.myForm.invalid) {
      return;
    } else {
      const obj = {
        strName: this.myForm.value.strUserName,
        strEmail: this.myForm.value.strEmail,
        strPhoneNo: this.myForm.value.strPhone,
        strStorageCapacity: this.myForm.value.strStorageCapacity,
        strVehicleNumber: this.myForm.value.strVehicleNumber,
        strVehicleType: this.myForm.value.strVehicleType,
        strCity: this.myForm.value.strCity,
        strUpdateUserId: localStorage.getItem("userId"),
        pkStaffId: this.id,  
        strShopId:this.myForm.value.cmbShopName,

      };
      // this.spinner.show();
      this.DeliveryUsers.updateDeliveryUser(obj).subscribe((res) => {
        console.log("User Update ResponsE:::::", res);

        if (res.success) {
          // this.spinner.hide();
          this.submitted = false;
          Swal.fire({
            title: "Saved!",
            text: "Delivery user has been updated",
            icon: "success",
            confirmButtonText: "Ok",
          }).then((result) => {
            if (result.value) {
              this.submitted = false;
              // this.myForm.reset();
              this.router.navigate(["/delivery-user"]);
            }
          });
          // this.myForm.reset();
          this.router.navigate(["/delivery-user"]);
        } else {
          // this.spinner.hide();
          Swal.fire({
            title: "Error",
            text: res.message,
            icon: "error",
            confirmButtonText: "Ok",
          });
        }
      });
    }
  }
}
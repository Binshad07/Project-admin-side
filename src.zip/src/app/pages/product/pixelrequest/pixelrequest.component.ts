// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-pixelrequest',
//   templateUrl: './pixelrequest.component.html',
//   styleUrls: ['./pixelrequest.component.scss']
// })
// export class PixelrequestComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }
// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-analytics-request',
//   templateUrl: './analytics-request.component.html',
//   styleUrls: ['./analytics-request.component.scss']
// })
// export class AnalyticsRequestComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }

import { Component, OnInit } from '@angular/core';

import { PagerService } from "src/app/shared/services/pager.service";
import { FormGroup, FormBuilder } from "@angular/forms";
import { ReportsService } from "src/app/shared/services/Reports/reports.service";
import { modItemSales } from "src/app/shared/Classes/report.model";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";
import { DatePipe } from "@angular/common";
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';



@Component({
  selector: 'app-pixelrequest',
  templateUrl: './pixelrequest.component.html',
  styleUrls: ['./pixelrequest.component.scss']
})
export class PixelrequestComponent implements OnInit {
  //  myform: FormGroup;

  currentDate = new Date();
  frmItemSales: FormGroup;
  eventForm: FormGroup;
  pager: any = {};
  intTotalCount = 0;
  intPageLimit = 10;
  pageLimit: any[];
  strShopId = "";
  arrStores = [];
  intSkipCount = 0;
  datePipe = new DatePipe("en-US");
  // arrItemSales: modItemSales[] = [];
  arrItemSales: any[] = [];
  shops: any[] = [];
  fromDate;
  toDate;
  blnLoader = false;
  blnDownloadLoader = false;
  userType: string;
  arrShops:[];
  // withdrawAmount:"";
  status:""
  submitted = false
  strPixelId:[""]
  currentItem: any;
   arr = []
     arrPixel: [
    {
      AddToWishlist: true,
      AddToCart: true,
      PageView: true,
      Contact: true,
      Search: true,
      ViewContent: true
    }
  ]
  
  constructor(


    private pageServiceObj: PagerService,
    private reportServiceObj: ReportsService,
    private companyService: CompanyServiceService,
    private formBuilder: FormBuilder,
    private modalService: NgbModal,


  ) { }

  ngOnInit() {


    this.frmItemSales = this.formBuilder.group({
      txtFromDate: [""],
      txtToDate: [""],
      txtOrderId: [""],
      cmbShopName: "",
      drpPageLimit: "10",
      strPixelId:[""],
      status: "",
      strShopName:[""]
      
      // status:""
    });


    this.eventForm = this.formBuilder.group({
      AddToWishlist: [false],
      AddToCart: [false],
      PageView: [false],
      Contact: [false],
      Search: [false],
      ViewContent: [false]
    });
  
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getShopListingFn();
    this.getAllPixels();

  }


  get formControls() {
    return this.frmItemSales.controls;
  }

  _clearForm(form: FormGroup) {
    form.reset({
      txtFromDate: "",
      txtToDate: "",
      // txtOrderId: "",
      cmbShopName: "",
      drpPageLimit: "10",
      status:"",
      strPixelId:""
    });
    // this.intTotalCount = 0;
    // this.intSkipCount = 0;
    // this.intPageLimit = 10;
    this.getAllPixels();

  }

  _getPageLimit(value$) {
    this.intPageLimit = parseInt(this.frmItemSales.value.drpPageLimit);
    this.setPage(1);
  }


  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
this.getAllPixels();
  }


  getShopListingFn() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
    }
    if (localStorage.getItem('fkShopId')) {
      // Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
      this.arrStores = res.data;
      this.strShopId = res.data[0].pkShopId;
    });
  }
  // getAllShop() {
  //   const obj = {
  //     loginUserId: localStorage.getItem("userId"),
  //   }
  //   console.log(obj, "tesghjchbv")
  //   if (localStorage.getItem('fkShopId')) {
  //     // Object.assign(obj, { strShopId: localStorage.getItem('fkShopId') })
  //     Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

  //     // obj.fkShopId=localStorage.getItem('fkShopId')
  //   }
  //   this.companyService.fngetallCompany(obj).subscribe((res) => {

  //     this.arrShops = res.data
  //   })
  // }


  // strPixelId:any

// Search:any = false
  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    // this.Search = true
    this.getAllPixels();
  }

  _getShopId(id$) {
    this.strShopId = id$;
  }
  // openEventModal(content: any, item: any) {
  //   this.currentItem = item;
  //   this.modalService.open(content, { ariaLabelledBy: 'eventModalLabel' });



  // }


  openEventModal(modal: any, shop: any) {
    this.currentItem = shop;
    this.eventForm.patchValue(this.getEventValues(shop));
    this.modalService.open(modal);
  }

  getEventValues(shop: any) {
    const defaultValues = {
      AddToWishlist: false,
      AddToCart: false,
      PageView: false,
      Contact: false,
      Search: false,
      ViewContent: false
    }
  
  if (shop.shopSettings.arrPixel && shop.shopSettings.arrPixel[0]) {
    return { ...defaultValues, ...shop.shopSettings.arrPixel[0] };
  }
  return defaultValues;
}

  // openEventModal(content: any, item: any) {
  //   // this.currentItem = item;
  //   const pixelSettings = item.shopSettings?.arrPixel?.[0] || {};
  //   this.eventForm.patchValue({
  //     AddToWishlist: pixelSettings.AddToWishlist || false,
  //     AddToCart: pixelSettings.AddToCart || false,
  //     PageView: pixelSettings.PageView || false,
  //     Contact: pixelSettings.Contact || false,
  //     Search: pixelSettings.Search || false,
  //     ViewContent: pixelSettings.ViewContent || false
  //   });
  //   this.modalService.open(content, { ariaLabelledBy: 'eventModalLabel' });
  

  // openEventModal(content: any, item: any) {
  //   this.currentItem = item;
  //   const pixelSettings = item.shopSettings?.arrPixel?.[0] || {};
  //   this.eventForm.patchValue({
  //     AddToWishlist: pixelSettings.AddToWishlist || false,
  //     AddToCart: pixelSettings.AddToCart || false,
  //     PageView: pixelSettings.PageView || false,
  //     Contact: false, // Set default value if not available
  //     Search: false,  // Set default value if not available
  //     ViewContent: false // Set default value if not available
  //   });
  //   this.modalService.open(content, { ariaLabelledBy: 'eventModalLabel' });
  // }
  saveEventOptions() {
    const selectedOptions = this.eventForm.value;
    console.log('Selected options:', selectedOptions);
    this.modalService.dismissAll();
  }

  
  getAllPixels() {
    let skipCount = this.intSkipCount;
    this.blnLoader = false;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }

    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
    if (
      this.frmItemSales.value.txtFromDate === "txtFromDate" &&
      this.frmItemSales.value.txtToDate === "txtToDate"
    ) {
      console.log("From Date ::::", this.frmItemSales.value.txtFromDate);
      this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
      this.toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    }
    if (
      this.frmItemSales.value.txtFromDate &&
      this.frmItemSales.value.txtToDate === "txtToDate"
    ) {
      console.log("To Date ::::", this.frmItemSales.value.txtToDate);
      this.fromDate = `${this.frmItemSales.value.txtFromDate.year}-${this.frmItemSales.value.txtFromDate.month}-${this.frmItemSales.value.txtFromDate.day}`;
      this.toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    }
    if (
      this.frmItemSales.value.txtToDate &&
      this.frmItemSales.value.txtFromDate === "txtFromDate"
    ) {
      console.log("To Date ::::", this.frmItemSales.value.txtToDate);
      this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
      this.toDate = `${this.frmItemSales.value.txtToDate.year}-${this.frmItemSales.value.txtToDate.month}-${this.frmItemSales.value.txtToDate.day}`;
    }

    if (
      this.frmItemSales.value.txtFromDate &&
      this.frmItemSales.value.txtToDate
    ) {
      this.fromDate = `${this.frmItemSales.value.txtFromDate.year}-${this.frmItemSales.value.txtFromDate.month}-${this.frmItemSales.value.txtFromDate.day}`;
      this.toDate = `${this.frmItemSales.value.txtToDate.year}-${this.frmItemSales.value.txtToDate.month}-${this.frmItemSales.value.txtToDate.day}`;
    }

  
   
    
    const obj = {

      strLoginUserId: localStorage.getItem("userId"),
      strSkipCount: skipCount,
      strPageLimit: this.intPageLimit,
       strShopName: this.frmItemSales.value.cmbShopName,
      // strFromDate: this.fromDate, // fromTime
      // strToDdate: this.toDate,
      fromDate: this.fromDate,
      toDate: this.toDate,
      // strPixelId: strPixelId,
      strPixelId: this.frmItemSales.value.strPixelId,
      // "strPixelId": "978525840305521",
      //  fkDefaultDepartmentId: fkDepartmentId,


      //  status:this.frmItemSales.value.status
    }




    this.companyService. getAllPixels(obj).subscribe((res) => {

      
      

      if (res && res.success) {

        this.blnLoader = true;
        this.arrItemSales = res.data ;

        this.intTotalCount = res.count;
        this.arrItemSales = res.data;
        // if (res.data[0]) {
        //   this.intTotalCount = res.data.intTotalCount;
        // }
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
        
        this.arrPixel=res.data
        // console.log(this.arrPixel)
        // Assuming this.arrPixel is assigned the data from the response
// this.arrPixel = res.data;

// Declare the result as an array to hold multiple arrPixel objects
// let result: any[] = [];

// this.arrPixel.forEach((element) => {
//   if (element.shopSettings && element.shopSettings.arrPixel) {
//     result.push(element.shopSettings.arrPixel);
//   }
// });

// console.log(result);

// Initialize the result string to build the HTML
// let resultString: string = "<ul>";

// result.forEach(innerArray => {
//   innerArray.forEach(obj => {
//     let itemString: string = "<li>";
//     for (const key in obj) {
//       if (obj.hasOwnProperty(key)) {
//         itemString += `${key}: ${obj[key]}, `;
//       }
//     }
//     // Remove the trailing comma and space
//     if (itemString.endsWith(", ")) {
//       itemString = itemString.slice(0, -2);
//     }
//     itemString += "</li>";
//     resultString += itemString;
//   });
// });

// resultString += "</ul>";

// Get the modalEvent element and set its innerHTML
// const modalEventDiv = document.getElementById('modalEvent');
// if (modalEventDiv) {
//   modalEventDiv.innerHTML = resultString;
// }


    
      } else {
        this.arrItemSales = []

      }
    })
  }




  }

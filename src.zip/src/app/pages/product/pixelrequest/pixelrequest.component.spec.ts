import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PixelrequestComponent } from './pixelrequest.component';

describe('PixelrequestComponent', () => {
  let component: PixelrequestComponent;
  let fixture: ComponentFixture<PixelrequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PixelrequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PixelrequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadmultipleimageComponent } from './uploadmultipleimage.component';

describe('UploadmultipleimageComponent', () => {
  let component: UploadmultipleimageComponent;
  let fixture: ComponentFixture<UploadmultipleimageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UploadmultipleimageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadmultipleimageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import * as XLSX from "ts-xlsx";
import { ProductService } from "../../../shared/services/product.service";

@Component({
  selector: 'app-uploadmultipleimage',
  templateUrl: './uploadmultipleimage.component.html',
  styleUrls: ['./uploadmultipleimage.component.scss']
})
export class UploadmultipleimageComponent implements OnInit {
  constructor(private srvProduct: ProductService) {}
  blnImport = true;
  arrayBuffer: any;
  file: File;
  arrayAllData = new Array();
  arrayErrorData = new Array();
  arraySuccessData = new Array();
  fileError = false;
  ngOnInit() {}

  /*
    TODO @Function: THIS FUNCATION USE GET DATA FROM .xlsx file
    */

  convertFileXLSXFormate(ObjEvent: any) {
      this.arrayAllData = [];
      try {
          let extension = ObjEvent.target.files[0].name.split(".").pop();
          if (extension === "xlsx") {
              this.fileError = false;
              this.file = ObjEvent.target.files[0];
              let fileReader = new FileReader();
              fileReader.onload = (e) => {
                  this.arrayBuffer = fileReader.result;
                  var arrayOfData = new Uint8Array(this.arrayBuffer);
                  var arr = new Array();

                  for (var i = 0; i != arrayOfData.length; ++i)
                      arr[i] = String.fromCharCode(arrayOfData[i]);
                  var bstr = arr.join("");
                  var workbook = XLSX.read(bstr, { type: "binary" });
                  var str_first_sheet_name = workbook.SheetNames[0];
                  var worksheet = workbook.Sheets[str_first_sheet_name];
                  this.arrayAllData = XLSX.utils.sheet_to_json(worksheet, {
                      raw: true,
                  });
              };

              fileReader.readAsArrayBuffer(this.file);
              this.blnImport = false;
              ObjEvent.srcElement.value = null;
          } else {
              // console.log("else called");
              this.fileError = true;
          }
      } catch (err) {}
  }
  /*
    TODO @Function: THIS FUNCATION USE Clear Data 
    */

  onClickClearData(event) {
      event.srcElement.value = null;
      this.arrayAllData = [];
      this.blnImport = true;
      this.arrayAllData = [];
      this.arrayErrorData = [];
      this.arraySuccessData = [];
  }
  /*
    TODO @Function: THIS FUNCATION USE EDIT PRICE LIST TO DATABASE
    */

  UpdateImageData() {
      try {
          this.blnImport = true;
          if (this.arrayAllData.length) {
              this.srvProduct
                  .ImportProductImages(this.arrayAllData)
                  .subscribe((res) => {
                      if (res.success === true) {
                          this.arrayErrorData = res.data.arrayError;
                          this.arraySuccessData = res.data.arraySuccessData;
                          alert(res.message);
                      } else {
                          alert("update faild");
                      }
                  });
          } else {
              alert("Data not Found");
          }
      } catch (err) {
          alert("Error" + err);
      }
  }
}

import { Component, OnInit } from "@angular/core";
import { PagerService } from "src/app/shared/services/pager.service";
import { Router } from "@angular/router";
import { FormGroup, FormBuilder } from "@angular/forms";
import { DeliveryUserService } from "src/app/shared/services/delivery-user/delivery-user.service";
import Swal from "sweetalert2";
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-delivery-user',
  templateUrl: './delivery-user.component.html',
  styleUrls: ['./delivery-user.component.scss']
})
export class DeliveryUserComponent implements OnInit {

  intSkipCount = 0;
  intTotalCount = 0;
  intPageLimit = 10;
  pageLimit: any[];
  pager: any = {};
  DeliveryUser = [];
  frmFilter: FormGroup;
  pkStaffId: any;
  strStaffIdd: ""

  constructor(
    private pageServiceObj: PagerService,
    private router: Router,
    private formBuilder: FormBuilder,
    private DeliveryUsers: DeliveryUserService,
    private modalService: NgbModal,

  ) { }

  ngOnInit() {
    this.frmFilter = this.formBuilder.group({
      txtStaffName: [""],
      txtEmail: [""],
    });
    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getAllDeliveryUser();
  }


  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getAllDeliveryUser();
  }

  getAllDeliveryUser() {
    let skipCount = this.intSkipCount;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
    const obj = {
      strStaffName: this.frmFilter.value.txtStaffName,
      strEmail: this.frmFilter.value.txtEmail,
      strSkipCount: skipCount,
      strPageLimit: this.intPageLimit,
    }
    if (localStorage.getItem("fkShopId")) {
      Object.assign(obj, { fkShopId: localStorage.getItem("fkShopId") });
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.DeliveryUsers.getListDeliveryUser(obj).subscribe((res) => {
      if (res.success) {
        this.DeliveryUser = res.data.data
        console.log("delivery user", this.DeliveryUser)
        this.intTotalCount = res.data.total;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
      } else {
        this.DeliveryUser = [];
      }
    });
  }

  _clearFormFilter(form: FormGroup) {
    form.reset({
    });
    this.resetValues();
    this.getAllDeliveryUser();
  }

  resetValues() {
    this.pager = {}
    this.intTotalCount = 0;
    this.intSkipCount = 0;
    this.intPageLimit = 10;
  }


  edit(item) {
    this.router.navigate(["/add-deliveryuser"], {
      queryParams: { id: item.pkStaffId },
    });
  }

  deleteUser(responsiveDelete, item) {
    this.strStaffIdd = item.pkStaffId;
    this.modalService.open(responsiveDelete);
  }

  delete() {
    const obj = {
      pkStaffId: this.strStaffIdd,
      strUpdateUserId: localStorage.getItem('userId')
    }
    console.log(obj)
    this.DeliveryUsers.deleteDeliveryUser(obj).subscribe((res) => {
      if (res.success) {
        this.modalService.dismissAll();
        // this.spinner.hide();
        Swal.fire({
          title: "Delivery User Deleted!",
          text: 'Delivery User Deleted successfully',
          icon: "success",
          confirmButtonText: "Ok",
        }).then(() => {
          this.ngOnInit()
          this.getAllDeliveryUser()
        })
      } else {
        // this.spinner.hide();
        Swal.fire({
          title: "Error",
          text: res.message,
          icon: "error",
          confirmButtonText: "Ok",
        });
      }
      this.getAllDeliveryUser();
    }, (err) => {
      this.ngOnInit()
      console.log(err)
    })
  }
  
  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.getAllDeliveryUser();
  }
}
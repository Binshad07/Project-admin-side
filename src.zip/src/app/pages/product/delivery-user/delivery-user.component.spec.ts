import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeliveryUserComponent } from './delivery-user.component';

describe('DeliveryUserComponent', () => {
  let component: DeliveryUserComponent;
  let fixture: ComponentFixture<DeliveryUserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeliveryUserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeliveryUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";
import { Router } from '@angular/router';
import { Validators } from '@angular/forms';

@Component({
  selector: 'app-shop-settings',
  templateUrl: './shop-settings.component.html',
  styleUrls: ['./shop-settings.component.scss']
})
export class ShopSettingsComponent implements OnInit {

  frmOrderDetail: FormGroup;
  myform: FormGroup;
  arrShops = [];
  arrShop = [];
  submitted = false;


  constructor(
    private formBuilder: FormBuilder,
    private companyService: CompanyServiceService,
    private router: Router,
  ) { }

  ngOnInit() {
    this.frmOrderDetail = this.formBuilder.group({
      fkShopId: ['']
    });
    this.myform = this.formBuilder.group({
      txtName: ['',Validators.required],
      txtDescription: ['',Validators.required],
      txtViewType: ['',Validators.required],
      txtImageUrl: ['',Validators.required],
      blnStatus: [''],
      txtSortNo: ['',Validators.required],
    
      arabicName :['',Validators.required],
      imgFile : ['']
      
    })
    this.getAllShop();
  }

  _clear(form: FormGroup) {
    form.reset({
      txtMobileNo: ['']
    })
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    this.router.onSameUrlNavigation = 'reload';
    this.router.navigate(['shop-settings']);
  }

  onSearchFn(){
    const obj = {
      shopId:"",
      strLoginUserId: localStorage.getItem("userId"),
    }
    this.companyService.fngetallNewCompany(obj).subscribe((res) => {

      this.arrShop = res.data
    })
    console.log(this.arrShop)
  }

  getAllShop() {
    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
    }
    if (localStorage.getItem('fkShopId')) {
      Object.assign(obj, { strShopId: localStorage.getItem('fkShopId') })
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {

      this.arrShops = res.data
    })
  }
  getSaveDepartmentFn(){

  }
  
  _clearForm(){

  }

  get formControls() {
    return this.frmOrderDetail.controls;
  }

}

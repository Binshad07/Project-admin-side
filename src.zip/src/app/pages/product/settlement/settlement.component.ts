import { Router } from '@angular/router';
import { Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { HypermarketService } from './../../../shared/services/Hypermarket/hypermarket.service';
import { ProductService } from './../../../shared/services/product.service';
import { FormBuilder } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { PagerService } from 'src/app/shared/services/pager.service';
import { FormGroup } from '@angular/forms';
import Swal from 'sweetalert2';
import { ShopServiceService } from 'src/app/shared/services/shopService/shop-service.service';
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";

@Component({
  selector: 'app-settlement',
  templateUrl: './settlement.component.html',
  styleUrls: ['./settlement.component.scss']
})
export class SettlementComponent implements OnInit {

  frmSettlement: FormGroup;
  frmSettlementEdit: FormGroup;
  pager: any = {};
  intTotalCount = 0;
  intPageLimit = 10;
  datePipe = new DatePipe('en-US');
  pageLimit: any[];
  intSkipCount = 0;
  strCategoryId = '';
  blnLoader = false;
  submitted = false;
  arrOfSettlementList = [];
  arrViewType = [];
  arrShops = [];
  categoryImg: File[] = [];
  clicked = false;

  constructor(
    private pageServiceObj: PagerService,
    private myProductService: ProductService,
    private modalService: NgbModal,
    private hypermarketServiceObj: HypermarketService,
    private formBuilder: FormBuilder,
    private router: Router,
    private shopService: ShopServiceService,
    private companyService: CompanyServiceService
  ) { }

  ngOnInit() {
    this.frmSettlement = this.formBuilder.group({
      settlementTransactionId: ['',Validators.required],
      amount: ['', Validators.required],
      strStoreId: ['', Validators.required],
    });
    // this.frmSettlementEdit = this.formBuilder.group({
    //   txtName: [''],
    //   arabicName :[''] ,
    //   // txtDescription: [''],
    //   txtImageUrl: [''],
    //   blnStatus: [''],
    //   drpViewType: [''],

    //   txtSortNo: [''],
    //   fkShopId: [''],
    // });

    //this.getDepartmentFn();
    // this.pageLimit = this.pageServiceObj.showPagelist;
    this.getAllShop();
    this.pageLimit = this.pageServiceObj.showPagelist;
    // this.getSettlementTransactionFn();
  }
  get formControls() {
    return this.frmSettlement.controls;
  }

  // clearForm(){
  //   this.frmSettlement.reset();
  // }
  clear(){
    this.frmSettlement.reset();
  }

  refreshPage() {
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    this.router.onSameUrlNavigation = 'reload';
    this.router.navigate(['settlement']);
  }

  /*
  strDeptName strCategoryName
    TODO @Function: FUNCTION TO SET PAGE LIMIT
    */
  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }
  /*
    TODO @Function: FUNCTION TO SET PAGE NUMBER
    */
  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(this.intTotalCount, page, this.intPageLimit);
    // this.getSettlementTransactionFn();
  }

  /*
   TODO @Function: FUNCTION TO GET DEPARTMENT
   */
  getAllShop() {
    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
    }
    if (localStorage.getItem('fkShopId')) {
      Object.assign(obj, { strShopId: localStorage.getItem('fkShopId') })
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {

      this.arrShops = res.data
    })
  }

  // getSettlementTransactionFn() {
  
  //   let skipCount = this.intSkipCount;
  //   this.blnLoader = true;

  //   if (this.pager.intSkipCount) {
  //     skipCount = this.pager.intSkipCount;
  //   }

  //   const obj = {
  //     pkUserId: localStorage.getItem("userId"),
  //     intPageLimit: this.intPageLimit,
  //     intSkipCount: skipCount,
  //   };
  //   if(localStorage.getItem('fkShopId')){
  //     Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
  //     // obj.fkShopId=localStorage.getItem('fkShopId')
  //   }
  //   this.hypermarketServiceObj.getSettlementTransactionService(obj).subscribe((res) => {
  //     this.blnLoader = true;
  //     this.arrOfSettlementList = res.data[1];
  //     console.log(res)
  //     // this._clearForm(this.frmSubCategory)
  //     this.intTotalCount = res.data[0].intTotalCount;
  //     this.arrOfSettlementList = res.data[1];
      
  //     // this.intTotalCount = res.data.length;
  //     this.pager = this.pageServiceObj.getPager(
  //       this.intTotalCount,
  //       this.pager.currentPage,
  //       this.intPageLimit
  //     );

      

  //   })

  // }

  saveSettlementTransactionFn() {
    this.blnLoader = false;
    this.submitted = true;
    // this.submitted = !this.submitted;
    if (this.frmSettlement.invalid) {
      this.blnLoader = true;
      return;
    }
    const obj = {
      settlementTransactionId: this.frmSettlement.value.settlementTransactionId,
      amount: this.frmSettlement.value.amount,
      strStoreId: this.frmSettlement.value.strStoreId,
      strLoginUserId: localStorage.getItem('userId'),
    };
 
    this.clicked = true;

    this.hypermarketServiceObj.saveSettlementTransactionService(obj).subscribe((res => {
      console.log(res,"ufieeeeeeeeeeeeeeeeeeeeeeeeeee")

      if (res.success === true) {
        this.clicked = false;
        // this.blnLoader = true;
        Swal.fire({
          title: "Saved!",
          text: "New Settlement Transaction Saved Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then(() => {
          this.router.navigate(['/product/settlement-list'])
          // this.refreshPage()
          // this.getSettlementTransactionFn();
        })
      } else {
        this.blnLoader = true;
        Swal.fire({
          title: "Error",
          text: res.message,
          icon: "error",
          confirmButtonText: "Ok",
        })
        alert(res.message)
      }
      // this.getSettlementTransactionFn();
    }));
  }

  getViewTypeFn() {
    const obj ={}
    if (localStorage.getItem('strUserType') == 'SHOP REPORTER') {
      Object.assign(obj,{
       strViewTypeName: localStorage.getItem("strViewType"),
     }) 
   }
    this.hypermarketServiceObj.getVieType(obj).subscribe((res) => {
      console.log(res, "resssviwetype")
      this.arrViewType = res.data;
      console.log(this.arrViewType, "console")
    })
  }

  onFileChange(event) {
    console.log("event")
    for (let i of event.target.files) {
      this.categoryImg.push(i);
    }
  }

  //  _getShoptId($ShopId) {
  //   this.strShopId = $ShopId;
  //   this.getListCategoryFn($ShopId);
  // }

}

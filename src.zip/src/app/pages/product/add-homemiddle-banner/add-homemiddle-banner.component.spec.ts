import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddHomemiddleBannerComponent } from './add-homemiddle-banner.component';

describe('AddHomemiddleBannerComponent', () => {
  let component: AddHomemiddleBannerComponent;
  let fixture: ComponentFixture<AddHomemiddleBannerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddHomemiddleBannerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddHomemiddleBannerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

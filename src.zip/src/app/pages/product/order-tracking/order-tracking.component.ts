import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { NeworderServiceService } from 'src/app/shared/services/neworder/neworder-service.service';
import { OrderService } from 'src/app/shared/services/order.service';

@Component({
  selector: 'app-order-tracking',
  templateUrl: './order-tracking.component.html',
  styleUrls: ['./order-tracking.component.scss']
})
export class OrderTrackingComponent implements OnInit {
  arrOrderTracking: any = [];
  frmOrderTracking: FormGroup;
  strOrderId: String = '';
  OrderStatus: string = '';

  constructor(
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private orderService: OrderService,

  ) { }

  ngOnInit() {
    this.route.queryParams.subscribe((parmas) => {
      this.strOrderId = parmas.id ? parmas.id : ''
    })

    this.frmOrderTracking = this.formBuilder.group({
      txtOrderNo: [""],
    });

    if (this.strOrderId) {
      this.frmOrderTracking.patchValue({ txtOrderNo: this.strOrderId });
      this.frmOrderTracking.get('txtOrderNo').disable()
    }
    if (this.strOrderId) {
      this.frmOrderTracking.patchValue({
        txtOrderNo: this.strOrderId
      })
    }
    this.getOrderDetails()
  }


  _clearForm() {
    this.frmOrderTracking.reset()
  }

  onSearch() {
    this.strOrderId = this.frmOrderTracking.value.txtOrderNo.toUpperCase()
    // this.getOrderTracking()
  }

  getOrderDetails() {

    let obj = {
      strOrderID: this.strOrderId
    }

    this.orderService.getSingleOrderDetails(obj).subscribe((res) => {
      if (res && res.success) {
        this.arrOrderTracking = res.data[0];
        console.log("order details ::::::::::::::::::::::::::::::::::", this.arrOrderTracking)
      } else {
        this.arrOrderTracking = []
      }
    })
  }

  mapModal(orderMapModal) {

    let obj = {
      strOrderID: orderMapModal.strOrderId
    }

    this.orderService.getSingleOrderDetails(obj).subscribe((res) => {
      if (res && res.success) {
        this.arrOrderTracking = res.data[0];
        console.log("order details ::::::::::::::::::::::::::::::::::", this.arrOrderTracking)
      } else {
        this.arrOrderTracking = []
      }
    })
  }

}








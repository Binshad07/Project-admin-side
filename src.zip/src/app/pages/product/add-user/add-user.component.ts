import { Component, OnInit } from '@angular/core';
import { UserGroupService } from "src/app/shared/services/UserGroup/user-group.service";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { ShopServiceService } from 'src/app/shared/services/shopService/shop-service.service';
import { CompanyServiceService } from 'src/app/shared/services/company/company-service.service';
import Swal from "sweetalert2";


@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.scss']
})
export class AddUserComponent implements OnInit {
  type = "Add";
  myForm: FormGroup;
  id = "";
  submitted = false;
  deliveryType: any;
  blnUpdate = false;
  userTypes = [];
  countries = [];
  selectedCity = "";
  arrShop = [];
  arrFranchise =[];
  franchiseId:string ="";
  blnAdmin = false;
  userType: any;
  strShopId = "";
  strFranchiseId = "";
  

  constructor(
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    // private userService: UsersService,
    private shopService: ShopServiceService,
    private router: Router,
    // private spinner: NgxSpinnerService,
    private userGroupService: UserGroupService,
    // private franchiseService: FranchiseService,
    private companyService:CompanyServiceService,
  ) { }

  ngOnInit() {
    this.userType = localStorage.getItem('userRole')
    if(this.userType === null || this.userType === '' || this.userType === undefined ){
      this.blnAdmin = !this.blnAdmin;
    } else {
      this.strShopId = localStorage.getItem('shopId');
      this.strFranchiseId=localStorage.getItem('franchiseId')
      
      
    }
    this.getUserType();
    this.getAllShop();
    // this.getFranchise();
    this.route.queryParams.subscribe((params) => {
      this.id = params["id"];
    });
    this.myForm = this.formBuilder.group({
      strUserName: ["", Validators.required],
      strEmail: ["",  [Validators.required, Validators.email]],
      strPassword: ["", Validators.required],
      strUserTypeId: ["", Validators.required],
      strShopId: ["", Validators.required],
      
      strShop: [""],
    });

    if (this.id) {
      this.myForm.get('strPassword').disable();
      this.getallUsers();
      this.blnUpdate = true;
      this.type = "Update";
    }
  }

  get f() {
    return this.myForm.controls;
  }

  // getFranchise(){
  //   let obj={
  //     strLoginUserId:localStorage.getItem("userId")
  //   }
  
  //   this.franchiseService.getAllFranchise(obj).subscribe((res)=>{
  //     if(res.success){
  //       this.arrFranchise=res.data.data
  //     }else{
  //       this.arrFranchise=[]
  //     }
  //   })
  // }

  getFranchiseId(id){
    this.arrShop =[];
    if(!id){
      return
    }
    this.franchiseId=id;
    
    this.getAllShop();
  
  }

  getUserType() {
    const obj = {
      strSkipCount: "",
      strPageLimit: "500",
    };
    this.userGroupService.getAllUserGroup(obj).subscribe((res) => {
      this.userTypes = res.data.data;
    });
  }

  // getOneUser() {
  //   const obj = {
  //     strSkipCount: "",
  //     strPageLimit: "500",
  //     strUpdateUserId: localStorage.getItem("userId"),
  //     pkUserId: this.id,


  //   };
  //   // this.spinner.show();
  //   this.userGroupService.getAdminList(obj).subscribe((res) => {
  //     if (res.success) {
  //       // this.spinner.hide();
  //       const datas = res.data.data;
  //       for (let i = 0; i < datas.length; i++) {
  //         const element = datas[i];
  //         if (element.pkUserId === this.id) {
  //           this.myForm.patchValue({
  //             strUserName: element.strUserName,
  //             strEmail: element.strEmail,
  //             strUserTypeId: element.strUserTypeId,
  //             rdbUserRole:element.strUserRole
            
              
  //           });
  //           if(!element.strUserRole){
  //             this.myForm.patchValue({
           
  //               rdbUserRole:"SHOP"
                
  //             });
  //           }

  //           this.myForm.patchValue({
  //             strFranchiseId:element.fkFranchiseId,
  //             //strShop: element.fkShopId,
              
  //           });
  //           this.franchiseId=element.fkFranchiseId,
  //           this.getAllShop();

  //           if(this.myForm.value.rdbUserRole =='SHOP'){
  //             this.myForm.patchValue({
           
  //               strShopId: element.fkShopId,
                
  //             });
  //           }            
  //         }
  //       }
  //     }
  //   });
  // }



  getallUsers() {
    const obj = {
      strUpdateUserId: localStorage.getItem("userId"),
      pkUserId: this.id,
    };
    console.log(obj);
    this.userGroupService.getAdminList(obj).subscribe((res) => {
      console.log("resonseeeeeeeee", res);
      this.myForm.patchValue({
        strUserName: res.data[0].strUserName,
        strEmail: res.data[0].strEmail,
        strUserTypeId : res.data[0].fkUserTypeId,
        strShopId: res.data[0].fkShopId,
        // strShopId:res.data[0]. strShopId
      });
    });
    console.log(this.myForm,"res:::::::")


  }



  save() {
    console.log(this.myForm.value,this.userTypes,"formconsoleeeeeeeeeee")

    this.submitted = true;
    if (this.myForm.invalid) {
      return;
    }
    else {
      let strUserType
      for (let i = 0; i < this.userTypes.length; i++) {
        if (this.userTypes[i].pkUserTypeId == this.myForm.value.strUserTypeId) {
          strUserType = this.userTypes[i].strUserType;
        }
      }
      const obj = {
        strUserName: this.myForm.value.strUserName,
        strEmail: this.myForm.value.strEmail,
        strPassword: this.myForm.value.strPassword,

        strUserType: strUserType,
        loginUserId: localStorage.getItem("userId"),
        fkShopId: this.myForm.value.strShopId,
      };
      this.userGroupService.createNewAdmin(obj).subscribe((res) => {
        console.log(res,"testttttttt")
        if (res.success) {
          this.submitted = false;
          Swal.fire(
            'Created!',
            'New user has been added.',
            'success')
            let userTypeId
            for (let i = 0; i < this.userTypes.length; i++) {
              if (this.userTypes[i].strUserType == res.data.strUserType) {
                userTypeId = this.userTypes[i].pkUserTypeId;
              }
            }
          this.router.navigate(["/user-permissions"], {
            queryParams: {
              id: res.data.pkUserId,
              userTypeId:userTypeId,
              user: true
            },
          });
        } else {
          // this.spinner.hide();
          Swal.fire({
            title: "Error",
            text: res.message,
            icon: "error",
            confirmButtonText: "Ok",
          });
        }
      });
    }
  }

  onReset() {
    this.submitted = false;
    this.myForm.reset({
      strUserName:"",
      strEmail: "",
      strPassword: "",
      strUserTypeId: "",
      rdbUserRole: "FRANCHISE",
      strFranchiseId:"",
      strShop: "",

    });
  }

  update() {
    console.log(this.myForm,"formconsoleeeeeeeeeee")
    this.submitted = true;
    if (this.myForm.invalid) {

      return;
    } 
    else {
      let strUserType
      for (let i = 0; i < this.userTypes.length; i++) {
        if (this.userTypes[i].pkUserTypeId == this.myForm.value.strUserTypeId) {
          strUserType = this.userTypes[i].strUserType;
        }
      }
      const obj = {
        strUserName: this.myForm.value.strUserName,
        // strPassword: this.myForm.value.strPassword,
        strEmail: this.myForm.value.strEmail,
        pkUserId: this.id,
        strUserType:this.myForm.value.strUserType,
        fkShopId: this.myForm.value.strShopId,
        loginUserId: localStorage.getItem("userId"),
      };

      if(this.myForm.value.rdbUserRole =="SHOP"){
        if(!this.myForm.value.strShopId){
          Swal.fire({
            title: "Warning",
            text: 'Please select a shop',
            icon: "error",
            confirmButtonText: "Ok",
          });
          return;
  
        }
      }
      // this.spinner.show();
      this.userGroupService.updateAdmin(obj).subscribe((res) => {
        // console.log('User Update ResponsE:::::', res);

        if (res.success) {

          Swal.fire({
            title: "Updated!",
            text: "Admin user has been updated",
            icon: "success",
            confirmButtonText: "Ok",
          }).then((result) => {
            if(result.value){
              this.submitted = false;
              this.router.navigate(["/user"]);
            }
          })


          // this.spinner.hide();
          // this.submitted = false;
          // this.myForm.reset();
          // this.router.navigate(["/user"]);
        } else {
          // this.spinner.hide();
          Swal.fire({
            title: "Error",
            text: res.message,
            icon: "error",
            confirmButtonText: "Ok",
          });
        }
      });
    }
  }

  getAllShop() {
    const obj = {
      loginUserId:localStorage.getItem("userId"),
    }
    if(localStorage.getItem('fkShopId')){
      // Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
      console.log(res)
      if(res && res.success){
        this.arrShop = res.data
      }
    },(err) => {
      console.log(err)
    })
}
}
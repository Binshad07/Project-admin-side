import { environment } from "./../../../../environments/environment.prod";
import { Component, OnInit } from "@angular/core";
import { PagerService } from "src/app/shared/services/pager.service";
import { DatePipe } from "@angular/common";
import { FormBuilder, FormGroup } from "@angular/forms";
import { ReportsService } from "src/app/shared/services/Reports/reports.service";
import { modCancel } from "src/app/shared/Classes/report.model";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";

@Component({
  selector: "app-cancelled-report",
  templateUrl: "./cancelled-report.component.html",
  styleUrls: ["./cancelled-report.component.scss"],
})
export class CancelledReportComponent implements OnInit {
  frmCancelledOrder: FormGroup;
  currentDate = new Date();
  pager: any = {};
  intTotalCount = 0;
  intPageLimit = 10;
  datePipe = new DatePipe("en-US");
  pageLimit: any[];
  strShopId = "";
  arrStores = [];
  intSkipCount = 0;
  arrCancelOrder: modCancel[] = [];
  fromDate;
  toDate;
  loading = false;
  blnLoader = false;
  blnDownloadLoader = false;
  userType: string;

  private apiURL: string = environment.API_ENDPOINT;

  constructor(
    private pageServiceObj: PagerService,
    private formBuilder: FormBuilder,
    private companyService:CompanyServiceService,
    private reportServiceObj: ReportsService
  ) {}

  ngOnInit() {
    this.frmCancelledOrder = this.formBuilder.group({
      txtFromDate: [""],
      txtToDate: [""],
      txtOrderId: [""],
      cmbShopName: "",
      drpPageLimit: "10",
    });
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getShopListingFn();
    this.getOrderCancelFn();
    this.userType=localStorage.getItem("strUserType");
  }

  _clearForm(form: FormGroup) {
    form.reset({
      txtFromDate: "",
      txtToDate: "",
      txtOrderId: "",
      cmbShopName: "",
      drpPageLimit: "10",
    });
    this.intTotalCount = 0;
    this.intSkipCount = 0;
    this.intPageLimit = 10;
    this.getOrderCancelFn();
  }

  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }
  _getShopId(id$) {
    this.strShopId = id$;
  }
  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getOrderCancelFn();
  }

  getShopListingFn() {
    const obj = {
      loginUserId:localStorage.getItem("userId"),
    }
    if(localStorage.getItem('fkShopId')){
      // Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
      this.arrStores = res.data;
      this.strShopId = res.data[0].pkShopId;
    });
  }
  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.getOrderCancelFn();
  }

  getOrderCancelFn() {
    let skipCount = this.intSkipCount;
    this.blnLoader = false;

    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }

    if (
      this.frmCancelledOrder.value.txtFromDate === "" &&
      this.frmCancelledOrder.value.txtToDate === ""
    ) {
      console.log("From Date ::::", this.frmCancelledOrder.value.txtFromDate);
      this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
      this.toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    }
    if (
      this.frmCancelledOrder.value.txtFromDate &&
      this.frmCancelledOrder.value.txtToDate === ""
    ) {
      console.log("To Date ::::", this.frmCancelledOrder.value.txtToDate);
      this.fromDate = `${this.frmCancelledOrder.value.txtFromDate.year}-${this.frmCancelledOrder.value.txtFromDate.month}-${this.frmCancelledOrder.value.txtFromDate.day}`;
      this.toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    }
    if (
      this.frmCancelledOrder.value.txtToDate &&
      this.frmCancelledOrder.value.txtFromDate === ""
    ) {
      console.log("To Date ::::", this.frmCancelledOrder.value.txtToDate);
      this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
      this.toDate = `${this.frmCancelledOrder.value.txtToDate.year}-${this.frmCancelledOrder.value.txtToDate.month}-${this.frmCancelledOrder.value.txtToDate.day}`;
    }

    if (
      this.frmCancelledOrder.value.txtFromDate &&
      this.frmCancelledOrder.value.txtToDate
    ) {
      this.fromDate = `${this.frmCancelledOrder.value.txtFromDate.year}-${this.frmCancelledOrder.value.txtFromDate.month}-${this.frmCancelledOrder.value.txtFromDate.day}`;
      this.toDate = `${this.frmCancelledOrder.value.txtToDate.year}-${this.frmCancelledOrder.value.txtToDate.month}-${this.frmCancelledOrder.value.txtToDate.day}`;
    }
    const obj = {
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
      strStoreId: this.frmCancelledOrder.value.cmbShopName, // this.strShopId
      strFromDate: this.fromDate, // fromTime
      strToDdate: this.toDate, // toTime
      strOrderNo: this.frmCancelledOrder.value.txtOrderId.toUpperCase(),
    };
    if(localStorage.getItem('fkShopId')){
      Object.assign(obj,{strStoreId: localStorage.getItem('fkShopId')})
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }

    console.log("OBJECT BEFROE::::::::", obj);

    this.reportServiceObj.getCancelOrderService(obj).subscribe((res) => {
      this.blnLoader = true;

      this.arrCancelOrder = res.data[1];
      if (res.data[0]) {
        this.intTotalCount = res.data[0].intTotalCount;
      }
      this.pager = this.pageServiceObj.getPager(
        this.intTotalCount,
        this.pager.currentPage,
        this.intPageLimit
      );
      console.log("Cancell order Respinse::::::", res);
    });
  }

  getDownloadExcel() {
    this.blnDownloadLoader = !this.blnDownloadLoader;
    const obj = {
      strStoreId: this.frmCancelledOrder.value.cmbShopName, // this.strShopId
      strFromDate: this.fromDate, // fromTime
      strToDdate: this.toDate, // toTime
      strOrderNo: this.frmCancelledOrder.value.txtOrderId.toUpperCase(),
      strDataType: "EXCEL",
    };

    this.reportServiceObj.getCancelOrderService(obj).subscribe((res) => {
      this.blnDownloadLoader = !this.blnDownloadLoader;
      console.log("RESPONSE EXCEL", res);
      const strPath = this.apiURL + "/" + res.data;
      window.location.href = strPath;

    });
  }
}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CancelledReportComponent } from './cancelled-report.component';

describe('CancelledReportComponent', () => {
  let component: CancelledReportComponent;
  let fixture: ComponentFixture<CancelledReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CancelledReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CancelledReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { PagerService } from "src/app/shared/services/pager.service";
import { ReportsService } from "src/app/shared/services/Reports/reports.service";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { DatePipe } from "@angular/common";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";


@Component({
  selector: 'app-order-transaction-report',
  templateUrl: './order-transaction-report.component.html',
  styleUrls: ['./order-transaction-report.component.scss']
})
export class OrderTransactionReportComponent implements OnInit {


  myform: FormGroup;
  currentDate = new Date();
  pager: any = {};
  intTotalCount = 0;
  intSkipCount = 0;
  intPageLimit = 10;
  arrStores = [];
  datePipe = new DatePipe("en-US");
  pageLimit: any[];
  arrorderReport = [];
  blnLoader = false;
  strShopId = "";

  arrShops = [];
  submitted = false;
  constructor(
    private pageServiceObj: PagerService,

    private formBuilder: FormBuilder,
    private companyService: CompanyServiceService,
    private reportService: ReportsService,


  ) { }

  ngOnInit() {

    this.myform = this.formBuilder.group({
      txtFromDate: [""],
      txtToDate: [""],
      fkShopId: ["", Validators.required],
      txtorderid: ["", Validators.required],
      drpPageLimit: "10",




    });
    // this.pageLimit = this.pageServiceObj.showPagelist;
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getAllShop();
    this.getRazorpayReport()



  }


  _clearForm(form: FormGroup) {
    form.reset({
      txtFromDate: "",
      txtToDate: "",
      fkShopId: "",
      txtorderid: "",
      drpPageLimit: "10",
    });
    this.intTotalCount = 0;
    this.intSkipCount = 0;
    this.intPageLimit = 10;
    this.getAllShop();
  }




  _getPageLimit(value$) {
    this.intPageLimit = parseInt(this.myform.value.drpPageLimit);
    this.setPage(1);
  }


  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getRazorpayReport()
  
  }


  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.getRazorpayReport();
  }



  get formControls() {
    return this.myform.controls;
    fkShopId: this.myform.value.fkShopId
  }

  getAllShop() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),

    }
    console.log(obj, "tesghjchbv")
    if (localStorage.getItem('fkShopId')) {
    
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

     
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {

      this.arrShops = res.data
    

    })
  }

  getRazorpayReport() {

    let skipCount = this.intSkipCount;
    this.blnLoader = false;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }

    const obj = {


      strShopId: this.myform.value.fkShopId,
      // datCreateDateAndTime:this.myform.value.strFromDate,
      strLoginUserId: localStorage.getItem("userId"),

      
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
    


    }
    if (localStorage.getItem('fkShopId')) {
      Object.assign(obj, { fkShopId: localStorage.getItem('fkShopId') })
      
    }


    this.reportService.getRazorpayReport(obj).subscribe((res) => {
      console.log("jpg", res)
      if (res && res.success) {

        this.blnLoader = true;
        this.arrorderReport = res.data;
        this.intTotalCount = res.count;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
      } else {
        this.arrorderReport = []

      }
    })
  }

}



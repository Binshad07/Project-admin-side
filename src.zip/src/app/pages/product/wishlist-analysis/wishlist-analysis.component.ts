import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { OrderService } from 'src/app/shared/services/order.service';
import { PagerService } from 'src/app/shared/services/pager.service';
import { ReturnReportService } from 'src/app/shared/services/Reports/return-report.service';
import { DatePipe } from '@angular/common';
import { ReportsService } from 'src/app/shared/services/Reports/reports.service';

@Component({
  selector: 'app-wishlist-analysis',
  templateUrl: './wishlist-analysis.component.html',
  styleUrls: ['./wishlist-analysis.component.scss'],
})
export class WishlistAnalysisComponent implements OnInit {
  userDetailsArray = [];
  shopListArray = [];
  formUserDetails: FormGroup;
  currentDate  = new Date();
  pager: any = {};
  intTotalCount = 0;
  intSkipCount = 0;
  intPageLimit = 10;
  arrStores = [];
  datePipe = new DatePipe('en-US');
  pageLimit: any[];
  blnLoader = false;


  constructor(
    private returnReportService: ReturnReportService,
    private formBuilder: FormBuilder,
    private reportServiceObj: ReportsService,
    private pageServiceObj: PagerService,
  ) {}

  ngOnInit() {

    this.formUserDetails = this.formBuilder.group({
      txtFromDate      :  [''],
      txtToDate        :  [''],
      txtEmail         :  [''],
      txtPhoneNumber   :  [''],
      drpPageLimit     : "10",
    });
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getShopListingFn();
    this.getUserData();
  }

   _clearForm(form: FormGroup) {
    form.reset({
      txtFromDate      :  '',
      txtToDate        :  '',
      txtEmail         :  '',
      txtPhoneNumber   :  '',
      drpPageLimit     : "10",
    });
    this.intTotalCount = 0;
    this.intSkipCount = 0;
    this.intPageLimit = 10;
    this.getUserData();
  }

  _getPageLimit(value$) {
    this.intPageLimit = parseInt(this.formUserDetails.value.drpPageLimit);
    this.setPage(1);
  }
  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(this.intTotalCount, page, this.intPageLimit);
    this.getUserData();
  }

  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.getUserData();
  }

  getShopListingFn() {
    this.reportServiceObj.getShopListingService().subscribe((res) => {
      this.arrStores = res.data;
    });
  }

  getUserData() {
    this.blnLoader = false;
    let skipCount = this.intSkipCount;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
    let fromDate;
    let toDate;
    if (this.formUserDetails.value.txtFromDate === '' && this.formUserDetails.value.txtToDate === '') {
      console.log('From Date ::::', this.formUserDetails.value.txtFromDate);
      fromDate = this.datePipe.transform(this.currentDate, 'yyyy-M-dd');
      toDate = this.datePipe.transform(this.currentDate, 'yyyy-M-dd' );
    }
    if (this.formUserDetails.value.txtFromDate && this.formUserDetails.value.txtToDate === '') {
      console.log('To Date ::::', this.formUserDetails.value.txtToDate);
      fromDate = `${this.formUserDetails.value.txtFromDate.year}-${this.formUserDetails.value.txtFromDate.month}-${this.formUserDetails.value.txtFromDate.day}`;
      toDate = this.datePipe.transform(this.currentDate, 'yyyy-M-dd' );
    }
    if (this.formUserDetails.value.txtToDate && this.formUserDetails.value.txtFromDate === '') {
      console.log('To Date ::::', this.formUserDetails.value.txtToDate);
      fromDate = this.datePipe.transform(this.currentDate, 'yyyy-M-dd');
      toDate = `${this.formUserDetails.value.txtToDate.year}-${this.formUserDetails.value.txtToDate.month}-${this.formUserDetails.value.txtToDate.day}`;
    }

    if (this.formUserDetails.value.txtFromDate && this.formUserDetails.value.txtToDate) {
      fromDate = `${this.formUserDetails.value.txtFromDate.year}-${this.formUserDetails.value.txtFromDate.month}-${this.formUserDetails.value.txtFromDate.day}`;
      toDate = `${this.formUserDetails.value.txtToDate.year}-${this.formUserDetails.value.txtToDate.month}-${this.formUserDetails.value.txtToDate.day}`;
    }
    if (this.formUserDetails.value.txtPhoneNumber === null || this.formUserDetails.value.txtPhoneNumber === undefined) {
      this.formUserDetails.value.txtPhoneNumber = '';
    }
    const obj = {
      strSkipCount: skipCount,
      strPageLimit: this.intPageLimit,
      strFromDate: fromDate, // fromDate,
      strToDdate: toDate, // toDate,
      strPhone : (this.formUserDetails.value.txtPhoneNumber) + '', // (this.formUserDetails.value.txtPhoneNumber).toString() 7034674705,
      strEmail: this.formUserDetails.value.txtEmail
    };
    console.log('OBJECT :::::::::::', obj);

      // console.log("---", obj);

    this.returnReportService.GetWishlistAnalysis(obj).subscribe((res) => {
        console.log('RESPONESSS::::::::::', res);
        this.blnLoader = true;
        this.userDetailsArray = res.data[1];
        if (res.data[0].intTotalCOunt) {
          this.intTotalCount = res.data[0].intTotalCOunt;
          console.log('Totalcount::::::', this.intTotalCount      );

        }
        this.pager = this.pageServiceObj.getPager(this.intTotalCount, this.pager.currentPage, this.intPageLimit);
      });



  }

}

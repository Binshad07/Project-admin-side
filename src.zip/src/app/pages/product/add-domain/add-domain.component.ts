import { Component, OnInit } from "@angular/core";
import Swal from "sweetalert2";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { BannerServiceService } from "src/app/shared/services/BannerService/banner-service.service";
// import { BannersService } from 'src/app/shared/services/banners.service';
import { DatePipe } from "@angular/common";
import { PagerService } from "src/app/shared/services/pager.service";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";

@Component({
  selector: "app-add-domain",
  templateUrl: "./add-domain.component.html",
  styleUrls: ["./add-domain.component.scss"],
})
export class AddDomainComponent implements OnInit {

  myForm: FormGroup;
  pager: any = {};
  intTotalCount = 0;
  intPageLimit = 10;
  pageLimit: any[];
  intSkipCount = 0;
  strCategoryId = "";
  blnLoader = false;
  submitted = false;
  Arrbanner = [];
  arrViewType = [];
  arrShop = [];
  bannerImg: File[] = [];
  id = "";
  type = "Add";
  blnUpdate = false;
  clicked = false;

  constructor(
    private bannerService: BannerServiceService,
    private pageServiceObj: PagerService,
    private modalService: NgbModal,
    private formBuilder: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private companyService: CompanyServiceService
  ) {}

  ngOnInit() {
    this.route.queryParams.subscribe((params) => {
      this.id = params["id"];
    });
    this.myForm = this.formBuilder.group({
      cmbShopName: ["", Validators.required],
      strDn1: ["", Validators.required],
      strDn2: ["", Validators.required],
      strDn3: ["", Validators.required],
      strDn4: ["", Validators.required],
    });

    if (this.id) {
      this.type = "Update";
      this.getallDomain();
  
    }

    this.getAllShop();

  }

  get f() {
    return this.myForm.controls;
  }

  getAllShop() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
    };
    if (localStorage.getItem("fkShopId")) {
      // Object.assign(obj, { strShopId: localStorage.getItem("fkShopId") });
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    // if(localStorage.getItem('fkShopId')){
    //   Object.assign(obj,{fkShopId: localStorage.getItem('fkShopId')})
    //   // obj.fkShopId=localStorage.getItem('fkShopId')
    // }
    
    this.companyService.fngetallCompany(obj).subscribe((res) => {
      this.arrShop = res.data;
    });
  }


  getallDomain() {
    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
      fkShopId: this.id,
    };
    console.log(obj);
    this.bannerService.ListDomain(obj).subscribe((res) => {
      if (res && res.success) {

      this.myForm.patchValue({
        cmbShopName: res.data[0].fkShopId,
        strDn1: res.data[0].DN1,
        strDn2: res.data[0].DN2,
        strDn3: res.data[0].DN3,
        strDn4: res.data[0].DN4,
      });
    }
    });
  }


  UpdateDomain() {
    this.submitted = true;
    if (this.myForm.invalid) {
      return;
    }
    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
      fkShopId  : this.myForm.value.cmbShopName,
      dn1: this.myForm.value.strDn1,
      dn2: this.myForm.value.strDn2,
      dn3: this.myForm.value.strDn3,
      dn4: this.myForm.value.strDn4,
      pkDomainId: this.id,


    };
    this.bannerService.AddDomain(obj).subscribe(
      (res) => {
        if (res.success) {
          // this.spinner.hide()
          Swal.fire({
            title: "Saved!",
            text: "Domain Updated Successfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then(() => {
            this.myForm.reset();
            this.submitted = false;  
            this.router.navigate(["/product/List-Domain"]);
          });
        } else {
          // this.spinner.hide();
          Swal.fire({
            title: "Error",
            text: res.message,
            icon: "error",
            confirmButtonText: "Ok",
          }).then(() => {
            this.submitted = false;
          });
        }
      },
      (err) => {
        this.submitted = false;
        console.log(err);
      }
    );
  }

  clearForm() {
    this.submitted = false;
    this.myForm.reset();
  }
  
}

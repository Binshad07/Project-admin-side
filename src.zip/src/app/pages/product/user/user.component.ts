import { Component, OnInit } from '@angular/core';
// import { UsersService } from "./../../../shared/services/User/user.service";
import { PagerService } from "src/app/shared/services/pager.service";
import { Router } from "@angular/router";
import Swal from "sweetalert2";
import { FormGroup, FormBuilder } from "@angular/forms";
import { environment } from "src/environments/environment";
import { UserGroupService } from "src/app/shared/services/UserGroup/user-group.service";

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit {
  intSkipCount = 0;
  intTotalCount = 0;
  intPageLimit = 10;
  pageLimit: any[];
  pager: any = {};
  frmFilter: FormGroup;
  users = [];
  blnAdmin = false;
  userType: any;
  strShopId = "";
  strFranchiseId = "";
  blnDownloadLoader = false;
  blnLoader = false;


  constructor(
    private pageServiceObj: PagerService,
    private router: Router,
    private formBuilder: FormBuilder,
    private userGroupService: UserGroupService
  ) { }
  private apiURL: string = environment.API_ENDPOINT;
  downoloadPdfFileService: any;


  ngOnInit() {
    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.frmFilter = this.formBuilder.group({
      txtEmail: [""],
      txtUserName:[""],
      txtUserType:[""],
    });

    this.userType = localStorage.getItem('userRole')
    if (this.userType === null || this.userType === '' || this.userType === undefined) {
      this.blnAdmin = !this.blnAdmin;
    } else {
      this.strShopId = localStorage.getItem('shopId');
      this.strFranchiseId = localStorage.getItem('franchiseId')
    }
    this.pager = {};
    this.users = [];
    this.getAllUsers();

  }
  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getAllUsers();
  }

  getAllUsers() {
    let skipCount = this.intSkipCount;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
    const obj = {
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
      strFranchiseId: this.strFranchiseId,
      strStoreId: this.strShopId,
      strUpdateUserId: localStorage.getItem("userId"),
      strEmail:this.frmFilter.value.txtEmail,
      strUserType:this.frmFilter.value.txtUserType,
      strUserName:this.frmFilter.value.txtUserName

    };
    console.log("adsfsd" , obj)
    // this.spinner.show();

    this.userGroupService.getAdminList(obj).subscribe((res) => {
      console.log("User response:::::::::", res);

      if (res.success) {
        // this.spinner.hide();
        this.users = res.data;
        this.intTotalCount = res.data.total;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          
          this.pager.currentPage,
          this.intPageLimit
        );
      }
       else {
        this.users=[];
        // this.spinner.hide()
        // Swal.fire({
        //   title: "Error",
        //   text: res.message,
        //   icon: "error",
        //   confirmButtonText: "Ok",
        // });
      }
    });
  }

  _clearFormFilter(form: FormGroup) {
    form.reset({
      txtEmail: "",
      txtUserName:"",
      txtUserType:""
    });
    this.resetValues();
    this.getAllUsers();
  }

  // get f() {
  //   return this.frmFilter.controls;
  // }



  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.getAllUsers();
  }

  resetValues() {
    this.users=[]
    this.pager = {}
    this.intTotalCount = 0;
    this.intSkipCount = 0;
    this.intPageLimit = 10;
  }

  edit(item) {
    this.router.navigate(["/add-user"], {
      queryParams: { id: item.pkUserId, user: false },

    });
  }
  delete(item) {
    const swalWithBootstrapButtons = Swal.mixin({
      customClass: {
        confirmButton: "btn btnAdd ml-2",
        cancelButton: "btn btnCancel",
      },
      buttonsStyling: false,
    });

    swalWithBootstrapButtons
      .fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Yes, delete it!",
        cancelButtonText: "No, cancel!",
        reverseButtons: true,
      })
      .then((result) => {
        if (result.value) {
          const obj = {
            pkUserId: item.pkUserId,
            loginUserId: localStorage.getItem("userId"),
          };
          // this.spinner.show();
          this.userGroupService.deleteAdmin(obj).subscribe((res) => {
            if (res.success) {
              Swal.fire({
                title: "Deleted!",
                text:"User Deleted Successfully",
                icon: "success",
                confirmButtonText: "Ok",
              })
              this.ngOnInit();
            } else {
              Swal.fire({
                title: "Error",
                text: res.message,
                icon: "error",
                confirmButtonText: "Ok",
              });
            }
          });
        } else if (
          /* Read more about handling dismissals below */
          result.dismiss === Swal.DismissReason.cancel
        ) {
          // swalWithBootstrapButtons.fire(
          //   "Cancelled",
          //   "Your file is safe :)",
          //   "error"
          // );
        }
      });
  }

  _uerPermissions(item) {
    this.router.navigate(["/user-permissions"], {
      queryParams: { id: item.pkUserId },
    });
  }



  // onClickDownloadPdf(){
  //   this.blnDownloadLoader = true;
  //   let obj  = {
  //     // strStoreId: this.frmItemSales.value.cmbShopName, // this.strShopId
  //     //     strFromDate: this.fromDate, //fromDate,
  //     //     strToDdate: this.toDate, //toDate,
  //     //     strOrderNo: this.frmItemSales.value.txtOrderId.toUpperCase(),
  //     //     strDataType: "EXCEL",
  //         // id:this.arrItemSales[1]._id

  //       }

  //   this.userService.getUserPdfReport().subscribe((res)=>{
  //     console.log("Pdf report Response ::::", res);
  //     if(res.success){
  //       const strPath = this.apiURL + "/" + res.data;
  //     window.location.href = strPath;
  //     this.blnDownloadLoader = false;
  //     }else{
  //       console.log(res);
        

  //     }
  //     console.log(res)
  //   })
  // }


}

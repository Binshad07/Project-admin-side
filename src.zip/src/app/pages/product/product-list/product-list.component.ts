import { Component, OnInit } from '@angular/core';
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { PagerService } from "src/app/shared/services/pager.service";
import { Router } from "@angular/router";
import Swal from "sweetalert2";
import { FormGroup, FormBuilder } from "@angular/forms";
import { BannerServiceService } from 'src/app/shared/services/BannerService/banner-service.service';


@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnInit {

  intTotalCount = 0;
  intSkipCount = 0;
  pageLimit: any[];
  intPageLimit = 10;
  pager: any = {};
  arrReviews = [];
  showModal: boolean;
  strSelectedImg: string;
  strSelectedImageType: string;
  objSelectedItem: any;

  constructor(
    private pageServiceObj: PagerService,
    private bannerService: BannerServiceService,
    private modalService: NgbModal,
    private router: Router,
    private formBuilder: FormBuilder
  ) { }

  ngOnInit() {

    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist;

    this.getProductReviewList()
  }

  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getProductReviewList();
  }

  getProductReviewList() {

    let skipCount = this.intSkipCount;

    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }

    const obj = {
      loginUserId: localStorage.getItem("userId"),
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
    }
    
    this.bannerService.getListProductReview(obj).subscribe((res) => {
      if (res && res.success) {

        console.log(res,"id")
        // this.spinner.hide();
        this.arrReviews = res.data;
        this.intTotalCount = res.count;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
      } else {
        Swal.fire({
          title: "Error",
          text: res.message,
          icon: "error",
          confirmButtonText: "Ok",
        });
        // this.spinner.hide();
      }
    })
  }

  // getproductreview() {

  //   let skipCount = this.intSkipCount;
  //   if (this.pager.intSkipCount) {
  //     skipCount = this.pager.intSkipCount;
  //   }

  //   const obj = {
  //     loginUserId: localStorage.getItem("userId"),
  //     // deviceType: this.formBannerImages.value.deviceType,
  //     intSkipCount: skipCount,
  //     intPageLimit: this.intPageLimit,
  //   }
  //   console.log("obj", obj)
  //   this.bannerService.getAllbanners(obj).subscribe((res) => {
  //     if (res && res.success) {
  //       console.log("REsponse", res)
  //       // this.spinner.hide();
  //       this.arrBanner = res.data;
  //       this.intTotalCount = res.count;
  //       this.pager = this.pageServiceObj.getPager(
  //         this.intTotalCount,
  //         this.pager.currentPage,
  //         this.intPageLimit
  //       );
  //     } else {
  //       Swal.fire({
  //         title: "Error",
  //         text: res.message,
  //         icon: "error",
  //         confirmButtonText: "Ok",
  //       });
  //       // this.spinner.hide();
  //     }
  //   })
  // }

  onClickViewImg(item, image, type) {
    this.objSelectedItem = item;
    this.strSelectedImg = image;
    this.strSelectedImageType = type;
    this.show();
  }

  show() {
    this.showModal = true;
  }
  hide() {
    this.showModal = false;
  }

  // _onSearch() {
  //   let skipCount = this.intSkipCount;
  //   if (this.pager.intSkipCount) {
  //     skipCount = this.pager.intSkipCount;
  //   }

  //   const obj = {
  //     loginUserId: localStorage.getItem("userId"),
  //     deviceType: this.formBannerImages.value.deviceType,
  //     intSkipCount: skipCount,
  //     intPageLimit: this.intPageLimit,
  //   }

  //   console.log(obj)
  //   this.bannerService.getAllbanners(obj).subscribe((res) => {
  //     if (res.success) {
  //       this.arrBanner = res.data;
  //       this.intTotalCount = res.count;
  //       this.pager = this.pageServiceObj.getPager(
  //         this.intTotalCount,
  //         this.pager.currentPage,
  //         this.intPageLimit
  //       );
  //     } else {
  //       this.arrBanner = []
  //       Swal.fire({
  //         title: "Error",
  //         text: res.message,
  //         icon: "error",
  //         confirmButtonText: "Ok",
  //       });
  //       // this.spinner.hide();
  //     }
  //   }, (err) => {
  //     this.arrBanner = []
  //     console.log(err)
  //   })

  // }
  // errorImage(event) {
  //   event.target.src = 'assets/images/cart_logo.png';
  // }
  // _onClear() {
  //   this.formBannerImages.reset()
  //   this.ngOnInit()
  // }


  // deleteModal(responsiveDelete, item) {
  //   this.strBannerId = item.pkBannerId;
  //   this.modalService.open(responsiveDelete);
  // }

  // delete() {
  //   const obj = {
  //     pkBannerId: this.strBannerId,
  //     loginUserId: localStorage.getItem("userId")
  //   }
  //   console.log(obj)

  //   // this.spinner.show();

  //   this.bannerService.DeleteBanner(obj).subscribe((res) => {
  //     if (res.success && res) {
  //       this.modalService.dismissAll();
  //       // this.spinner.hide();
  //       Swal.fire({
  //         title: "Deleted!",
  //         text: res.message,
  //         icon: "success",
  //         confirmButtonText: "Ok",
  //       }).then(() => {
  //         this.getProductReviewList()
  //         this.ngOnInit()
  //       })
  //     } else {
  //       // this.spinner.hide();
  //       Swal.fire({
  //         title: "Error",
  //         text: res.message,
  //         icon: "error",
  //         confirmButtonText: "Ok",
  //       });
  //     }
  //     this.getProductReviewList();
  //   }, (err) => {
  //     console.log(err)
  //   })
  // }



  edit(item) {

    console.log(item)
    this.router.navigate(["/product/add-banner"], {
      queryParams: { id: item.pkBannerId },
    });
  }

  errorImage(event) {
    event.target.src = 'assets/images/cart_logo.png';
  }



}

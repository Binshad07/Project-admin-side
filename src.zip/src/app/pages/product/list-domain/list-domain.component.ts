import { Component, OnInit } from "@angular/core";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { PagerService } from "src/app/shared/services/pager.service";
import { Router } from "@angular/router";
import Swal from "sweetalert2";
import { FormGroup, FormBuilder } from "@angular/forms";
import { BannersService } from "src/app/shared/services/Banner/banners.service";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";

@Component({
  selector: "app-list-domain",
  templateUrl: "./list-domain.component.html",
  styleUrls: ["./list-domain.component.scss"],
})
export class ListDomainComponent implements OnInit {
  intTotalCount = 0;
  formFilterImages: FormGroup;
  intSkipCount = 0;
  pageLimit: any[];
  intPageLimit = 10;
  pager: any = {};
  arrDomainList = [];
  strBannerImageId = "";
  showModal: boolean;
  strSelectedImg: string;
  strSelectedImageType: string;
  objSelectedItem: any;
  strDeleteDomain: any;
  strBannerId: "";
  blnLoader = false;
  arrStores = [];
  keyword: string = "strShopName";
  selectedShopName: string;
  searchTimeout: any;
  strShopId = "";
  strShopName: string;
  myForm: FormGroup;

  constructor(
    private pageServiceObj: PagerService,
    private modalService: NgbModal,
    private router: Router,
    private formBuilder: FormBuilder,
    private BannerService: BannersService,
    private companyService: CompanyServiceService
  ) {}

  ngOnInit() {
    this.formFilterImages = this.formBuilder.group({});
    this.myForm = this.formBuilder.group({
      domainName: [""],
      strport: [""],
      strVerfication: [""],
    });

    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getDomainList();
  }

  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }

  modalExtendList(modalExtend, item) {
    this.objSelectedItem = item;
    this.modalService.open(modalExtend, {
      centered: true,
      windowClass: "modal-product-delete",
    });
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getDomainList();
  }

  getDomainList() {
    let skipCount = this.intSkipCount;
    this.blnLoader = false;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
      fkShopId: this.strShopId,
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
    };
    if (localStorage.getItem("fkShopId")) {
      Object.assign(obj, { fkShopId: localStorage.getItem("fkShopId") });
    }
    this.BannerService.ListDomain(obj).subscribe((res) => {
      if (res && res.success) {
        this.blnLoader = true;
        this.arrDomainList = res.data;
        this.intTotalCount = res.count;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
      }
    });
  }

  onClickViewImg(item, image, type) {
    this.objSelectedItem = item;
    this.strSelectedImg = image;
    this.strSelectedImageType = type;
    this.show();
  }

  show() {
    this.showModal = true;
  }

  hide() {
    this.showModal = false;
  }

  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.getDomainList();
  }

  _onClear() {
    this.strShopId = "";
    this.formFilterImages.reset();
    this.ngOnInit();
  }

  openModal1(item: any) {
    const obj = {
      fkShopId: item.fkShopId,
      domain: item.strDomainName,
    };
    this.BannerService.verifydomain(obj).subscribe(
      (res) => {
        if (res.success && res) {
          this.modalService.dismissAll();
          Swal.fire({
            title: "Yes!",
            text: "Verified successfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then(() => {
            this.getDomainList();
            this.ngOnInit();
          });
        } else {
          const errorMessage =
            res.message || "Verification failed. Please try again.";
          Swal.fire({
            title: "Error",
            text: errorMessage,
            icon: "error",
            confirmButtonText: "Ok",
          });
          this.modalService.dismissAll();
          this.arrDomainList = [];
        }
        this.getDomainList();
      },
      (err) => {
        console.error(err);
        Swal.fire({
          title: "warning",
          text: "An error occurred during the verification process. Please try again later.",
          icon: "warning",
          confirmButtonText: "Ok",
        });
        this.modalService.dismissAll();
      }
    );
  }

  edit(item) {
    this.router.navigate(["/product/add-domain"], {
      queryParams: { id: item.fkShopId },
    });
  }

  setSecurityGroupAddedfn(item: any) {
    const obj = {
      strDomainName: this.myForm.value.domainName || item.strDomainName,
      intPort: this.myForm.value.strport || "1666",
      strVerificationNo: this.myForm.value.strVerfication,
    };
    this.BannerService.setSecurityGroupAdded(obj).subscribe((res) => {
      if (res && res.success) {
        Swal.fire({
          title: "Saved!",
          text: "SecurityGroupAdded Saved Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        });
      }
    });
  }

  setNginxConnectionfn(item: any) {
    const obj = {
      strDomainName: this.myForm.value.domainName || item.strDomainName,
      intPort: this.myForm.value.strport || "1666",
      strVerificationNo: this.myForm.value.strVerfication,
    };
    this.BannerService.setNginxConnection(obj).subscribe((res) => {
      if (res && res.success) {
        Swal.fire({
          title: "Saved!",
          text: "NginxConnection Saved Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        });
      }
    });
  }

  setSLLConnectionfn(item: any) {
    const obj = {
      strDomainName: this.myForm.value.domainName || item.strDomainName,
      intPort: this.myForm.value.strport || "1666",
      strVerificationNo: this.myForm.value.strVerfication,
    };
    this.BannerService.setSLLConnection(obj).subscribe((res) => {
      if (res && res.success) {
        Swal.fire({
          title: "Saved!",
          text: "SLLConnection Saved Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        });
      }
    });
  }

  setServerFileConnectionfn(item: any) {
    const obj = {
      strDomainName: this.myForm.value.domainName || item.strDomainName,
      intPort: this.myForm.value.strport || "1666",
      strVerificationNo: this.myForm.value.strVerfication,
    };
    this.BannerService.setServerFileConnection(obj).subscribe((res) => {
      if (res && res.success) {
        Swal.fire({
          title: "Saved!",
          text: "ServerFileConnection Saved Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        });
      }
    });
  }

  setBrandNameChangefb(item: any) {
    const obj = {
      strDomainName: this.myForm.value.domainName || item.strDomainName,
      intPort: this.myForm.value.strport || "1666",
      strVerificationNo: this.myForm.value.strVerfication,
    };
    this.BannerService.setBrandNameChange(obj).subscribe((res) => {
      if (res && res.success) {
        Swal.fire({
          title: "Saved!",
          text: "BrandNameChange Saved Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        });
      }
    });
  }

  errorImage(event) {
    event.target.src = "assets/images/Group 4024 (1).png";
  }

  _getShopId(id$) {
    this.strShopId = id$;
  }

  onChangeSearch(event: any) {
    clearTimeout(this.searchTimeout);
    this.searchTimeout = setTimeout(() => {
      this.getShopListingFn(event);
    }, 300);
  }

  getShopListingFn(searchString: string) {
    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
      strShopName: searchString || "",
    };
    this.companyService.fnShopListFn(obj).subscribe(
      (res) => {
        if (res && res.data) {
          this.arrStores = res.data
            .filter((shop) => {
              const shopName =
                typeof shop.strShopName === "object" &&
                shop.strShopName !== null
                  ? shop.strShopName.strShopName
                  : shop.strShopName;
              return shopName
                .toLowerCase()
                .includes(searchString.toLowerCase());
            })
            .map((shop) => ({
              pkShopId: shop.pkShopId,
              strShopName:
                typeof shop.strShopName === "object" &&
                shop.strShopName !== null
                  ? shop.strShopName.strShopName
                  : shop.strShopName,
            }));
          if (this.arrStores.length > 0) {
            this.strShopId = this.arrStores[0].pkShopId;
            this.selectedShopName = this.arrStores[0].strShopName;
          }
        } else {
          this.arrStores = [];
        }
      },
      (error) => {
        console.error("Error fetching shop list", error);
        this.arrStores = [];
      }
    );
  }
  handleButtonClick(item: any, modalbtn: any) {
    if (
      item.strAdminStatus === "APPROVED" ||
      item.strAdminStatus === "VERIFIED"
    ) {
      // Open the modal for approved and verified statuses
      this.btnPopup(modalbtn, item); // Call the existing modal function
    } else {
      // Show warning message for other statuses using SweetAlert
      Swal.fire({
        icon: "warning",
        title: "Warning",
        text: `You clicked the  ${item.strDomainName} with status ${item.strAdminStatus}.`,
        confirmButtonText: "OK",
      });
    }
  }

  btnPopup(modalbtn, item) {
    this.objSelectedItem = item;
    this.modalService.open(modalbtn, {
      centered: true,
      windowClass: "modal-product-delete",
    });
  }

  deleteModal(responsiveDelete, item) {
    this.strDeleteDomain = item.pkDomainId;
    this.modalService.open(responsiveDelete);
  }

  delete() {
    const obj = {
      pkDomainId: this.strDeleteDomain,
    };
    console.log(obj);
    // this.spinner.show();

    this.BannerService.deleteDomainList(obj).subscribe(
      (res) => {
        if (res.success && res) {
          this.modalService.dismissAll();
          Swal.fire({
            title: "Deleted!",
            text: "Domain deleted successfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then(() => {
            this.getDomainList();
            this.ngOnInit();
          });
        } else {
          // this.spinner.hide();
          this.arrDomainList = [];

          // Swal.fire({
          //   // title: "Error",
          //   // text: res.message,
          //   // icon: "error",
          //   // confirmButtonText: "Ok",
          // });
        }
        this.getDomainList();
      },
      (err) => {
        console.log(err);
      }
    );
  }
}

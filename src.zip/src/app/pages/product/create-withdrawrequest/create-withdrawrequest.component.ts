
import { Component, OnInit } from '@angular/core';

// import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from "@angular/router";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";
import Swal from 'sweetalert2';
import { ReportsService } from 'src/app/shared/services/Reports/reports.service';





@Component({
  selector: 'app-create-withdrawrequest',
  templateUrl: './create-withdrawrequest.component.html',
  styleUrls: ['.//create-withdrawrequest.component.scss']
})
export class CreateWithdrawrequestComponent implements OnInit {



  myForm: FormGroup;
  // frmItemSales: FormGroup;

  pager: any = {};
  intTotalCount = 0;
  intPageLimit = 10;
  pageLimit: any[];
  intSkipCount = 0;
  // submitted: boolean = false;
  
  id = "";
  fkShopId: any
  type = "Add";
 

  clicked = false;

  arrShops: [];
  arrUnit: any;

  withdrawAmount: "";
  strLoginUserId: any;
  blnLoader: boolean;

  submitted = false
  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private companyService: CompanyServiceService,
    private reportService: ReportsService,

  ) { }

  ngOnInit() {


    this.route.queryParams.subscribe((params) => {
      this.id = params["id"];
    });

    this.myForm = this.formBuilder.group({
      // withdrawAmount: ["", Validators.required],
      withdrawAmount: ['', [Validators.required, Validators.min(1)]],
      fkShopId: ["",],



    })
    this.getAllShop();

  }
  // get f() {
  //   return this.myForm.controls;
  // }



  get f() {
    return this.myForm.controls;
  }


  addWithdrawRequest() {
    
      this.submitted = true;
      if (this.myForm.invalid) {
        return;
      }
    const obj = {
      strLoginUserId: localStorage.getItem('userId'),

      fkShopId: this.myForm.value.fkShopId,
      // "fkShopId": "65ab5e3669fde9f1cea9614f",
      withdrawAmount: this.myForm.value.withdrawAmount,

    }

    {
      // "strLoginUserId": "6565bb3e9744b236386d9585",
      // "fkShopId": "65ab5e3669fde9f1cea9614f",
      // "withdrawAmount": 199.0
    }
    this.clicked = true;
    this.companyService.addWithdrawRequest(obj).subscribe((res) => {
      console.log(res)
      if (res && res.success) {
        if (res.message === "Failed, not enough balance in wallet.") {
          Swal.fire({
            title: "Warning",
            text: "Not enough balance in wallet.",
            icon: "warning",
            confirmButtonText: "Ok",
          });
        }
        else {
          Swal.fire({
            title: "Saved!",
            text: "Withdrawrequest Saved Successfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then(() => {
            this.myForm.reset()
            this.router.navigate(['/withdraw-request'])
            this.submitted = false;
          })
        }

      }

      else {
        Swal.fire({
          title: "Warning",
          text: res.message,
          icon: "warning",
          confirmButtonText: "Ok",
        });
      }


    }, (err) => {
      console.log(err)
    })
  }



 



  getAllShop() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
    }
    console.log(obj, "tesghjchbv")
    if (localStorage.getItem('fkShopId')) {
      // Object.assign(obj, { strShopId: localStorage.getItem('fkShopId') })
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });


    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {

      this.arrShops = res.data
    })
  }

  clearForm() {
    this.myForm.reset();
    this.ngOnInit();
  }















}


import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateWithdrawrequestComponent } from './create-withdrawrequest.component';

describe('CreateWithdrawrequestComponent', () => {
  let component: CreateWithdrawrequestComponent;
  let fixture: ComponentFixture<CreateWithdrawrequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateWithdrawrequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateWithdrawrequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

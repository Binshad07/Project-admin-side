import { Component, OnInit } from "@angular/core";
import Swal from "sweetalert2";
// import { NgxSpinnerService } from "ngx-spinner";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { BannersService } from "src/app/shared/services/Banner/banners.service";
import { HypermarketService } from "src/app/shared/services/Hypermarket/hypermarket.service";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";
import { AbstractControl, ValidatorFn } from "@angular/forms";

@Component({
  selector: "app-voucher",
  templateUrl: "./voucher.component.html",
  styleUrls: ["./voucher.component.scss"],
})
export class VoucherComponent implements OnInit {
  intSkipCount = 0;
  submitted: boolean = false;
  arrRentalItem: any[] = [];
  myForm: FormGroup;
  myFormShopFilteration: FormGroup;
  id = "";
  type = "Add";
  blnUpdate = false;
  strImageUrl: [""];
  clicked = false;
  arrViewType: any[] = [];
  arrShop: any[] = [];
  arrPlans: any[] = [];
  today: string;
  strStartDateAndTime: string;
  frmDate: any;
  showShops = false;
  selectedShopId: string | null = null;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private hypermarketServiceObj: HypermarketService,
    private companyService: CompanyServiceService
  ) {
    const currentDate = new Date();
    this.today = currentDate.toISOString().split("T")[0];
  }

  ngOnInit() {
    this.route.queryParams.subscribe((params) => {
      this.id = params["id"];
    });

    this.myForm = this.formBuilder.group({
      frmDate: [{ value: this.today, disabled: true }],
      toDate: ["", Validators.required],
      cmbShopName: [null, [Validators.required, this.shopRequiredValidator()]],
      Amount: ["", Validators.required],
      cmbPlans: ["", Validators.required],
      cmbOffer: ["Exclusive Offer"],
      description: [""],
    });

    this.myFormShopFilteration = this.formBuilder.group({
      strEmail: [""],
      strPhoneNumber: [""],
    });

    this.getAllShop();
    if (this.id) {
      this.type = "Update";
      this.blnUpdate = true;
    }
  }

  shopRequiredValidator(): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } | null => {
      if (this.arrShop.length === 0) {
        return control.value ? null : { required: true }; // require a selection if no shops are present
      }
      return null; // No error if shops are available
    };
  }

  get f() {
    return this.myForm.controls;
  }
  addVoucher() {
    this.submitted = true;

    const selectedShopId =
      (this.arrShop.length > 0 ? this.arrShop[0].pkShopId : null) ||
      this.myForm.value.cmbShopName;
    console.log("Selected Shop ID:", selectedShopId);
    if (!selectedShopId) {
      alert("No shop selected or available!");
      return;
    }
    if (this.myForm.invalid) {
      console.log(this.myForm, "erss");
      return;
    }

    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
      fkShopId: selectedShopId,
      strStartDateAndTime: this.today,
      strEndDateAndTime: this.myForm.value.toDate,
      intAmount: this.myForm.value.Amount,
      strPromoDescription: this.myForm.value.description,
      fkPlanId: this.myForm.value.cmbPlans,
      strOfferName: this.myForm.value.cmbOffer,
    };
    console.log(obj, "object::::::::");
    this.hypermarketServiceObj.addVocher(obj).subscribe(
      (res) => {
        console.log(res, "resrrggggg");
        if (res && res.success) {
          this.clicked = false;
          this.hypermarketServiceObj.addVocher(res.data.pkStorePromocodeId);
          // this.spinner.hide();
          Swal.fire({
            title: "Saved!",
            text: "Voucher Saved Successfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then(() => {
            this.myForm.reset();
            this.router.navigate(["/product/voucher-list"]);
            this.submitted = false;
          });
        } else {
          // this.spinner.hide();
          Swal.fire({
            title: "Error",
            text: res.message,
            icon: "error",
            confirmButtonText: "Ok",
          });
        }
      },
      (err) => {
        console.log(err);
      }
    );
  }

  filterShop() {
    const email = this.myFormShopFilteration.value.strEmail;
    const phoneNumber = this.myFormShopFilteration.value.strPhoneNumber;

    if (email || phoneNumber) {
      this.showShops = true;
      this.getAllShop();
    } else {
      this.showShops = false;
      console.log("Please provide either an email or a phone number.");
    }
  }

  getAllShop() {
    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
      strEmail: this.myFormShopFilteration.value.strEmail,
      strContactNumber: this.myFormShopFilteration.value.strPhoneNumber,
    };
    if (localStorage.getItem("fkShopId")) {
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });
    }
    this.companyService.fnShopListFn(obj).subscribe((res) => {
      this.arrShop = res.data;
      console.log(res, "res:");
    });
    this.getPlans()
  }

  getPlans() {
    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
      isActive: true,
      fkShopId: this.selectedShopId,
    };
    console.log(obj,"objj")
    this.companyService.fngetallPlans(obj).subscribe((res) => {
      this.arrPlans = res.data;
    });
  }

  clearForm() {
    this.submitted = false;
    this.myForm.reset();
    this.myFormShopFilteration.reset();
  }


  onShopChange(event: any): void {
    this.selectedShopId =
      event.target.value !== "Select shop" ? event.target.value : null;

      console.log(this.selectedShopId,"eee")
  }

  // getPatchVocher() {
  //   const obj = {
  //     // loginUserId: localStorage.getItem("userId"),
  //     pkStorePromocodeId: "66ce326fd60e64e73f72bab1",
  //   };
  //   console.log(obj, "obj");
  //   this.hypermarketServiceObj.getListVoucher(obj).subscribe((res) => {
  //     if (res && res.success) {
  //       console.log("patch", res.data);
  //       this.myForm.patchValue({
  //         frmDate: res.data[0].dateCreateDateAndTime,
  //         toDate: res.data[0].dateUpdateDateAndTime,
  //         vocherCode: res.data[0].strPromoCode,
  //         description: res.data[0].strPromoDescription,
  //         cmbShopName: res.data[0].fkShopId,
  //         intAmount  : res.data[0].Amount,
  //       });
  //     }
  //   });
  // }

  // getPatchVocher() {
  //   const obj = {
  //     pkStorePromocodeId: "66ce326fd60e64e73f72bab1",
  //     fkShopId:"65ae107069fde9f1cea978cd",

  //   };
  //   console.log(obj, "obj");

  //   this.hypermarketServiceObj.getListVoucher(obj).subscribe((res) => {
  //     if (res && res.success && res.data && res.data.length) {
  //       const voucher = res.data[0];
  //       console.log("patch", voucher);

  //       this.myForm.patchValue({
  //         frmDate: voucher.dateCreateDateAndTime,
  //         toDate: voucher.dateUpdateDateAndTime,
  //         vocherCode: voucher.strPromoCode,
  //         description: voucher.strPromoDescription,
  //         cmbShopName: voucher.fkShopId,
  //         intAmount: voucher.intAmount, // Corrected the key name
  //       });
  //     } else {
  //       console.error("No valid data found in the response");
  //     }
  //   });
  // }

  update() {
    // this.submitted = true;
    // if (this.myForm.invalid) {
    //   return;
    // }
    // const obj = {
    //   strLoginUserId: localStorage.getItem("userId"),
    //   fkShopId: this.myForm.value.cmbShopName,
    //   strStartDateAndTime: this.myForm.value.frmDate,
    //   strEndDateAndTime: this.myForm.value.toDate,
    //   intAmount: this.myForm.value.Amount,
    //   strPromoCode: this.myForm.value.vocherCode,
    //   strPromoDescription: this.myForm.value.description,
    //   fkStorePromocodeId: "66ce326fd60e64e73f72bab1",
    // };
    // this.hypermarketServiceObj.updateVocher(obj).subscribe(
    //   (res) => {
    //     if (res.success) {
    //       console.log(res,"resupdate")
    //       // this.spinner.hide()
    //       Swal.fire({
    //         title: "Saved!",
    //         text: "Voucher updated successfully",
    //         icon: "success",
    //         confirmButtonText: "Ok",
    //       }).then(() => {
    //         this.myForm.reset();
    //         this.submitted = false;
    //         this.router.navigate(["/product/voucher-list"]);
    //       });
    //     } else {
    //       // this.spinner.hide();
    //       Swal.fire({
    //         title: "Error",
    //         text: res.message,
    //         icon: "error",
    //         confirmButtonText: "Ok",
    //       }).then(() => {
    //         this.submitted = false;
    //       });
    //     }
    //   },
    //   (err) => {
    //     this.submitted = false;
    //     console.log(err);
    //   }
    // );
  }
}

import { Component, OnInit } from '@angular/core';
import { PagerService } from "src/app/shared/services/pager.service";
import { DatePipe } from "@angular/common";
import { ReportsService } from "src/app/shared/services/Reports/reports.service";
import { FormBuilder, FormGroup } from "@angular/forms";
import { modOrderSummary } from "src/app/shared/Classes/report.model";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";
import { HypermarketService } from './../../../shared/services/Hypermarket/hypermarket.service';
import { environment } from "./../../../../environments/environment.prod";
@Component({
  selector: 'app-customer-ticket-request',
  templateUrl: './customer-ticket-request.component.html',
  styleUrls: ['./customer-ticket-request.component.scss']
})
export class CustomerTicketRequestComponent implements OnInit {
  currentDate = new Date();
  frmTicket: FormGroup;
  pager: any = {};
  intTotalCount = 0;
  strPageLimit = 10;
  datePipe = new DatePipe("en-US");
  pageLimit: any[];
  strShopId = "";
  arrStores = [];
  strSkipCount = 0;
  arrTicket: [];
  fromDate;
  toDate;
  blnLoader = false;
  blnDownloadLoader = false;
  private apiURL: string = environment.API_ENDPOINT;
  userType: string;
  

  constructor(
    private pageServiceObj: PagerService,
    private formBuilder: FormBuilder,
    private companyService:CompanyServiceService,
    private reportServiceObj: ReportsService,
    private hypermarketServiceObj: HypermarketService,
  ) { }

  ngOnInit() {
    this.frmTicket = this.formBuilder.group({
      txtFromDate: [""],
      txtToDate: [""],
      strTicketNO: [""],
      strTitle :[],
      cmbShopName: "",
      drpPageLimit: "10",
    });
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getShopListingFn();
    this.getTicket();
    this.userType=localStorage.getItem("strUserType");
  }
  _clearForm(form: FormGroup) {
    form.reset({
      txtFromDate: "",
      txtToDate: "",
      strTicketNO: "",
      strTitle:"",
      cmbShopName: "",
      drpPageLimit: "10",
    });
    this.intTotalCount = 0;
    this.strSkipCount = 0;
    this.strPageLimit = 10;
    this.getTicket();
  }
  _getPageLimit(value$) {
    this.strPageLimit = parseInt(this.frmTicket.value.drpPageLimit);
    this.setPage(1);
  }
  _getShopId(id$) {
    this.strShopId = id$;
  }
  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.strPageLimit
    );
    this.getTicket();
  }
  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.getTicket();
  }

  getShopListingFn() {
    const obj = {
      loginUserId:localStorage.getItem("userId"),
    }
    if(localStorage.getItem('fkShopId')){
      // Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
      this.arrStores = res.data;
      this.strShopId = res.data[0].pkShopId;
    });
  }
  getTicket() {
    let skipCount = this.strSkipCount;
    this.blnLoader = false;

    if (this.pager.strSkipCount) {
      skipCount = this.pager.strSkipCount;
    }
    if (
      this.frmTicket.value.txtFromDate === "txtFromDate" &&
      this.frmTicket.value.txtToDate === "txtToDate"
    ) {
      console.log("From Date ::::", this.frmTicket.value.txtFromDate);
      this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
      this.toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    }
    if (
      this.frmTicket.value.txtFromDate &&
      this.frmTicket.value.txtToDate === "txtToDate"
    ) {
      console.log("To Date ::::", this.frmTicket.value.txtToDate);
      this.fromDate = `${this.frmTicket.value.txtFromDate.year}-${this.frmTicket.value.txtFromDate.month}-${this.frmTicket.value.txtFromDate.day}`;
      this.toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    }
    if (
      this.frmTicket.value.txtToDate &&
      this.frmTicket.value.txtFromDate === "txtFromDate"
    ) {
      console.log("To Date ::::", this.frmTicket.value.txtToDate);
      this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
      this.toDate = `${this.frmTicket.value.txtToDate.year}-${this.frmTicket.value.txtToDate.month}-${this.frmTicket.value.txtToDate.day}`;
    }

    if (
      this.frmTicket.value.txtFromDate &&
      this.frmTicket.value.txtToDate
    ) {
      this.fromDate = `${this.frmTicket.value.txtFromDate.year}-${this.frmTicket.value.txtFromDate.month}-${this.frmTicket.value.txtFromDate.day}`;
      this.toDate = `${this.frmTicket.value.txtToDate.year}-${this.frmTicket.value.txtToDate.month}-${this.frmTicket.value.txtToDate.day}`;
    }

    const obj = {
      loginUserId:localStorage.getItem("userId"),
      strSkipCount: skipCount,
      strPageLimit: this.strPageLimit,
      strShopName: this.frmTicket.value.cmbShopName, // this.strShopId
      fromCreatedAt: this.fromDate, // fromTime
      toCreatedAt: this.toDate, // toTime
      strTicketNO: this.frmTicket.value.strTicketNO,
      strTitle: this.frmTicket.value.strTitle
    };

    console.log("Object:::::", obj);

    this.hypermarketServiceObj.getCustomerTicketCount(obj).subscribe((res) => {
      this.blnLoader = true;
      this.arrTicket = res.data;
      if (res.data) {
        this.intTotalCount = res.count;
      }
      this.pager = this.pageServiceObj.getPager(
        this.intTotalCount,
        this.pager.currentPage,
        this.strPageLimit
      );
    });
  }
}

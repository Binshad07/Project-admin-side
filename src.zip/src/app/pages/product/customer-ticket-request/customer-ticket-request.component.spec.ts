import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerTicketRequestComponent } from './customer-ticket-request.component';

describe('CustomerTicketRequestComponent', () => {
  let component: CustomerTicketRequestComponent;
  let fixture: ComponentFixture<CustomerTicketRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerTicketRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerTicketRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

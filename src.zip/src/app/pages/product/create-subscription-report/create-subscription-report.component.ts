import { Component, OnInit } from "@angular/core";
import Swal from "sweetalert2";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { BannerServiceService } from "src/app/shared/services/BannerService/banner-service.service";
// import { BannersService } from 'src/app/shared/services/banners.service';
import { PagerService } from "src/app/shared/services/pager.service";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";

@Component({
  selector: "app-create-subscription-report",
  templateUrl: "./create-subscription-report.component.html",
  styleUrls: ["./create-subscription-report.component.scss"],
})
export class CreateSubscriptionReportComponent implements OnInit {
  myForm: FormGroup;

  pager: any = {};
  intTotalCount = 0;
  intPageLimit = 10;
  pageLimit: any[];
  intSkipCount = 0;
  strCategoryId = "";
  blnLoader = false;
  submitted = false;
  arrShops = [];
  id = "";
  type = "Add";
  blnUpdate = false;
  clicked = false;
  arrPlantList: [];
  arrCompany: [];

  planamount: "";
  // strPlanId:"";
  strPlan: "";
  txtSortNo: "";
  billingPeriod: "";
  plandetails: "";
  // planTag:"";
  Currency: "";
  arrcurrencytList: [];
  strplanTag: ""


  constructor(
    private companyService: CompanyServiceService,
    private pageServiceObj: PagerService,
    private modalService: NgbModal,
    private formBuilder: FormBuilder,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.route.queryParams.subscribe((params) => {
      this.id = params["id"];
    });
    this.myForm = this.formBuilder.group({
      strPlanId: ["", Validators.required],
      StrTranscation: ["", Validators.required],
      fkShopId: ["", Validators.required],
      cmbShopName: "",
      strPlaneType: ["", Validators.required],
      planamount: ["", Validators.required],
      txtSortNo: ["", Validators.required],
      billingPeriod: ["", Validators.required],
      strPlan: ["", Validators.required],
      plandetails: ["", Validators.required],
      // Currency:"",
      strCurrency: ["", Validators.required],
      planName: ["", Validators.required],
      strplanamount: "",
      discount: "",
      flexCheckDefault: "",
      strplanTag: "",
      strSymbol: ""


    });

    this.ListcurrencyList();

  }

  get f() {
    return this.myForm.controls;
  }

  clearForm() {
    this.submitted = false;
    this.myForm.reset();
  }
  AddSubscriptionReport() {
    console.log("aaaaaaaaaaaaaaaaaa")
    this.submitted = true;
    // if (this.myForm.invalid) {
    //   this.blnLoader = true;
    //   return;
    // }

    const obj = {

      strLoginUserId: localStorage.getItem("userId"),
      planAmount: this.myForm.value.planamount,

      strCurrency: this.strCurrency,
      sortNumber: this.myForm.value.txtSortNo,
      planName: this.myForm.value.planName,

      planDetails: this.myForm.value.plandetails,
      planTag: this.myForm.value.strplanTag,
      discountPercentage: this.myForm.value.discount,

      planAmountPer: this.myForm.value.strplanamount,
      strSymbol: this.strSymbol,

      isGoldPlan: this.myForm.value.flexCheckDefault,

    };

    console.log(obj, "respose")
    this.companyService.AddsubscriptionReport(obj).subscribe(
      (res) => {
        console.log(res, "fasgdjg");
        if (res && res.success) {
          this.clicked = false;
          // this.spinner.hide();
          Swal.fire({
            title: "Saved!",
            text: "Subscription added successfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then(() => {
            this.myForm.reset();
            // this.router.navigate(["/product/Offline-Subscription-Report"]);
            this.submitted = false;
          });
        } else {
          // this.spinner.hide();
          Swal.fire({
            title: "Error",
            text: res.message,
            icon: "error",
            confirmButtonText: "Ok",
          });
        }
      },
      (err) => {
        console.log(err);
      }
    );
  }

  



  ListcurrencyList() {
    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
      strCurrencyPayment: this.myForm.value.currency,
      // "strCurrencyPayment": "IQD"

    };

    this.companyService.ListcurrencyList(obj).subscribe((res) => {
      console.log(res, "objdfghijko")
      if (res.success) {
        this.arrcurrencytList = res.data;
      }
    },
      (err) => {
        this.arrcurrencytList = [];
        console.log(err);
      }
    );
  }


  strCurrency: any
  strSymbol: any

  onCurrencyChange(value: string) {
    const [strCurrency, strSymbol] = value.split(',');
    this.strCurrency = strCurrency
    this.strSymbol = strSymbol


    // Now you have both the currency and symbol
    console.log('Currency:', this.strCurrency);
    console.log('Symbol:', strSymbol);
  }

}
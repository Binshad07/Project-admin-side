import { modTransaction } from './../../../shared/Classes/report.model';
import { environment } from "./../../../../environments/environment.prod";
import { Component, OnInit } from "@angular/core";
import { PagerService } from "src/app/shared/services/pager.service";
import { FormGroup, FormBuilder } from "@angular/forms";
import { ReportsService } from "src/app/shared/services/Reports/reports.service";
import { modItemSales } from "src/app/shared/Classes/report.model";
import { DatePipe } from "@angular/common";

@Component({
  selector: 'app-transaction-report',
  templateUrl: './transaction-report.component.html',
  styleUrls: ['./transaction-report.component.scss']
})
export class TransactionReportComponent implements OnInit {
  currentDate = new Date();
  frmItemSales: FormGroup;
  pager: any = {};
  intTotalCount = 0;
  intPageLimit = 10;
  pageLimit: any[];
  strShopId = "";
  arrStores = [];
  intSkipCount = 0;
  datePipe = new DatePipe("en-US");
  arrTransaction: modTransaction[] = [];
  fromDate;
  toDate;
  blnLoader = false;
  blnDownloadLoader = false;

  private apiURL: string = environment.API_ENDPOINT;

  constructor(
    private pageServiceObj: PagerService,
    private reportServiceObj: ReportsService,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit() {
    this.frmItemSales = this.formBuilder.group({
      txtFromDate: [""],
      txtToDate: [""],
      txtOrderId: [""],
      cmbShopName: "",
      drpPageLimit: "10",
    });
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getShopListingFn();
    this.getItemSalesFn();
  }

  _clearForm(form: FormGroup) {
    form.reset({
      txtFromDate: "",
      txtToDate: "",
      txtOrderId: "",
      cmbShopName: "",
      drpPageLimit: "10",
    });
    this.intTotalCount = 0;
    this.intSkipCount = 0;
    this.intPageLimit = 10;
    this.getItemSalesFn();
  }

  _getPageLimit(value$) {
    this.intPageLimit = parseInt(this.frmItemSales.value.drpPageLimit);
    this.setPage(1);
  }
  _getShopId(id$) {
    this.strShopId = id$;
  }
  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getItemSalesFn();
  }

  getShopListingFn() {
    this.reportServiceObj.getShopListingService().subscribe((res) => {
      this.arrStores = res.data;
    });
  }
  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.getItemSalesFn();
  }
  getItemSalesFn() {
    let skipCount = this.intSkipCount;
    this.blnLoader = false;

    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }

    if (
      this.frmItemSales.value.txtFromDate === "" &&
      this.frmItemSales.value.txtToDate === ""
    ) {
      // console.log("From Date ::::", this.frmItemSales.value.txtFromDate);
      this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
      this.toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    }
    if (
      this.frmItemSales.value.txtFromDate &&
      this.frmItemSales.value.txtToDate === ""
    ) {
      // console.log("To Date ::::", this.frmItemSales.value.txtToDate);
      this.fromDate = `${this.frmItemSales.value.txtFromDate.year}-${this.frmItemSales.value.txtFromDate.month}-${this.frmItemSales.value.txtFromDate.day}`;
      this.toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    }
    if (
      this.frmItemSales.value.txtToDate &&
      this.frmItemSales.value.txtFromDate === ""
    ) {
      // console.log("To Date ::::", this.frmItemSales.value.txtToDate);
      this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
      this.toDate = `${this.frmItemSales.value.txtToDate.year}-${this.frmItemSales.value.txtToDate.month}-${this.frmItemSales.value.txtToDate.day}`;
    }

    if (
      this.frmItemSales.value.txtFromDate &&
      this.frmItemSales.value.txtToDate
    ) {
      this.fromDate = `${this.frmItemSales.value.txtFromDate.year}-${this.frmItemSales.value.txtFromDate.month}-${this.frmItemSales.value.txtFromDate.day}`;
      this.toDate = `${this.frmItemSales.value.txtToDate.year}-${this.frmItemSales.value.txtToDate.month}-${this.frmItemSales.value.txtToDate.day}`;
    }

    const obj = {
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
      strStoreId: this.frmItemSales.value.cmbShopName, // this.strShopId
      strFromDate: this.fromDate, //fromDate,
      strToDdate: this.toDate, //toDate,
      strLoginUserId: localStorage.getItem('userId'),
    };
    console.log("Sales report object ::::", obj);

    this.reportServiceObj.getTransactionDetailsService(obj).subscribe((res) => {
      this.blnLoader = true;

      this.arrTransaction = res.data;
      if (res.data[0]) {
        this.intTotalCount = res.count[0].intTotalCount;
      }
      console.log("Item Sales data:::::", res);
      this.pager = this.pageServiceObj.getPager(
        this.intTotalCount,
        this.pager.currentPage,
        this.intPageLimit
      );
    });
  }

  getDownloadExcel() {
    this.blnDownloadLoader = !this.blnDownloadLoader;
    const obj = {
      strStoreId: this.frmItemSales.value.cmbShopName, // this.strShopId
      strFromDate: this.fromDate, //fromDate,
      strToDdate: this.toDate, //toDate,
      strOrderNo: this.frmItemSales.value.txtOrderId.toUpperCase(),
      strDataType: "EXCEL",
    };

    this.reportServiceObj.getItemSalesService(obj).subscribe((res) => {
      console.log("RESPONSE EXCEL", res);
      const strPath = this.apiURL + "/" + res.data;
      window.location.href = strPath;
      this.blnDownloadLoader = !this.blnDownloadLoader;
    });
  }

}

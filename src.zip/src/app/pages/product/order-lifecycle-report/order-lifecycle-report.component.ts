import { environment } from "./../../../../environments/environment.prod";
import { Component, OnInit } from "@angular/core";
import { PagerService } from "src/app/shared/services/pager.service";
import { DatePipe } from "@angular/common";
import { FormBuilder, FormGroup } from "@angular/forms";
import { ReportsService } from "src/app/shared/services/Reports/reports.service";
import { modOrderLifecycle } from "src/app/shared/Classes/report.model";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";

@Component({
  selector: "app-order-lifecycle-report",
  templateUrl: "./order-lifecycle-report.component.html",
  styleUrls: ["./order-lifecycle-report.component.scss"],
})
export class OrderLifecycleReportComponent implements OnInit {
  frmOrderLifecylce: FormGroup;
  currentDate = new Date();
  pager: any = {};
  intTotalCount = 0;
  intPageLimit = 10;
  datePipe = new DatePipe("en-US");
  pageLimit: any[];
  strShopId = "";
  arrStores = [];
  intSkipCount = 0;
  arrOrderLifeCycle: modOrderLifecycle[] = [];
  fromDate;
  toDate;
  blnLoader = false;
  blnDownloadLoader = false;

  private apiURL: string = environment.API_ENDPOINT;

  constructor(
    private pageServiceObj: PagerService,
    private formBuilder: FormBuilder,
    private companyService:CompanyServiceService,
    private reportServiceObj: ReportsService
  ) {}

  ngOnInit() {
    this.frmOrderLifecylce = this.formBuilder.group({
      txtFromDate: [""],
      txtToDate: [""],
      txtOrderId: [""],
      cmbShopName: "",
      drpPageLimit: "10",
    });

    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getShopListingFn();
    this.getOrderLifeCycleFn();
  }

  _clearForm(form: FormGroup) {
    form.reset({
      txtFromDate: "",
      txtToDate: "",
      txtOrderId: "",
      cmbShopName: "",
      drpPageLimit: "10",
    });
    this.intTotalCount = 0;
    this.intSkipCount = 0;
    this.intPageLimit = 10;
    this.getOrderLifeCycleFn();
  }

  _getPageLimit(value$) {
    this.intPageLimit = parseInt(this.frmOrderLifecylce.value.drpPageLimit);
    this.setPage(1);
  }
  _getShopId(id$) {
    this.strShopId = id$;
  }
  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getOrderLifeCycleFn();
  }

  getShopListingFn() {
    const obj = {
      loginUserId:localStorage.getItem("userId"),
    }
    if(localStorage.getItem('fkShopId')){
      // Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
      this.arrStores = res.data;
      this.strShopId = res.data[0].pkShopId;
    });
  }

  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.getOrderLifeCycleFn();
  }

  getOrderLifeCycleFn() {
    let skipCount = this.intSkipCount;
    this.blnLoader = false;

    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
    if (
      this.frmOrderLifecylce.value.txtFromDate === "txtFromDate" &&
      this.frmOrderLifecylce.value.txtToDate === "txtToDate"
    ) {
      console.log("From Date ::::", this.frmOrderLifecylce.value.txtFromDate);
      this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
      this.toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    }
    if (
      this.frmOrderLifecylce.value.txtFromDate &&
      this.frmOrderLifecylce.value.txtToDate === "txtToDate"
    ) {
      console.log("To Date ::::", this.frmOrderLifecylce.value.txtToDate);
      this.fromDate = `${this.frmOrderLifecylce.value.txtFromDate.year}-${this.frmOrderLifecylce.value.txtFromDate.month}-${this.frmOrderLifecylce.value.txtFromDate.day}`;
      this.toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    }
    if (
      this.frmOrderLifecylce.value.txtToDate &&
      this.frmOrderLifecylce.value.txtFromDate === "txtFromDate"
    ) {
      console.log("To Date ::::", this.frmOrderLifecylce.value.txtToDate);
      this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
      this.toDate = `${this.frmOrderLifecylce.value.txtToDate.year}-${this.frmOrderLifecylce.value.txtToDate.month}-${this.frmOrderLifecylce.value.txtToDate.day}`;
    }

    if (
      this.frmOrderLifecylce.value.txtFromDate &&
      this.frmOrderLifecylce.value.txtToDate
    ) {
      this.fromDate = `${this.frmOrderLifecylce.value.txtFromDate.year}-${this.frmOrderLifecylce.value.txtFromDate.month}-${this.frmOrderLifecylce.value.txtFromDate.day}`;
      this.toDate = `${this.frmOrderLifecylce.value.txtToDate.year}-${this.frmOrderLifecylce.value.txtToDate.month}-${this.frmOrderLifecylce.value.txtToDate.day}`;
    }
    const obj = {
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
      strStoreId: this.frmOrderLifecylce.value.cmbShopName, // this.strShopId
      strFromDate: this.fromDate, // fromTime
      strToDdate: this.toDate, // toTime
      strOrderNo: this.frmOrderLifecylce.value.txtOrderId.toUpperCase(),
    };
    if(localStorage.getItem('fkShopId')){
      Object.assign(obj,{strStoreId: localStorage.getItem('fkShopId')})
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    console.log("OBJECT BEFROE::::::::", obj);

    this.reportServiceObj.getOrderLifeCycleService(obj).subscribe((res) => {
      this.blnLoader = true;

      this.arrOrderLifeCycle = res.data[1];
      if (res.data[0]) {
        this.intTotalCount = res.data[0].intTotalCount;
      }
      this.pager = this.pageServiceObj.getPager(
        this.intTotalCount,
        this.pager.currentPage,
        this.intPageLimit
      );
      console.log("OrderLifecycle Response::::::", res);
    });
  }

  getDownloadExcel() {
    this.blnDownloadLoader = !this.blnDownloadLoader;
    const obj = {
      strStoreId: this.frmOrderLifecylce.value.cmbShopName, // this.strShopId
      strFromDate: this.fromDate, // fromTime
      strToDdate: this.toDate, // toTime
      strOrderNo: this.frmOrderLifecylce.value.txtOrderId.toUpperCase(),
      strDataType: "EXCEL",
    };
    this.reportServiceObj.getOrderLifeCycleService(obj).subscribe((res) => {
      console.log("RESPONSE EXCEL", res);
      const strPath = this.apiURL + "/" + res.data;
      window.location.href = strPath;
      this.blnDownloadLoader = !this.blnDownloadLoader;
    });
  }
}

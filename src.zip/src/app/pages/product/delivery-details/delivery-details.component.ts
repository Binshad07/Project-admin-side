import { environment } from './../../../../environments/environment.prod';
import { modDeliveryDetails } from './../../../shared/Classes/report.model';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { PagerService } from 'src/app/shared/services/pager.service';
import { ReportsService } from 'src/app/shared/services/Reports/reports.service';

@Component({
  selector: 'app-delivery-details',
  templateUrl: './delivery-details.component.html',
  styleUrls: ['./delivery-details.component.scss']
})
export class DeliveryDetailsComponent implements OnInit {

  currentDate = new Date();
  frmDeliveryDetails: FormGroup;
  pager: any = {};
  intTotalCount = 0;
  intPageLimit = 10;
  datePipe = new DatePipe('en-US');
  pageLimit: any[];
  strShopId = '';
  arrStores = [];
  intSkipCount = 0;
  arrDeliveryDetails: modDeliveryDetails[] = [];
  fromDate;
  toDate;
  blnLoader = false;
  blnDownloadLoader = false;

  private apiURL: string = environment.API_ENDPOINT;

  constructor(private pageServiceObj: PagerService,
              private formBuilder: FormBuilder,
              private reportServiceObj: ReportsService,
  ) { }

  ngOnInit() {
    this.frmDeliveryDetails = this.formBuilder.group({
      txtFromDate   :  [''],
      txtToDate     :  [''],
      drpPageLimit  : "10",
    });
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getShopListingFn();
    this.getDeliveryDetailsFn();
  }

  _clearForm(form: FormGroup) {
    form.reset({
      txtFromDate   :  '',
      txtToDate     :  '',
      drpPageLimit  : "10",
    });
    this.intTotalCount = 0;
    this.intSkipCount = 0;
    this.intPageLimit = 10;
    this.getDeliveryDetailsFn();
  }
  _getPageLimit(value$) {
    this.intPageLimit = parseInt(this.frmDeliveryDetails.value.drpPageLimit);
    this.setPage(1);
  }
  _getShopId(id$) {
    this.strShopId = id$;
  }
  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(this.intTotalCount, page, this.intPageLimit);
    this.getDeliveryDetailsFn();
  }
  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.getDeliveryDetailsFn();
    // /api/product-excel/GetAllDeliveryData

  }

  getShopListingFn() {
    this.reportServiceObj.getShopListingService().subscribe((res) => {
      this.arrStores = res.data;
      this.strShopId = res.data[0].pkShopId;
    });
  }

  getDeliveryDetailsFn() {
    this.blnLoader = false;
    let skipCount = this.intSkipCount;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }


    if (this.frmDeliveryDetails.value.txtFromDate === '' && this.frmDeliveryDetails.value.txtToDate === '') {
      console.log('From Date ::::', this.frmDeliveryDetails.value.txtFromDate);
      this.fromDate = this.datePipe.transform(this.currentDate, 'yyyy-M-dd');
      this.toDate = this.datePipe.transform(this.currentDate, 'yyyy-M-dd' );
    }
    if (this.frmDeliveryDetails.value.txtFromDate && this.frmDeliveryDetails.value.txtToDate === '') {
      console.log('To Date ::::', this.frmDeliveryDetails.value.txtToDate);
      this.fromDate = `${this.frmDeliveryDetails.value.txtFromDate.year}-${this.frmDeliveryDetails.value.txtFromDate.month}-${this.frmDeliveryDetails.value.txtFromDate.day}`;
      this.toDate = this.datePipe.transform(this.currentDate, 'yyyy-M-dd' );
    }
    if (this.frmDeliveryDetails.value.txtToDate && this.frmDeliveryDetails.value.txtFromDate === '') {
      console.log('To Date ::::', this.frmDeliveryDetails.value.txtToDate);
      this.fromDate = this.datePipe.transform(this.currentDate, 'yyyy-M-dd');
      this.toDate = `${this.frmDeliveryDetails.value.txtToDate.year}-${this.frmDeliveryDetails.value.txtToDate.month}-${this.frmDeliveryDetails.value.txtToDate.day}`;
    }

    if (this.frmDeliveryDetails.value.txtFromDate && this.frmDeliveryDetails.value.txtToDate) {
      this.fromDate = `${this.frmDeliveryDetails.value.txtFromDate.year}-${this.frmDeliveryDetails.value.txtFromDate.month}-${this.frmDeliveryDetails.value.txtFromDate.day}`;
      this.toDate = `${this.frmDeliveryDetails.value.txtToDate.year}-${this.frmDeliveryDetails.value.txtToDate.month}-${this.frmDeliveryDetails.value.txtToDate.day}`;
    }
    const obj = {
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
      strFromDate : this.fromDate, // fromTime
      strToDdate  : this.toDate, // toTime

    };

    console.log('OBJECT BEFROE::::::::', obj);

    this.reportServiceObj.getDeliveryDetailsService(obj).subscribe((res) => {
      this.blnLoader = true;
      this.arrDeliveryDetails = res.data[1];
      if (res.data[0]) {
        this.intTotalCount = res.data[0].totalCount;
      }
      this.pager = this.pageServiceObj.getPager(this.intTotalCount, this.pager.currentPage, this.intPageLimit);
      console.log('DELVERY DETAILS Response::::::', res);

    });
  }

  getDownloadExcel() {
    this.blnDownloadLoader = !this.blnDownloadLoader;
    const obj = {
      strFromDate : this.fromDate, // fromTime
      strToDdate  : this.toDate, // toTime
    };

    this.reportServiceObj.getDeliveryDetailsExcelService(obj).subscribe(res => {
      this.blnDownloadLoader = !this.blnDownloadLoader;
      console.log('RESPONSE EXCEL', res);
      const strPath = this.apiURL + '/' + res.data;
      window.location.href = strPath;
    });

  }

}

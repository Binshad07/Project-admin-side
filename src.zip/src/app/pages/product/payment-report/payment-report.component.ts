import { environment } from './../../../../environments/environment.prod';
import { Component, OnInit } from '@angular/core';
import { PagerService } from 'src/app/shared/services/pager.service';
import { DatePipe } from '@angular/common';
import { modOrderPayment, modPaymentTotal } from 'src/app/shared/Classes/report.model';
import { ReportsService } from 'src/app/shared/services/Reports/reports.service';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-payment-report',
  templateUrl: './payment-report.component.html',
  styleUrls: ['./payment-report.component.scss']
})
export class PaymentReportComponent implements OnInit {

  currentDate       = new Date();
  pager: any        = {};
  intTotalCount     = 0;
  intPageLimit      = 10;
  datePipe          = new DatePipe('en-US');
  pageLimit = [];
  strShopId         = '';
  arrStores         = [];
  intSkipCount      = 0;
  arrTotal: modPaymentTotal[] = [];
  blnNoData         = false;
  frmOrderPayment: FormGroup;
  arrOrderPayment: modOrderPayment[] = [];
  fromDate;
  toDate;
  blnLoader = true;
  blnDownloadLoader = false;
  private apiURL: string = environment.API_ENDPOINT;

  constructor(private pageServiceObj: PagerService,
              private formBuilder: FormBuilder,
              private reportServiceObj: ReportsService) { }

  ngOnInit() {

    this.frmOrderPayment = this.formBuilder.group({

      txtFromDate   :  [''],
      txtToDate     :  [''],
      txtOrderId    :  [''],
      cmbShopName   :  [''],
      drpPageLimit  : "10",
    });
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getShopListingFn();
    this.getOrderPaymentFn();
  }

  _clearForm(form: FormGroup) {
    form.reset({
      txtFromDate   :  '',
      txtToDate     :  '',
      txtOrderId    :  '',
      cmbShopName   :  '',
      drpPageLimit  : "10",
    });
    this.intTotalCount   = 0;
    this.intSkipCount    = 0;
    this.intPageLimit    = 10;
    this.getOrderPaymentFn();

  }
  _getPageLimit(value$) {
    this.intPageLimit = parseInt(this.frmOrderPayment.value.drpPageLimit);
    this.setPage(1);
  }

  _getShopId(id$) {
    this.strShopId = id$;
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(this.intTotalCount, page, this.intPageLimit);
    this.getOrderPaymentFn();
  }

  getShopListingFn() {
    this.reportServiceObj.getShopListingService().subscribe((res) => {
      this.arrStores = res.data;

    });
  }

  onSearch() {
    this.pager = {};
    this.intTotalCount    = 0;
    this.getOrderPaymentFn();
  }

  getOrderPaymentFn() {
    this.blnLoader = !this.blnLoader;
    console.log('Loader First::::', this.blnLoader);

    let skipCount = this.intSkipCount;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
    if (this.frmOrderPayment.value.txtFromDate === '' && this.frmOrderPayment.value.txtToDate === '') {
      console.log('From Date ::::', this.frmOrderPayment.value.txtFromDate);
      this.fromDate = this.datePipe.transform(this.currentDate, 'yyyy-M-dd');
      this.toDate = this.datePipe.transform(this.currentDate, 'yyyy-M-dd' );
    }
    if (this.frmOrderPayment.value.txtFromDate && this.frmOrderPayment.value.txtToDate === '') {
      console.log('To Date ::::', this.frmOrderPayment.value.txtToDate);
      this.fromDate = `${this.frmOrderPayment.value.txtFromDate.year}-${this.frmOrderPayment.value.txtFromDate.month}-${this.frmOrderPayment.value.txtFromDate.day}`;
      this.toDate = this.datePipe.transform(this.currentDate, 'yyyy-M-dd' );
    }
    if (this.frmOrderPayment.value.txtToDate && this.frmOrderPayment.value.txtFromDate === '') {
      console.log('To Date ::::', this.frmOrderPayment.value.txtToDate);
      this.fromDate = this.datePipe.transform(this.currentDate, 'yyyy-M-dd');
      this.toDate = `${this.frmOrderPayment.value.txtToDate.year}-${this.frmOrderPayment.value.txtToDate.month}-${this.frmOrderPayment.value.txtToDate.day}`;
    }

    if (this.frmOrderPayment.value.txtFromDate && this.frmOrderPayment.value.txtToDate) {
      this.fromDate = `${this.frmOrderPayment.value.txtFromDate.year}-${this.frmOrderPayment.value.txtFromDate.month}-${this.frmOrderPayment.value.txtFromDate.day}`;
      this.toDate = `${this.frmOrderPayment.value.txtToDate.year}-${this.frmOrderPayment.value.txtToDate.month}-${this.frmOrderPayment.value.txtToDate.day}`;
    }

    const obj = {
          intSkipCount: skipCount,
          intPageLimit: this.intPageLimit,
          strStoreId  : this.frmOrderPayment.value.cmbShopName,
          strFromDate : this.fromDate,
          strToDdate  : this.toDate,
          strOrderNo  : this.frmOrderPayment.value.txtOrderId.toUpperCase()
        };
    console.log('OBJECT::::::', obj);

    this.reportServiceObj.getOrderPaymentService(obj).subscribe((res) => {

          this.blnLoader        = !this.blnLoader;
          console.log('Loader Second::::', this.blnLoader);
          this.arrOrderPayment  = res.data[1];
          this.arrTotal         = res.data[2];
          if (res.data[1]) {
            this.intTotalCount  = res.data[0].intTotalCount;
          }
          console.log('Response is here::::::', res);

          this.pager = this.pageServiceObj.getPager(this.intTotalCount, this.pager.currentPage, this.intPageLimit);
          if (res.data.length === 0) {
            this.blnNoData = true;
          }
        });
  }

  getDownloadExcel() {
    this.blnDownloadLoader = !this.blnDownloadLoader;
    const obj = {
      strStoreId  : this.frmOrderPayment.value.cmbShopName,
      strFromDate : this.fromDate,
      strToDdate  : this.toDate,
      strOrderNo  : this.frmOrderPayment.value.txtOrderId.toUpperCase(),
      strDataType : 'EXCEL'
    };

    this.reportServiceObj.getOrderPaymentService(obj).subscribe(res => {
      console.log('RESPONSE EXCEL', res);
      this.blnDownloadLoader = !this.blnDownloadLoader;
      const strPath = this.apiURL + '/' + res.data;
      window.location.href = strPath;
    });

  }

}

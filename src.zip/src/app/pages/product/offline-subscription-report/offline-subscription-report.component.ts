import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import Swal from "sweetalert2";
import { PagerService } from "./../../../shared/services/pager.service";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";

@Component({
  selector: "app-offline-subscription-report",
  templateUrl: "./offline-subscription-report.component.html",
  styleUrls: ["./offline-subscription-report.component.scss"],
})
export class OfflineSubscriptionReportComponent implements OnInit {
  myform: FormGroup;
  submitted: boolean = false;
  intSkipCount = 0;
  pager: any = {};
  intPageLimit = 10;
  pageLimit: any[];
  intTotalCount = 0;
  strTypelId = "";
  formOfflineSubscription: FormGroup;
  editSubmitted: boolean = false;
  spinner: any;
  arrListReport: [];
  arrPlantList: [];
  arrShops: [];
  strFromDate: string;
  strPlanStatus: ""
  strToDdate: string;
  blnLoader = false
  clicked = false;
  strPlanId: "";
  response: any
  PlanStatus: any

  strPlaneType ="";
  arrStores:[];
  strShopId:'';
  cmbShopName:"";
  arrCompany:[];
  constructor(
    private pageServiceObj: PagerService,
    private formBuilder: FormBuilder,
    private modalService: NgbModal,
    private companyService: CompanyServiceService
  ) { }

  ngOnInit() {
    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.formOfflineSubscription = this.formBuilder.group({
      Strstatus: ["", Validators.required],
      txtFromDate: ["", Validators.required],
      txtToDate: ["", Validators.required],
      fkShopId: ["", Validators.required],
      strPlanStatus: "",
      strPlanId: ""

    });

    this.ListOfflineSubscription();
     this.getAllShop();
    // this.getAllCompany();
    this.ListPlantList();
  }

  _getPageLimit(value$) {
    this.intPageLimit = parseInt(value$);
    this.setPage(1);
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.ListOfflineSubscription();
  }

  get f() {
    return this.formOfflineSubscription.controls;
  }

  _onSearch() {
    // this.submitted = true;
    // if (this.formOfflineSubscription.invalid) {
    //   return;
    // }
    this.pager = {};
    this.intTotalCount = 0;
    this.ListOfflineSubscription();
  }

  ListOfflineSubscription() {
    let skipCount = this.intSkipCount;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
      strPlanStatus: this.formOfflineSubscription.value.Strstatus,
      fkShopId: this.formOfflineSubscription.value.fkShopId,
      fkPlanId: this.formOfflineSubscription.value.strPlanId,

      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
      // fkPlanId:this.formOfflineSubscription.value.strPlanId,
      // strShopName: this.myform.value.cmbShopName,


    };

    // if (localStorage.getItem("fkShopId")) {
    //   // Object.assign(obj, { fkShopId: localStorage.getItem("fkShopId") });
    //   Object.assign(obj, { fkShopId: localStorage.getItem("fkShopId") });

    //   // obj.fkShopId=localStorage.getItem('fkShopId')
    // }




    if(localStorage.getItem('fkShopId')){
      // Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
      this.arrStores = res.data;
      this.strShopId = res.data[0].pkShopId;
    });
    // if (
    //   this.formOfflineSubscription.value.txtFromDate &&
    //   this.formOfflineSubscription.value.txtToDate

    // ) {
    //   this.strFromDate = `${this.formOfflineSubscription.value.txtFromDate.year}-${this.formOfflineSubscription.value.txtFromDate.month}-${this.formOfflineSubscription.value.txtFromDate.day}`;
    //   this.strToDdate = `${this.formOfflineSubscription.value.txtToDate.year}-${this.formOfflineSubscription.value.txtToDate.month}-${this.formOfflineSubscription.value.txtToDate.day}`;
    //   obj.strFromDate = this.strFromDate,
    //   obj.strToDdate = this.strToDdate
    // }
    this.companyService.ListStoreSubscription(obj).subscribe((res) => {
      if (res && res.success) {
        this.arrListReport = res.data;
        this.intTotalCount = res.count;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
      } else {
        this.arrListReport = [];
       
      }
    });
  }

  onClear() {
    this.formOfflineSubscription.reset();
    this.ngOnInit();
  }

  



  getAllShop() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
    };
    if (localStorage.getItem("fkShopId")) {
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
      this.arrShops = res.data;
    });
  }
  ListPlantList() {
    const obj = {
      strLoginUserId: localStorage.getItem("userId"),

    };
    this.companyService.ListPlanDetails(obj).subscribe(
      (res) => {
        if (res.success) {
          this.arrPlantList = res.data;
        }
      },
      (err) => {
        this.arrPlantList = [];
        console.log(err);
      }
    );
  }

 
   onSwithProductStatus(status, PlanStatus) {
    if(PlanStatus === 'ACTIVE'){
      Swal.fire({
        title:"Warning",
        text:"Can't Deactivate",
        icon:"warning",
        confirmButtonText:"OK"
      }).then(()=>{
        this.ListOfflineSubscription()
      })
      return
    }
    console.log(PlanStatus, "status")
    const obj = {
      loginUserId: localStorage.getItem("userId"),
      storeId: status.fkShopId,
      subscriptionPlanId: status.fkPlanId,
      strOfflineSubscriptionId: status.pkOfflineSubscriptionId
    }
    this.companyService.AddOfflineactiveReport(obj).subscribe((res) => {
      if (res && res.success) {
        this.ListOfflineSubscription()
        // this.spinner.hide()
      } else {
        Swal.fire({
          title: 'Error',
          text: 'Try again later',
          icon: 'error',
          confirmButtonText: 'Ok'
        }).then(()=>{
          this.ListOfflineSubscription()
        })
        // this.spinner.hide()
      }
    })
  }
}









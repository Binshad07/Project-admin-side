import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OfflineSubscriptionReportComponent } from "./offline-subscription-report.component";

describe('OfflineSubscriptionReportComponent', () => {
  let component: OfflineSubscriptionReportComponent;
  let fixture: ComponentFixture<OfflineSubscriptionReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OfflineSubscriptionReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OfflineSubscriptionReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Router } from "@angular/router";
import { Validators } from "@angular/forms";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { modCategory } from "./../../../shared/Classes/HyperMarket.model";
import { HypermarketService } from "./../../../shared/services/Hypermarket/hypermarket.service";
import { ProductService } from "./../../../shared/services/product.service";
import { FormBuilder } from "@angular/forms";
import { Component, OnInit } from "@angular/core";
import { DatePipe } from "@angular/common";
import { PagerService } from "src/app/shared/services/pager.service";
import { FormGroup } from "@angular/forms";
import Swal from "sweetalert2";
import { ShopServiceService } from "src/app/shared/services/shopService/shop-service.service";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";

@Component({
  selector: "app-add-category",
  templateUrl: "./add-category.component.html",
  styleUrls: ["./add-category.component.scss"],
})
export class AddCategoryComponent implements OnInit {
  frmCategory: FormGroup;
  frmCategoryEdit: FormGroup;
  pager: any = {};
  intTotalCount = 0;
  intPageLimit = 10;
  datePipe = new DatePipe("en-US");
  pageLimit: any[];
  intSkipCount = 0;
  strCategoryId = "";
  blnLoader = false;
  submitted = false;
  arrayOfObjDeptList = [];
  arrViewType = [];
  arrShops = [];
  arrOfCategoryList: modCategory[] = [];
  categoryImg: File[] = [];
  clicked = false;
  isAdmin = true;

  constructor(
    private pageServiceObj: PagerService,
    private myProductService: ProductService,
    private modalService: NgbModal,
    private hypermarketServiceObj: HypermarketService,
    private formBuilder: FormBuilder,
    private router: Router,
    private shopService: ShopServiceService,
    private companyService: CompanyServiceService
  ) {}

  ngOnInit() {
    this.frmCategory = this.formBuilder.group({
      txtName: ["", Validators.required],
      arabicName: ["", Validators.required],
      // txtDescription: ['', Validators.required],
      txtImageUrl: ["", Validators.required],
      blnStatus: [true],
      drpViewType: ["", Validators.required],
      txtSortNo: ["", Validators.required],
      fkShopId: ["", Validators.required],
    });
    this.frmCategoryEdit = this.formBuilder.group({
      txtName: [""],
      arabicName: [""],
      // txtDescription: [''],
      txtImageUrl: [""],
      blnStatus: [""],
      drpViewType: [""],
      txtSortNo: [""],
      fkShopId: [""],
    });

    //this.getDepartmentFn();
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getAllShop();
    // this.pageLimit = this.pageServiceObj.showPagelist;
    this.getListCategoryFn();
    this.getViewTypeFn();
    if (localStorage.getItem("strUserType") == "SHOP REPORTER") {
      this.isAdmin = false;
    }
  }

  get formControls() {
    return this.frmCategory.controls;
  }

  /*
    TODO @Function: FUNCTION TO CLEAR FORM
    */
  //  _clearForm(form: FormGroup) {
  //    form.patchValue({txtName: ''});
  //    form.patchValue({arabicName: ''});
  //    form.patchValue({txtDescription: ''});
  //    form.patchValue({txtImageUrl: ''});
  //    form.patchValue({drpViewType: ''});
  //    form.patchValue({txtSortNo: ''});
  //    form.patchValue({drpDepartment: ''});
  //  }

  // _clearForm(form: FormGroup) {
  //   this.submitted = true
  //   form.patchValue({
  //     txtName: '',
  //     arabicName: '',
  //     txtDescription: '',
  //     txtImageUrl: '',
  //     drpViewType: '',
  //     txtSortNo: '',
  //     drpDepartment: '',
  //   });
  //   Object.keys(form.controls).forEach(key => {
  //     const control = form.get(key) as FormGroup;
  //     control.clearValidators();
  //     control.updateValueAndValidity();
  //   });
  // }

  _clearForm(form: FormGroup) {
    this.submitted = false;
    form.patchValue({
      txtName: "",
      arabicName: "",
      // txtDescription: '',
      txtImageUrl: "",
      drpViewType: "",
      txtSortNo: "",
      fkShopId: "",
    });
    //  form.patchValue({blnStatus: 'true'});
  }

  refreshPage() {
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    this.router.onSameUrlNavigation = "reload";
    this.router.navigate(["add-category"]);
  }

  /*
  strDeptName strCategoryName
    TODO @Function: FUNCTION TO SET PAGE LIMIT
    */
  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }
  /*
    TODO @Function: FUNCTION TO SET PAGE NUMBER
    */
  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getListCategoryFn();
  }

  _getEditModal(responsiveData, objValue) {
    console.log(objValue);
    this.modalService.open(responsiveData);
    this.strCategoryId = objValue.pkCategoryId;
    this.frmCategoryEdit.patchValue({ txtName: objValue.strName });
    this.frmCategoryEdit.patchValue({ arabicName: objValue.strArabicName });
    // this.frmCategoryEdit.patchValue({txtDescription: objValue.strDescription});
    this.frmCategoryEdit.patchValue({ txtImageUrl: objValue.strImageUrl });
    this.frmCategoryEdit.patchValue({ txtType: objValue.strType });
    this.frmCategoryEdit.patchValue({ txtSortNo: objValue.intSortNo });
    this.frmCategoryEdit.patchValue({ drpViewType: objValue.strViewType });
    this.frmCategoryEdit.patchValue({ fkShopId: objValue.fkShopId });
    if (objValue.strCategoryStatus === "N") {
      this.frmCategoryEdit.patchValue({ blnStatus: true });
    } else {
      this.frmCategoryEdit.patchValue({ blnStatus: false });
    }
  }

  _getDeleteModal(responsiveDelete, id) {
    this.strCategoryId = id;
    this.modalService.open(responsiveDelete);
  }

  /*
   TODO @Function: FUNCTION TO GET DEPARTMENT
   */
  getAllShop() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
    };
    if (localStorage.getItem("fkShopId")) {
      // Object.assign(obj, { strShopId: localStorage.getItem("fkShopId") });
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
      this.arrShops = res.data;
    });
  }

  getListCategoryFn() {
    // let skipCount = this.intSkipCount;
    // this.blnLoader = false;

    // if (this.pager.intSkipCount) {
    //   skipCount = this.pager.intSkipCount;
    // }
    // const obj = {
    //   strCategoryId: '',
    //   intPageLimit: this.intPageLimit,
    //   intSkipCount: skipCount,
    // };
    // if (localStorage.getItem('fkShopId')) {
    //   Object.assign(obj, { strShopId: localStorage.getItem('fkShopId') })
    //   // obj.fkShopId=localStorage.getItem('fkShopId')
    // }

    // this.hypermarketServiceObj.getListCategoryService(obj).subscribe(res => {
    //   console.log(res,"hssdddddddddddddddddddddddddddddddddddddddddddddddefsff")
    //   console.log(this.intTotalCount,"ufsuuidfffffffffffifhedkdiiiiiiiiiiiiii")
    //   if (res.success == true) {
    //     this.intTotalCount = res.data[0].intTotalCount;
    //     console.log(this.intTotalCount)
    //     this.arrOfCategoryList = res.data[1];
    //     console.log(this.arrOfCategoryList)
    //     this.pager = this.pageServiceObj.getPager(this.intTotalCount, this.pager.currentPage, this.intPageLimit);
    //   }
    //   else {
    //     this.intTotalCount = 0;
    //     this.pager = this.pageServiceObj.getPager(this.intTotalCount, this.pager.currentPage, this.intPageLimit);
    //   }

    // });

    let skipCount = this.intSkipCount;
    this.blnLoader = true;

    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }

    const obj = {
      strCategoryId: "",
      intPageLimit: this.intPageLimit,
      intSkipCount: skipCount,
    };
    if (localStorage.getItem("fkShopId")) {
      Object.assign(obj, { strShopId: localStorage.getItem("fkShopId") });
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.hypermarketServiceObj.getListCategoryService(obj).subscribe((res) => {
      this.blnLoader = true;
      this.arrOfCategoryList = res.data[1];
      console.log(res);
      // this._clearForm(this.frmSubCategory)
      this.intTotalCount = res.data[0].intTotalCount;
      this.arrOfCategoryList = res.data[1];

      // this.intTotalCount = res.data.length;
      this.pager = this.pageServiceObj.getPager(
        this.intTotalCount,
        this.pager.currentPage,
        this.intPageLimit
      );
    });
  }

  getSaveCategoryFn() {
    this.blnLoader = false;
    this.submitted = true;
    // this.submitted = !this.submitted;
    if (this.frmCategory.invalid) {
      this.blnLoader = true;
      return;
    }
    let fData = new FormData();
    fData.append("strCategoryName", this.frmCategory.value.txtName);
    fData.append("strArabicName", this.frmCategory.value.arabicName);
    // fData.append("strDescription", this.frmCategory.value.txtDescription)
    fData.append("strViewStatus", this.frmCategory.value.blnStatus);
    fData.append("strLoginUserId", localStorage.getItem("userId"));
    fData.append("fkShopId", this.frmCategory.value.fkShopId);
    fData.append("strViewType", this.frmCategory.value.drpViewType);
    fData.append("strSortCount", this.frmCategory.value.txtSortNo);
    for (let image of this.categoryImg) {
      fData.append("strImageUrl", image, image.name);
    }
    fData.forEach((value, key) => {
      console.log(key, value);
    });
    // this.clicked = true;

    this.hypermarketServiceObj
      .getSaveCategoryService(fData)
      .subscribe((res) => {
        if (res.success === true) {
          this.clicked = false;
          this.blnLoader = true;
          Swal.fire({
            title: "Saved!",
            text: "New Category Added Successfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then(() => {
            // this.refreshPage()
            // this.getListCategoryFn();


            this.frmCategory.reset();
            this.router.navigate(["/add-category"]);
            this.submitted = false;
          });
        } else {
          this.blnLoader = true;
          // Swal.fire({
          //   title: "Error",
          //   text: res.message,
          //   icon: "error",
          //   confirmButtonText: "Ok",
          // })
          // alert(res.message)
        }
        this.getListCategoryFn();
      });
  }

  getDeleteCategoryFn() {
    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
      strCategoryId: this.strCategoryId,
    };
    this.hypermarketServiceObj
      .getDeleteCategoryService(obj)
      .subscribe((res) => {
        if (res.success === true) {
          Swal.fire({
            title: "Deleted!",
            text: "Category deleted successfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then(() => {
            this.modalService.dismissAll();
            this.router.routeReuseStrategy.shouldReuseRoute = () => false;
            this.router.onSameUrlNavigation = "reload";
            this.router.navigate(["add-category"]);
          });
        } else {
          Swal.fire({
            title: "Error",
            text: res.message,
            icon: "error",
            confirmButtonText: "Ok",
          });
        }
        this.getListCategoryFn();
      });
  }

  getUpdateCategoryFn() {
    let fData = new FormData();

    fData.append("strCategoryName", this.frmCategoryEdit.value.txtName);
    fData.append("strArabicName", this.frmCategoryEdit.value.arabicName);
    fData.append("strViewType", this.frmCategoryEdit.value.drpViewType);
    fData.append("fkShopId", this.frmCategoryEdit.value.fkShopId);
    fData.append("strViewStatus", this.frmCategoryEdit.value.blnStatus);
    fData.append("strLoginUserId", localStorage.getItem("userId"));
    // fData.append("strDescription",this.frmCategoryEdit.value.txtDescription)
    fData.append("strSortCount", this.frmCategoryEdit.value.txtSortNo);
    for (let image of this.categoryImg) {
      fData.append("strImageUrl", image, image.name);
    }

    fData.append("strCategoryId", this.strCategoryId);

    fData.forEach((value, key) => {
      console.log(key + " " + value);
    });

    this.hypermarketServiceObj
      .getUpdateCategoryService(fData)
      .subscribe((res) => {
        if (res.success === true) {
          // alert('Category Updated');
          Swal.fire({
            title: "Updated!",
            text: "Category Updated successfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then(() => {
            this.modalService.dismissAll();
            // this.refreshPage()
            this.router.routeReuseStrategy.shouldReuseRoute = () => false;
            this.router.onSameUrlNavigation = "reload";
            this.router.navigate(["add-category"]);
          });
        } else {
          Swal.fire({
            title: "Error",
            text: res.message,
            icon: "error",
            confirmButtonText: "Ok",
          });
        }
        this.getListCategoryFn();
      });
  }

  getViewTypeFn() {
    const obj = {};
    if (localStorage.getItem("strUserType") == "SHOP REPORTER") {
      Object.assign(obj, {
        strViewTypeName: localStorage.getItem("strViewType"),
      });
    }
    this.hypermarketServiceObj.getVieType(obj).subscribe((res) => {
      console.log(res, "resssviwetype");
      this.arrViewType = res.data;
      console.log(this.arrViewType, "console");
      this.setDefaultViewType(this.arrViewType);
    });
  }

  onFileChange(event) {
    console.log("event");
    for (let i of event.target.files) {
      this.categoryImg.push(i);
    }
  }

  //  _getShoptId($ShopId) {
  //   this.strShopId = $ShopId;
  //   this.getListCategoryFn($ShopId);
  // }
  setDefaultViewType(viewType) {
    if (!this.isAdmin) {
      const firstOptionValue = viewType[0].strName;
      this.frmCategory.get("drpViewType").setValue(firstOptionValue);
    }
  }
}

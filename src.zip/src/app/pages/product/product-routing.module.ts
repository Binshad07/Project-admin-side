import { AddPromogroupComponent } from "./add-promogroup/add-promogroup.component";
import { AddPromocodeComponent } from "./add-promocode/add-promocode.component";
import { PromocodeComponent } from "./promocode/promocode.component";
import { TransactionReportComponent } from "./transaction-report/transaction-report.component";
import { AddSubcategoryComponent } from "./add-subcategory/add-subcategory.component";
import { AddDepartmentComponent } from "./add-department/add-department.component";
import { DeliveryDetailsComponent } from "./delivery-details/delivery-details.component";
import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AddProductComponent } from "./add-product/add-product.component";
import { ImportProductComponent } from "./import-product/import-product.component";
import { ImportAllProductsComponent } from "./import-all-products/import-all-products.component";
import { ImportCategorySubcategoryComponent } from "./import-category-subcategory/import-category-subcategory.component";
import { ReportProductComponent } from "./report-product/report-product.component";
import { HubOrderSummaryComponent } from "./hub-order-summary/hub-order-summary.component";
import { HubSummaryComponent } from "./hub-summary/hub-summary.component";
import { OrderSummaryComponent } from "./order-summary/order-summary.component";
import { UpdateOutOfStockComponent } from "./update-out-of-stock/update-out-of-stock.component";
import { NewImportProductComponent } from "./new-import-product/new-import-product.component";
import { PayComponent } from "./pay/pay.component";
import { CustomerOrderSummaryComponent } from "./customer-order-summary/customer-order-summary.component";
import { CustomerOrderTrackingComponent } from "./customer-order-tracking/customer-order-tracking.component";
import { TimeSlotManagementComponent } from "./time-slot-management/time-slot-management.component";
import { OrderSummaryReportComponent } from "./order-summary-report/order-summary-report.component";
import { ReturnReportComponent } from "./return-report/return-report.component";
import { CancelledReportComponent } from "./cancelled-report/cancelled-report.component";
import { PaymentReportComponent } from "./payment-report/payment-report.component";
import { DeliveryReportComponent } from "./delivery-report/delivery-report.component";
import { OrderLifecycleReportComponent } from "./order-lifecycle-report/order-lifecycle-report.component";
import { DeliverySummaryComponent } from "./delivery-summary/delivery-summary.component";
import { UserDetailsComponent } from "./user-details/user-details.component";
import { WishlistAnalysisComponent } from "./wishlist-analysis/wishlist-analysis.component";
import { SalesReportComponent } from "./sales-report/sales-report.component";
import { CartAnalysisComponent } from "./cart-analysis/cart-analysis.component";
import { AddCategoryComponent } from "./add-category/add-category.component";
import { CreateAdminUserComponent } from "./create-admin-user/create-admin-user.component";
import { NewReportComponent } from "./new-report/new-report.component";
import { UploadmultipleimageComponent } from "./uploadmultipleimage/uploadmultipleimage.component";
import { CancelReasonsComponent } from "./cancel-reasons/cancel-reasons.component";
import { AddShopComponent } from "./add-shop/add-shop.component";
import { ListShopComponent } from "./list-shop/list-shop.component";
import { AddBannerComponent } from "./add-banner/add-banner.component";
import { DeliveryUserComponent } from "./delivery-user/delivery-user.component";
import { AddDeliveryuserComponent } from "./add-deliveryuser/add-deliveryuser.component";
import { HomebannerComponent } from "./homebanner/homebanner.component";
import { AddHomebannerComponent } from "./add-homebanner/add-homebanner.component";
import { ListBannerComponent } from "./list-banner/list-banner.component";
import { AddStoreUserComponent } from "./add-store-user/add-store-user.component";
import { StoreUserComponent } from "./store-user/store-user.component";
import { OfferBannersComponent } from "./offer-banners/offer-banners.component";
import { PermissionsComponent } from "./permissions/permissions.component";
import { OrderTrackingComponent } from "./order-tracking/order-tracking.component";
import { ProductListComponent } from "./product-list/product-list.component";
import { UserComponent } from "./user/user.component";
import { AddUserComponent } from "./add-user/add-user.component";
import { UserPermissionsComponent } from "./user-permissions/user-permissions.component";
import { ListBrandComponent } from "./list-brand/list-brand.component";
import { ShopSettingsComponent } from "./shop-settings/shop-settings.component";
import { OfflineSubscriptionReportComponent } from "./offline-subscription-report/offline-subscription-report.component";
import { AddOfflineReportComponent } from "./add-offline-report/add-offline-report.component";
import { ListSubscriptionReportComponent } from "./list-subscription-report/list-subscription-report.component";
import { AddHomemiddleBannerComponent } from "./add-homemiddle-banner/add-homemiddle-banner.component";
import { ListHomemiddleBannerComponent } from "./list-homemiddle-banner/list-homemiddle-banner.component";
import { SettlementComponent } from "./settlement/settlement.component";
import { InsightsComponent } from "./insights/insights.component";
import { SettlementListComponent } from "./settlement-list/settlement-list.component";
import { ListDomainComponent } from "./list-domain/list-domain.component";
import { AddDomainComponent } from "./add-domain/add-domain.component";
import { StoreloginreportComponent } from "./storeloginreport/storeloginreport.component";
import { UnitnameComponent } from "./unitname/unitname.component";
import { AddUnitComponent } from "./add-unit/add-unit.component";
import { PushNotificationComponent } from "./push-notification/push-notification.component";
import { ListShopCountComponent } from "./list-shop-count/list-shop-count.component";
import { ReturnRequestComponent } from "./return-request/return-request.component";
import { RenewShopComponent } from "./renew-shop/renew-shop.component";
import { BypassSettingsComponent } from "./bypass-settings/bypass-settings.component";
import { OrderTransactionReportComponent } from "./order-transaction-report/order-transaction-report.component";
import { OtpLimitComponent } from "./otp-limit/otp-limit.component";
import { CreateWithdrawrequestComponent } from "./create-withdrawrequest/create-withdrawrequest.component";
// import { WithdrawrequestComponent } from "./withdrawrequest/withdrawrequest.component";
import { WithdrawRequestComponent } from "./withdraw-request/withdraw-request.component";
// import { CreateSubscriptionReportComponent } from "./create-subscription-report/create-subscription-report.component";
import { CreateSubscriptionReportComponent } from "./create-subscription-report/create-subscription-report.component";

import { CustomledgerComponent } from "./customledger/customledger.component";
import { SalesLeadsComponent } from "./sales-leads/sales-leads.component";
import { VoucherComponent } from "./voucher/voucher.component";
import { VoucherListComponent } from "./voucher-list/voucher-list.component";
import { PixelrequestComponent } from "./pixelrequest/pixelrequest.component";
import { AnalyticsRequestComponent } from "./analytics-request/analytics-request.component";
import { RazorpayRequestComponent } from "./razorpay-request/razorpay-request.component";
import { AgencyModuleComponent } from "./agency-module/agency-module.component";
import { FreezingModuleComponent } from "./freezing-module/freezing-module.component";
import { CustomerTicketRequestComponent } from "./customer-ticket-request/customer-ticket-request.component";
import { UpcomingStoreRenewalsComponent } from "./upcoming-store-renewals/upcoming-store-renewals.component";
import { WebsiteLeadsListComponent } from "./website-leads-list/website-leads-list.component";
import { OtpRequestDetailsComponent } from "./otp-request-details/otp-request-details.component";
import { BypassLoginComponent } from "./bypass-login/bypass-login.component";


const routes: Routes = [
  // {
  //   path: "",
  //   redirectTo: "/product/add-product",
  //   pathMatch: "full",
  // },
  {
    path: "add-product",
    component: AddProductComponent,
  },
  {
    path: "update-product",
    component: ImportProductComponent,
  },
  {
    path: "import-product",
    component: ImportAllProductsComponent,
  },
  {
    path: "import-category-subcategory",
    component: ImportCategorySubcategoryComponent,
  },
  {
    path: "report-product",
    component: ReportProductComponent,
  },
  {
    path: "hub-summary",
    component: HubSummaryComponent,
  },
  {
    path: "hub-order-summary",
    component: HubOrderSummaryComponent,
  },
  {
    path: "order-summary",
    component: OrderSummaryComponent,
  },
  {
    path: "update-product-details",
    component: UpdateOutOfStockComponent,
  },
  {
    path: "import-product-2",
    component: NewImportProductComponent,
  },
  {
    path: "pay",
    component: PayComponent,
  },
  {
    path: "customer-order-summary",
    component: CustomerOrderSummaryComponent,
  },
  {
    path: "customer-order-tracking",
    component: CustomerOrderTrackingComponent,
  },
  {
    path: "time-slot",
    component: TimeSlotManagementComponent,
  },
  // JULY 15th 2020
  {
    path: "return-report",
    component: ReturnReportComponent,
  },
  {
    path: "delivery-report",
    component: DeliveryReportComponent,
  },
  {
    path: "delivery-summary",
    component: DeliverySummaryComponent,
  },
  {
    path: "user-details",
    component: UserDetailsComponent,
  },
  {
    path: "wishlist-analysis",
    component: WishlistAnalysisComponent,
  },
  {
    path: "add-category",
    component: AddCategoryComponent,
  },
  {
    path: "create-admin-user",
    component: CreateAdminUserComponent,
  },
  {
    path: "order-summary-report",
    component: OrderSummaryReportComponent,
  },
  {
    path: "cancelled-report",
    component: CancelledReportComponent,
  },
  {
    path: "payment-report",
    component: PaymentReportComponent,
  },

  {
    path: "order-lifecycle-report",
    component: OrderLifecycleReportComponent,
  },
  {
    path: "sales-report",
    component: SalesReportComponent,
  },
  {
    path: "cart-analysis",
    component: CartAnalysisComponent,
  },
  {
    path: "new-report",
    component: NewReportComponent,
  },
  {
    path: "image-uploaded",
    component: UploadmultipleimageComponent,
  },
  {
    path: "delivery-details",
    component: DeliveryDetailsComponent,
  },

  {
    path: "cancel-reasons",
    component: CancelReasonsComponent,
  },
  {
    path: "add-department",
    component: AddDepartmentComponent,
  },
  {
    path: "add-subcategory",
    component: AddSubcategoryComponent,
  },
  {
    path: "transaction-report",
    component: TransactionReportComponent,
  },
  {
    path: "promocode",
    component: PromocodeComponent,
  },
  {
    path: "add-promocode",
    component: AddPromocodeComponent,
  },
  {
    path: "add-promo-group",
    component: AddPromogroupComponent,
  },
  {
    path: "add-shop",
    component: AddShopComponent,
  },
  {
    path: "add-banner",
    component: AddBannerComponent,
  },
  {
    path: "list-banner",
    component: ListBannerComponent,
  },
  {
    path: "list-shop",
    component: ListShopComponent,
  },
  {
    path: "delivery-user",
    component: DeliveryUserComponent,
  },
  {
    path: "add-deliveryuser",
    component: AddDeliveryuserComponent,
  },
  {
    path: "homepagebanner",
    component: HomebannerComponent,
  },
  {
    path: "add-homebanner",
    component: AddHomebannerComponent,
  },
  {
    path: "add-store-user",
    component: AddStoreUserComponent,
  },
  {
    path: "store-user",
    component: StoreUserComponent,
  },
  {
    path: "offer-banners",
    component: OfferBannersComponent,
  },
  {
    path: "permission",
    component: PermissionsComponent,
  },
  {
    path: "order-tracking",
    component: OrderTrackingComponent,
  },
  {
    path: "product-review",
    component: ProductListComponent,
  },
  {
    path: "user",
    component: UserComponent,
  },
  {
    path: "add-user",
    component: AddUserComponent,
  },
  {
    path: "user-permissions",
    component: UserPermissionsComponent,
  },
  {
    path: "list-brand",
    component: ListBrandComponent,
  },
  {
    path: "Offline-Subscription-Report",
    component: OfflineSubscriptionReportComponent,
  },
  {
    path: "Add-Offline-Reports",
    component: AddOfflineReportComponent,
  },
  {
    path: "List-SubscriptionReport",
    component: ListSubscriptionReportComponent,
  },

  {
    path: "add-homemiddle-banner",
    component: AddHomemiddleBannerComponent,
  },

  {
    path: "List-homemiddle-bannerlist",
    component: ListHomemiddleBannerComponent,
  },
  {
    path: "shop-settings",
    component: ShopSettingsComponent,
  },
  {
    path: "settlement",
    component: SettlementComponent,
  },
  {
    path: "List-Domain",
    component: ListDomainComponent,
  },
  {
    path: "add-domain",
    component: AddDomainComponent,
  },
  {
    path: "insights",
    component: InsightsComponent,
  },
  {
    path: "Push-Notification",
    component: PushNotificationComponent,
  },
  {
    path: "list-shop-count",
    component: ListShopCountComponent,
  },
  {
    path: "settlement-list",
    component: SettlementListComponent,
  },

  {
    path: "storeloginreport",
    component: StoreloginreportComponent,
  },
  {
    path: "productunit",
    component: UnitnameComponent,
  },
  {
    path: "add-unit",
    component: AddUnitComponent,
  },

  {
    path: "returnrequest",
    component: ReturnRequestComponent,
  },

  {
    path: "renew-shop",
    component: RenewShopComponent,
  },

  {
    path: "create-withdrawrequest",
    component: CreateWithdrawrequestComponent,
  },
  {
    path: "withdraw-request",
    component: WithdrawRequestComponent
  },
  {
    path: "bypass-settings",
    component: BypassSettingsComponent
  },


  {
    path: "order-transaction-report",
    component: OrderTransactionReportComponent
  },

  {
    path: "otp-limit",
    component: OtpLimitComponent
  },

  {
    path: "create-subscription-report",
    component: CreateSubscriptionReportComponent
  },

  {
    path: "custom-ledger",
    component: CustomledgerComponent
  },

  {
    path: "pixel-request",
    component: PixelrequestComponent
  },
  {
    path: "analytics-request",
    component: AnalyticsRequestComponent
  },

  {
    path: "razorpay-request",
    component: RazorpayRequestComponent
  },
  {
    path: "Agency-module",
    component: AgencyModuleComponent
  },
  {
    path: "sales-leads",
    component: SalesLeadsComponent
  },
  {
    path: "voucher",
    component: VoucherComponent
  },
  {
    path: "voucher-list",
    component: VoucherListComponent
  },
  {
    path: "Customer-Ticket-request",
    component: CustomerTicketRequestComponent
  },
  {
    path: "Upcoming-store-renewals",
    component: UpcomingStoreRenewalsComponent
  },
  {
    path: "Website-leads",
    component: WebsiteLeadsListComponent
  },
  {
    path: "Otp-request-details",
    component: OtpRequestDetailsComponent
  },
  {
    path:"freezing-module",
    component:FreezingModuleComponent
  },
  {
    path:"user-creation",
    component:BypassLoginComponent
  },
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ProductRoutingModule { }

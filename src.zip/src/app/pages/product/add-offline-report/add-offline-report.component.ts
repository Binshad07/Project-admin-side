import { Component, OnInit } from "@angular/core";
import Swal from "sweetalert2";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { BannerServiceService } from "src/app/shared/services/BannerService/banner-service.service";
// import { BannersService } from 'src/app/shared/services/banners.service';
import { PagerService } from "src/app/shared/services/pager.service";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";

@Component({
  selector: "app-add-offline-report",
  templateUrl: "./add-offline-report.component.html",
  styleUrls: ["./add-offline-report.component.scss"],
})
export class AddOfflineReportComponent implements OnInit {
  myForm: FormGroup;
  // frmProductReport: FormGroup;
  pager: any = {};
  intTotalCount = 0;
  intPageLimit = 10;
  pageLimit: any[];
  intSkipCount = 0;
  strCategoryId = "";
  blnLoader = false;
  submitted = false;
  arrShops = [];
  id = "";
  type = "Add";
  blnUpdate = false;
  clicked = false;
  arrPlantList: [];
  fkShopId:''
  pkShopId:''
  constructor(
    private companyService: CompanyServiceService,
    private pageServiceObj: PagerService,
    private modalService: NgbModal,
    private formBuilder: FormBuilder,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.route.queryParams.subscribe((params) => {
      this.id = params["id"];
    });
    this.myForm = this.formBuilder.group({
      strPlanId: ["", Validators.required],
      StrTranscation: ["", Validators.required],
      fkShopId: ["", Validators.required],
    });

    this.getAllShop();
    this.ListPlantList();
  }

  get f() {
    return this.myForm.controls;
  }

  // getAllShop() {
  //   const obj = {
  //     strLoginUserId: localStorage.getItem("userId"),
  //   };
  //   if (localStorage.getItem("fkShopId")) {
  //     // Object.assign(obj, { strShopId: localStorage.getItem("fkShopId") });
  //     Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

  //     // obj.fkShopId=localStorage.getItem('fkShopId')
  //   }
  //   this.companyService.fngetallCompany(obj).subscribe((res) => {
  //     if (res.success === true) {
  //       this.arrShops = res.data;
  //     }
  //   });
  // }




  getAllShop() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
    };
    if (localStorage.getItem("fkShopId")) {
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
      this.arrShops = res.data;
    });
  }
  clearForm() {
    this.submitted = false;
    this.myForm.reset();
  }
  addOfflineRepoort() {
    this.submitted = true;
    if (this.myForm.invalid) {
      this.blnLoader = true;
      return;
    }

    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
      fkShopId: this.myForm.value.fkShopId,
      strTransactionId: this.myForm.value.StrTranscation,
      fkPlanId: this.myForm.value.strPlanId,
    };

    this.companyService.AddOfflineReport(obj).subscribe(
      (res) => {
        console.log(res);
        if (res && res.success) {
          this.clicked = false;
          // this.spinner.hide();
          Swal.fire({
            title: "Saved!",
            text: "Offline Report Add Saved Successfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then(() => {
            this.myForm.reset();
            this.router.navigate(["/product/Offline-Subscription-Report"]);
            this.submitted = false;
          });
        } else {
          // this.spinner.hide();
          Swal.fire({
            title: "Error",
            text: res.message,
            icon: "error",
            confirmButtonText: "Ok",
          });
        }
      },
      (err) => {
        console.log(err);
      }
    );
  }
  
  ListPlantList() {
    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
      fkShopId: this.myForm.value.fkShopId
    };
    this.companyService.ListPlanDetails(obj).subscribe(
      (res) => {
        if (res.success) {
          this.arrPlantList = res.data;
        }
      },
      (err) => {
        this.arrPlantList = [];
        console.log(err);
      }
    );
  }
 
  
  
}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddOfflineReportComponent } from './add-offline-report.component';

describe('AddOfflineReportComponent', () => {
  let component: AddOfflineReportComponent;
  let fixture: ComponentFixture<AddOfflineReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddOfflineReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddOfflineReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

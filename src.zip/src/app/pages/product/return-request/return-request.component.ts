import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";

import { FormGroup, FormBuilder } from "@angular/forms";
import { PagerService } from "src/app/shared/services/pager.service";

import { ReportsService } from 'src/app/shared/services/Reports/reports.service';
import { DatePipe } from "@angular/common";

@Component({
  selector: 'app-return-request',
  templateUrl: './return-request.component.html',
  styleUrls: ['./return-request.component.scss']
})
export class ReturnRequestComponent implements OnInit {



  intTotalCount = 0;
  intSkipCount = 0;
  pageLimit: any[];
  intPageLimit = 10;
  pager: any = {};
  arrRequest = [];
  datePipe = new DatePipe("en-US");
  blnLoader = false;


  constructor(

   private pageServiceObj: PagerService,
    private reportService: ReportsService,
    private router: Router,
    private formBuilder: FormBuilder
  
  ) { }

  ngOnInit() {

    
      this.pager = {};
      this.pageLimit = this.pageServiceObj.showPagelist;
      this.getAllRequest()
  
    
  }

  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getAllRequest();
  }

  getAllRequest() {

  let skipCount = this.intSkipCount;
    this.blnLoader = false;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }

    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
      // deviceType: this.formBannerImages.value.deviceType,
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
    }
    


    this.reportService.getAllRequest(obj).subscribe((res) => {
      
      if (res && res.success) {
        
        this.blnLoader = true;
        this.arrRequest = res.data;
        this.intTotalCount = res.count;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
      } else {
        this.arrRequest = []
       
      }
    })
  }


}



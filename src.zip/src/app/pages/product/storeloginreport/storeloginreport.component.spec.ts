import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StoreloginreportComponent } from './storeloginreport.component';

describe('StoreloginreportComponent', () => {
  let component: StoreloginreportComponent;
  let fixture: ComponentFixture<StoreloginreportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StoreloginreportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StoreloginreportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

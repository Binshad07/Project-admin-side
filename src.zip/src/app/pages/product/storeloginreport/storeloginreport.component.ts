// import { Component, OnInit } from '@angular/core';


// @Component({
//   selector: 'app-storeloginreport',
//   templateUrl: './storeloginreport.component.html',
//   styleUrls: ['./storeloginreport.component.scss']
// })
// export class StoreloginreportComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }

import { Component, OnInit } from '@angular/core';
import { PagerService } from "src/app/shared/services/pager.service";
import { Router } from "@angular/router";
import Swal from "sweetalert2";
import { FormGroup, FormBuilder } from "@angular/forms";
import { ReportsService } from 'src/app/shared/services/Reports/reports.service';
import { DatePipe } from "@angular/common";

@Component({
  //   selector: 'app-storeloginreport',
  selector: 'app-storereportComponent',
  templateUrl: './storeloginreport.component.html',
  styleUrls: ['./storeloginreport.component.scss'],
})
export class StoreloginreportComponent implements OnInit {
  intTotalCount = 0;
  formBannerImages: FormGroup;
  intSkipCount = 0;
  pageLimit: any[];
  intPageLimit = 10;
  pager: any = {};
  arrReport = [];
  datePipe = new DatePipe("en-US");

  blnLoader = false;

  constructor(
    private pageServiceObj: PagerService,
    private reportService: ReportsService,
    private router: Router,
    private formBuilder: FormBuilder
  ) { }

  ngOnInit() {
    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getSignupList()

  }
  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getSignupList();
  }

  getSignupList() {

    let skipCount = this.intSkipCount;
    this.blnLoader = false;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }

    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
      // deviceType: this.formBannerImages.value.deviceType,
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
    }
    // if(localStorage.getItem('fkShopId')){
    //   Object.assign(obj,{fkShopId: localStorage.getItem('fkShopId')})
    //   // obj.fkShopId=localStorage.getItem('fkShopId')
    // }


    this.reportService.getAllSignUp(obj).subscribe((res) => {
      console.log("jpg", res)
      if (res && res.success) {
        //  this.ngOnInit()
        // this.spinner.hide();
        this.blnLoader = true;
        this.arrReport = res.data;
        this.intTotalCount = res.count;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
      } else {
        this.arrReport = []
        // Swal.fire({
        //   title: "Error",
        //   text: res.message,
        //   icon: "error",
        //   confirmButtonText: "Ok",
        // });
        // this.spinner.hide();
      }
    })
  }


}

import { Component, OnInit } from '@angular/core';
import { FormArray } from "@angular/forms";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
// import { UsersService } from "src/app/shared/services/User/user.service";
import Swal from "sweetalert2";
import { GeneralDataService } from "src/app/shared/services/general-data.service";

import { UserGroupService } from "src/app/shared/services/UserGroup/user-group.service";
import { element } from "protractor";

@Component({
  selector: 'app-user-permissions',
  templateUrl: './user-permissions.component.html',
  styleUrls: ['./user-permissions.component.scss']
})
export class UserPermissionsComponent implements OnInit {
  type = "Add";
  myForm: FormGroup;
  id = "";
  permissionId = "";
  submitted = false;
  deliveryType: any;
  blnUpdate = false;
  userTypes = [];
  countries = [];
  users = [];
  arrPermissions = [];
  selectedCity = "";
  arrModules = [];
  arrModuleBody = [];
  user: any;
  userTypeId: any;
  blnAdmin = false;
  userType: any;
  strShopId = "";
  strFranchiseId = "";

  constructor(
    private formBuilder: FormBuilder,
    // private userService: UsersService,
    private router: Router,
    private route: ActivatedRoute,
    // private spinner: NgxSpinnerService,
    private userGroupService: UserGroupService
  ) { }

  ngOnInit() {
    this.userType = localStorage.getItem('userRole')
    if (this.userType === null || this.userType === '' || this.userType === undefined) {
      this.blnAdmin = !this.blnAdmin;
    } else {
      this.strShopId = localStorage.getItem('shopId');
      this.strFranchiseId = localStorage.getItem('franchiseId')


    }

    this.myForm = this.formBuilder.group({
      strUserName: ["", Validators.required],
      strUserTypeId: ["", Validators.required],
      userPermissions: this.formBuilder.array([this.getCheckBoxValue()]),
    });
    this.route.queryParams.subscribe((params) => {
      this.id = params["id"];
      this.user = params["user"];
      this.userTypeId = params["userTypeId"];
    });
    this.getUserPermissionsFn();
    this.getUserType();
    this.getAllUsers();
    if (this.id && !this.user) {
      this.blnUpdate = true;
      this.getCurrentUserPermission();
    }
    if (this.id && this.user) {
      this.myForm.patchValue({
        strUserName: this.id,
        strUserTypeId: this.userTypeId
      })
      this.myForm.get("strUserName").disable();
      this.myForm.get("strUserTypeId").disable();
    }
  }
  addCheckBoxes() {
    this.arrPermissions.forEach(() =>
      this.permissionsFormArray.push(this.getCheckBoxValue())
    );
    this.permissionsFormArray.removeAt(0);
  }

  get f() {
    return this.myForm.controls;
  }

  get permissionsFormArray() {
    return this.myForm.get("userPermissions") as FormArray;
  }

  getCheckBoxValue() {
    return this.formBuilder.group({
      strCheckBox: "",
    });
  }

  getUserType() {
    const obj = {
      strSkipCount: "",
      strPageLimit: "",
    };
    this.userGroupService.getAllUserGroup(obj).subscribe((res) => {
      this.userTypes = res.data.data;
    });
  }
  getAllUsers() {
    const obj = {
      strSkipCount: "",
      strPageLimit: "",
      strShopId: this.strShopId,
      strFranchiseId: this.strFranchiseId,
      strUpdateUserId: localStorage.getItem("userId"),
    };
    this.userGroupService.getAdminList(obj).subscribe((res) => {
      console.log(res,"ressssupdated");
      if (res.success) {
        this.users = res.data;
      }
    });
  }
  getUserPermissionsFn() {
    const obj = {
      strCreateUserId: localStorage.getItem("userId"),
    };
    this.userGroupService.getUserPermissionsService(obj).subscribe((res) => {
      this.arrPermissions = res.data[0].arryModuleDetails;
      //console.log('Array Permissions:::::::::', this.arrPermissions);
      this.addCheckBoxes();
    });
  }

  _changeModules(name) {
    //  console.log('Name:::::', name);

    if (
      this.arrModules.find((moduleName) => moduleName.strModuleName === name)
    ) {
      const index = this.arrModules.findIndex(
        (moduleName) => moduleName.strModuleName === name
      );
      this.arrModules.splice(index, 1);
    } else {
      this.arrPermissions.find((module) => {
        if (module.strModuleName === name) {
          this.arrModules.push(module);
          return module;
        }
      }, []);
    }
  }

  getCurrentUserPermission() {
  
    let testArray = this.myForm.get("userPermissions") as FormArray;
    const obj = {
      fkIntUserId: this.id,
    };
    console.log(obj)
    this.userGroupService.getCurrentPermissionsService(obj).subscribe((res) => {
      console.log('Current permissions::::::', res);

      if (res.success === true) {
       
        this.permissionId = res.data[0].pkPermissionId;
        this.myForm.patchValue({
          strUserName: res.data[0].fkIntUserId,
          strUserTypeId: res.data[0].strUserTypeId,
        });
        // this.arrModules.findIndex(moduleName => moduleName.strModuleName === name);
        let arrModuleVal = res.data[0].arryModuleDetails;
        setTimeout(() => {
          for (let i = 0; i < arrModuleVal.length; i++) {
            let index = this.arrPermissions.findIndex(
              (moduleName) =>
                moduleName.strModuleName === arrModuleVal[i].strModuleName
            );
            testArray.at(index).patchValue({
              strCheckBox: arrModuleVal[i].strModuleName,
            });
            this._changeModules(arrModuleVal[i].strModuleName);
          }
        }, 1000);
      } else {
        Swal.fire({
          title: "error",
          text: res.message,
          icon: "error",
          confirmButtonText: "Ok",
        });

      }
    });
  }

  getSavePermissionsFn() {
    if (!this.arrModules.length) {
      Swal.fire({
        title: "error",
        text: 'Please provide permission to atleast one module',
        icon: "error",
        confirmButtonText: "Ok",
      });
      return;
    }

    this.submitted = true;
    if (this.myForm.invalid) {

      return;
    }
    if (!this.id) { 
    this.id = this.myForm.value.strUserName
  }
  if(!this.user){
    this.userTypeId=this.myForm.value.strUserTypeId
  }
  const userTypeName = this.userTypes.find(
    (userType) => userType.pkUserTypeId === this.userTypeId
  ).strUserType;

  const obj = {
    strCreateUserId: localStorage.getItem("userId"),
    fkIntUserId: this.id,
    strUserTypeId: this.userTypeId,
    strUserType: userTypeName,
    arryModuleDetails: this.arrModules,
  };
    this.userGroupService.getAddUserPermissionsService(obj).subscribe((res) => {
    if (res.success === true) {

      console.log(res,"ressssssssssss")
   
      Swal.fire({
        title: "success",
        text: "Permissions added",
        icon: "success",
        confirmButtonText: "Ok",
      });
      this.refreshPage();
    } else {
      Swal.fire({
        title: "error",
        text: res.message,
        icon: "error",
        confirmButtonText: "Ok",
      });
     
    }
  });
  }

getUpdatePermisssion() {

  const obj = {
    pkPermissionId: this.permissionId,
    strUpdateUserId: localStorage.getItem("userId"),
    fkIntUserId: this.id,
    arryModuleDetails: this.arrModules,
  };
  console.log(obj)

  this.userGroupService
    .getUpdateUserPermissionsService(obj)
    .subscribe((res) => {
      console.log(res, "response")
      if (res.success === true) {
        Swal.fire({
          title: "success",
          text: "Successfully updated",
          icon: "success",
          confirmButtonText: "Ok",
        });
      
        this.refreshPage();
      } else {
        Swal.fire({
          title: "error",
          text: res.message,
          icon: "error",
          confirmButtonText: "Ok",
        });
        // this.spinner.hide();
      }
    });
}
refreshPage() {
  this.router.routeReuseStrategy.shouldReuseRoute = () => false;
  this.router.onSameUrlNavigation = "reload";
  this.router.navigate(["user"]);
}

cancelFn() {
  this.ngOnInit();
}

}

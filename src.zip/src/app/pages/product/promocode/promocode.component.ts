import { Component, OnInit } from "@angular/core";
import { PagerService } from "src/app/shared/services/pager.service";
import { PromocodeService } from "src/app/shared/services/promocode/promocode.service";
import { Router } from "@angular/router";
import Swal from "sweetalert2";
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-promocode',
  templateUrl: './promocode.component.html',
  styleUrls: ['./promocode.component.scss']
})
export class PromocodeComponent implements OnInit {

  pager: any = {};
  intTotalCount = 0;
  intSkipCount = 0;
  intPageLimit = 10;
  arrPromoList = [];
  pageLimit: any[];
  blnLoader = false;


  constructor(
    private pageServiceObj: PagerService,
    private promoCodeService: PromocodeService,
    private router: Router
  ) {}

  ngOnInit() {
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getPromoCode();
  }

  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }
  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getPromoCode();
  }

  getPromoCode() {
    let skipCount = this.intSkipCount;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
    const obj = {
      strSkipCount: skipCount,
      strPageLimit: this.intPageLimit,
      strLoginUserId: localStorage.getItem("userId"),
    };
    if(localStorage.getItem('fkShopId')){
      Object.assign(obj,{fkShopId: localStorage.getItem('fkShopId')})
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    console.log(obj);

    this.promoCodeService.getPromoCode(obj).subscribe((res) => {
      console.log(res,"getPromoceede");
      this.blnLoader = true;
      if (res.success) {
        this.arrPromoList = res.data;
        console.log("this.arrr" ,this.arrPromoList)
        this.intTotalCount = res.count[0].intTotalCount;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
      }
    });
  }

  update(item) {
    this.router.navigate(["/add-promocode"], {
      queryParams: { id: item.pkPromocodeId },
    });
  }
  delete(item) {
    const swalWithBootstrapButtons = Swal.mixin({
      customClass: {
        confirmButton: "btn btnAdd ml-2",
        cancelButton: "btn btnCancel",
      },
      buttonsStyling: false,
    });

    swalWithBootstrapButtons
      .fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Yes, delete it!",
        cancelButtonText: "No, cancel!",
        reverseButtons: true,
      })
      .then((result) => {
        if (result.value) {
          const obj = {
            strLoginUserId: localStorage.getItem("userId"),
            strPromocodeId: item.pkPromocodeId,
          };
          this.blnLoader = false;

          this.promoCodeService.deletePromoCode(obj).subscribe((res) => {
            if (res.success) {
              this.blnLoader = true;
              swalWithBootstrapButtons.fire(
                "Deleted!",
                "Promocode has been deleted Successfully",
                "success"
              );
              this.ngOnInit();
              this.getPromoCode();
              
            } else{
              Swal.fire({
                title: "Error",
                text: res.message,
                icon: "error",
                confirmButtonText: "Ok",
              });
            }
          });
        }
        //  else if (
        //   /* Read more about handling dismissals below */
        //   result.dismiss === Swal.DismissReason.cancel
        // ) {
        //   // swalWithBootstrapButtons.fire(
        //     // "Cancelled",
        //     // "Your file is safe :)",
        //     // "error"
        //   // );
        // }
      });
  }

}

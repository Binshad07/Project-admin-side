import { Component, OnInit } from '@angular/core';
import { PagerService } from "src/app/shared/services/pager.service";
import { DatePipe } from "@angular/common";
import { ReportsService } from "src/app/shared/services/Reports/reports.service";
import { FormBuilder, FormGroup } from "@angular/forms";
import { modOrderSummary } from "src/app/shared/Classes/report.model";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";
import { HypermarketService } from './../../../shared/services/Hypermarket/hypermarket.service';
import { environment } from "./../../../../environments/environment.prod";

@Component({
  selector: 'app-upcoming-store-renewals',
  templateUrl: './upcoming-store-renewals.component.html',
  styleUrls: ['./upcoming-store-renewals.component.scss']
})
export class UpcomingStoreRenewalsComponent implements OnInit {
  currentDate = new Date();
  frmStore: FormGroup;
  pager: any = {};
  intTotalCount = 0;
  strPageLimit = 10;
  datePipe = new DatePipe("en-US");
  pageLimit: any[];
  strShopId = "";
  arrStores = [];
  strSkipCount = 0;
  arrStore: [];
  fromDate;
  toDate;
  blnLoader = false;
  blnDownloadLoader = false;
  private apiURL: string = environment.API_ENDPOINT;
  userType: string;

  constructor(
    private pageServiceObj: PagerService,
    private formBuilder: FormBuilder,
    private companyService:CompanyServiceService,
    private reportServiceObj: ReportsService,
    private hypermarketServiceObj: HypermarketService,
  ) { }

  ngOnInit() {
    this.frmStore = this.formBuilder.group({
      txtFromDate: [""],
      txtToDate: [""],
      strContactNumber: [""],
      strEmail :[],
      cmbShopName: "",
      drpPageLimit: "10",
    });
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getShopListingFn();
    this.getRenewal();
    this.userType=localStorage.getItem("strUserType");
  }
  _clearForm(form: FormGroup) {
    form.reset({
      fromDate: "",
      toDate: "",
      cmbShopName: "",
      strContactNumber: "",
      strEmail :"",
      drpPageLimit: "10",
    });
    this.intTotalCount = 0;
    this.strSkipCount = 0;
    this.strPageLimit = 10;
    this.getRenewal();
  }
  _getPageLimit(value) {
    this.strPageLimit = parseInt(this.frmStore.value.drpPageLimit);
    this.setPage(1);
  }
  _getShopId(id$) {
    this.strShopId = id$;
  }
  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.strPageLimit
    );
    this.getRenewal();
  }
  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.getRenewal();
  }

  getShopListingFn() {
    const obj = {
      loginUserId:localStorage.getItem("userId"),
    }
    if(localStorage.getItem('fkShopId')){
      // Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
      this.arrStores = res.data;
      this.strShopId = res.data[0].pkShopId;
    });
  }
  getRenewal() {
    let skipCount = this.strSkipCount;
    this.blnLoader = false;

    if (this.pager.strSkipCount) {
      skipCount = this.pager.strSkipCount;
    }
    if (
      this.frmStore.value.txtFromDate === "txtFromDate" &&
      this.frmStore.value.txtToDate === "txtToDate"
    ) {
      console.log("From Date ::::", this.frmStore.value.txtFromDate);
      this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
      this.toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    }
    if (
      this.frmStore.value.txtFromDate &&
      this.frmStore.value.txtToDate === "txtToDate"
    ) {
      console.log("To Date ::::", this.frmStore.value.txtToDate);
      this.fromDate = `${this.frmStore.value.txtFromDate.year}-${this.frmStore.value.txtFromDate.month}-${this.frmStore.value.txtFromDate.day}`;
      this.toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    }
    if (
      this.frmStore.value.txtToDate &&
      this.frmStore.value.txtFromDate === "txtFromDate"
    ) {
      console.log("To Date ::::", this.frmStore.value.txtToDate);
      this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
      this.toDate = `${this.frmStore.value.txtToDate.year}-${this.frmStore.value.txtToDate.month}-${this.frmStore.value.txtToDate.day}`;
    }

    if (
      this.frmStore.value.txtFromDate &&
      this.frmStore.value.txtToDate
    ) {
      this.fromDate = `${this.frmStore.value.txtFromDate.year}-${this.frmStore.value.txtFromDate.month}-${this.frmStore.value.txtFromDate.day}`;
      this.toDate = `${this.frmStore.value.txtToDate.year}-${this.frmStore.value.txtToDate.month}-${this.frmStore.value.txtToDate.day}`;
    }

    const obj = {
      loginUserId:localStorage.getItem("userId"),
      strSkipCount: skipCount,
      strPageLimit: this.strPageLimit,
      strShopName: this.frmStore.value.cmbShopName, // this.strShopId
      fromDate: this.fromDate, // fromTime
      toDate: this.toDate, // toTime
      strContactNumber: this.frmStore.value.strContactNumber,
      strEmail: this.frmStore.value.strEmail
    };


    console.log("Object:::::", obj);

    this.hypermarketServiceObj.getStoreRenewalCount(obj).subscribe((res) => {
      this.blnLoader = true;
      this.arrStore = res.data;
      if (res.data) {
        this.intTotalCount = res.count;
      }
      this.pager = this.pageServiceObj.getPager(
        this.intTotalCount,
        this.pager.currentPage,
        this.strPageLimit
      );
    });
  }
}

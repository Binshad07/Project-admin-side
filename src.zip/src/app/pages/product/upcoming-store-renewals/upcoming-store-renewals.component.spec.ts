import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpcomingStoreRenewalsComponent } from './upcoming-store-renewals.component';

describe('UpcomingStoreRenewalsComponent', () => {
  let component: UpcomingStoreRenewalsComponent;
  let fixture: ComponentFixture<UpcomingStoreRenewalsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpcomingStoreRenewalsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpcomingStoreRenewalsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

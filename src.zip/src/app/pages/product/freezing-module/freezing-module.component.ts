import { Component, OnInit } from "@angular/core";
import Swal from "sweetalert2";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";
import { HypermarketService } from "src/app/shared/services/Hypermarket/hypermarket.service";
@Component({
  selector: "app-freezing-module",
  templateUrl: "./freezing-module.component.html",
  styleUrls: ["./freezing-module.component.scss"],
})

export class FreezingModuleComponent implements OnInit {
  myForm: FormGroup;
  blnLoader = false;
  submitted = false;
  arrShops = [];
  selectedShopDetails: any = null;  
  isFrozen: boolean = false; 
  clicked:false
  


  constructor(
    private modalService: NgbModal,
    private formBuilder: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private companyService: CompanyServiceService,
    private hypermarketServiceObj: HypermarketService
  ) {}

  ngOnInit() {
    this.myForm = this.formBuilder.group({
      fkShopId: ["", Validators.required],
    });
    this.getAllShop();
  }

  get f() {
    return this.myForm.controls;
  }

  getAllShop() {
    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
    };
    if (localStorage.getItem("fkShopId")) {
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });
    }
    this.companyService.fnShopListFn(obj).subscribe((res) => {
      this.arrShops = res.data;
    });
  }

  onShopSelect(event: any) {
    const selectedShopId = event.target.value;
    this.selectedShopDetails = this.arrShops.find(shop => shop.pkShopId === selectedShopId);
  }

  capitalizeFirstLetter(str: string): string {
    if (!str) return '';
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
  }
  
  
  confirmUnfreeze() {
    Swal.fire({
      title: 'Confirm Unfreeze',
      text: 'Do you want to unfreeze the shop?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes',
      cancelButtonText: 'No'
    }).then((result) => {
      if (result.isConfirmed) {
        this.unfreezeShop();
      }
    });
  }
  
  confirmFreeze() {
    Swal.fire({
      title: 'Confirm Freeze',
      text: 'Do you want to freeze the shop?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes',
      cancelButtonText: 'No'
    }).then((result) => {
      if (result.isConfirmed) {
        this.freezeShop();
      }
    });
  }
  
  //   this.submitted = !this.submitted;
  //   if (this.myForm.invalid) {
  //     this.submitted = true;
  //     return;
  //   }
  //   const obj = {
  //     pkUserId: localStorage.getItem("userId"),
  //     fkShopId:
  //   };
  //   console.log(obj,"tyft")
  //   this.hypermarketServiceObj.addfreezeBMKPay(obj).subscribe(
  //     (res) => {
  //       console.log(res);
  //       if (res && res.success) {
  //         Swal.fire({
  //           title: "Saved!",
  //           text: "Freezing Saved Successfully",
  //           icon: "success",
  //           confirmButtonText: "Ok",
  //         }).then(() => {
  //           this.myForm.reset();
  //           this.submitted = false;
  //         });
  //       } else {
  //         Swal.fire({
  //           title: "Error",
  //           text: res.message,
  //           icon: "error",
  //           confirmButtonText: "Ok",
  //         });
  //       }
  //     },
  //     (err) => {
  //       console.log(err);
  //     }
  //   );
  
  unfreezeShop() {
    if (!this.selectedShopDetails) {
      Swal.fire({
        title: "Error",
        text: "No shop selected.",
        icon: "error",
        confirmButtonText: "Ok",
      });
      return;
    }
  
    const obj = {
      pkUserId: localStorage.getItem("userId"),
      fkShopId: this.selectedShopDetails.pkShopId
    };
  
    this.hypermarketServiceObj.addUnfreezeBMKPay(obj).subscribe(
      (res) => {
        if (res && res.success) {
          this.isFrozen = false; // Set the frozen state to false
          Swal.fire({
            title: "Saved!",
            text: "Shop has been unfrozen successfully.",
            icon: "success",
            confirmButtonText: "Ok",
          });
        } else {
          Swal.fire({
            title: "Error",
            text: res.message,
            icon: "error",
            confirmButtonText: "Ok",
          });
        }
      },
      (err) => {
        console.log(err);
      }
    );
  }

  
  freezeShop() {
    if (!this.selectedShopDetails) {
      Swal.fire({
        title: "Error",
        text: "No shop selected.",
        icon: "error",
        confirmButtonText: "Ok",
      });
      return;
    }
  
    const obj = {
      pkUserId: localStorage.getItem("userId"),
      fkShopId: this.selectedShopDetails.pkShopId
    };
  
    this.hypermarketServiceObj.addfreezeBMKPay(obj).subscribe(
      (res) => {
        if (res && res.success) {
          this.isFrozen = true; // Set the frozen state to true
          Swal.fire({
            title: "Saved!",
            text: "Shop has been frozen successfully.",
            icon: "success",
            confirmButtonText: "Ok",
          });
        } else {
          Swal.fire({
            title: "Error",
            text: res.message,
            icon: "error",
            confirmButtonText: "Ok",
          });
        }
      },
      (err) => {
        console.log(err);
      }
    );
  }
  
  

  clearForm() {
    this.myForm.reset();
    this.selectedShopDetails = null;
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FreezingModuleComponent } from './freezing-module.component';

describe('FreezingModuleComponent', () => {
  let component: FreezingModuleComponent;
  let fixture: ComponentFixture<FreezingModuleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FreezingModuleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FreezingModuleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';

import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from "@angular/router";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";
import Swal from 'sweetalert2';
import { ReportsService } from 'src/app/shared/services/Reports/reports.service';





@Component({
  selector: 'app-add-unit',
  templateUrl: './add-unit.component.html',
  styleUrls: ['./add-unit.component.scss']
})
export class AddUnitComponent implements OnInit {



  myForm: FormGroup;

  pager: any = {};
  intTotalCount = 0;
  intPageLimit = 10;
  pageLimit: any[];
  intSkipCount = 0;
  submitted: boolean = false;
  
  id = "";
  type = "Add";
  blnUpdate = false;
 
  clicked = false;
  
  arrShops: [];
  arrUnit: any;

  strUnitName;
  strLoginUserId: any;
  blnLoader: boolean;


  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private companyService: CompanyServiceService,
    private reportService: ReportsService,

  ) { }

  ngOnInit() {


    this.route.queryParams.subscribe((params) => {
      this.id = params["id"];
    });

    this.myForm = this.formBuilder.group({
      unit: ["", Validators.required],
      fkShopId: ["", Validators.required],



    })
    this.getAllShop();
    this.getunitlistFn();


    if (this.id) {
      this.type = "Update";
     
      this.blnUpdate = true;

      this.patchvalue();
    }
  }
  get f() {
    return this.myForm.controls;
  }



  

  addUnitlist() {
    const obj = {
      strLoginUserId: localStorage.getItem('userId'),
      strUnitName: this.myForm.value.unit,
      strShopId: this.myForm.value.fkShopId,
      
      intPageLimit: this.intPageLimit,
    }

    this.clicked = true;
    this.reportService.Addunitlist(obj).subscribe((res) => {
      console.log(res)
      if (res && res.success) {
        
        Swal.fire({
          title: "Saved!",
          text: "Unit Saved Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then(() => {
          this.myForm.reset()
          this.router.navigate(['/productunit'])
          this.submitted = false;
        })
      } else {
       if(res.message == "Unit name already in use. Please choose another."){
        Swal.fire({
          title: "Warning",
          text: res.message,
          icon: "warning",
          confirmButtonText: "Ok",
        });
       }
       else{
        Swal.fire({
          title: "Warning",
           text: res.message,
          icon: "warning",
          confirmButtonText: "Ok",
        });
       }
        
      }
    }, (err) => {
      console.log(err)
    })


  }







  getAllShop() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
    }
    console.log(obj, "tesghjchbv")
    if (localStorage.getItem('fkShopId')) {
      // Object.assign(obj, { strShopId: localStorage.getItem('fkShopId') })
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

    
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {

      this.arrShops = res.data
    })
  }

  clearForm() {
    this.myForm.reset();
    this.ngOnInit();
  }

  

  getunitlistFn() {
    const obj = {
      loginUserId: localStorage.getItem('userId'),
    
      pkUnitId: this.id

    }

    this.reportService.getunitlist(obj).subscribe((res) => {
      if (res && res.success) {
        console.log("patch", res.data)
        this.myForm.patchValue({
         
          pkUnitId: res.data[0].unit,
          fkShopId: res.data[0].strShopId,
          
        })
      }
    })
  }




  update() {

    const obj = {
      strLoginUserId: localStorage.getItem('userId'),
      strUnitName: this.myForm.value.unit,
      strShopId: this.myForm.value.fkShopId,
      strUnitId: this.id,
    }

    console.log(obj)

    this.clicked = true;
    this.reportService.updateunitlist(obj).subscribe((res) => {
      console.log(res)
      if (res && res.success) {
        
        Swal.fire({
          title: "Saved!",
          text: "Unit Updated Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then(() => {
          this.myForm.reset()
          this.router.navigate(['/productunit'])
          this.submitted = false;
        })
      } else {
        
        Swal.fire({
          title: "Error",
          text: res.message,
          icon: "error",
          confirmButtonText: "Ok",
        });
      }
    }, (err) => {
      console.log(err)
    })


  }

  
  




  patchvalue() {

    this.blnLoader = false;

    const obj = {
      strLoginUserId: localStorage.getItem('userId'),
      pkUnitId: this.id,
    }

    this.reportService.UnitList(obj).subscribe((res) => {
      if (res && res.success) {
        this.arrUnit = res.data;
        console.log(this.arrUnit)
        if (this.arrUnit.length) {

          this.myForm.patchValue({ unit: this.arrUnit[0].strUnitName });
          this.myForm.patchValue({ fkShopId: this.arrUnit[0].fkShopId });

        }
      }
    })
  }
}


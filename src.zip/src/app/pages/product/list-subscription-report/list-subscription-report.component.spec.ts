import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListSubscriptionReportComponent } from './list-subscription-report.component';

describe('ListSubscriptionReportComponent', () => {
  let component: ListSubscriptionReportComponent;
  let fixture: ComponentFixture<ListSubscriptionReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListSubscriptionReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListSubscriptionReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

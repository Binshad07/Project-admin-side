import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import Swal from "sweetalert2";
import { PagerService } from "./../../../shared/services/pager.service";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";

@Component({
  selector: "app-list-subscription-report",
  templateUrl: "./list-subscription-report.component.html",
  styleUrls: ["./list-subscription-report.component.scss"],
})
export class ListSubscriptionReportComponent implements OnInit {
  myform: FormGroup;
  submitted: boolean = false;
  intSkipCount = 0;
  pager: any = {};
  intPageLimit = 10;
  pageLimit: any[];
  intTotalCount = 0;
  strTypelId = "";
  arrSubscriptionReportList: [];
  arrShops: [];
  frmTypeEdit: FormGroup;
  editSubmitted: boolean = false;
  arrPlantList: [];
  fromDate: string;
  toDate: string;

  constructor(
    private pageServiceObj: PagerService,
    private formBuilder: FormBuilder,
    private modalService: NgbModal,
    private companyService: CompanyServiceService
  ) {}

  ngOnInit() {
    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.myform = this.formBuilder.group({
      strPlaneType: "",
      strPlanId: [""],
      fkShopId: [""],
      txtToDate: [""],
      txtFromDate: [""],
      strsubscriptionStatus: [""],
    });
    this.ListSubscriptionReportList();
    this.getAllShop();
    this.ListPlantList();
  }

  ListSubscriptionReportList() {
    let skipCount = this.intSkipCount;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }

    const obj = {

      strLoginUserId: localStorage.getItem("userId"),
      planType: this.myform.value.strPlaneType,
      pkPlanId: this.myform.value.strPlanId,
      fkShopId: this.myform.value.fkShopId,
      toDate : this.myform.value.txtToDate,
      fromDate: this.myform.value. txtFromDate,
      subscriptionStatus: this.myform.value.strsubscriptionStatus,
      strSkipCount: skipCount,
      strPageLimit: this.intPageLimit,
    };
    if (localStorage.getItem("fkShopId")) {
      Object.assign(obj, { fkShopId: localStorage.getItem("fkShopId") });
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    
    if (
      this.myform.value.txtFromDate &&
      this.myform.value.txtToDate

    ) {
      this.fromDate = `${this.myform.value.txtFromDate.year}-${this.myform.value.txtFromDate.month}-${this.myform.value.txtFromDate.day}`;
      this.toDate = `${this.myform.value.txtToDate.year}-${this.myform.value.txtToDate.month}-${this.myform.value.txtToDate.day}`;
      obj.fromDate = this.fromDate,
      obj.toDate = this.toDate
    }
    console.log(obj, "obj::::::::::::");
    this.companyService.ListSubscriptionReport(obj).subscribe(
      (res) => {
        if (res.success) {
          console.log(res, "response:::::::::::::::::::");
          this.arrSubscriptionReportList = res.data;
          this.intTotalCount = res.count;
          this.pager = this.pageServiceObj.getPager(
            this.intTotalCount,
            this.pager.currentPage,
            this.intPageLimit
          );
        }
      },
      (err) => {
        Swal.fire({
          title: "Error",
          text: "Something went wrong! Please try again",
          icon: "error",
          confirmButtonText: "Ok",
        });
        console.log(err);
      }
    );
  }

  //Plans

  ListPlantList() {
    let skipCount = this.intSkipCount;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }

    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
    };

    this.companyService.ListPlanDetails(obj).subscribe(
      (res) => {
        if (res.success) {
          this.arrPlantList = res.data;
          this.pager = this.pageServiceObj.getPager(
            this.intTotalCount,
            this.pager.currentPage,
            this.intPageLimit
          );
        }
      },
      (err) => {
        Swal.fire({
          title: "Error",
          text: "Something went wrong! Please try again",
          icon: "error",
          confirmButtonText: "Ok",
        });
        console.log(err);
      }
    );
  }
  _getPageLimit(value$) {
    this.intPageLimit = parseInt(value$);
    this.setPage(1);
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.ListSubscriptionReportList();
  }

  get formControlsEdit() {
    return this.myform.controls;
  }

  getAllShop() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
    };
    if (localStorage.getItem("fkShopId")) {
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
      this.arrShops = res.data;
    });
  }

  get f() {
    return this.myform.controls;
  }

  onClear() {
    this.submitted = false;
    this.myform.reset();
    this.ngOnInit();
  }

  _onSearch() {
    // this.submitted = true;
    // if (this.myform.invalid) {
    //   return;
    // }
    this.pager = {};
    this.intTotalCount = 0;
    this.ListSubscriptionReportList();
  }
}

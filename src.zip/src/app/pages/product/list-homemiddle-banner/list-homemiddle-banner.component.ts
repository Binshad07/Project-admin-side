import { Component, OnInit } from "@angular/core";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { PagerService } from "src/app/shared/services/pager.service";
import { Router } from "@angular/router";
import Swal from "sweetalert2";
import { FormGroup, FormBuilder } from "@angular/forms";
import { BannersService } from "src/app/shared/services/Banner/banners.service";

@Component({
  selector: "app-list-homemiddle-banner",
  templateUrl: "./list-homemiddle-banner.component.html",
  styleUrls: ["./list-homemiddle-banner.component.scss"],
})
export class ListHomemiddleBannerComponent implements OnInit {
  intTotalCount = 0;
  formBannerImages: FormGroup;
  intSkipCount = 0;
  pageLimit: any[];
  intPageLimit = 10;
  pager: any = {};
  arrMiddleBanner = [];
  strBannerImageId = "";
  showModal: boolean;
  strSelectedImg: string;
  strSelectedImageType: string;
  objSelectedItem: any;
  strBannerId: "";
  blnLoader = false;
  submitted : boolean = false

  constructor(
    private pageServiceObj: PagerService,
    private modalService: NgbModal,
    private router: Router,
    private formBuilder: FormBuilder,
    private BannerService: BannersService,

  ) {}

  ngOnInit() {
    this.formBannerImages = this.formBuilder.group({
      deviceType: "",
    });
    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getMiddleBannerList();
  }

  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getMiddleBannerList();
  }

  getMiddleBannerList() {
    let skipCount = this.intSkipCount;
    this.blnLoader = false;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }

    const obj = {
      loginUserId: localStorage.getItem("userId"),
      strImageType: this.formBannerImages.value.deviceType,
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
    };
    if (localStorage.getItem("fkShopId")) {
      Object.assign(obj, { fkShopId: localStorage.getItem("fkShopId") });
    }
    this.BannerService.getListHomeMiddleBanner(obj).subscribe(
      (res) => {
        if (res && res.success) {
          //  this.ngOnInit()
          // this.spinner.hide();
          this.blnLoader = true;
          this.arrMiddleBanner = res.data;
          this.intTotalCount = res.count;
          this.pager = this.pageServiceObj.getPager(
            this.intTotalCount,
            this.pager.currentPage,
            this.intPageLimit
          );
        } else {
          this.arrMiddleBanner = [];

          // Swal.fire({
          //   title: "Error",
          //   text: res.message,
          //   icon: "error",
          //   confirmButtonText: "Ok",
          // });
          // this.spinner.hide();
        }
      },
      (err) => {
        this.arrMiddleBanner = [];
        console.log(err);
      }
    );
  }

  onClickViewImg(item, image, type) {
    this.objSelectedItem = item;
    this.strSelectedImg = image;
    this.strSelectedImageType = type;
    this.show();
  }

  show() {
    this.showModal = true;
  }
  hide() {
    this.showModal = false;
  }

  _onSearch() {
    this.submitted = true;
    if (this.formBannerImages.invalid) {
      return;
    }
    this.pager = {};
    this.intTotalCount = 0;
    this.getMiddleBannerList();
  }

  _onClear() {
    this.submitted = false;
    this.formBannerImages.reset();
    this.ngOnInit();
  }

  deleteModal(responsiveDelete, item) {
    this.strBannerId = item.pkMiddleBannerId;
    this.modalService.open(responsiveDelete);
  }

  delete() {
    const obj = {
      pkMiddleBannerId: this.strBannerId,
      loginUserId: localStorage.getItem("userId"),
    };
    console.log(obj);

    // this.spinner.show();

    this.BannerService.deleteHomeMiddleBanner(obj).subscribe(
      (res) => {
        if (res.success && res) {
          this.modalService.dismissAll();
          // this.spinner.hide();
          Swal.fire({
            title: "Deleted!",
            text: "Delete home middle banner successfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then(() => {
            this.getMiddleBannerList();
            this.ngOnInit();
          });
        } else {
          // this.spinner.hide();
          this.arrMiddleBanner = [];

          // Swal.fire({
          //   // title: "Error",
          //   // text: res.message,
          //   // icon: "error",
          //   // confirmButtonText: "Ok",
          // });
        }
        this.getMiddleBannerList();
      },
      (err) => {
        console.log(err);
      }
    );
  }

  edit(item) {
    console.log(item);
    this.router.navigate(["/product/add-homemiddle-banner"], {
      queryParams: { id: item.pkMiddleBannerId },
    });
  }

  errorImage(event) {
    event.target.src = "assets/images/Group 4024 (1).png";
  }
}

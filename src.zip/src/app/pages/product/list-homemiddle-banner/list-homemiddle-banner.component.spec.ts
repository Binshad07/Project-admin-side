import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListHomemiddleBannerComponent } from './list-homemiddle-banner.component';

describe('ListHomemiddleBannerComponent', () => {
  let component: ListHomemiddleBannerComponent;
  let fixture: ComponentFixture<ListHomemiddleBannerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListHomemiddleBannerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListHomemiddleBannerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

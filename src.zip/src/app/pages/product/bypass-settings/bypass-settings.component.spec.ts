import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BypassSettingsComponent } from './bypass-settings.component';

describe('BypassSettingsComponent', () => {
  let component: BypassSettingsComponent;
  let fixture: ComponentFixture<BypassSettingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BypassSettingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BypassSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

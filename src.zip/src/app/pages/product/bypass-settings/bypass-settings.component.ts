import { Component, OnInit } from "@angular/core";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";
import Swal from "sweetalert2";
import { ReportsService } from "src/app/shared/services/Reports/reports.service";

@Component({
  selector: "app-bypass-settings",
  templateUrl: "./bypass-settings.component.html",
  styleUrls: ["./bypass-settings.component.scss"],
})
export class BypassSettingsComponent implements OnInit {
  myform: FormGroup;
  submitted: boolean = false;
  blnUpdate = false;
  arrShops: [];
  blnLoader: boolean;
  fkShopId: any;
  arrshopdetails: [];
  clicked = false;
  phoneno: any;
  selectedShopId: any;
  isFeatureEnabled = false;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private companyService: CompanyServiceService,
    private route: ActivatedRoute,
    private reportService: ReportsService
  ) {}

  ngOnInit() {
    this.route.queryParams.subscribe((parmas) => {
      this.fkShopId = parmas.id ? parmas.id : "";
    });
    this.myform = this.formBuilder.group({
      fkShopId: ["", Validators.required],
    });
    this.getAllShop();
  }

  getAllShop() {
    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
    };
    console.log(obj, "tesghjchbv");
    if (localStorage.getItem("fkShopId")) {
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });
    }
    this.companyService.fnShopListFn(obj).subscribe((res) => {
      console.log(res, "abcdef");
      this.arrShops = res.data;
    });
  }

  onFileChange(event: any) {
    this.selectedShopId = event.target.value;
    console.log("Selected Shop ID:", this.selectedShopId);
    this.BypassingShopDetails(this.selectedShopId);
  }


  get formControls() {
    return this.myform.controls;
  }

  get f() {
    return this.myform.controls;
  }

  BypassingShopDetails(shopId: any) {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
      fkShopId: shopId,
      strEmail: this.myform.value.Email,
    };
    this.companyService.ByPassFilter(obj).subscribe(
      (res) => {
        if (res.success) {
          this.arrshopdetails = res.data;
        }
      },
      (err) => {
        this.arrshopdetails = [];
        console.log(err);
      }
    );
  }

  toggleFeature() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
      fkShopId: this.selectedShopId,
    };
    console.log(obj,"obj:::::")
    if (this.isFeatureEnabled) {
      // Disable the feature
      this.reportService.removebypassfilter(obj).subscribe(
        (res) => {
          console.log(res,"res::::::::::")
          if (res && res.success) {
            Swal.fire({
              title: "Saved!",
              text: "Disabled Successfully",
              icon: "success",
              confirmButtonText: "Ok",
            }).then(() => {
              this.myform.reset();
              this.submitted = false;
              this.isFeatureEnabled = false; // Update the flag
            });
          } else {
            Swal.fire({
              title: "Error",
              text: res.message,
              icon: "error",
              confirmButtonText: "Ok",
            });
          }
        },
        (err) => {
          console.log(err);
        }
      );
    } else {
      // Enable the feature
      this.reportService.byPassShop(obj).subscribe(
        (res) => {
          if (res && res.success) {
            console.log(res,"res::::::::::")
            Swal.fire({
              title: "Saved!",
              text: "Enabled Successfully",
              icon: "success",
              confirmButtonText: "Ok",
            }).then(() => {
              this.myform.reset();
              this.submitted = false;
              this.isFeatureEnabled = true; // Update the flag
            });
          } else {
            Swal.fire({
              title: "Error",
              text: res.message,
              icon: "error",
              confirmButtonText: "Ok",
            });
          }
        },
        (err) => {
          console.log(err);
        }
      );
    }
  }
}

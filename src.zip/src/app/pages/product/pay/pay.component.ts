import { Component, OnInit } from '@angular/core';
import { Injectable } from '@angular/core';
import * as $  from 'jquery';
import { ReportsService } from 'src/app/shared/services/Reports/reports.service';
declare const myfun:any;

@Injectable()
@Component({
  selector: 'app-pay',
  templateUrl: './pay.component.html',
  styleUrls: ['./pay.component.scss']
})
export class PayComponent implements OnInit {


  constructor( ) { }

   ngOnInit() {

   }


}

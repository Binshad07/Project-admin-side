import { Component, OnInit } from '@angular/core';
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { PagerService } from "src/app/shared/services/pager.service";
import { Router } from "@angular/router";
// import { NgxSpinnerService } from "ngx-spinner";
import Swal from "sweetalert2";
import { FormGroup, FormBuilder } from "@angular/forms";
import { BannersService } from 'src/app/shared/services/Banner/banners.service';

@Component({
  selector: 'app-homebanner',
  templateUrl: './homebanner.component.html',
  styleUrls: ['./homebanner.component.scss']
})
export class HomebannerComponent implements OnInit {


  intTotalCount = 0;
  formBannerImages: FormGroup;
  intSkipCount = 0;
  pageLimit: any[];
  intPageLimit = 10;
  pager: any = {};
  arrHomeBanner = [];
  strBannerImageId = "";
  showModal: boolean;
  strSelectedImg: string;
  strSelectedImageType: string;
  objSelectedItem: any;
  pkImageId:any;

  constructor(
    private pageServiceObj: PagerService,
    private modalService: NgbModal,
    // private spinner: NgxSpinnerService,
    private router: Router,
    private formBuilder: FormBuilder,
    private BannerService:BannersService
  ) { }

  ngOnInit() {

    this.formBannerImages = this.formBuilder.group({
      txtdeviceType: "",
    });

    

    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getListBannerImagesFn();
  }


  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getListBannerImagesFn();
  }

  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.getListBannerImagesFn();
  }



  _onClear(form: FormGroup) {
    form.reset({
    txtdeviceType: "",
    });
    this.getListBannerImagesFn();
  }



  getListBannerImagesFn() {

    let skipCount = this.intSkipCount;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
     const obj = {
      loginUserId:  localStorage.getItem('userId'),
      strImageType: this.formBannerImages.value.txtdeviceType,
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,

    };
    if(localStorage.getItem('fkShopId')){
      Object.assign(obj,{fkShopId: localStorage.getItem('fkShopId')})
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    console.log(obj,"list banner obj::::::::::::::::::::");
    
    this.BannerService.getListHomeBanner(obj).subscribe((res) => {
      console.log("Banners", res);
      // this.spinner.hide();
      if (res.success) {
        // this.spinner.hide();
        this.intTotalCount =  res.data[0].intTotalCount;
        this.arrHomeBanner = res.data;
        this.intTotalCount = res.count;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
      } else {
        this.arrHomeBanner =[];
        // Swal.fire({
        //   title: "Error",
        //   text: res.message,
        //   icon: "error",
        //   confirmButtonText: "Ok",
        // });
        // this.spinner.hide();
      }
    });
  }

  deleteModal(responsiveDelete, item) {
    this.strBannerImageId = item.pkImageId;
    this.modalService.open(responsiveDelete);
  }

  edit(item) {
    this.router.navigate(["/add-homebanner"], {
      queryParams: { id: item.pkImageId },
    });
  }

  deleteBanner() {
    const obj = {
      pkImageId: this.strBannerImageId,
      loginUserId:localStorage.getItem("userId"),
    }
    console.log(obj)
    this.BannerService.deleteHomeBanner(obj).subscribe((res) => {      
      if (res.success) {
        this.modalService.dismissAll();
        // this.spinner.hide();
        Swal.fire({
          title: "Home Banner deleted!",
          text: "Home Banner Deleted Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then(() => {
          this.ngOnInit()
          this.getListBannerImagesFn()
        })
      } else {
        // this.spinner.hide();
        Swal.fire({
          title: "Error",
          text: res.message,
          icon: "error",
          confirmButtonText: "Ok",
        });
      }
      this.getListBannerImagesFn();
    }, (err) => {
      this.ngOnInit()
      console.log(err)
    })
  }




  onClickViewImg(item, image, type) {
    this.objSelectedItem = item;
    this.strSelectedImg = image;
    this.strSelectedImageType = type;
    this.show();
  }

  show() {
    this.showModal = true; // Show-Hide Modal Check

  }
  //Bootstrap Modal Close event
  hide() {
    this.showModal = false;
  }

  errorImage(event) {
    event.target.src = 'assets/images/Group 4024 (1).png';
  }



}
import { environment } from "./../../../../environments/environment.prod";
import { Component, OnInit } from "@angular/core";
import { PagerService } from "src/app/shared/services/pager.service";
import { DatePipe } from "@angular/common";
import { ReportsService } from "src/app/shared/services/Reports/reports.service";
import { FormBuilder, FormGroup } from "@angular/forms";
import { modOrderSummary } from "src/app/shared/Classes/report.model";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";
import { HypermarketService } from './../../../shared/services/Hypermarket/hypermarket.service';
@Component({
  selector: 'app-settlement-list',
  templateUrl: './settlement-list.component.html',
  styleUrls: ['./settlement-list.component.scss']
})
export class SettlementListComponent implements OnInit {
  currentDate = new Date();
  frmOrderSummary: FormGroup;
  pager: any = {};
  intTotalCount = 0;
  intPageLimit = 10;
  datePipe = new DatePipe("en-US");
  pageLimit: any[];
  strShopId = "";
  arrStores = [];
  intSkipCount = 0;
  arrOrderSummary: modOrderSummary[] = [];
  fromDate;
  toDate;
  blnLoader = false;
  blnDownloadLoader = false;
  private apiURL: string = environment.API_ENDPOINT;
  userType: string;

  constructor(
    private pageServiceObj: PagerService,
    private formBuilder: FormBuilder,
    private companyService:CompanyServiceService,
    private reportServiceObj: ReportsService,
    private hypermarketServiceObj: HypermarketService,
  ) { }

  ngOnInit() {
    this.frmOrderSummary = this.formBuilder.group({
      fromDate: [""],
      toDate: [""],
      cmbShopName: [""],
      drpPageLimit: "10",
    });
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getShopListingFn();
    this.getOrderSummaryFn();
    this.userType=localStorage.getItem("strUserType");
  }
  _clearForm(form: FormGroup) {
    form.reset({
      fromDate: "",
      toDate: "",
      cmbShopName: "",
      drpPageLimit: "10",
    });
    this.intTotalCount = 0;
    this.intSkipCount = 0;
    this.intPageLimit = 10;
    this.getOrderSummaryFn();
  }
  _getPageLimit(value) {
    this.intPageLimit = parseInt(this.frmOrderSummary.value.drpPageLimit);
    this.setPage(1);
  }
  _getShopId(id$) {
    this.strShopId = id$;
  }
  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getOrderSummaryFn();
  }
  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.getOrderSummaryFn();
  }

  getShopListingFn() {
    const obj = {
      loginUserId:localStorage.getItem("userId"),
    }
    if(localStorage.getItem('fkShopId')){
      // Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
      this.arrStores = res.data;
      this.strShopId = res.data[0].pkShopId;
    });
  }
  getOrderSummaryFn() {
    let skipCount = this.intSkipCount;
    this.blnLoader = false;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
    // if (
    //   this.frmOrderSummary.value.fromDate === "" &&
    //   this.frmOrderSummary.value.toDate === ""
    // ) {
    //   console.log("From Date ::::", this.frmOrderSummary.value.fromDate);
    //   this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    //   this.toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    // }
    // if (
    //   this.frmOrderSummary.value.fromDate &&
    //   this.frmOrderSummary.value.toDate === ""
    // ) {
    //   this.fromDate = `${this.frmOrderSummary.value.fromDate.year}-${this.frmOrderSummary.value.fromDate.month}-${this.frmOrderSummary.value.fromDate.day}`;
    //   this.toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    // }
    // if (
    //   this.frmOrderSummary.value.toDate &&
    //   this.frmOrderSummary.value.fromDate === ""
    // ) {
    //   this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    //   this.toDate = `${this.frmOrderSummary.value.toDate.year}-${this.frmOrderSummary.value.toDate.month}-${this.frmOrderSummary.value.toDate.day}`;
    // }

    if (
      this.frmOrderSummary.value.fromDate &&
      this.frmOrderSummary.value.toDate
    ) {
      this.fromDate = `${this.frmOrderSummary.value.fromDate.year}-${this.frmOrderSummary.value.fromDate.month}-${this.frmOrderSummary.value.fromDate.day}`;
      this.toDate = `${this.frmOrderSummary.value.toDate.year}-${this.frmOrderSummary.value.toDate.month}-${this.frmOrderSummary.value.toDate.day}`;
    }

    const obj = {
      pkUserId:localStorage.getItem("userId"),
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
      fkShopId: this.frmOrderSummary.value.cmbShopName, //this.strShopId, // this.strShopId
    };
    if(localStorage.getItem('fkShopId')){
      Object.assign(obj,{fkShopId: localStorage.getItem('fkShopId')})
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    if (this.fromDate,this.toDate) {
      Object.assign(obj, {
        fromDate: this.fromDate,
        toDate: this.toDate,
      })

 

      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    if(localStorage.getItem('fkShopId')){
      Object.assign(obj,{fkShopId: localStorage.getItem('fkShopId')})
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    console.log("Object:::::", obj);

    this.hypermarketServiceObj.getSettlementTransactionService(obj).subscribe((res) => {
      this.blnLoader = true;
     console.log(res,"njnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn")
      this.arrOrderSummary = res.data;
      if (res.data) {
        this.intTotalCount = res.count;
      }
      this.pager = this.pageServiceObj.getPager(
        this.intTotalCount,
        this.pager.currentPage,
        this.intPageLimit
      );
    });
  }
}



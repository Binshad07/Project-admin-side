import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import Swal from "sweetalert2";
import { PagerService } from "./../../../shared/services/pager.service";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { BrandserviceService } from "src/app/shared/services/brand/brandservice.service";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";

export interface modType {
  strName?: any;
}

export interface modShop {
  fkShopId?: any;
}

@Component({
  selector: 'app-otp-limit',
  templateUrl: './otp-limit.component.html',
  styleUrls: ['./otp-limit.component.scss']
})
export class OtpLimitComponent implements OnInit {
  myform: FormGroup;
  submitted: boolean = false;
  intSkipCount = 0;
  pager: any = {};
  intPageLimit = 10;
  pageLimit: any[];
  intTotalCount = 0;
  strTypelId = "";
  arrShops: modShop[] = [];
  frmTypeEdit: FormGroup;
  editSubmitted: boolean = false;
  router: any;


  constructor(
    private pageServiceObj: PagerService,
    private formBuilder: FormBuilder,
    private brandService: BrandserviceService,
    // private spinner: NgxSpinnerService,
    // private spinnerObj: NgxSpinnerService,
    private modalService: NgbModal,
    private companyService: CompanyServiceService
  ) { }

  ngOnInit() {
    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.myform = this.formBuilder.group({
      intOtpCreditLimit: ["", Validators.required],
      fkShopId: ["", Validators.required],
    });
    // this.pageLimit = this.pageServiceObj.showPagelist;
    this.getAllShop();
  }




  AddOtp() {
    this.submitted = true;
    if (this.myform.invalid) {
      return;
    }
    const obj = {
      intOtpCreditLimit: this.myform.value.intOtpCreditLimit,
      fkShopId: this.myform.value.fkShopId,
      loginUserId: localStorage.getItem("userId"),
    };
    console.log(obj, "testttttt");
    this.brandService.OtpLimit(obj).subscribe(
      (res) => {
        console.log(res);
        if (res.success === true) {


        // if (res && res.success) {
          // this.clicked = false;
          // this.spinner.hide();
          Swal.fire({
            title: "Saved!",
            text: "OTP Limit Set Successfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then(() => {
            this.myform.reset();
            this.submitted = false;
          });
        } else {
          // this.spinner.hide();
          Swal.fire({
            title: "Warning",
            text: res.message,
            icon: "warning",
            confirmButtonText: "Ok",
          });
        }
      },
      (err) => {
        console.log(err);
      }
    );
  }

  _onClear() {
    this.submitted = false;
    this.myform.reset();
    this.ngOnInit();
  }

  getAllShop() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
    };
    if (localStorage.getItem("fkShopId")) {
      // Object.assign(obj, { strShopId: localStorage.getItem("fkShopId") });
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
      this.arrShops = res.data;
    });
  }

  get f() {
    return this.myform.controls;
  }




}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtpLimitComponent } from './otp-limit.component';

describe('OtpLimitComponent', () => {
  let component: OtpLimitComponent;
  let fixture: ComponentFixture<OtpLimitComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtpLimitComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtpLimitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

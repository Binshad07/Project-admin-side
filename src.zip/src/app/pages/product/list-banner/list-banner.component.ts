import { Component, OnInit } from '@angular/core';
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { PagerService } from "src/app/shared/services/pager.service";
import { Router } from "@angular/router";
import Swal from "sweetalert2";
import { FormGroup, FormBuilder } from "@angular/forms";
import { BannerServiceService } from 'src/app/shared/services/BannerService/banner-service.service';


@Component({
  selector: 'app-list-banner',
  templateUrl: './list-banner.component.html',
  styleUrls: ['./list-banner.component.scss']
})
export class ListBannerComponent implements OnInit {

  intTotalCount = 0;
  formBannerImages: FormGroup;
  intSkipCount = 0;
  pageLimit: any[];
  intPageLimit = 10;
  pager: any = {};
  arrBanner = [];
  strBannerImageId = "";
  showModal: boolean;
  strSelectedImg: string;
  strSelectedImageType: string;
  objSelectedItem: any;
  strBannerId: "";
  // blnLoader = false;

  constructor(
    private pageServiceObj: PagerService,
    private bannerService: BannerServiceService,
    private modalService: NgbModal,
    private router: Router,
    private formBuilder: FormBuilder
  ) { }

  ngOnInit() {

    this.formBannerImages = this.formBuilder.group({
      deviceType: "",
    });
    // this.shops = [];
    this.pager = {};
    this.pageLimit = this.pageServiceObj.showPagelist;

    this.getBannerList()
    // this.getRentalType()
  }

  _getPageLimit(value$) {
    this.intPageLimit = value$;
    this.setPage(1);
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
    this.getBannerList();
  }

  getBannerList() {

    let skipCount = this.intSkipCount;
    // this.blnLoader = false;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }
 

    const obj = {
      loginUserId: localStorage.getItem("userId"),
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
    }
    if (localStorage.getItem("fkShopId")) {
      Object.assign(obj, { fkShopId: localStorage.getItem("fkShopId") });
      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.bannerService.getAllbanners(obj).subscribe((res) => {
      if (res && res.success) {
        //  this.ngOnInit()
        // this.spinner.hide();
        // this.blnLoader = true;
        this.arrBanner = res.data;
        this.intTotalCount = res.count;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
      } else {
        this.arrBanner = []
        // Swal.fire({
        //   title: "Error",
        //   text: res.message,
        //   icon: "error",
        //   confirmButtonText: "Ok",
        // });
        // this.spinner.hide();
      }
    })
  }

  onClickViewImg(item, image, type) {
    this.objSelectedItem = item;
    this.strSelectedImg = image;
    this.strSelectedImageType = type;
    this.show();
  }

  show() {
    this.showModal = true;
  }
  hide() {
    this.showModal = false;
  }

  _onSearch() {

    const obj = {
      loginUserId: localStorage.getItem("userId"),
      strImageType: this.formBannerImages.value.deviceType,

    }

    console.log(obj, "search")
    this.bannerService.getAllbanners(obj).subscribe((res) => {
      if (res.success) {
        this.arrBanner = res.data;
        this.intTotalCount = res.count;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
      } else {
        this.arrBanner = []
        // Swal.fire({
        //   title: "Error",
        //   text: res.message,
        //   icon: "error",
        //   confirmButtonText: "Ok",
        // });
        // this.spinner.hide();
      }
    }, (err) => {
      this.arrBanner = []
      console.log(err)
    })

  }
  // errorImage(event) {
  //   event.target.src = 'assets/images/cart_logo.png';
  // }
  _onClear() {
    this.formBannerImages.reset()
    this.ngOnInit()
  }


  deleteModal(responsiveDelete, item) {
    this.strBannerId = item.pkImageId;
    this.modalService.open(responsiveDelete);
  }

  delete() {
    const obj = {
      pkImageId: this.strBannerId,
      loginUserId: localStorage.getItem("userId")
    }
    console.log(obj)

    // this.spinner.show();

    this.bannerService.DeleteBanner(obj).subscribe((res) => {
      if (res.success && res) {
        this.modalService.dismissAll();
        // this.spinner.hide();
        Swal.fire({
          title: "Deleted!",
          text: "Bottom Banner deleted successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then(() => {
          this.getBannerList()
          this.ngOnInit()
        })
      } else {
        // this.spinner.hide();
        this.arrBanner = []

        // Swal.fire({
        //   // title: "Error",
        //   // text: res.message,
        //   // icon: "error",
        //   // confirmButtonText: "Ok",
        // });
      }
      this.getBannerList();
    }, (err) => {
      console.log(err)
    })
  }



  edit(item) {

    console.log(item)
    this.router.navigate(["/product/add-banner"], {
      queryParams: { id: item.pkImageId },
    });
  }

errorImage(event) {
 
  event.target.src = 'assets/images/Group 4024 (1).png';
}



}

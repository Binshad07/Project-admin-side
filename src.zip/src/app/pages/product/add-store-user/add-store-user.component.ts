import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CompanyServiceService } from 'src/app/shared/services/company/company-service.service';
import { StoreServiceService } from 'src/app/shared/services/store/store-service.service';
// import { NgxSpinnerService } from "ngx-spinner";
import Swal from "sweetalert2";


@Component({
  selector: 'app-add-store-user',
  templateUrl: './add-store-user.component.html',
  styleUrls: ['./add-store-user.component.scss'],
  // providers: [NgxSpinnerService],
})
export class AddStoreUserComponent implements OnInit {
  type = "Add";
  myForm: FormGroup;
  arrCompany:any[] = []
  strShopId = ""
  submitted:boolean = false;
  id = "";
  blnUpdate = false;



  constructor(
    private route: ActivatedRoute,
    private router:Router,
    private formBuilder: FormBuilder,
    private companyService:CompanyServiceService,
    private storeservice:StoreServiceService
    // private spinner: NgxSpinnerService,
  ) { }

  ngOnInit() {

    this.route.queryParams.subscribe((params) => {
      this.id = params["id"];
    });


    this.myForm = this.formBuilder.group({
      strUserName: ["", Validators.required],
      strEmail: ["", [Validators.required, Validators.email]],
      strPhone: ["", [Validators.required,Validators.pattern("[0-9 ]{8,12}")]],
      strPassword: ["",Validators.required],
      strShopId: ["", Validators.required],
      location:["",Validators.required]
    });

    this.getAllCompany()
    
    if (this.id) {
      this.getSingleUser()
      this.blnUpdate = true;
      this.type = "Update";

      const passwordControl = this.myForm.get('strPassword');
      passwordControl.clearValidators();
      passwordControl.updateValueAndValidity();
    }

  }

  get f(){
    return this.myForm.controls;
  }

 
  save(){
    this.submitted = true;

    if (this.myForm.invalid) {
      return;
    }


    this.strShopId = this.myForm.value.strShopId;

    let shopName = this.arrCompany.find(
      (e) => e.pkShopId === this.strShopId
    ).strShopName;
    

    const obj = {
      strName : this.myForm.value.strUserName,
      strEmail : this.myForm.value.strEmail,
      strPassword : this.myForm.value.strPassword,
      location : this.myForm.value.location,
      strPhoneNo : this.myForm.value.strPhone + "",
      strShopId : this.myForm.value.strShopId,
      strShopName : shopName,
      strUpdateUserId : localStorage.getItem('userId')
    }

    this.storeservice.addStoreUser(obj).subscribe((res) => {
      if(res && res.success){
        Swal.fire({
          title: "Saved!",
          text: "New store user saved successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then((result) => {
          if(result.value){
            this.submitted = false;
            this.router.navigate(['/store-user']);
          }
        })
        
      }else{
        Swal.fire({
          title:"Warning",
          text:res.message,
          icon:'warning',
          confirmButtonText:"Ok"
        })
      }
    },(err )=> {
      console.log(err)
    })
  
  }

  getAllCompany(){
    const obj = {
      loginUserId:localStorage.getItem("userId"),
    }
    if(localStorage.getItem('fkShopId')){
      // Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
      console.log(res)
      if(res && res.success){
        this.arrCompany = res.data
      }
    },(err) => {
      console.log(err)
    })
  }

  onReset() {

    if(this.blnUpdate){
      this.myForm.patchValue({
        strUserName: '',
        strPhone:''
      });
    }else{
    this.submitted = false;
    this.myForm.reset();
    }

  }

  getSingleUser(){
    const obj = {
      pkUserId: this.id,
      strUpdateUserId: localStorage.getItem("userId"),
    }
    
    this.storeservice.getAllStoresUsers(obj).subscribe((res) => {
      if(res && res.success){
        console.log("res",res)
        let data = res.data[0]

        this.myForm.patchValue({
          strUserName:data.strUserName,
          strPhone:data.strPhone,
          strEmail:data.strEmail,
          location:data.location,
          strShopId:data.fkShopId
        })
      }
    })
  }

  update(){
    this.submitted = true;

    if (this.myForm.invalid) {
      return;
    }
    
    const obj = {
      strUserName:this.myForm.value.strUserName,
      strEmail:this.myForm.value.strEmail,
      pkUserId:this.id,
      strPhone:this.myForm.value.strPhone,
      location : this.myForm.value.location,
      strUpdateUserId:localStorage.getItem("userId")
    }
    this.storeservice.updateStoreUser(obj).subscribe((res) => {
      if(res && res.success){
        Swal.fire({
          title: "Updated!",
          text: "Store user has been updated",
          icon: "success",
          confirmButtonText: "Ok",
        }).then((result) => {
          if(result.value){
            this.submitted = false;
            this.router.navigate(['/store-user']);
          }
        })
      }else{
        this.submitted = false;
        Swal.fire({
          title: "Error",
          text: res.message,
          icon: "error",
          confirmButtonText: "Ok",
        });
      }
    },(err) => {
      Swal.fire({
        title: "Error",
        text: err.message,
        icon: "error",
        confirmButtonText: "Ok",
      });
    })
  }

  

}

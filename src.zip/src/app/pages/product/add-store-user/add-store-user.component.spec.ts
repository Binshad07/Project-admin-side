import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddStoreUserComponent } from './add-store-user.component';

describe('AddStoreUserComponent', () => {
  let component: AddStoreUserComponent;
  let fixture: ComponentFixture<AddStoreUserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddStoreUserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddStoreUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});


import { Component, OnInit } from '@angular/core';

import { PagerService } from "src/app/shared/services/pager.service";
import { FormGroup, FormBuilder,Validators } from "@angular/forms";
import { ReportsService } from "src/app/shared/services/Reports/reports.service";
import { modItemSales } from "src/app/shared/Classes/report.model";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";
import { DatePipe } from "@angular/common";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { HypermarketService } from "./../../../shared/services/Hypermarket/hypermarket.service";
import Swal from "sweetalert2";
import { Router } from "@angular/router";

@Component({
  selector: 'app-withdraw-request',
  templateUrl: './withdraw-request.component.html',
  styleUrls: ['./withdraw-request.component.scss']
})
export class WithdrawRequestComponent implements OnInit {
  //  myform: FormGroup;

  currentDate = new Date();
  frmItemSales: FormGroup;
  frmTypeStatus: FormGroup;
  pager: any = {};
  intTotalCount = 0;
  intPageLimit = 10;
  pageLimit: any[];
  strWihtdrawalId: "";
  strShopId = "";
  arrStores = [];
  intSkipCount = 0;
  datePipe = new DatePipe("en-US");
  arrItemSales: modItemSales[] = [];
  fromDate;
  toDate;
  blnLoader = false;
  blnDownloadLoader = false;
  userType: string;
  arrShops:[];
  withdrawAmount:"";
  status:""
  submitted = false;
  transactionImg: File[] = []
  pkWithdrawRequestId:  "";
  withdrawalImg: File[] = [];
  clicked = false;
  selectedPaymentMethod: string = 'BANK';
  imageSrc: any;;
  strNewImageUrl:["",];
  singledata: any;
  strSelectedImg: string;
  strSelectedImageType: string;
  objSelectedItem: any;
  showModal: boolean;
  imageUrl: string[];
  strBankName:"";
  strReference:""
  constructor(


    private pageServiceObj: PagerService,
    private reportServiceObj: ReportsService,
    private companyService: CompanyServiceService,
    private formBuilder: FormBuilder,
    private modalService: NgbModal,
    private hypermarketServiceObj: HypermarketService,
    private router: Router,


  ) { }

  ngOnInit() {


    this.frmItemSales = this.formBuilder.group({
      txtFromDate: [""],
      txtToDate: [""],
      txtOrderId: [""],
      cmbShopName: "",
      drpPageLimit: "10",
      withdrawAmount:"",
      status:""
    });
    this.frmTypeStatus = this.formBuilder.group({
      approvalStatus: ["Pending", Validators.required],
      strUTRNumber: ["", Validators.required],
      strImageUrl: ["", Validators.required],
      strBankType: ["BANK", Validators.required],
      strReference: ["",],
      strBankName:["",Validators.required],
      strNewImageUrl:[""],
    });

    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getShopListingFn();
    this.getWithdrawrequestReport();

  }


  get formControls() {
    return this.frmItemSales.controls;
  }

  get f() {
    return this.frmTypeStatus.controls;
  }

  _clearForm(form: FormGroup) {
    form.reset({
      txtFromDate: "",
      txtToDate: "",
      // txtOrderId: "",
      cmbShopName: "",
      drpPageLimit: "10",
      status:"",
      withdrawAmount:""
    });
    this.intTotalCount = 0;
    this.intSkipCount = 0;
    this.intPageLimit = 10;
    this.getWithdrawrequestReport();

  }

  _getPageLimit(value$) {
    this.intPageLimit = parseInt(this.frmItemSales.value.drpPageLimit);
    this.setPage(1);
  }


  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );
this.getWithdrawrequestReport();
  }


  getShopListingFn() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
    }
    if (localStorage.getItem('fkShopId')) {
      // Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
      this.arrStores = res.data;
      this.strShopId = res.data[0].pkShopId;
    });
  }
  // getAllShop() {
  //   const obj = {
  //     loginUserId: localStorage.getItem("userId"),
  //   }
  //   console.log(obj, "tesghjchbv")
  //   if (localStorage.getItem('fkShopId')) {
  //     // Object.assign(obj, { strShopId: localStorage.getItem('fkShopId') })
  //     Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

  //     // obj.fkShopId=localStorage.getItem('fkShopId')
  //   }
  //   this.companyService.fngetallCompany(obj).subscribe((res) => {

  //     this.arrShops = res.data
  //   })
  // }




Search:any = false
  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.Search = true
    this.getWithdrawrequestReport();
  }

  _getShopId(id$) {
    this.strShopId = id$;
  }

  getWithdrawrequestReport() {
    let skipCount = this.intSkipCount;
    this.blnLoader = false;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }

    if(this.Search === true){
      let fromDate
      let  toDate
      if (
        this.frmItemSales.value.txtFromDate === "" &&
        this.frmItemSales.value.txtToDate === ""
      ) {
        console.log("From Date ::::", this.frmItemSales.value.txtFromDate);
        this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-mm-dd");
        this.toDate = this.datePipe.transform(this.currentDate, "yyyy-mm-dd");
      }
      if (
        this.frmItemSales.value.txtFromDate &&
        this.frmItemSales.value.txtToDate === ""
      ) {
        this.fromDate = `${this.frmItemSales.value.txtFromDate.year}-${this.frmItemSales.value.txtFromDate.month}-${this.frmItemSales.value.txtFromDate.day}`;
        this.toDate = this.datePipe.transform(this.currentDate, "yyyy-mm-dd");
      }
      if (
        this.frmItemSales.value.txtToDate &&
        this.frmItemSales.value.txtFromDate === ""
      ) {
        this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-mm-dd");
        this.toDate = `${this.frmItemSales.value.txtToDate.year}-${this.frmItemSales.value.txtToDate.month}-${this.frmItemSales.value.txtToDate.day}`;
      }
  
      if (
        this.frmItemSales.value.txtFromDate &&
        this.frmItemSales.value.txtToDate
      ) {
        this.fromDate = `${this.frmItemSales.value.txtFromDate.year}-${this.frmItemSales.value.txtFromDate.month}-${this.frmItemSales.value.txtFromDate.day}`;
        this.toDate = `${this.frmItemSales.value.txtToDate.year}-${this.frmItemSales.value.txtToDate.month}-${this.frmItemSales.value.txtToDate.day}`;
      }
  
    }
    else{
      this.fromDate = "";
      this.toDate = ""
    }
    
    const obj = {

      strLoginUserId: localStorage.getItem("userId"),
      intSkipCount: skipCount,
      intPageLimit: this.intPageLimit,
      fkShopId: this.frmItemSales.value.cmbShopName,
      // strFromDate: this.fromDate, // fromTime
      // strToDdate: this.toDate,
      strFromDate:this.fromDate,
      strTodate:this.toDate,
       withdrawAmount:this.frmItemSales.value.withdrawAmount,
       status:this.frmItemSales.value.status
    }



    this.companyService.Getwithdrawreport(obj).subscribe((res) => {
      console.log (obj,"listresponse")

      if (res && res.success) {

        this.blnLoader = true;
        this.arrItemSales = res.data ;
        console.log(this.arrItemSales,"response")

        this.intTotalCount = res.count;
        this.arrItemSales = res.data;
        // if (res.data[0]) {
        //   this.intTotalCount = res.data.intTotalCount;
        // }
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
      } else {
        this.arrItemSales = []

      }
    })
  }

  _getEditType(responsiveData, objType) {
    console.log(responsiveData,"syammmm")
    console.log(objType,"mayssssw")
    this.modalService.open(responsiveData);
    this.strWihtdrawalId = objType.pkWithdrawRequestId;
    this.frmTypeStatus.patchValue({ approvalStatus: objType.approvalStatus });
    this.frmTypeStatus.patchValue({ strReference: objType.strReference });
    this.frmTypeStatus.patchValue({ strImageUrl: objType.strImageUrl });
    this.frmTypeStatus.patchValue({ strBankType: objType.strBankType });
    this.frmTypeStatus.patchValue({ strBankName: objType.strBankName });
    this.frmTypeStatus.patchValue({ strUTRNumber: objType.strUTRNumber });
    this.frmTypeStatus.patchValue({ imageUrl: objType.strNewImageUrl });
  }
  getUpdateTypeFn() {


    this.blnLoader = false;
    this.submitted = true;

    if (this.frmTypeStatus.invalid) {
      this.blnLoader = true;
      return;
    }
    let fData = new FormData();
    // pkImageId: this.strBannerId,

       fData.append("pkWithdrawRequestId", this.strWihtdrawalId,
        
      )
      

    fData.append("strLoginUserId", localStorage.getItem("userId"));


    fData.append("approvalStatus", this.frmTypeStatus.value.approvalStatus);
   
    // fData.append("strReference", this.frmTypeStatus.value.strReference || "");
      fData.append("strReference", this.frmTypeStatus.value.strReference || "");
    
    
   
    fData.append("strBankType", this.frmTypeStatus.value.strBankType);
    fData.append("strBankName", this.frmTypeStatus.value.strBankName);
    fData.append("strUTRNumber", this.frmTypeStatus.value.strUTRNumber);


    for (let image of this.withdrawalImg) {
      fData.append("strImageUrl", image, image.name);
    }
    fData.forEach((value, key) => {
      console.log(key, value);
    });



    this.hypermarketServiceObj
      .getUpdatedeWithdrawalstatus(fData)
      .subscribe((res) => {
        console.log(res,"fggggggg")
        if (res.success === true) {
          this.clicked = false;
          this.blnLoader = true;
          Swal.fire({
            title: "Saved!",
            text: "Withdrawal Status Updated Successfully",
            icon: "success",
            confirmButtonText: "Ok",
          }).then(() => {
            this.getWithdrawrequestReport();
            // this.refreshPage()
            // this.getListCategoryFn();


            this.modalService.dismissAll()
            // this.frmBanners.reset();
            this.router.navigate(["/product/withdraw-request"]);
            this.submitted = false;
          });
        }  else {
          Swal.fire({
            title: "Warning",
            text: "Change the approval status",
            icon: "warning",
            confirmButtonText: "Ok",
          }).then((result) => {
            if (result.value) {
              // this.modalService.dismissAll();
            }
          });
          // this.spinnerObj.hide();
        }
        this.getWithdrawrequestReport();

      });
  }
  // onFileChange(event) {
  //   for (let i of event.target.files) {
  //     this.withdrawalImg.push(i)
  //   }
  // }
  onFileChange(event) {
    const files: FileList = event.target.files;

    if (files.length > 0) {
      // Always ensure this.imageFile is an array
      this.withdrawalImg = Array.isArray(this.withdrawalImg) ? this.withdrawalImg : [];

      for (let i = 0; i < files.length; i++) {
        // Use spread operator to create a new array with the new file(s)
        this.withdrawalImg = [...this.withdrawalImg, files[i]];
      }

      const file: File = files[0];
      const reader = new FileReader();

      reader.onload = () => {
        const timestamp = new Date().getTime();
        this.imageSrc = reader.result as string;
      };

      reader.readAsDataURL(file);
    }
  }
  onclear(){
    // this.frmTypeStatus.reset();
    this.submitted=false;
    this.frmTypeStatus.reset();
    this.ngOnInit();
    this.imageSrc = "";
        // this.getWithdrawrequestReport();
  }
  onclose(){
    this.submitted=false;
    this.imageSrc = "";
    // this.frmTypeStatus.reset();
    this.ngOnInit();
        // this.getWithdrawrequestReport();
        this.modalService.dismissAll();
  }

  modalExtendList(modalExtend, item) {
    console.log(item,"hfhdfhdhhd")
    this.singledata = item
    this.modalService.open(modalExtend, {
      centered: true,
      windowClass: 'modal-product-delete',
    });
  }

  closeModal(){
    this.submitted=false;
    this.ngOnInit();
    this.getWithdrawrequestReport();
    this.modalService.dismissAll();
  }

  onClickViewImg(singledata, image, type) {
    this.objSelectedItem = singledata;
    this.strSelectedImg = image;
    this.strSelectedImageType = type;
    this.show();
  }
  show() {
    this.showModal = true;
  }
  }

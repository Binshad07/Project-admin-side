import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HypermarketService } from './../../../shared/services/Hypermarket/hypermarket.service';
// import { FranchiseService } from 'src/app/shared/services/franchise/franchise.service';
// import { RentalService } from 'src/app/shared/services/rental/rental.service';
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { ActivatedRoute, Router } from '@angular/router';
// import { NgxSpinnerService } from 'ngx-spinner';
import Swal from 'sweetalert2';
import { ShopServiceService } from 'src/app/shared/services/shopService/shop-service.service';

@Component({
  selector: 'app-add-shop',
  templateUrl: './add-shop.component.html',
  styleUrls: ['./add-shop.component.scss']
})
export class AddShopComponent implements OnInit {
  // arrRentalItem: any[] = [];
  frmCompany: FormGroup;
  intTblIndexZipcodes = 0;
  intTblIndexConditions = 0;
  intTblIndexLinks = 0
  intTableArrayZipCodesLen = 0;
  intTableArrayConditionLen = 0;
  intTableArrayLinksLen = 0;
  tempArrayZipcodes: any[] = [];
  arrayOfObjDeptList = [];
  arrZipcodes: any[] = [];
  arrConditions: any = [];
  arrSocialMediaLinks: any = [];
  submitted: boolean = false;
  arrUploadedDocs = [];
  strSelectedImg = "";
  logoImg: File[] = []
  otherImage: File[] = []
  iconImg: File[] = []
  id = "";
  blnUpdate = false;
  type = "Add";
  arrViewType = [];
  clicked = false;
  // arrOfCategoryList = [];
  // isIOS: boolean = true;
  // isIOS : any = true
  isIOS: boolean = true;  // Initially disable the iOS input field
  isAndroid: boolean = true;  // Initially disable the Android input field
  strIosUrl:""
  logoImageurl: "";
  iconImageurl: "";
  otherImageurl: "";

  blnLoader = false;
  editable: boolean = true;
  userType: string;
  liveApps:"";
  strios:""
  webUrl:"";
  iosUrl:"";
  androidUrl:"";
  domainUrl:"";
  constructor(
    private formbuilder: FormBuilder,
    private shopService: ShopServiceService,
    // private franchiseService: FranchiseService,
    private modalService: NgbModal,
    private route: ActivatedRoute,
    private hypermarketServiceObj: HypermarketService,
    private router: Router
  ) { 

    this.frmCompany = this.formbuilder.group({
      shopName: ['', Validators.required],
      arabicName: ['', Validators.required],
      strLocation: ['', Validators.required],
      email: ["", [Validators.required, Validators.email]],
      contact: ['', Validators.required],
      strWhatsAppNumber: ['', Validators.required],
      orderCount: ['', Validators.required],
      password: ['', Validators.required],
      shopStatus: ["Active", Validators.required],
      address: ['', Validators.required],
      arrSocialMediaLinks: this.formbuilder.array([this.getArrLinks()]),
      strZipCode: this.formbuilder.array([this.getArrZipcode()]),
      conditon: this.formbuilder.array([this.getArrConditions()]),
      storeId: ['', Validators.required],
      emirate: ['', Validators.required],
      description: ['', Validators.required],
      latitude: ["", [Validators.required, Validators.min(-90), Validators.max(90)]],
      longitude: ["", [Validators.required, Validators.min(-180), Validators.max(180)]],
      privacyPolicy: ['', Validators.required],
      termsofuse: ['', Validators.required],
      termsOfSale: ['', Validators.required],
      drpViewType: ['', Validators.required],
      drpDepartment: ['', Validators.required],
      // termsofuse: ['', Validators.required],
      iconImg: [''],
      otherImage: [''],
      logoImg: [''],
      liveApps:"",
      strios:[false,],
      iosUrl: [ {value:"",disabled: this.isIOS}],
      strweb:[true,],
      strAndroid:[false],
      strDomain:[false],
      domainUrl:[""],
      webUrl:[""],
      // iosUrl:[""], 
     androidUrl:[""],

    })
    this.frmCompany.get('strios').valueChanges.subscribe(value => {
      this.toggleUrlInput('ios', value);
    });

    this.frmCompany.get('strAndroid').valueChanges.subscribe(value => {
      this.toggleUrlInput('android', value);
    });
  }

  ngOnInit() {

    this.route.queryParams.subscribe((params) => {
      this.id = params["id"];
    });
    console.log("thisid", this.id)


    


   
   
    
    
    
    
    
    


    if (this.id) {
      this.type = "Update";
      this.getSingleShopItem()
      this.blnUpdate = true;
    }
    // this.getDefaultDepartmentFn();
    // this.getDepartmentFn();
    (this.type == "Update") ? this.getDepartmentFn() : this.getDefaultDepartmentFn();
    this.getViewTypeFn();
    // this.getListSubCategoryFn();

   
    if (localStorage.getItem('strUserType') == 'SHOP REPORTER') {
      this.editable=false;
    }
    this.userType=localStorage.getItem("strUserType");
  }




  get formControls() {
    return this.frmCompany.controls;
  }


  getArrZipcode() {
    return this.formbuilder.group({
      strZipCode: ["", Validators.required]
    })
  }




  getArrConditions() {
    return this.formbuilder.group({
      conditon: ["", Validators.required]
    })
  }




  

  getArrLinks() {
    return this.formbuilder.group({
      type: ["", Validators.required],
      link: ["", Validators.required],

    })
  }
  // toggleUrlInput(){
     
  //     const checkboxControl = this.frmCompany.get(iosUrl);
  //     const urlControl = this.frmCompany.get(`${controlName}Url`);
  //     if (checkboxControl.value) {
  //       urlControl.enable();
  //     } else {
  //       urlControl.disable();
  //     }
  //   }




  get newRowZipCodes(): FormArray {
    return this.frmCompany.get('strZipCode') as FormArray;
  }

  get newRowConditions(): FormArray {
    return this.frmCompany.get('conditon') as FormArray;
  }


  get newRowLinks(): FormArray {
    return this.frmCompany.get('arrSocialMediaLinks') as FormArray;
  }



  _addNewRowBZipCodes() {
    const intIndex = this.newRowZipCodes.value.length - 1;
    this.intTblIndexZipcodes++;

    this.newRowZipCodes.push(this.getArrZipcode());
    // console.log("working", this.newRowBenifits);
  }

  _deleteRowZipcode(index) {
    if (this.newRowZipCodes) {
      this.intTableArrayZipCodesLen = this.newRowZipCodes.value.length;
    }
    if (this.intTableArrayZipCodesLen > 1) {
      this.intTblIndexZipcodes--;
      this.newRowZipCodes.removeAt(index);
    } else {
      alert("One row required");
      return;
    }
  }


  setZipcode(strZipCode) {
    let control = <FormArray>this.frmCompany.controls.strZipCode;
    control.removeAt(0)
    strZipCode.forEach(x => {
      control.push(this.formbuilder.group({

        strZipCode: [x.strZipCode, Validators.required],
        // strZipCode: x.strZipCode
      }))
    })
  }

  setArrConditions(conditon) {
    let control = <FormArray>this.frmCompany.controls.conditon;
    control.removeAt(0)

    conditon.forEach(x => {
      control.push(this.formbuilder.group({

        conditon: x.conditon,
      }))
    })
  }


  setArrLinks(arrSocialMediaLinks) {
    let control = <FormArray>this.frmCompany.controls.arrSocialMediaLinks;
    control.removeAt(0)

    arrSocialMediaLinks.forEach(x => {
      control.push(this.formbuilder.group({
        type: x.type,
        link: x.link,

      }))
    })
  }

  _addNewRowConditions() {
    const intIndex = this.newRowConditions.value.length - 1;
    this.intTblIndexConditions++;

    this.newRowConditions.push(this.getArrConditions());
    console.log("working", this.newRowConditions);
  }

  _deleteConditions(index) {
    if (this.newRowConditions) {
      this.intTableArrayConditionLen = this.newRowConditions.value.length;
    }
    if (this.intTableArrayConditionLen > 1) {
      this.intTblIndexConditions--;
      this.newRowConditions.removeAt(index);
    } else {
      alert("One row required");
      return;
    }
  }







  _addNewRowLinks() {
    const intIndex = this.newRowLinks.value.length - 1;
    this.intTblIndexLinks++;

    this.newRowLinks.push(this.getArrLinks());
    // console.log("working", this.newRowBenifits);
  }

  _deleteRowLink(index) {
    if (this.newRowLinks) {
      this.intTableArrayLinksLen = this.newRowLinks.value.length;
    }
    if (this.intTableArrayLinksLen > 1) {
      this.intTblIndexLinks--;
      this.newRowLinks.removeAt(index);
    } else {
      alert("One row required");
      return;
    }
  }




  fnaddShop() {
    console.log("frm company", this.frmCompany)
    this.submitted = true;

    if (this.frmCompany.invalid) {
      return
    }
    const formData = new FormData()
    for (let item of this.frmCompany.value.strZipCode) {
      this.arrZipcodes.push(item)
      console.log("itwm::::::;", item.strZipCode)
    }

    for (let item of this.frmCompany.value.conditon) {
      console.log("item::::::::::;", item.features)
      this.arrConditions.push(item)
    }

    for (let item of this.frmCompany.value.arrSocialMediaLinks) {
      // console.log("item pacakges",item)
      this.arrSocialMediaLinks.push(item)
    }

    formData.append("strShopName", this.frmCompany.value.shopName)
    formData.append("strShopArabicName", this.frmCompany.value.arabicName)
    formData.append("strLocation", this.frmCompany.value.strLocation)
    formData.append("strEmail", this.frmCompany.value.email)
    formData.append("arrayZipCodes", JSON.stringify(this.arrZipcodes))
    formData.append("arrSocialMediaLinks", JSON.stringify(this.arrSocialMediaLinks))
    formData.append("strReturnTermsAndCondition", JSON.stringify(this.arrConditions))
    formData.append("intMaxOrderCount", this.frmCompany.value.orderCount)
    formData.append("strContactNumber", this.frmCompany.value.contact)
    formData.append("strWhatsAppNumber", this.frmCompany.value.strWhatsAppNumber)
    formData.append("strAddress", this.frmCompany.value.address)
    formData.append("strDescription", this.frmCompany.value.description)
    formData.append("strPassword", this.frmCompany.value.password)
    formData.append("strBMKStoreId", this.frmCompany.value.storeId)
    formData.append("strEmirate", this.frmCompany.value.emirate)
    formData.append("strShopStatus", this.frmCompany.value.shopStatus)
    formData.append("strLongitude", this.frmCompany.value.longitude)
    formData.append("strLatitude", this.frmCompany.value.latitude)
    formData.append("privacyPolicy", this.frmCompany.value.privacyPolicy)
    formData.append("termsOfUse", this.frmCompany.value.termsofuse)
    formData.append("termsOfSale", this.frmCompany.value.termsOfSale)
    formData.append("fkDefaultDepartmentId", this.frmCompany.value.drpDepartment)
    formData.append("strViewType", this.frmCompany.value.drpViewType)

     formData.append("storeUrl", this.frmCompany.value.webUrl)
     formData.append("domainConnectedUrl", this.frmCompany.value.domainUrl)
     formData.append("strAndroidUrl", this.frmCompany.value.androidUrl)
     formData.append("strIosUrl", this.frmCompany.value.iosUrl)
    
    //  formData.append("iosUrl", this.frmCompany.value.strIosUrl)

    
    
    formData.append("strLoginUserId", localStorage.getItem("userId"))
    for (let image of this.logoImg) {
      formData.append("logoImage", image, image.name)
    }
    for (let image of this.iconImg) {
      formData.append("iconImage", image, image.name)
    }

    for (let image of this.otherImage) {
      formData.append("otherImage", image, image.name)
    }

    formData.forEach((a, b) => console.log(`${a} :: ${b}`))

    // this.spinner.show()
    this.clicked = true;
    this.shopService.addShop(formData).subscribe((res) => {
      if (res.success) {
        this.clicked = false;
        Swal.fire({
          title: "Saved!",
          text: "Shop Created Successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then(() => {
          this.submitted = false;
          this.frmCompany.reset()
          this.router.navigate(['/product/list-shop'])
        })
      } else {
        // this.spinner.hide();
        Swal.fire({
          title: "Error",
          text: res.message,
          icon: "error",
          confirmButtonText: "Ok",
        }).then(() => {
          this.submitted = false;
        })
      }
    }, (err) => {
      console.log(err)
    })

  }






  fnUpdateShop() {
    
    this.submitted = true;

    // if (this.frmCompany.invalid) {
    //   return
    // }



    // if (this.frmCompany.invalid || this.newRowZipCodes.invalid || this.newRowConditions.invalid || this.newRowLinks.invalid) {
    //   return
    // }


    const formData = new FormData()


    // for (let item of this.frmCompany.value.strZipCode) {
      
    //   this.arrZipcodes.push(item)
    //   console.log("syam::::::;",item)
      
    // }
    // console.log("itwm::::::;",this.frmCompany.value.strZipCode)

    for (let item of this.frmCompany.value.conditon) {
      // console.log("item::::::::::;",item.features)
      this.arrConditions.push(item)
    }

    // for (let item of this.frmCompany.value.arrSocialMediaLinks) {
    //   // console.log("item pacakges",item)
    //   this.arrSocialMediaLinks.push(item)

    //   // console.log("arr phjhjf", this.arrSocialMediaLinks)
    // }

    formData.append("strShopName", this.frmCompany.value.shopName)
    formData.append("strShopArabicName", this.frmCompany.value.arabicName)
    formData.append("strLocation", this.frmCompany.value.strLocation)
    formData.append("strEmail", this.frmCompany.value.email)
    formData.append("arrayZipCodes", JSON.stringify(this.frmCompany.value.strZipCode))
    formData.append("arrSocialMediaLinks", JSON.stringify(this.frmCompany.value.arrSocialMediaLinks))
    formData.append("strReturnTermsAndCondition", JSON.stringify(this.arrConditions))
    formData.append("intMaxOrderCount", this.frmCompany.value.orderCount)
    formData.append("strContactNumber", this.frmCompany.value.contact)
    formData.append("strWhatsAppNumber", this.frmCompany.value.strWhatsAppNumber) 
    formData.append("strAddress", this.frmCompany.value.address)
    formData.append("strDescription", this.frmCompany.value.description)
    // formData.append("strPassword", this.frmCompany.value.password)
    formData.append("strBMKStoreId", this.frmCompany.value.storeId)
    formData.append("strEmirate", this.frmCompany.value.emirate)
    formData.append("strShopStatus", this.frmCompany.value.shopStatus)
    formData.append("strLongitude", this.frmCompany.value.longitude)
    formData.append("strLatitude", this.frmCompany.value.latitude)
    formData.append("privacyPolicy", this.frmCompany.value.privacyPolicy)
    formData.append("termsOfUse", this.frmCompany.value.termsofuse)
    formData.append("termsOfSale", this.frmCompany.value.termsOfSale)
    formData.append("fkDepartmentId", this.frmCompany.value.drpDepartment)
    formData.append("strViewType", this.frmCompany.value.drpViewType)
    formData.append("shopId", this.id)

    formData.append("blnWebStatus", this.frmCompany.value.strweb)
    formData.append("blnAndroidStatus", this.frmCompany.value.strAndroid)
    formData.append("blnIOsStatus", this.frmCompany.value.strios)
     formData.append("isDomainConnected", this.frmCompany.value.strDomain)
     formData.append("strLoginUserId", localStorage.getItem("userId"))
     formData.append("storeUrl", this.frmCompany.value.webUrl)
     formData.append("strAndroidUrl", this.frmCompany.value.androidUrl)
     formData.append("domainUrl", this.frmCompany.value.domainUrl)
     formData.append("strIosUrl", this.frmCompany.value.iosUrl)

    //  formData.append("iosUrl", this.frmCompany.value.strIosUrl)
     


    //  storeUrl:shopItem.strweb


    // for (let image of this.logoImg) {
    //   formData.append("logoImage", image, image.name)
    // }



    if (this.logoImg.length) {
      for (const image of this.logoImg) {
        formData.append('logoImage', image, image.name)
      }
    } else {
      formData.append("logoUrl", this.logoImageurl)
    }


    if (this.iconImg.length) {
      for (const image of this.iconImg) {
        formData.append('iconImage', image, image.name)
      }
    } else {
      formData.append("iconUrl", this.iconImageurl)
    }


    if (this.otherImage.length) {
      for (const image of this.otherImage) {
        formData.append('otherImage', image, image.name)
      }
    } else {
      formData.append("otherImageUrl", this.iconImageurl)
    }



    // for (let image of this.iconImg) {
    //   formData.append("iconImage", image, image.name)
    // }

    // for (let image of this.otherImage) {
    //   formData.append("otherImage", image, image.name)
    // }

    // formData.forEach((a, b) => console.log(`${a} :: ${b}`))

    // this.spinner.show()

    this.shopService.updateShop(formData).subscribe((res) => {
      if (res.success) {
        // this.spinner.hide()
        Swal.fire({
          title: "Updated!",
          text: "Shop updated successfully",
          icon: "success",
          confirmButtonText: "Ok",
        }).then(() => {
          this.submitted = false;
          this.frmCompany.reset()
          this.router.navigate(['/product/list-shop'])

        })
      } else {
        // this.spinner.hide();
        // Swal.fire({
        //   title: "Error",
        //   text: res.message,
        //   icon: "error",
        //   confirmButtonText: "Ok",
        // }).then(() => {
        //   this.submitted = false;
        // })
      }
    }, (err) => {
      console.log(err)
    })

  }


  onchangeIconImg(event) {
    for (let i of event.target.files) {
      this.iconImg.push(i)
    }
  }


  onchangeOtherImg(event) {
    for (let i of event.target.files) {
      this.otherImage.push(i)
    }
  }

  onchangelogoImg(event) {
    for (let i of event.target.files) {
      this.logoImg.push(i)
    }
  }



  getSingleShopItem() {
    const obj = {
      strLoginUserId: localStorage.getItem("userId"),
      strShopId: this.id
    }

    console.log("objctsss", obj)

    this.shopService.getAllShops(obj).subscribe((res) => {
      if (res && res.success) {
        let shopItem = res.data[0]

        console.log("shopppppppppp item", shopItem)
        this.frmCompany.patchValue({
          // fkRentalTypeId: shopItem.fkRentalTypeId,
          // fkRentalTypeId:shopItem.forEach((item) => item.arrItemTypes),

          shopName: shopItem.strShopName,
          arabicName: shopItem.strShopArabicName,
          strLocation: shopItem.strLocation,
          email: shopItem.strEmail,
          orderCount: shopItem.intMaxOrderCount,
          contact: shopItem.strContactNumber,
          strWhatsAppNumber: shopItem.strWhatsAppNumber,
          address: shopItem.strAddress,
          description: shopItem.strDescription,
          password: shopItem.strPassword,
          storeId: shopItem.strBMKStoreId,
          emirate: shopItem.strEmirate,
          shopStatus: shopItem.strShopStatus,
          // longitude: shopItem.strLongitude,
          // latitude: shopItem.strLatitude,

          longitude: shopItem.location.coordinates[0],
          latitude: shopItem.location.coordinates[1],
          privacyPolicy: shopItem.privacyPolicy,
          termsofuse: shopItem.termsOfUse,
          termsOfSale: shopItem.termsOfSale,
          drpDepartment: shopItem.fkDepartmentId,
          drpViewType: shopItem.strViewType,
          blnWebStatus:shopItem.strweb,
          blnIOsStatus:shopItem.strios,
          blnAndroidStatus:shopItem.strAndroid,
          isDomainConnected:shopItem.strDomain,
          // storeUrl:shopItem.webUrl
          webUrl:shopItem.storeUrl,
          domainUrl:shopItem.domainConnectedUrl,
          iosUrl: shopItem.strIosUrl,
          androidUrl:shopItem.strAndroidUrl
          // termsOfSale: shopItem.termsOfSale,
        })


        // iosUrl: shopItem.strIosUrl,
        // androidUrl:shopItem.strAndroidUrl



        let strZipCode = []
        shopItem.arrayZipCodes.forEach((a) => {
          console.log(a, "aaaaaaa")
          let objUpdateZipCode = {
            strZipCode: a.strZipCode
          }
          strZipCode.push(objUpdateZipCode);

        })

        this.setZipcode(strZipCode)
        let conditon = []
        shopItem.strReturnTermsAndCondition
          .forEach((a) => {
            let objUpdateConditios = {
              conditon: a.conditon
            }
            conditon.push(objUpdateConditios)
          })

        this.setArrConditions(conditon)
        let arrSocialMediaLinks = []
        shopItem.arrSocialMediaLinks.forEach((a) => {
          let linkDet = {
            type: a.type,
            link: a.link,
          }
          arrSocialMediaLinks.push(linkDet)
        })
        this.setArrLinks(arrSocialMediaLinks)
        //  // this.gridImage = this.arrProperty[0].strGridImage;
        this.logoImageurl = shopItem.logoUrl;
        this.iconImageurl = shopItem.iconUrl;
        this.otherImageurl = shopItem.otherImageUrl;
        //  this.currentLisitingImg = shopItem.listingImageUrl

        // this.getAllShopes()

      }
    })



  }

  getDepartmentFn() {
    const obj = {
      strDeptId: '',
      strLoginUserId: localStorage.getItem('userId'),
    }
    this.hypermarketServiceObj.getListDepartmentService(obj).subscribe((res) => {
      this.arrayOfObjDeptList = res.data;
    })
  }

  getDefaultDepartmentFn() {
    const obj = {
      fkDefaultDepartmentId: '',
      strLoginUserId: localStorage.getItem('userId'),
    }
    this.hypermarketServiceObj.getDefaultDepartmentService(obj).subscribe((res) => {
      this.arrayOfObjDeptList = res.data;
    })
  }



  getViewTypeFn() {
    this.hypermarketServiceObj.getViewType().subscribe((res) => {
      this.arrViewType = res.data;
    })
  }


  clearForm() {
    this.submitted = false;
    this.frmCompany.reset()
  }

  // toggleUrlInput(type,value){
    toggleUrlInput(type: string, isChecked: boolean)  {
      if (type === 'ios') {
        this.isIOS = !isChecked;
        if (isChecked) {
          this.frmCompany.get('iosUrl').enable();
          console.log('Enabled iosUrl input');
        } else {
          this.frmCompany.get('iosUrl').disable();
        }
      } else if (type === 'android') {
        this.isAndroid = !isChecked;
        if (isChecked) {
          this.frmCompany.get('androidUrl').enable();
        } else {
          this.frmCompany.get('androidUrl').disable();
        }
      }
    }
 

  }
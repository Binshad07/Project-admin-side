import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cancel-reasons',
  templateUrl: './cancel-reasons.component.html',
  styleUrls: ['./cancel-reasons.component.scss']
})
export class CancelReasonsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomledgerComponent } from './customledger.component';

describe('CustomledgerComponent', () => {
  let component: CustomledgerComponent;
  let fixture: ComponentFixture<CustomledgerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomledgerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomledgerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

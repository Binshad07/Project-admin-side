
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from "@angular/forms";
import { PagerService } from "src/app/shared/services/pager.service";
import { DatePipe } from "@angular/common";
import { CompanyServiceService } from "src/app/shared/services/company/company-service.service";
// import { modCartDetails } from "src/app/shared/Classes/report.model";





@Component({
  selector: 'app-custom-ledger',
  templateUrl: './customledger.component.html',
  styleUrls: ['./customledger.component.scss']
})
export class CustomledgerComponent implements OnInit {
  openingCr: number = 0; // Initialize openingCr
  closingDr: number = 0; // Initialize openingDr
  credit:number=0
  debit:number=0;
  arraLength:any
  currentDate = new Date();
  frmItemSales: FormGroup;
  pager: any = {};
  intTotalCount = 0;
  intPageLimit = 10;
  pageLimit: any[];
  strShopId = "";
  arrStores = [];
  intSkipCount = 0;
  datePipe = new DatePipe("en-US");
  arrItemSales: [] = [];
  arrpricedetails:any;
  fromDate;
  toDate;
  blnLoader = false;
  blnDownloadLoader = false;
  userType: string;
  // filterDate: Date | null = null;
  closeAmount:number = 0;
  closingCr: number;
  closingdr: number;
  // openingCr:number;
  // arrCartDetails: modCartDetails[] = [];




  constructor(
    private pageServiceObj: PagerService,
    // private reportServiceObj: ReportsService,
    private companyService: CompanyServiceService,
    private formBuilder: FormBuilder

  ) {}

  ngOnInit() {

    this.frmItemSales = this.formBuilder.group({
      txtFromDate: "",
      txtToDate: "",
      cmbShopName: "",
      drpPageLimit: "10",
    });
    this.pageLimit = this.pageServiceObj.showPagelist;
    this.getShopListingFn();
    this.Getcustomledger();

  }

  _clearForm(form: FormGroup) {
    form.reset({
      txtFromDate: "",
      txtToDate: "",
      // txtOrderId: "",
      cmbShopName: "",
      drpPageLimit: "10",
    });
    // this.intTotalCount = 0;
    // this.intSkipCount = 0;
    // this.intPageLimit = 10;

  }


  _getPageLimit(value$) {
    this.intPageLimit = parseInt(this.frmItemSales.value.drpPageLimit);
    this.setPage(1);
  }

  setPage(page) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    this.pager = this.pageServiceObj.getPager(
      this.intTotalCount,
      page,
      this.intPageLimit
    );

  }


  _onSearch() {
    this.pager = {};
    this.intTotalCount = 0;
    this.Getcustomledger();
  }
  _getShopId(id$) {
    this.strShopId = id$;
  }

  getShopListingFn() {
    const obj = {
      loginUserId: localStorage.getItem("userId"),
    }
    if (localStorage.getItem('fkShopId')) {
      // Object.assign(obj,{strShopId: localStorage.getItem('fkShopId')})
      Object.assign(obj, { pkShopId: localStorage.getItem("fkShopId") });

      // obj.fkShopId=localStorage.getItem('fkShopId')
    }
    this.companyService.fngetallCompany(obj).subscribe((res) => {
      this.arrStores = res.data;
      this.strShopId = res.data[0].pkShopId;
    });
  }





  Getcustomledger() {
    let skipCount = this.intSkipCount;
    this.blnLoader = false;
    if (this.pager.intSkipCount) {
      skipCount = this.pager.intSkipCount;
    }

    if (
      this.frmItemSales.value.txtFromDate === "txtFromDate" &&
      this.frmItemSales.value.txtToDate === "txtToDate"
    ) {
      console.log("From Date ::::", this.frmItemSales.value.txtFromDate);
      this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
      this.toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    }
    if (
      this.frmItemSales.value.txtFromDate &&
      this.frmItemSales.value.txtToDate === "txtToDate"
    ) {
      console.log("To Date ::::", this.frmItemSales.value.txtToDate);
      this.fromDate = `${this.frmItemSales.value.txtFromDate.year}-${this.frmItemSales.value.txtFromDate.month}-${this.frmItemSales.value.txtFromDate.day}`;
      this.toDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
    }
    if (
      this.frmItemSales.value.txtToDate &&
      this.frmItemSales.value.txtFromDate === "txtFromDate"
    ) {
      console.log("To Date ::::", this.frmItemSales.value.txtToDate);
      this.fromDate = this.datePipe.transform(this.currentDate, "yyyy-M-dd");
      this.toDate = `${this.frmItemSales.value.txtToDate.year}-${this.frmItemSales.value.txtToDate.month}-${this.frmItemSales.value.txtToDate.day}`;
    }

    if (
      this.frmItemSales.value.txtFromDate &&
      this.frmItemSales.value.txtToDate
    ) {
      this.fromDate = `${this.frmItemSales.value.txtFromDate.year}-${this.frmItemSales.value.txtFromDate.month}-${this.frmItemSales.value.txtFromDate.day}`;
      this.toDate = `${this.frmItemSales.value.txtToDate.year}-${this.frmItemSales.value.txtToDate.month}-${this.frmItemSales.value.txtToDate.day}`;
    }

    console.log("form date",this.fromDate)
    console.log("To date",this.toDate)

    const obj = {
      pkUserId: localStorage.getItem("userId"),
      strSkipCount: skipCount,
      strPageLimit: this.intPageLimit,
      fkShopId: this.frmItemSales.value.cmbShopName,
      // fromDate:this. frmItemSales.value.txtFromDate, //fromDate,
      // toDate: this.frmItemSales.value.txtToDate, //toDate,
      fromDate: this.fromDate ? this.fromDate : '', // fromTime
      toDate: this.toDate ? this.toDate : '',
    }

    console.log(obj,"obj")

    this.companyService.Getcustomledger(obj).subscribe((res) => {
      console.log(res,"res::::::::::::")

      if (res && res.success) {
        this.blnLoader = true;
        this.arrpricedetails = res
        this.arrItemSales = res.data;
        this.arraLength=  this.arrItemSales .length

        let debit=0 ;
        this.arrItemSales.filter((a :any)=> {
         this.debit = parseFloat( this.debit+a.dr)
        })

        let credit=0 ;
        this.arrItemSales.filter((crvalue:any)=> {
          this.credit = parseFloat(this.credit+crvalue.cr) 
        })
        

        this.closingCr = Math.abs(this.credit - this.debit); 

        console.log("CLOSIGN CR",this.closingCr)
        // this.closingdr =  this.debit -   this.credit

        
      

     
        // this.drValue =  this.arrItemSales.dr
        this.intTotalCount = res.count;
        this.pager = this.pageServiceObj.getPager(
          this.intTotalCount,
          this.pager.currentPage,
          this.intPageLimit
        );
      } else {
        this.arrItemSales = []

      }
    })
  }


  }



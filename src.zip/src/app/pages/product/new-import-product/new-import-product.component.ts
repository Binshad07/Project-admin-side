import { Component, OnInit } from "@angular/core";
import * as XLSX from "ts-xlsx";
import { ProductService } from "src/app/shared/services/product.service";

@Component({
  selector: "app-new-import-product",
  templateUrl: "./new-import-product.component.html",
  styleUrls: ["./new-import-product.component.scss"],
})
export class NewImportProductComponent implements OnInit {
  constructor(private srvProduct: ProductService) {}

  blnImportProduct = true;
  arrayProductBuffer: any;
  fileProduct: File;
  arrayAllData = new Array();
  arrayErrorData = new Array();
  arraySuccessData = new Array();
  arrayDuplicateData = new Array();
  ngOnInit() {}

  /*
    TODO @Function: THIS FUNCATION USE GET DATA FROM .xlsx file
    */

  convertFileXLSXFormate(ObjEvent: any) {
    this.arrayAllData = [];
    try {
      this.fileProduct = ObjEvent.target.files[0];
      let fileReader = new FileReader();
      fileReader.onload = (e) => {
        this.arrayProductBuffer = fileReader.result;
        var arrayOfData = new Uint8Array(this.arrayProductBuffer);
        var arr = new Array();

        for (var i = 0; i != arrayOfData.length; ++i)
          arr[i] = String.fromCharCode(arrayOfData[i]);
        var bstr = arr.join("");
        var workbook = XLSX.read(bstr, { type: "binary" });
        var str_first_sheet_name = workbook.SheetNames[0];
        var worksheet = workbook.Sheets[str_first_sheet_name];
        this.arrayAllData = XLSX.utils.sheet_to_json(worksheet, {
          raw: true,
        });
      };
      this.blnImportProduct = false;
      fileReader.readAsArrayBuffer(this.fileProduct);
      ObjEvent.srcElement.value = null;
    } catch (err) {}
  }
  /*
    TODO @Function: THIS FUNCATION USE Clear Data
    */

  onClickClearButtonData(event) {
    event.srcElement.value = null;
    this.blnImportProduct = true;
    this.arrayAllData = [];
    this.arrayErrorData = [];
    this.arraySuccessData = [];
    this.arrayDuplicateData = [];
  }
  /*
    TODO @Function: THIS FUNCATION USE EDIT PRICE LIST TO DATABASE
    */

  UpdateProductData() {
    try {
      this.blnImportProduct = true;
      let intuserId = localStorage.getItem("userId");
      if (this.arrayAllData.length && intuserId) {
        for(let i = 0; i< this.arrayAllData.length; i++) {
          if(!this.arrayAllData[i].MaxProductQuantity
            || !this.arrayAllData[i].MinimumQuantity) {
            this.arrayAllData[i].MinimumQuantity = 1;
            this.arrayAllData[i].MaxProductQuantity = 30
          }
        }
        let objData = {
          intuserId: intuserId,
          arrayAllData: this.arrayAllData
        };
        this.srvProduct.ImportProductList(objData).subscribe((res) => {
          if (res.success === true) {
            this.arrayErrorData = res.data.arrayError;
            this.arraySuccessData = res.data.arraySuccessData;
            this.arrayDuplicateData = res.data.arrayDuplicateData;
            alert(res.message);
          } else {
            alert("update faild :" + res.message);
          }
        });
      } else {
        if (!intuserId) {
          alert("Invalied User");
        } else {
          alert("Data not Found");
        }
      }
    } catch (err) {}
  }
}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewImportProductComponent } from './new-import-product.component';

describe('NewImportProductComponent', () => {
  let component: NewImportProductComponent;
  let fixture: ComponentFixture<NewImportProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewImportProductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewImportProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
